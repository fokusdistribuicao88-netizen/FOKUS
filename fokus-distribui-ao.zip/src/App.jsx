import React, { Suspense } from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import { Toaster } from "@/components/ui/toaster"
import { QueryClientProvider } from '@tanstack/react-query'
import { queryClientInstance } from '@/lib/query-client'
import NavigationTracker from '@/lib/NavigationTracker'
import { pagesConfig } from './pages.config'
import { BrowserRouter as Router, Route, Routes, Navigate, useLocation } from 'react-router-dom';
import PageNotFound from './lib/PageNotFound';
import { AuthProvider, useAuth } from '@/lib/AuthContext';
import UserNotRegisteredError from '@/components/UserNotRegisteredError';
import ProtectedRoute from '@/components/ProtectedRoute';
import AdminRoute from '@/components/AdminRoute';
import MobileTabBar from '@/components/MobileTabBar';
import FloatingNav from '@/components/FloatingNav';
// Retry wrapper for React.lazy — recovers from transient Vite HMR cache misses
const retryImport = (importFn, retries = 3) =>
  importFn().catch((error) => {
    if (retries <= 0) throw error;
    return new Promise((resolve) => setTimeout(resolve, 1500)).then(() =>
      retryImport(importFn, retries - 1)
    );
  });
const lazyRetry = (importFn) => React.lazy(() => retryImport(importFn));

const Login = lazyRetry(() => import('@/pages/Login'));
const Register = lazyRetry(() => import('@/pages/Register'));
const ForgotPassword = lazyRetry(() => import('@/pages/ForgotPassword'));
const ResetPassword = lazyRetry(() => import('@/pages/ResetPassword'));
const PriceManagement = lazyRetry(() => import('@/pages/PriceManagement'));
const PriceTables = lazyRetry(() => import('@/pages/PriceTables'));
const Dashboard = lazyRetry(() => import('@/pages/Dashboard'));
const MyAccount = lazyRetry(() => import('@/pages/MyAccount'));
const Promotions = lazyRetry(() => import('@/pages/Promotions'));
const Users = lazyRetry(() => import('@/pages/Users'));
const Clients = lazyRetry(() => import('@/pages/Clients'));
const Inventory = lazyRetry(() => import('@/pages/Inventory'));
const Financial = lazyRetry(() => import('@/pages/Financial'));
const Logistics = lazyRetry(() => import('@/pages/Logistics'));
const POS = lazyRetry(() => import('@/pages/POS'));
const PdfTemplateManagement = lazyRetry(() => import('@/pages/PdfTemplateManagement'));
const Reports = lazyRetry(() => import('@/pages/Reports'));
const AdminProfile = lazyRetry(() => import('@/pages/AdminProfile'));
const Employees = lazyRetry(() => import('@/pages/Employees'));
const Expenses = lazyRetry(() => import('@/pages/Expenses'));
const CustomerAccounts = lazyRetry(() => import('@/pages/CustomerAccounts'));
const Notifications = lazyRetry(() => import('@/pages/Notifications'));
const Quotes = lazyRetry(() => import('@/pages/Quotes'));

const { Pages, Layout, mainPage } = pagesConfig;
const mainPageKey = mainPage ?? Object.keys(Pages)[0];
const MainPage = mainPageKey ? Pages[mainPageKey] : <></>;

const LayoutWrapper = ({ children, currentPageName }) => Layout ?
  <Layout currentPageName={currentPageName}>{children}</Layout>
  : <>{children}</>;

const AuthenticatedApp = () => {
  const { isLoadingAuth, isLoadingPublicSettings, authError, navigateToLogin } = useAuth();
  const location = useLocation();

  // Show loading spinner while checking app public settings or auth
  if (isLoadingPublicSettings || isLoadingAuth) {
    return (
      <div className="fixed inset-0 flex items-center justify-center">
        <div className="w-8 h-8 border-4 border-slate-200 border-t-slate-800 rounded-full animate-spin"></div>
      </div>
    );
  }

  // Handle authentication errors
  if (authError?.type === 'user_not_registered') {
    return <UserNotRegisteredError />;
  }

  // Pages that require authentication
  const protectedPageKeys = ['AdminProducts', 'Orders'];

  // Render the main app
  return (
    <Suspense fallback={
      <div className="fixed inset-0 flex items-center justify-center">
        <div className="w-8 h-8 border-4 border-slate-200 border-t-slate-800 rounded-full animate-spin"></div>
      </div>
    }>
      <AnimatePresence mode="wait">
        <motion.div
          key={location.pathname}
          initial={{ opacity: 0, x: 12 }}
          animate={{ opacity: 1, x: 0 }}
          exit={{ opacity: 0, x: -12 }}
          transition={{ duration: 0.18, ease: 'easeOut' }}
          transformTemplate={(values) => {
            const x = values?.x;
            return !x ? 'none' : `translateX(${x}px)`;
          }}
        >
        <Routes location={location}>
        {/* Auth routes */}
        <Route path="/login" element={<Login />} />
        <Route path="/register" element={<Register />} />
        <Route path="/forgot-password" element={<ForgotPassword />} />
        <Route path="/reset-password" element={<ResetPassword />} />

        {/* Public routes */}
        <Route path="/" element={
          <LayoutWrapper currentPageName={mainPageKey}>
            <MainPage />
          </LayoutWrapper>
        } />
        <Route path="/Catalog" element={<Navigate to="/" replace />} />
        {Object.entries(Pages)
          .filter(([path]) => !protectedPageKeys.includes(path) && path !== 'Catalog')
          .map(([path, Page]) => (
            <Route
              key={path}
              path={`/${path}`}
              element={
                <LayoutWrapper currentPageName={path}>
                  <Page />
                </LayoutWrapper>
              }
            />
          ))}

        {/* Customer area — isolated from admin */}
        <Route element={<ProtectedRoute unauthenticatedElement={<Navigate to="/login" replace />} />}>
          <Route path="/MinhaConta" element={<MyAccount />} />
        </Route>

        {/* Admin area — restricted to admins/managers */}
        <Route element={<AdminRoute />}>
          {Object.entries(Pages)
            .filter(([path]) => protectedPageKeys.includes(path))
            .map(([path, Page]) => (
              <Route
                key={path}
                path={`/${path}`}
                element={
                  <LayoutWrapper currentPageName={path}>
                    <Page />
                  </LayoutWrapper>
                }
              />
            ))}
          <Route path="/PriceManagement" element={<PriceManagement />} />
          <Route path="/price-management" element={<PriceTables />} />
          <Route path="/Dashboard" element={<Dashboard />} />
          <Route path="/promotions" element={<Promotions />} />
          <Route path="/users" element={<Users />} />
          <Route path="/clients" element={<Clients />} />
          <Route path="/inventory" element={<Inventory />} />
          <Route path="/financial" element={<Financial />} />
          <Route path="/pos" element={<POS />} />
          <Route path="/pdf-template-management" element={<PdfTemplateManagement />} />
          <Route path="/reports" element={<Reports />} />
          <Route path="/employees" element={<Employees />} />
          <Route path="/expenses" element={<Expenses />} />
          <Route path="/customer-accounts" element={<CustomerAccounts />} />
          <Route path="/notifications" element={<Notifications />} />
          <Route path="/quotes" element={<Quotes />} />
          <Route path="/admin-profile" element={<AdminProfile />} />
        </Route>

        {/* Logistics — restricted to admin/gerente/motorista/auxiliar (page enforces role) */}
        <Route element={<ProtectedRoute unauthenticatedElement={<Navigate to="/login" replace />} />}>
          <Route path="/logistics" element={<Logistics />} />
        </Route>

        <Route path="*" element={<PageNotFound />} />
        </Routes>
        </motion.div>
      </AnimatePresence>
    </Suspense>
  );
};


function App() {

  return (
    <AuthProvider>
      <QueryClientProvider client={queryClientInstance}>
        <Router>
          <NavigationTracker />
          <AuthenticatedApp />
          <MobileTabBar />
          <FloatingNav />
        </Router>
        <Toaster />
      </QueryClientProvider>
    </AuthProvider>
  )
}

export default App