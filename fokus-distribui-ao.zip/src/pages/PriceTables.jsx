import React, { useState, useMemo, useCallback } from 'react';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { useAuth } from '@/lib/AuthContext';
import { useToast } from '@/components/ui/use-toast';
import * as XLSX from 'xlsx';
import { jsPDF } from 'jspdf';
import { logActivity } from '@/lib/activityLog';
import {
  ArrowLeft, DollarSign, Plus, Upload, Loader2, FileSpreadsheet, FileText, Sparkles,
} from 'lucide-react';
import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { canAccessPriceTables } from '@/lib/priceTables';
import { SYSTEM_TABLES } from '@/lib/posPriceTables';
import PriceTablesOverview from '@/components/pricetables/PriceTablesOverview';
import PriceTablesList from '@/components/pricetables/PriceTablesList';
import PriceTableFormDialog from '@/components/pricetables/PriceTableFormDialog';
import PriceTableDetail, { DuplicateDialog } from '@/components/pricetables/PriceTableDetail';
import ApplyToCustomersDialog from '@/components/pricetables/ApplyToCustomersDialog';
import PriceTableImportDialog from '@/components/pricetables/PriceTableImportDialog';
import PriceRulesDialog from '@/components/pricetables/PriceRulesDialog';
import ExportImportMenu from '@/components/admin/ExportImportMenu';

export default function PriceTables() {
  const queryClient = useQueryClient();
  const { user } = useAuth();
  const { toast } = useToast();
  const canEdit = user?.role === 'admin' || user?.role === 'gerente';

  const [selectedTable, setSelectedTable] = useState(null);
  const [formOpen, setFormOpen] = useState(false);
  const [editingTable, setEditingTable] = useState(null);
  const [duplicateFor, setDuplicateFor] = useState(null);
  const [applyFor, setApplyFor] = useState(null);
  const [importFor, setImportFor] = useState(null);
  const [rulesOpen, setRulesOpen] = useState(false);
  const [saving, setSaving] = useState(false);

  const { data: tables = [], isLoading } = useQuery({
    queryKey: ['price-tables'],
    queryFn: () => base44.entities.PriceTable.list('-updated_date'),
    staleTime: 30 * 1000,
  });
  const { data: customers = [] } = useQuery({
    queryKey: ['customers'],
    queryFn: () => base44.entities.Customer.list(),
    staleTime: 60 * 1000,
  });

  if (user && !canAccessPriceTables(user)) {
    return (
      <div className="min-h-screen flex items-center justify-center p-6 text-center">
        <div>
          <h1 className="text-xl font-bold text-foreground">Acesso restrito</h1>
          <p className="text-muted-foreground mt-2">Você não tem permissão para acessar a gestão de tabelas de preços.</p>
          <Link to="/Dashboard"><Button variant="outline" className="mt-4">Voltar ao Dashboard</Button></Link>
        </div>
      </div>
    );
  }

  const handleCreate = () => { setEditingTable(null); setFormOpen(true); };
  const handleEdit = (t) => { setEditingTable(t); setFormOpen(true); };

  const handleSubmit = async (data) => {
    setSaving(true);
    try {
      if (editingTable?.id) {
        const upd = { ...data, last_updated_by: user?.full_name || user?.email || '' };
        if (data.is_default) await clearOtherDefaults();
        await base44.entities.PriceTable.update(editingTable.id, upd);
        await logActivity({ action: 'price_table_update', description: `Tabela ${data.name} atualizada`, user, entityType: 'PriceTable', entityId: editingTable.id });
        toast({ title: 'Tabela atualizada' });
      } else {
        const created = await base44.entities.PriceTable.create({
          ...data,
          products_count: 0,
          customers_count: 0,
          last_updated_by: user?.full_name || user?.email || '',
        });
        if (data.is_default) await clearOtherDefaults(created.id);
        await logActivity({ action: 'price_table_create', description: `Tabela ${data.name} criada`, user, entityType: 'PriceTable', entityId: created.id });
        toast({ title: 'Tabela criada' });
      }
      queryClient.invalidateQueries({ queryKey: ['price-tables'] });
      setFormOpen(false);
      setEditingTable(null);
    } catch (e) {
      toast({ title: 'Erro ao salvar', description: e.message, variant: 'destructive' });
    } finally {
      setSaving(false);
    }
  };

  const clearOtherDefaults = async (exceptId) => {
    const defaults = tables.filter((t) => t.is_default && t.id !== exceptId);
    await Promise.all(defaults.map((t) => base44.entities.PriceTable.update(t.id, { is_default: false })));
  };

  const handleToggleStatus = async (t) => {
    try {
      const next = t.status === 'active' ? 'inactive' : 'active';
      await base44.entities.PriceTable.update(t.id, { status: next, last_updated_by: user?.full_name || user?.email || '' });
      await logActivity({ action: 'price_table_status', description: `Tabela ${t.name} ${next === 'active' ? 'ativada' : 'desativada'}`, user, entityType: 'PriceTable', entityId: t.id });
      queryClient.invalidateQueries({ queryKey: ['price-tables'] });
      toast({ title: next === 'active' ? 'Tabela ativada' : 'Tabela desativada' });
    } catch (e) {
      toast({ title: 'Erro', description: e.message, variant: 'destructive' });
    }
  };

  const handleSetDefault = async (t) => {
    try {
      await clearOtherDefaults(t.id);
      await base44.entities.PriceTable.update(t.id, { is_default: true, last_updated_by: user?.full_name || user?.email || '' });
      await logActivity({ action: 'price_table_set_default', description: `Tabela ${t.name} definida como padrão`, user, entityType: 'PriceTable', entityId: t.id });
      queryClient.invalidateQueries({ queryKey: ['price-tables'] });
      toast({ title: 'Tabela padrão definida' });
    } catch (e) {
      toast({ title: 'Erro', description: e.message, variant: 'destructive' });
    }
  };

  const handleDelete = async (t) => {
    if (SYSTEM_TABLES.some((s) => s.code === t.code)) {
      toast({ title: 'Tabela do sistema', description: 'As tabelas do sistema não podem ser excluídas.', variant: 'destructive' });
      return;
    }
    if (!confirm(`Excluir a tabela "${t.name}"? Os preços personalizados serão removidos. Clientes vinculados ficarão sem tabela.`)) return;
    try {
      await base44.entities.PriceTableItem.deleteMany({ price_table_id: t.id });
      const linked = customers.filter((c) => c.price_table_id === t.id);
      await Promise.all(linked.map((c) => base44.entities.Customer.update(c.id, { price_table_id: '', price_table_name: '' })));
      await base44.entities.Order.updateMany({ price_table_id: t.id }, { $set: { price_table_id: '', price_table_name: '' } });
      await base44.entities.PriceTable.delete(t.id);
      await logActivity({ action: 'price_table_delete', description: `Tabela ${t.name} excluída e removida de clientes e pedidos`, user, entityType: 'PriceTable', entityId: t.id });
      queryClient.invalidateQueries({ queryKey: ['price-tables'] });
      queryClient.invalidateQueries({ queryKey: ['customers'] });
      queryClient.invalidateQueries({ queryKey: ['orders'] });
      queryClient.invalidateQueries({ queryKey: ['pos-orders'] });
      if (selectedTable?.id === t.id) setSelectedTable(null);
      toast({ title: 'Tabela excluída', description: 'Removida de clientes e pedidos vinculados' });
    } catch (e) {
      toast({ title: 'Erro ao excluir', description: e.message, variant: 'destructive' });
    }
  };

  const exportTable = async (t) => {
    try {
      const items = await base44.entities.PriceTableItem.filter({ price_table_id: t.id });
      const allProducts = await base44.entities.Product.list();
      const itemsByProduct = {};
      items.forEach((it) => { itemsByProduct[it.product_id] = it; });
      const rows = allProducts.map((p) => {
        const it = itemsByProduct[p.id];
        return {
          'Código': p.code || '',
          'Produto': p.name,
          'Categoria': p.category || '',
          'Marca': p.brand || '',
          'Custo': p.cost ?? '',
          'Preço padrão': p.price ?? '',
          'Preço na tabela': it?.custom_price ?? '',
          'Personalizado': it ? 'Sim' : 'Não',
        };
      });
      const ws = XLSX.utils.json_to_sheet(rows);
      const wb = XLSX.utils.book_new();
      XLSX.utils.book_append_sheet(wb, ws, t.name.slice(0, 28));
      XLSX.writeFile(wb, `tabela-${t.code || t.name}.xlsx`);
      await logActivity({ action: 'price_table_export', description: `Tabela ${t.name} exportada (Excel)`, user, entityType: 'PriceTable', entityId: t.id });
    } catch (e) {
      toast({ title: 'Erro ao exportar', description: e.message, variant: 'destructive' });
    }
  };

  const exportAllCSV = () => {
    const headers = ['Tabela', 'Código', 'Produto', 'Categoria', 'Marca', 'Custo', 'Preço Padrão', 'Preço na Tabela'];
    const rows = tables.map((t) => [t.name, t.code, '', '', '', '', '', '']);
    const csv = [headers, ...rows].map((r) => r.map((c) => `"${String(c).replace(/"/g, '""')}"`).join(',')).join('\n');
    const blob = new Blob(['\ufeff' + csv], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url; a.download = 'tabelas-preco.csv'; a.click();
    URL.revokeObjectURL(url);
  };

  const exportReportPDF = async () => {
    const doc = new jsPDF();
    doc.setFontSize(16);
    doc.text('Relatório de Tabelas de Preços', 14, 18);
    doc.setFontSize(10);
    doc.text(`Gerado em ${new Date().toLocaleString('pt-BR')} por ${user?.full_name || user?.email || '—'}`, 14, 26);
    let y = 36;
    doc.setFontSize(9);
    tables.forEach((t) => {
      if (y > 270) { doc.addPage(); y = 20; }
      doc.setFontSize(11);
      doc.text(`${t.name} (${t.code || '—'}) — ${t.status === 'active' ? 'Ativa' : 'Inativa'}${t.is_default ? ' — PADRÃO' : ''}`, 14, y);
      y += 6;
      doc.setFontSize(8);
      doc.text(`Produtos personalizados: ${Number(t.products_count) || 0} | Clientes vinculados: ${Number(t.customers_count) || 0} | Resp.: ${t.last_updated_by || '—'}`, 14, y);
      y += 5;
      doc.text(`Descrição: ${t.description || '—'}`, 14, y);
      y += 10;
    });
    doc.save('relatorio-tabelas-preco.pdf');
    await logActivity({ action: 'price_table_report', description: 'Relatório de tabelas de preços gerado (PDF)', user });
  };

  return (
    <div className="min-h-screen bg-background">
      <header className="sticky top-0 z-40 bg-card/95 backdrop-blur-md border-b border-border shadow-sm">
        <div className="max-w-[1600px] mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center gap-3 h-16">
            <div className="w-9 h-9 bg-gradient-to-br from-emerald-600 to-emerald-800 rounded-lg flex items-center justify-center">
              <DollarSign className="w-5 h-5 text-white" />
            </div>
            <div>
              <h1 className="text-base font-bold text-foreground leading-tight">Gestão de Tabelas de Preços</h1>
              <p className="text-xs text-muted-foreground">Crie, edite e aplique tabelas a clientes, pedidos e PDV</p>
            </div>
            <div className="ml-auto flex items-center gap-2 flex-wrap">
              <ExportImportMenu
                items={[
                  { label: 'Relatório PDF', icon: FileText, onClick: exportReportPDF, disabled: tables.length === 0 },
                  { label: 'Exportar CSV', icon: FileSpreadsheet, onClick: exportAllCSV, disabled: tables.length === 0 },
                ]}
              />
              {canEdit && (
                <Button size="sm" variant="outline" onClick={() => setRulesOpen(true)} className="gap-2 border-violet-300 text-violet-700 hover:bg-violet-50">
                  <Sparkles className="w-4 h-4" /> Regras do Catálogo
                </Button>
              )}
              {canEdit && (
                <Button size="sm" onClick={handleCreate} className="gap-2">
                  <Plus className="w-4 h-4" /> Nova tabela
                </Button>
              )}
            </div>
          </div>
        </div>
      </header>

      <main className="max-w-[1600px] mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-6">
        {!canEdit && (
          <div className="rounded-lg border border-amber-200 dark:border-amber-800 bg-amber-50 dark:bg-amber-950/30 px-4 py-2 text-sm text-amber-800 dark:text-amber-400">
            Você tem permissão somente leitura.
          </div>
        )}

        <PriceTablesOverview tables={tables} customers={customers} />

        {selectedTable ? (
          <PriceTableDetail
            table={tables.find((t) => t.id === selectedTable) || selectedTable}
            onBack={() => setSelectedTable(null)}
            canEdit={canEdit}
            onEdit={handleEdit}
            onDuplicate={(t) => setDuplicateFor(t)}
            onToggleStatus={handleToggleStatus}
            onDelete={handleDelete}
            onExport={exportTable}
            onSetDefault={handleSetDefault}
            onImport={(t) => setImportFor(t)}
          />
        ) : (
          <PriceTablesList
            tables={tables}
            loading={isLoading}
            canEdit={canEdit}
            onSelect={(t) => setSelectedTable(t)}
            onEdit={handleEdit}
            onDuplicate={(t) => setDuplicateFor(t)}
            onToggleStatus={handleToggleStatus}
            onDelete={handleDelete}
            onApplyToCustomers={(t) => setApplyFor(t)}
            onExport={exportTable}
            onSetDefault={handleSetDefault}
          />
        )}
      </main>

      <PriceTableFormDialog
        open={formOpen}
        onClose={() => { setFormOpen(false); setEditingTable(null); }}
        onSubmit={handleSubmit}
        initial={editingTable}
        saving={saving}
      />
      {duplicateFor && (
        <DuplicateDialog
          open={!!duplicateFor}
          table={duplicateFor}
          onClose={() => setDuplicateFor(null)}
          onDone={(created) => { queryClient.invalidateQueries({ queryKey: ['price-tables'] }); setSelectedTable(created); }}
        />
      )}
      {applyFor && (
        <ApplyToCustomersDialog
          open={!!applyFor}
          table={applyFor}
          onClose={() => setApplyFor(null)}
          onDone={() => queryClient.invalidateQueries({ queryKey: ['price-tables'] })}
        />
      )}
      {canEdit && importFor && (
        <PriceTableImportDialog
          open={!!importFor}
          table={importFor}
          onClose={() => setImportFor(null)}
          onDone={() => queryClient.invalidateQueries({ queryKey: ['price-tables'] })}
        />
      )}
      <PriceRulesDialog open={rulesOpen} onClose={() => setRulesOpen(false)} />
    </div>
  );
}