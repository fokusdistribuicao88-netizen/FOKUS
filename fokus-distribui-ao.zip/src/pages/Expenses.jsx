import React, { useState, useEffect } from 'react';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { useAuth } from '@/lib/AuthContext';
import { isStaffRole } from '@/lib/userRoles';
import { canExpense, hasExpenseAccess } from '@/lib/hrPermissions';
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs';
import { Receipt, Fuel, BarChart3, Tags } from 'lucide-react';
import ExpensesTab from '@/components/expenses/ExpensesTab';
import FuelTab from '@/components/expenses/FuelTab';
import ExpenseDashboardTab from '@/components/expenses/ExpenseDashboardTab';
import CategoriesTab from '@/components/expenses/CategoriesTab';
import { DEFAULT_EXPENSE_CATEGORIES } from '@/lib/expenseCategories';

export default function Expenses() {
  const { user } = useAuth();
  const qc = useQueryClient();
  const [tab, setTab] = useState('dashboard');

  const { data: perm } = useQuery({
    queryKey: ['perm', user?.id],
    queryFn: () => base44.entities.UserPermission.filter({ user_id: user?.id }).then((r) => r[0]),
    enabled: !!user,
  });

  const { data: expenses = [] } = useQuery({
    queryKey: ['expenses'],
    queryFn: () => base44.entities.Expense.list(),
  });
  const { data: categories = [], isSuccess: categoriesLoaded } = useQuery({
    queryKey: ['expense-categories'],
    queryFn: () => base44.entities.ExpenseCategory.list(),
  });
  const { data: fuelRecords = [] } = useQuery({
    queryKey: ['fuel-records'],
    queryFn: () => base44.entities.FuelRecord.list(),
  });
  const { data: employees = [] } = useQuery({
    queryKey: ['employees'],
    queryFn: () => base44.entities.Employee.list(),
  });

  // Seed default categories only after the query has confirmed none exist
  useEffect(() => {
    if (categoriesLoaded && categories.length === 0 && user) {
      base44.entities.ExpenseCategory.bulkCreate(
        DEFAULT_EXPENSE_CATEGORIES.map((c) => ({ ...c, status: 'active' }))
      ).then(() => qc.invalidateQueries(['expense-categories'])).catch(() => {});
    }
  }, [categoriesLoaded, categories.length, user, qc]);

  const reload = () => {
    qc.invalidateQueries(['expenses']);
    qc.invalidateQueries(['expense-categories']);
    qc.invalidateQueries(['fuel-records']);
  };

  const can = (action) => canExpense(user, perm, action);

  if (user && !hasExpenseAccess(user) && !isStaffRole(user.role)) {
    return (
      <div className="min-h-screen flex items-center justify-center p-6 text-center">
        <div>
          <h1 className="text-xl font-bold">Acesso restrito</h1>
          <p className="text-muted-foreground mt-2">Você não tem permissão para acessar o módulo de Despesas.</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <main className="p-4 sm:p-6 lg:p-8 space-y-4 max-w-7xl mx-auto">
          <div>
            <h1 className="text-2xl font-bold text-foreground">Despesas</h1>
            <p className="text-sm text-muted-foreground mt-1">Controle de gastos da empresa, combustível e indicadores.</p>
          </div>

          <Tabs value={tab} onValueChange={setTab}>
            <TabsList className="flex flex-wrap h-auto">
              <TabsTrigger value="dashboard" className="gap-1.5"><BarChart3 className="w-4 h-4" /> Painel</TabsTrigger>
              <TabsTrigger value="expenses" className="gap-1.5"><Receipt className="w-4 h-4" /> Despesas</TabsTrigger>
              <TabsTrigger value="fuel" className="gap-1.5"><Fuel className="w-4 h-4" /> Combustível</TabsTrigger>
              <TabsTrigger value="categories" className="gap-1.5"><Tags className="w-4 h-4" /> Categorias</TabsTrigger>
            </TabsList>

            <TabsContent value="dashboard" className="mt-4">
              <ExpenseDashboardTab expenses={expenses} categories={categories} />
            </TabsContent>
            <TabsContent value="expenses" className="mt-4">
              <ExpensesTab expenses={expenses} categories={categories} employees={employees} can={can} onReload={reload} />
            </TabsContent>
            <TabsContent value="fuel" className="mt-4">
              <FuelTab fuelRecords={fuelRecords} can={can} onReload={reload} />
            </TabsContent>
            <TabsContent value="categories" className="mt-4">
              <CategoriesTab categories={categories} can={can} onReload={reload} />
            </TabsContent>
          </Tabs>
        </main>
    </div>
  );
}