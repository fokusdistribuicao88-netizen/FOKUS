import React, { useState, useMemo } from 'react';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { useAuth } from '@/lib/AuthContext';
import { useToast } from '@/components/ui/use-toast';
import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { ShieldAlert, ArrowLeft, Truck } from 'lucide-react';

import LogisticsOverview from '@/components/logistics/LogisticsOverview';
import LogisticsDeliveryTable from '@/components/logistics/LogisticsDeliveryTable';
import DeliveryDetailDialog from '@/components/logistics/DeliveryDetailDialog';
import DeliveryActionDialog from '@/components/logistics/DeliveryActionDialog';
import ReassignDialog from '@/components/logistics/ReassignDialog';
import OnSitePaymentDialog from '@/components/logistics/OnSitePaymentDialog';
import DeliveryConfirmDialog from '@/components/logistics/DeliveryConfirmDialog';
import { confirmDelivery } from '@/lib/onSiteReceiptService';
import {
  canAccessLogistics, canReassign, canAssumeDelivery, isDriver,
  pushDeliveryHistory, userDisplayName, logActivity,
} from '@/lib/logistics';
import { LOGISTICS_STATUS } from '@/components/orders/orderStatus';

export default function Logistics() {
  const { user } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [detailOrder, setDetailOrder] = useState(null);
  const [actionOrder, setActionOrder] = useState(null);
  const [reassignOrder, setReassignOrder] = useState(null);
  const [receiptOrder, setReceiptOrder] = useState(null);
  const [confirmOrder, setConfirmOrder] = useState(null);

  const { data: orders = [], isLoading } = useQuery({
    queryKey: ['orders'],
    queryFn: () => base44.entities.Order.list('-created_date'),
  });

  const { data: users = [] } = useQuery({
    queryKey: ['users'],
    queryFn: () => base44.entities.User.list(),
    staleTime: 60000,
  });

  const deliveryOrders = useMemo(() =>
    orders.filter((o) => !['cancelled', 'refunded'].includes(o.status))
  , [orders]);

  if (user && !canAccessLogistics(user)) {
    return (
      <div className="min-h-screen flex items-center justify-center p-4">
        <div className="text-center">
          <ShieldAlert className="w-12 h-12 text-amber-500 mx-auto mb-3" />
          <h2 className="text-xl font-semibold mb-2">Acesso restrito</h2>
          <p className="text-muted-foreground mb-6">Este módulo é exclusivo para administradores, gerentes, motoristas e auxiliares de entrega.</p>
          <Link to="/Dashboard">
            <Button className="bg-blue-700 hover:bg-blue-800 gap-2"><ArrowLeft className="w-4 h-4" /> Voltar ao Dashboard</Button>
          </Link>
        </div>
      </div>
    );
  }

  const assumeDelivery = async (order) => {
    try {
      const userName = userDisplayName(user);
      const newStatus = 'in_route';
      const timeline = [...(order.timeline || []), { date: new Date().toISOString(), event: 'Entrega assumida pelo motorista', author: userName }];
      const deliveryHistory = pushDeliveryHistory(order, { status: newStatus, notes: 'Entrega assumida', driverName: userName, userName });
      await base44.entities.Order.update(order.id, {
        driver_name: userName,
        status: newStatus,
        delivery_status: 'in_transit',
        timeline,
        delivery_history: deliveryHistory,
      });
      toast({ title: 'Entrega assumida', description: `Pedido agora está em rota.` });
      logActivity({ action: 'logistics_assume', description: `Motorista ${userName} assumiu entrega do pedido ${order.id}`, user_email: user?.email, user_name: userName, entity_id: order.id, metadata: { status: newStatus } });
      queryClient.invalidateQueries({ queryKey: ['orders'] });
    } catch (e) {
      toast({ title: 'Erro ao assumir entrega', description: String(e.message || e), variant: 'destructive' });
    }
  };

  const updateDeliveryStatus = async (order, { status, notes, receiver_name, receiver_document, delivery_confirmed_at }) => {
    try {
      const userName = userDisplayName(user);
      const info = LOGISTICS_STATUS[status] || { label: status };
      const patch = {
        status,
        delivery_notes: notes || order.delivery_notes,
        delivery_history: pushDeliveryHistory(order, { status, notes, driverName: order.driver_name, helperName: order.helper_name, userName }),
        timeline: [...(order.timeline || []), { date: new Date().toISOString(), event: `Status atualizado: ${info.label}`, author: userName }],
      };
      if (delivery_confirmed_at) {
        patch.delivery_confirmed_at = delivery_confirmed_at;
        patch.delivery_status = 'delivered';
      }
      if (receiver_name) patch.receiver_name = receiver_name;
      if (receiver_document) patch.receiver_document = receiver_document;
      if (['customer_absent', 'rescheduled', 'refused', 'occurrence'].includes(status)) {
        patch.delivery_occurrence = info.label;
      }
      await base44.entities.Order.update(order.id, patch);
      toast({ title: 'Entrega atualizada', description: info.label });
      logActivity({ action: 'logistics_status_update', description: `Status do pedido ${order.id} atualizado para ${info.label}`, user_email: user?.email, user_name: userName, entity_id: order.id, metadata: { status, notes } });
      queryClient.invalidateQueries({ queryKey: ['orders'] });
    } catch (e) {
      toast({ title: 'Erro ao atualizar', description: String(e.message || e), variant: 'destructive' });
    }
  };

  const handleReceiptRegistered = (order) => {
    queryClient.invalidateQueries({ queryKey: ['orders'] });
  };

  const handleConfirmDelivery = async (receiver) => {
    if (!confirmOrder) return;
    try {
      await confirmDelivery({ order: confirmOrder, receiver, user });
      toast({ title: 'Entrega confirmada', description: 'Comprovante gerado e pedido finalizado.' });
      setConfirmOrder(null);
      setDetailOrder(null);
      queryClient.invalidateQueries({ queryKey: ['orders'] });
    } catch (e) {
      toast({ title: 'Erro ao confirmar entrega', description: String(e.message || e), variant: 'destructive' });
    }
  };

  const reassign = async (order, { driver_name, helper_name }) => {
    try {
      const userName = userDisplayName(user);
      const timeline = [...(order.timeline || []), { date: new Date().toISOString(), event: `Equipe reatribuída: ${driver_name || '—'} / ${helper_name || '—'}`, author: userName }];
      await base44.entities.Order.update(order.id, {
        driver_name: driver_name || null,
        helper_name: helper_name || null,
        timeline,
        delivery_history: pushDeliveryHistory(order, { status: order.status, notes: `Equipe reatribuída: ${driver_name || '—'} / ${helper_name || '—'}`, driverName: driver_name, helperName: helper_name, userName }),
      });
      toast({ title: 'Equipe reatribuída' });
      logActivity({ action: 'logistics_reassign', description: `Equipe reatribuída no pedido ${order.id}`, user_email: user?.email, user_name: userName, entity_id: order.id, metadata: { driver_name, helper_name } });
      queryClient.invalidateQueries({ queryKey: ['orders'] });
    } catch (e) {
      toast({ title: 'Erro ao reatribuir', description: String(e.message || e), variant: 'destructive' });
    }
  };

  return (
    <div className="min-h-screen bg-muted/30">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-4">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-orange-500 to-orange-700 flex items-center justify-center shadow-md flex-shrink-0">
            <Truck className="w-5 h-5 text-white" />
          </div>
          <div className="min-w-0">
            <h1 className="text-xl font-bold text-foreground">Logística de Entregas</h1>
            <p className="text-sm text-muted-foreground">Controle de conferência, distribuição e acompanhamento de entregas.</p>
          </div>
        </div>

        <div className="space-y-4">
          <LogisticsOverview orders={orders} users={users} />
          <LogisticsDeliveryTable
            orders={deliveryOrders}
            users={users}
            user={user}
            onAction={(order) => setActionOrder(order)}
            onAssume={assumeDelivery}
            onReassign={(order) => setReassignOrder(order)}
            onView={(order) => setDetailOrder(order)}
            onRegisterReceipt={(order) => setReceiptOrder(order)}
            onConfirmDelivery={(order) => setConfirmOrder(order)}
          />
        </div>
      </div>

      <DeliveryDetailDialog
        open={!!detailOrder}
        order={detailOrder}
        user={user}
        onClose={() => setDetailOrder(null)}
        onAction={(order) => { setDetailOrder(null); setActionOrder(order); }}
        onAssume={assumeDelivery}
        onReassign={(order) => { setDetailOrder(null); setReassignOrder(order); }}
        onRegisterReceipt={(order) => { setDetailOrder(null); setReceiptOrder(order); }}
        onConfirmDelivery={(order) => { setDetailOrder(null); setConfirmOrder(order); }}
      />
      <OnSitePaymentDialog
        open={!!receiptOrder}
        order={receiptOrder}
        onClose={() => setReceiptOrder(null)}
        onRegistered={handleReceiptRegistered}
      />
      <DeliveryActionDialog
        open={!!actionOrder}
        order={actionOrder}
        user={user}
        onClose={() => setActionOrder(null)}
        onSave={updateDeliveryStatus}
      />
      <ReassignDialog
        open={!!reassignOrder}
        order={reassignOrder}
        users={users}
        onClose={() => setReassignOrder(null)}
        onSave={reassign}
      />
      <DeliveryConfirmDialog
        open={!!confirmOrder}
        order={confirmOrder}
        user={user}
        onClose={() => setConfirmOrder(null)}
        onConfirmed={handleConfirmDelivery}
      />
    </div>
  );
}