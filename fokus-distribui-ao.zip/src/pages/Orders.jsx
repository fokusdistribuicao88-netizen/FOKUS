import React, { useState, useEffect, useMemo, useRef } from 'react';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { useAuth } from '@/lib/AuthContext';
import { useToast } from '@/components/ui/use-toast';

import OrdersHeader from '@/components/orders/OrdersHeader';
import OrdersFilters from '@/components/orders/OrdersFilters';
import OrdersTable from '@/components/orders/OrdersTable';
import OrderDetailDialog from '@/components/orders/OrderDetailDialog';
import OrderFormDialog from '@/components/orders/OrderFormDialog';
import OrdersDashboard from '@/components/orders/OrdersDashboard';
import OrdersSidePanel from '@/components/orders/OrdersSidePanel';
import OrderPrintDialog from '@/components/orders/OrderPrintDialog';
import OrderPaymentDialog from '@/components/orders/OrderPaymentDialog';
import { ORDER_STATUS, PAYMENT_METHODS } from '@/components/orders/orderStatus';
import OrdersAccessDenied from '@/components/orders/OrdersAccessDenied';
import { downloadCsv } from '@/lib/csvExport';
import { cancelOrderWithReversal } from '@/lib/orderCancelService';
import { hasStockBeenDepleted } from '@/lib/stockValidation';
import PullToRefresh from '@/components/PullToRefresh';
import CancelReasonDialog from '@/components/CancelReasonDialog';

const DEFAULT_FILTERS = {
  search: '', customer_name: '', cpf_cnpj: '', email: '', phone: '',
  product: '', category: '', dateStart: '', dateEnd: '', status: '',
  payment_method: '', payment_status: '', delivery_status: '',
  carrier: '', seller: '', city: '', state: '',
};

export default function Orders() {
  const { user } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [filters, setFilters] = useState(DEFAULT_FILTERS);
  const [sort, setSort] = useState({ key: 'created_date', dir: 'desc' });
  const [page, setPage] = useState(1);
  const [pageSize] = useState(15);
  const [detailOrder, setDetailOrder] = useState(null);
  const [formOpen, setFormOpen] = useState(false);
  const [editOrder, setEditOrder] = useState(null);
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [printOrder, setPrintOrder] = useState(null);
  const [finalizeOrder, setFinalizeOrder] = useState(null);
  const [cancelTarget, setCancelTarget] = useState(null);
  const fileInputRef = useRef(null);

  const { data: orders = [], isLoading } = useQuery({
    queryKey: ['orders'],
    queryFn: () => base44.entities.Order.list('-created_date'),
  });

  const { data: products = [] } = useQuery({
    queryKey: ['products'],
    queryFn: () => base44.entities.Product.list(),
  });

  const { data: customers = [] } = useQuery({
    queryKey: ['customers'],
    queryFn: () => base44.entities.Customer.list(),
  });

  const { data: settings } = useQuery({
    queryKey: ['settings'],
    queryFn: async () => {
      const list = await base44.entities.Settings.list();
      return list[0] || null;
    },
  });

  useEffect(() => {
    const unsubscribe = base44.entities.Order.subscribe(() => {
      queryClient.invalidateQueries({ queryKey: ['orders'] });
    });
    return () => unsubscribe();
  }, [queryClient]);

  const productMap = useMemo(() => {
    const map = {};
    products.forEach((p) => { map[p.id] = p; });
    return map;
  }, [products]);

  const filtered = useMemo(() => {
    const search = filters.search.toLowerCase().trim();
    // Por padrão (sem filtro de data), mostra apenas pedidos de hoje.
    // Para ver dias anteriores, usar o filtro de data.
    const noDateFilter = !filters.dateStart && !filters.dateEnd;
    const todayStr = new Date().toISOString().slice(0, 10);
    const dateStart = noDateFilter
      ? new Date(todayStr + 'T00:00:00')
      : (filters.dateStart ? new Date(filters.dateStart) : null);
    const dateEnd = noDateFilter
      ? new Date(todayStr + 'T23:59:59')
      : (filters.dateEnd ? new Date(filters.dateEnd + 'T23:59:59') : null);
    return orders.filter((o) => {
      if (search) {
        const itemNames = (o.items || []).map((i) => i.product_name).filter(Boolean).join(' ');
        const hay = [o.id, o.customer_name, o.customer_email, o.customer_phone, itemNames].filter(Boolean).join(' ').toLowerCase();
        if (!hay.includes(search)) return false;
      }
      if (filters.customer_name && !(o.customer_name || '').toLowerCase().includes(filters.customer_name.toLowerCase())) return false;
      if (filters.cpf_cnpj && !(o.cpf_cnpj || '').includes(filters.cpf_cnpj)) return false;
      if (filters.email && !(o.customer_email || '').toLowerCase().includes(filters.email.toLowerCase())) return false;
      if (filters.phone && !(o.customer_phone || '').includes(filters.phone)) return false;
      if (filters.product && !(o.items || []).some((i) => i.product_name === filters.product)) return false;
      if (filters.category) {
        const cats = (o.items || []).map((i) => productMap[i.product_id]?.category).filter(Boolean);
        if (!cats.includes(filters.category)) return false;
      }
      const d = new Date(o.created_date);
      if (dateStart && d < dateStart) return false;
      if (dateEnd && d > dateEnd) return false;
      if (filters.status && o.status !== filters.status) return false;
      if (filters.payment_method && o.payment_method !== filters.payment_method) return false;
      if (filters.payment_status && o.payment_status !== filters.payment_status) return false;
      if (filters.delivery_status && o.delivery_status !== filters.delivery_status) return false;
      if (filters.carrier && !(o.carrier || '').toLowerCase().includes(filters.carrier.toLowerCase())) return false;
      if (filters.seller && !(o.seller || '').toLowerCase().includes(filters.seller.toLowerCase())) return false;
      if (filters.city && !(o.city || '').toLowerCase().includes(filters.city.toLowerCase())) return false;
      if (filters.state && (o.state || '').toUpperCase() !== filters.state.toUpperCase()) return false;
      return true;
    });
  }, [orders, filters, productMap]);

  const sorted = useMemo(() => {
    const arr = [...filtered];
    arr.sort((a, b) => {
      let av = a[sort.key], bv = b[sort.key];
      if (sort.key === 'code') { av = a.id; bv = b.id; }
      if (sort.key === 'qty') { av = (a.items || []).reduce((s, i) => s + i.quantity, 0); bv = (b.items || []).reduce((s, i) => s + i.quantity, 0); }
      if (av == null) av = '';
      if (bv == null) bv = '';
      if (av < bv) return sort.dir === 'asc' ? -1 : 1;
      if (av > bv) return sort.dir === 'asc' ? 1 : -1;
      return 0;
    });
    return arr;
  }, [filtered, sort]);

  const paged = useMemo(() => sorted.slice((page - 1) * pageSize, page * pageSize), [sorted, page, pageSize]);

  useEffect(() => { setPage(1); }, [filters, sort]);

  const pushTimeline = (order, event) => [...(order.timeline || []), { date: new Date().toISOString(), event, author: user?.full_name || user?.email || 'Sistema' }];

  const handleNewOrder = () => { setEditOrder(null); setFormOpen(true); };
  const handleEdit = (order) => { setEditOrder(order); setFormOpen(true); };

  const handleSaveOrder = async (payload) => {
    try {
      const orderData = payload;
      if (editOrder) {
        await base44.entities.Order.update(editOrder.id, { ...orderData, timeline: pushTimeline(editOrder, 'Pedido editado') });
        toast({ title: 'Pedido atualizado' });
      } else {
        const hasDelivery = !!(orderData.customer_address && String(orderData.customer_address).trim());
        const newOrder = {
          ...orderData,
          status: hasDelivery ? 'separating' : 'pending',
          payment_status: 'pending',
          delivery_status: hasDelivery ? 'pending' : 'delivered',
          timeline: [
            { date: new Date().toISOString(), event: 'Pedido criado', author: user?.full_name || 'Sistema' },
            ...(hasDelivery ? [{ date: new Date().toISOString(), event: 'Pedido enviado à Logística — Em separação', author: user?.full_name || 'Sistema' }] : []),
          ],
        };
        await base44.entities.Order.create(newOrder);
        toast({ title: hasDelivery ? 'Pedido criado e enviado à Logística (Em separação)' : 'Pedido criado — use "Finalizar" para registrar o pagamento' });
      }
      queryClient.invalidateQueries({ queryKey: ['orders'] });
    } catch (e) {
      toast({ title: 'Erro ao salvar pedido', description: String(e.message || e), variant: 'destructive' });
    }
  };

  const handleUpdate = async (id, patch) => {
    try {
      await base44.entities.Order.update(id, patch);
      queryClient.invalidateQueries({ queryKey: ['orders'] });
      setDetailOrder((prev) => (prev && prev.id === id ? { ...prev, ...patch } : prev));
      toast({ title: 'Pedido atualizado' });
    } catch (e) {
      toast({ title: 'Erro ao atualizar', description: String(e.message || e), variant: 'destructive' });
    }
  };

  const handleBatchAction = async (type, ids, extra = {}) => {
    if (!ids.length) return;
    try {
      if (type === 'bulkStatus') {
        const label = ORDER_STATUS[extra.status]?.label || extra.status;
        await base44.entities.Order.bulkUpdate(
          ids.map((id) => {
            const o = orders.find((ord) => ord.id === id) || {};
            return { id, status: extra.status, timeline: pushTimeline(o, `Status alterado para ${label} (lote)`) };
          })
        );
        toast({ title: `${ids.length} pedido(s) atualizado(s)` });
      } else if (type === 'bulkDelete') {
        await Promise.all(ids.map((id) => base44.entities.Order.delete(id)));
        toast({ title: `${ids.length} pedido(s) excluído(s)` });
      } else if (type === 'bulkExport') {
        const sel = orders.filter((o) => ids.includes(o.id));
        const headers = ['Pedido', 'Data', 'Cliente', 'Telefone', 'Email', 'Total', 'Status', 'Pagamento'];
        const rows = sel.map((o) => [
          o.id, new Date(o.created_date).toLocaleString('pt-BR'), o.customer_name, o.customer_phone, o.customer_email || '',
          o.total, ORDER_STATUS[o.status]?.label || o.status, PAYMENT_METHODS[o.payment_method] || '',
        ]);
        downloadCsv(`pedidos-selecao-${new Date().toISOString().slice(0, 10)}.csv`, headers, rows);
        toast({ title: `${sel.length} pedido(s) exportado(s)` });
      }
      queryClient.invalidateQueries({ queryKey: ['orders'] });
    } catch (e) {
      toast({ title: 'Erro na operação em lote', description: String(e.message || e), variant: 'destructive' });
    }
  };

  const handleFinalized = (updatedOrder, opts = {}) => {
    queryClient.invalidateQueries({ queryKey: ['orders'] });
    queryClient.invalidateQueries({ queryKey: ['products'] });
    queryClient.invalidateQueries({ queryKey: ['financialEntries'] });
    queryClient.invalidateQueries({ queryKey: ['cashRegisters'] });
    queryClient.invalidateQueries({ queryKey: ['customers'] });
    queryClient.invalidateQueries({ queryKey: ['employee-purchases'] });
    setDetailOrder((prev) => (prev && prev.id === updatedOrder.id ? { ...prev, ...updatedOrder } : prev));
    if (opts.printOnly) {
      setPrintOrder(updatedOrder);
      return;
    }
    setFinalizeOrder(null);
    // Abre a impressão/PDF após finalizar (usa o Gerenciador de Modelos PDF)
    setPrintOrder(updatedOrder);
  };

  const handleAction = async (type, order) => {
    try {
      switch (type) {
        case 'view': setDetailOrder(order); break;
        case 'edit': handleEdit(order); break;
        case 'finalize': {
          if (order.status === 'completed' || order.status === 'invoiced') {
            toast({ title: 'Pedido já finalizado', variant: 'destructive' });
            break;
          }
          if (await hasStockBeenDepleted(order.id)) {
            toast({ title: 'Pedido já finalizado — estoque já baixado', variant: 'destructive' });
            break;
          }
          setFinalizeOrder(order);
          break;
        }
        case 'cancel': {
          setCancelTarget(order);
          break;
        }
        case 'duplicate': {
          const { id, created_date, updated_date, created_by_id, ...rest } = order;
          await base44.entities.Order.create({
            ...rest,
            status: 'pending',
            payment_status: 'pending',
            delivery_status: 'pending',
            financial_status: 'not_sent',
            financial_entry_ids: [],
            tracking_code: '',
            driver_name: '',
            helper_name: '',
            receiver_name: '',
            receiver_document: '',
            delivery_confirmed_at: '',
            delivery_occurrence: '',
            delivery_notes: '',
            proof_photo_url: '',
            delivery_signature_url: '',
            delivery_expected_date: '',
            delivery_history: [],
            documents: [],
            timeline: [{ date: new Date().toISOString(), event: 'Pedido duplicado', author: user?.full_name || 'Sistema' }],
          });
          toast({ title: 'Pedido duplicado' });
          queryClient.invalidateQueries({ queryKey: ['orders'] });
          break;
        }
        case 'print': setPrintOrder(order); break;
        case 'delete':
          await base44.entities.Order.delete(order.id);
          toast({ title: 'Pedido excluído' });
          queryClient.invalidateQueries({ queryKey: ['orders'] });
          break;
      }
    } catch (e) {
      toast({ title: 'Erro', description: String(e.message || e), variant: 'destructive' });
    }
  };

  const handleRefresh = async () => {
    setIsRefreshing(true);
    await queryClient.invalidateQueries({ queryKey: ['orders'] });
    setIsRefreshing(false);
  };

  const confirmCancel = async (reason) => {
    if (!cancelTarget) return;
    try {
      const result = await cancelOrderWithReversal({ order: cancelTarget, user, reason });
      toast({
        title: result.wasDepleted ? 'Pedido cancelado — estorno completo' : 'Pedido cancelado',
        description: [
          result.wasDepleted ? 'estoque restaurado' : '',
          result.financialCancelled ? 'financeiro cancelado' : '',
          result.cashReversed ? 'caixa revertido' : '',
        ].filter(Boolean).join(' · '),
      });
      queryClient.invalidateQueries({ queryKey: ['orders'] });
      queryClient.invalidateQueries({ queryKey: ['products'] });
      queryClient.invalidateQueries({ queryKey: ['financialEntries'] });
      queryClient.invalidateQueries({ queryKey: ['cashRegisters'] });
    } catch (e) {
      toast({ title: 'Erro ao cancelar', description: String(e.message || e), variant: 'destructive' });
    } finally {
      setCancelTarget(null);
    }
  };

  const handleExport = () => {
    const headers = ['Pedido', 'Data', 'Cliente', 'Telefone', 'Email', 'CPF/CNPJ', 'Cidade', 'Estado', 'Total', 'Status', 'Pagamento', 'Status Pagamento', 'Entrega', 'Transportadora', 'Rastreamento', 'Responsavel'];
    const rows = sorted.map((o) => [
      o.id, new Date(o.created_date).toLocaleString('pt-BR'), o.customer_name, o.customer_phone, o.customer_email || '',
      o.cpf_cnpj || '', o.city || '', o.state || '', o.total, ORDER_STATUS[o.status]?.label || o.status,
      PAYMENT_METHODS[o.payment_method] || '', o.payment_status || '', o.delivery_status || '',
      o.carrier || '', o.tracking_code || '', o.seller || '',
    ]);
    downloadCsv(`pedidos-${new Date().toISOString().slice(0, 10)}.csv`, headers, rows);
    toast({ title: 'Pedidos exportados' });
  };

  const parseCsv = (text) => {
    const lines = text.split(/\r?\n/).filter((l) => l.trim());
    if (!lines.length) return [];
    const split = (line) => {
      const out = []; let cur = ''; let q = false;
      for (let i = 0; i < line.length; i++) {
        const ch = line[i];
        if (ch === '"') { q = !q; }
        else if (ch === ',' && !q) { out.push(cur); cur = ''; }
        else { cur += ch; }
      }
      out.push(cur);
      return out;
    };
    const headers = split(lines[0]).map((h) => h.trim().toLowerCase());
    return lines.slice(1).map((line) => {
      const vals = split(line);
      const obj = {};
      headers.forEach((h, i) => { obj[h] = vals[i]; });
      return obj;
    });
  };

  const handleImportFile = async (e) => {
    const file = e.target.files?.[0];
    e.target.value = '';
    if (!file) return;
    try {
      const text = await file.text();
      const parsed = parseCsv(text);
      const records = parsed.map((r) => ({
        customer_name: r.cliente || r.customer_name || '',
        customer_phone: r.telefone || r.customer_phone || '',
        customer_email: r.email || '',
        items: [],
        total: Number(r.total || 0),
        status: 'pending',
        payment_status: 'pending',
        delivery_status: 'pending',
      })).filter((r) => r.customer_name && r.customer_phone);
      if (!records.length) { toast({ title: 'Nenhum pedido válido no arquivo', variant: 'destructive' }); return; }
      await base44.entities.Order.bulkCreate(records);
      toast({ title: `${records.length} pedido(s) importado(s)` });
      queryClient.invalidateQueries({ queryKey: ['orders'] });
    } catch (err) {
      toast({ title: 'Erro na importação', description: String(err.message || err), variant: 'destructive' });
    }
  };

  if (user && user.role !== 'admin' && user.role !== 'gerente') return <OrdersAccessDenied />;

  return (
    <div className="min-h-screen bg-muted/30">
      <PullToRefresh onRefresh={handleRefresh} />
      <input ref={fileInputRef} type="file" accept=".csv" className="hidden" onChange={handleImportFile} />
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-4">
        <OrdersHeader
          orders={orders}
          onNewOrder={handleNewOrder}
          onExport={handleExport}
          onImport={() => fileInputRef.current?.click()}
          onRefresh={handleRefresh}
          isRefreshing={isRefreshing}
        />

        <OrdersFilters
          filters={filters}
          setFilters={setFilters}
          products={products}
          onApply={() => setPage(1)}
          onClear={() => setFilters(DEFAULT_FILTERS)}
          resultsCount={sorted.length}
        />

        <OrdersTable
          orders={paged}
          loading={isLoading}
          productMap={productMap}
          settings={settings}
          onAction={handleAction}
          onBatchAction={handleBatchAction}
          user={user}
          sort={sort}
          setSort={setSort}
          page={page}
          setPage={setPage}
          pageSize={pageSize}
          total={sorted.length}
        />

        <OrdersSidePanel orders={orders} onSelect={setDetailOrder} />

        <OrdersDashboard orders={orders} customers={customers} />
      </div>

      <OrderDetailDialog
        order={detailOrder}
        productMap={productMap}
        onClose={() => setDetailOrder(null)}
        onUpdate={handleUpdate}
        onFinalize={(order) => setFinalizeOrder(order)}
      />

      <OrderFormDialog
        open={formOpen}
        order={editOrder}
        products={products}
        onClose={() => setFormOpen(false)}
        onSave={handleSaveOrder}
      />

      <OrderPrintDialog
        open={!!printOrder}
        order={printOrder}
        settings={settings}
        productMap={productMap}
        onClose={() => setPrintOrder(null)}
      />

      <OrderPaymentDialog
        order={finalizeOrder}
        onClose={() => setFinalizeOrder(null)}
        onFinalized={handleFinalized}
      />

      <CancelReasonDialog
        open={!!cancelTarget}
        onOpenChange={(v) => !v && setCancelTarget(null)}
        onConfirm={confirmCancel}
        title="Cancelar pedido"
        confirmLabel="Cancelar pedido"
      />
    </div>
  );
}