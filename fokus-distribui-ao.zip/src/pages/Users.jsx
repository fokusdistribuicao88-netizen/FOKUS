import React, { useState, useMemo } from 'react';
import { useQuery } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { useAuth } from '@/lib/AuthContext';
import { Users as UsersIcon, UserCheck, UserX, UserPlus, Truck } from 'lucide-react';
import { Tabs, TabsList, TabsTrigger } from '@/components/ui/tabs';
import UsersTab from '@/components/users/UsersTab';
import ActivityTab from '@/components/users/ActivityTab';

export default function Users() {
  const { user } = useAuth();
  const [tab, setTab] = useState('users');

  const { data: users = [] } = useQuery({ queryKey: ['users'], queryFn: () => base44.entities.User.list(), staleTime: 30000 });
  const { data: perms = [] } = useQuery({ queryKey: ['user-permissions'], queryFn: () => base44.entities.UserPermission.list(), staleTime: 30000 });

  const stats = useMemo(() => {
    const permMap = Object.fromEntries(perms.map((p) => [p.user_id, p]));
    const activeUsers = users.filter((u) => (permMap[u.id]?.status || 'active') === 'active').length;
    const inactiveUsers = users.length - activeUsers;
    const now = new Date();
    const newThisMonth = users.filter((u) => {
      if (!u.created_date) return false;
      const d = new Date(u.created_date);
      return d.getMonth() === now.getMonth() && d.getFullYear() === now.getFullYear();
    }).length;
    const motoristas = users.filter((u) => u.role === 'motorista').length;
    const auxiliares = users.filter((u) => u.role === 'auxiliar').length;
    return { totalUsers: users.length, activeUsers, inactiveUsers, newThisMonth, motoristas, auxiliares };
  }, [users, perms]);

  const cards = [
    { label: 'Total de usuários', value: stats.totalUsers, icon: UsersIcon, accent: 'text-blue-600' },
    { label: 'Usuários ativos', value: stats.activeUsers, icon: UserCheck, accent: 'text-green-600' },
    { label: 'Usuários inativos', value: stats.inactiveUsers, icon: UserX, accent: 'text-amber-600' },
    { label: 'Novos usuários (mês)', value: stats.newThisMonth, icon: UserPlus, accent: 'text-blue-600' },
    { label: 'Motoristas', value: stats.motoristas, icon: Truck, accent: 'text-orange-600' },
    { label: 'Auxiliares', value: stats.auxiliares, icon: UserCheck, accent: 'text-amber-600' },
  ];

  return (
    <div className="min-h-screen bg-background">
      <header className="sticky top-0 z-40 bg-card/95 backdrop-blur-md border-b border-border shadow-sm">
        <div className="max-w-[1600px] mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center gap-3 h-16">
            <div className="w-9 h-9 bg-gradient-to-br from-blue-600 to-indigo-800 rounded-lg flex items-center justify-center">
              <UsersIcon className="w-5 h-5 text-white" />
            </div>
            <div className="min-w-0">
              <h1 className="text-base font-bold text-foreground leading-tight truncate">Usuários & Clientes</h1>
              <p className="text-xs text-muted-foreground">Gestão de acesso, clientes e permissões</p>
            </div>
          </div>
        </div>
      </header>

      <main className="max-w-[1600px] mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-5">
        <div className="grid grid-cols-2 md:grid-cols-4 xl:grid-cols-8 gap-3">
          {cards.map((c) => {
            const Icon = c.icon;
            return (
              <div key={c.label} className="bg-card rounded-xl border border-border p-4 flex items-center gap-3">
                <div className={`w-10 h-10 rounded-lg bg-muted/60 flex items-center justify-center ${c.accent}`}><Icon className="w-5 h-5" /></div>
                <div className="min-w-0"><p className="text-xs text-muted-foreground truncate">{c.label}</p><p className="text-xl font-bold text-foreground">{c.value}</p></div>
              </div>
            );
          })}
        </div>

        <Tabs value={tab} onValueChange={setTab}>
          <TabsList>
            <TabsTrigger value="users">Usuários</TabsTrigger>
            <TabsTrigger value="activity">Histórico de Atividades</TabsTrigger>
          </TabsList>
          <div className="mt-4">
            {tab === 'users' && <UsersTab currentUser={user} />}
            {tab === 'activity' && <ActivityTab />}
          </div>
        </Tabs>
      </main>
    </div>
  );
}