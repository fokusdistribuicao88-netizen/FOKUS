import { useState, useEffect, useMemo } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { useAuth } from '@/lib/AuthContext';
import { round2 } from '@/lib/profitCalc';
import { Package, Plus, RefreshCw, Settings2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger, DropdownMenuLabel } from '@/components/ui/dropdown-menu';
import ExcelToolbar from '@/components/admin/ExcelToolbar';
import ProductFormDialog from '@/components/admin/ProductFormDialog';
import StatsBar from '@/components/admin/catalog/StatsBar';
import CatalogToolbar from '@/components/admin/catalog/CatalogToolbar';
import FilterPanel from '@/components/admin/catalog/FilterPanel';
import ProductListView from '@/components/admin/catalog/ProductListView';
import ProductGridView from '@/components/admin/catalog/ProductGridView';
import BatchActionBar from '@/components/admin/catalog/BatchActionBar';
import CatalogPagination from '@/components/admin/catalog/CatalogPagination';

const defaultCategories = ['Cervejas', 'Refrigerantes', 'Águas', 'Sucos', 'Energéticos', 'Destilados', 'Vinhos', 'Outros'];

export default function AdminProducts() {
  const queryClient = useQueryClient();
  const { user } = useAuth();
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [editingProduct, setEditingProduct] = useState(null);
  const [uploading, setUploading] = useState(false);
  const [costReason, setCostReason] = useState('');
  const canEditCost = user?.role === 'admin' || user?.role === 'gerente';

  const [formData, setFormData] = useState({
    name: '', description: '', price: '', price_promo: '', price_wholesale: '', price_cash: '', cost: '',
    image_url: '', category: 'Cervejas', brand: '', unit_type: 'unidade',
    units_per_pack: '', volume_ml: '', min_order: 1, in_stock: true, featured: false,
    stock_quantity: '', low_stock_threshold: 5
  });
  const [customCategories, setCustomCategories] = useState(() => {
    const saved = localStorage.getItem('customCategories');
    return saved ? JSON.parse(saved) : [];
  });
  const [newCategory, setNewCategory] = useState('');
  const categories = [...defaultCategories, ...customCategories];

  const addCategory = () => {
    if (newCategory.trim() && !categories.includes(newCategory.trim())) {
      const updated = [...customCategories, newCategory.trim()];
      setCustomCategories(updated);
      localStorage.setItem('customCategories', JSON.stringify(updated));
      setNewCategory('');
    }
  };

  const { data: products = [], isLoading } = useQuery({
    queryKey: ['products'],
    queryFn: () => base44.entities.Product.list()
  });

  // Helpers
  const hasStock = (p) => p.stock_quantity != null ? p.stock_quantity > 0 : p.in_stock !== false;
  const isLowStock = (p) => {
    if (p.stock_quantity == null) return false;
    const threshold = p.low_stock_threshold ?? 5;
    return p.stock_quantity > 0 && p.stock_quantity <= threshold;
  };

  // Filters (single-state, auto-applied)
  const defaultFilters = {
    search: '', category: 'all', brand: 'all', status: 'all',
    priceMin: '', priceMax: '',
    stock: 'all', promo: 'all',
    dateType: 'created', dateFrom: '', dateTo: ''
  };
  const [filters, setFilters] = useState(() => {
    const saved = localStorage.getItem('adminProductFilters');
    return saved ? { ...defaultFilters, ...JSON.parse(saved) } : defaultFilters;
  });
  const [debouncedSearch, setDebouncedSearch] = useState(filters.search);
  useEffect(() => {
    const timer = setTimeout(() => setDebouncedSearch(filters.search), 300);
    return () => clearTimeout(timer);
  }, [filters.search]);
  useEffect(() => {localStorage.setItem('adminProductFilters', JSON.stringify(filters));}, [filters]);

  const brands = useMemo(() => {
    const set = new Set();
    products.forEach((p) => {if (p.brand) set.add(p.brand);});
    return Array.from(set).sort();
  }, [products]);

  const filteredProducts = useMemo(() => {
    return products.filter((p) => {
      if (debouncedSearch) {
        const q = debouncedSearch.toLowerCase();
        if (!p.name?.toLowerCase().includes(q) && !p.brand?.toLowerCase().includes(q) &&
        !p.category?.toLowerCase().includes(q) && !p.description?.toLowerCase().includes(q))
        return false;
      }
      if (filters.status === 'active' && p.in_stock === false) return false;
      if (filters.status === 'inactive' && p.in_stock !== false) return false;
      if (filters.stock === 'in_stock' && !hasStock(p)) return false;
      if (filters.stock === 'out_of_stock' && hasStock(p)) return false;
      if (filters.stock === 'low' && !isLowStock(p)) return false;
      if (filters.stock === 'negative' && !(p.stock_quantity != null && p.stock_quantity < 0)) return false;
      if (filters.promo === 'on_promo' && !p.price_promo) return false;
      if (filters.promo === 'no_promo' && p.price_promo) return false;
      if (filters.category !== 'all' && p.category !== filters.category) return false;
      if (filters.brand !== 'all' && p.brand !== filters.brand) return false;
      const price = p.price || 0;
      if (filters.priceMin && price < parseFloat(filters.priceMin)) return false;
      if (filters.priceMax && price > parseFloat(filters.priceMax)) return false;
      const dateField = filters.dateType === 'updated' ? 'updated_date' : 'created_date';
      if (p[dateField]) {
        const pDate = new Date(p[dateField]);
        if (filters.dateFrom && pDate < new Date(filters.dateFrom)) return false;
        if (filters.dateTo && pDate > new Date(filters.dateTo + 'T23:59:59')) return false;
      }
      return true;
    });
  }, [products, debouncedSearch, filters]);

  // Sorting
  const [sortField, setSortField] = useState('name');
  const [sortDir, setSortDir] = useState('asc');
  const sortedProducts = useMemo(() => {
    const sorted = [...filteredProducts];
    sorted.sort((a, b) => {
      let aVal = a[sortField],bVal = b[sortField];
      if (['name', 'category', 'brand'].includes(sortField)) {
        aVal = (aVal || '').toLowerCase();
        bVal = (bVal || '').toLowerCase();
      }
      if (aVal == null && bVal == null) return 0;
      if (aVal == null) return 1;
      if (bVal == null) return -1;
      if (aVal < bVal) return sortDir === 'asc' ? -1 : 1;
      if (aVal > bVal) return sortDir === 'asc' ? 1 : -1;
      return 0;
    });
    return sorted;
  }, [filteredProducts, sortField, sortDir]);

  // View & Pagination
  const [viewMode, setViewMode] = useState(() => localStorage.getItem('adminViewMode') || 'list');
  const [density, setDensity] = useState(() => localStorage.getItem('adminDensity') || 'comfortable');
  const [pageSize, setPageSize] = useState(() => Number(localStorage.getItem('adminPageSize')) || 10);
  const [currentPage, setCurrentPage] = useState(1);
  const totalPages = Math.ceil(sortedProducts.length / pageSize);
  const paginatedProducts = sortedProducts.slice((currentPage - 1) * pageSize, currentPage * pageSize);
  useEffect(() => {setCurrentPage(1);}, [debouncedSearch, filters, sortField, sortDir, pageSize]);
  useEffect(() => {localStorage.setItem('adminViewMode', viewMode);}, [viewMode]);
  useEffect(() => {localStorage.setItem('adminPageSize', String(pageSize));}, [pageSize]);
  useEffect(() => {localStorage.setItem('adminDensity', density);}, [density]);

  // Selection
  const [selectedIds, setSelectedIds] = useState(new Set());
  const [showFilters, setShowFilters] = useState(true);
  const toggleSelect = (id) => {
    setSelectedIds((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);else next.add(id);
      return next;
    });
  };
  const toggleSelectAll = () => {
    setSelectedIds((prev) => {
      const allSelected = paginatedProducts.length > 0 && paginatedProducts.every((p) => prev.has(p.id));
      const next = new Set(prev);
      if (allSelected) paginatedProducts.forEach((p) => next.delete(p.id));else
      paginatedProducts.forEach((p) => next.add(p.id));
      return next;
    });
  };

  // Stats
  const stats = useMemo(() => ({
    total: products.length,
    active: products.filter((p) => p.in_stock !== false).length,
    inactive: products.filter((p) => p.in_stock === false).length,
    lowStock: products.filter((p) => isLowStock(p)).length
  }), [products]);

  // Mutations
  const createMutation = useMutation({
    mutationFn: (data) => base44.entities.Product.create(data),
    onSuccess: () => {queryClient.invalidateQueries({ queryKey: ['products'] });closeDialog();}
  });
  const updateMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.Product.update(id, data),
    onSuccess: () => {queryClient.invalidateQueries({ queryKey: ['products'] });closeDialog();}
  });
  const deleteMutation = useMutation({
    mutationFn: (id) => base44.entities.Product.delete(id),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ['products'] })
  });

  const handleExcelImport = async (toCreate, toUpdate) => {
    if (toCreate.length) await base44.entities.Product.bulkCreate(toCreate);
    if (toUpdate.length) await base44.entities.Product.bulkUpdate(toUpdate.map(({ id, ...data }) => ({ id, ...data })));
    queryClient.invalidateQueries({ queryKey: ['products'] });
  };

  const handleImageUpload = async (e) => {
    const file = e.target.files[0];
    if (!file) return;
    setUploading(true);
    const { file_url } = await base44.integrations.Core.UploadFile({ file });
    setFormData((prev) => ({ ...prev, image_url: file_url }));
    setUploading(false);
  };

  const openDialog = (product = null, isDuplicate = false) => {
    if (product) {
      setEditingProduct(isDuplicate ? null : product);
      setCostReason('');
      setFormData({
        name: isDuplicate ? `${product.name} (Cópia)` : product.name || '',
        description: product.description || '', price: product.price || '', price_promo: product.price_promo || '',
        price_wholesale: product.price_wholesale || '', price_cash: product.price_cash || '', cost: product.cost ?? '',
        image_url: product.image_url || '',
        category: product.category || 'Cervejas', brand: product.brand || '', unit_type: product.unit_type || 'unidade',
        units_per_pack: product.units_per_pack || '', volume_ml: product.volume_ml || '', min_order: product.min_order || 1,
        in_stock: product.in_stock !== false, featured: product.featured || false,
        stock_quantity: product.stock_quantity ?? '', low_stock_threshold: product.low_stock_threshold ?? 5
      });
    } else {
      setEditingProduct(null);
      setCostReason('');
      setFormData({ name: '', description: '', price: '', price_promo: '', price_wholesale: '', price_cash: '', cost: '',
        image_url: '', category: 'Cervejas', brand: '', unit_type: 'unidade', units_per_pack: '', volume_ml: '',
        min_order: 1, in_stock: true, featured: false, stock_quantity: '', low_stock_threshold: 5 });
    }
    setIsDialogOpen(true);
  };

  const closeDialog = () => {setIsDialogOpen(false);setEditingProduct(null);};

  const buildPayload = () => ({
    ...formData,
    price: parseFloat(formData.price) || 0,
    cost: Math.max(0, parseFloat(formData.cost) || 0),
    price_promo: formData.price_promo ? parseFloat(formData.price_promo) : null,
    price_wholesale: formData.price_wholesale ? parseFloat(formData.price_wholesale) : null,
    price_cash: formData.price_cash ? parseFloat(formData.price_cash) : null,
    units_per_pack: formData.units_per_pack ? parseInt(formData.units_per_pack) : null,
    volume_ml: formData.volume_ml ? parseInt(formData.volume_ml) : null,
    min_order: parseInt(formData.min_order) || 1,
    stock_quantity: formData.stock_quantity !== '' ? parseInt(formData.stock_quantity) : null,
    low_stock_threshold: parseInt(formData.low_stock_threshold) || 5
  });

  const handleSubmit = async (e) => {
    e.preventDefault();
    const data = buildPayload();
    if (editingProduct) {
      await updateMutation.mutateAsync({ id: editingProduct.id, data });
      const oldCost = Number(editingProduct.cost ?? 0);
      const newCost = Number(data.cost ?? 0);
      if (oldCost !== newCost) {
        try {
          await base44.entities.PriceHistory.create({
            product_id: editingProduct.id,
            product_name: editingProduct.name,
            field: 'cost',
            old_value: oldCost,
            new_value: newCost,
            percent: oldCost > 0 ? round2((newCost - oldCost) / oldCost * 100) : null,
            action_type: 'single',
            reason: costReason || '',
            user_email: user?.email || ''
          });
        } catch {/* histórico é best-effort */}
        setCostReason('');
      }
    } else {
      createMutation.mutate(data);
    }
  };

  const handleSaveAndNew = (e) => {
    e.preventDefault();
    const data = buildPayload();
    if (editingProduct) updateMutation.mutate({ id: editingProduct.id, data }, { onSuccess: () => openDialog(null) });else
    createMutation.mutate(data, { onSuccess: () => openDialog(null) });
  };

  const handleDuplicateFromDialog = () => openDialog({ ...formData, id: undefined }, true);
  const handleDeleteFromDialog = () => {
    if (editingProduct && window.confirm('Excluir este produto?')) deleteMutation.mutate(editingProduct.id, { onSuccess: () => closeDialog() });
  };
  const handleDelete = (id) => {
    if (window.confirm('Excluir este produto?')) deleteMutation.mutate(id);
  };

  // Batch actions
  const handleBatchActivate = async () => {
    const ids = [...selectedIds];
    if (!ids.length) return;
    await base44.entities.Product.updateMany({ id: { $in: ids } }, { $set: { in_stock: true } });
    queryClient.invalidateQueries({ queryKey: ['products'] });
    setSelectedIds(new Set());
  };
  const handleBatchDeactivate = async () => {
    const ids = [...selectedIds];
    if (!ids.length) return;
    await base44.entities.Product.updateMany({ id: { $in: ids } }, { $set: { in_stock: false } });
    queryClient.invalidateQueries({ queryKey: ['products'] });
    setSelectedIds(new Set());
  };
  const handleBatchDelete = async () => {
    const ids = [...selectedIds];
    if (!ids.length) return;
    if (!window.confirm(`Excluir ${ids.length} produto(s)?`)) return;
    await base44.entities.Product.deleteMany({ id: { $in: ids } });
    queryClient.invalidateQueries({ queryKey: ['products'] });
    setSelectedIds(new Set());
  };

  const handleFilterChange = (key, value) => setFilters((prev) => ({ ...prev, [key]: value }));
  const handleClearFilters = () => setFilters(defaultFilters);
  const hasActiveFilters = filters.search || filters.category !== 'all' || filters.brand !== 'all' ||
  filters.status !== 'all' || filters.priceMin || filters.priceMax || filters.stock !== 'all' ||
  filters.promo !== 'all' || filters.dateFrom || filters.dateTo;

  return (
    <div className="min-h-screen bg-muted/20">
      <header className="bg-white border-b sticky top-0 z-10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16 gap-3">
            <div className="flex items-center gap-3 min-w-0">
              <h1 className="text-lg font-semibold truncate">Catálogo de Produtos</h1>
            </div>
            <div className="flex items-center gap-2">
              <Button variant="outline" size="icon" onClick={() => queryClient.invalidateQueries({ queryKey: ['products'] })} title="Atualizar">
                <RefreshCw className="w-4 h-4" />
              </Button>
              <ExcelToolbar products={products} onImport={handleExcelImport} />
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="outline" size="icon" title="Configurações da Visualização">
                    <Settings2 className="w-4 h-4" />
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end">
                  <DropdownMenuLabel>Densidade da Lista</DropdownMenuLabel>
                  <DropdownMenuItem onClick={() => setDensity('comfortable')} className={density === 'comfortable' ? 'font-bold' : ''}>
                    Confortável
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={() => setDensity('compact')} className={density === 'compact' ? 'font-bold' : ''}>
                    Compacto
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
              <Button onClick={() => openDialog()} className="bg-blue-600 hover:bg-blue-700 px-2 rounded-xl">
                <Plus className="w-4 h-4 mr-2" /> Novo Produto
              </Button>
            </div>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-4">
        <StatsBar stats={stats} />
        <CatalogToolbar
          search={filters.search}
          onSearchChange={(v) => handleFilterChange('search', v)}
          viewMode={viewMode}
          onViewModeChange={setViewMode}
          sortField={sortField}
          onSortChange={setSortField}
          sortDir={sortDir}
          onToggleSortDir={() => setSortDir((d) => d === 'asc' ? 'desc' : 'asc')}
          onToggleFilters={() => setShowFilters((s) => !s)}
          showFilters={showFilters}
          hasActiveFilters={!!hasActiveFilters} />
        

        <div className="flex gap-4">
          {showFilters &&
          <FilterPanel
            filters={filters}
            onFilterChange={handleFilterChange}
            onClear={handleClearFilters}
            categories={categories}
            brands={brands}
            hasActiveFilters={!!hasActiveFilters} />

          }
          <div className="flex-1 min-w-0">
            {selectedIds.size > 0 &&
            <BatchActionBar
              selectedCount={selectedIds.size}
              onActivate={handleBatchActivate}
              onDeactivate={handleBatchDeactivate}
              onDelete={handleBatchDelete}
              onClear={() => setSelectedIds(new Set())} />

            }

            {viewMode === 'list' ?
            <ProductListView
              products={paginatedProducts}
              selectedIds={selectedIds}
              onToggleSelect={toggleSelect}
              onToggleSelectAll={toggleSelectAll}
              onEdit={(p) => openDialog(p)}
              onDuplicate={(p) => openDialog(p, true)}
              onDelete={handleDelete}
              isLoading={isLoading}
              density={density} /> :


            <ProductGridView
              products={paginatedProducts}
              selectedIds={selectedIds}
              onToggleSelect={toggleSelect}
              onToggleSelectAll={toggleSelectAll}
              onEdit={(p) => openDialog(p)}
              onDuplicate={(p) => openDialog(p, true)}
              onDelete={handleDelete}
              isLoading={isLoading} />

            }

            {!isLoading && sortedProducts.length > 0 &&
            <CatalogPagination
              currentPage={currentPage}
              totalPages={totalPages}
              pageSize={pageSize}
              onPageSizeChange={setPageSize}
              onPageChange={setCurrentPage}
              totalRecords={sortedProducts.length} />

            }

            {!isLoading && sortedProducts.length === 0 &&
            <div className="text-center py-16">
                <div className="w-20 h-20 bg-blue-50 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Package className="w-8 h-8 text-blue-300" />
                </div>
                <h2 className="text-lg font-semibold mb-1">Nenhum produto encontrado</h2>
                <p className="text-sm text-muted-foreground">Tente ajustar os filtros para ver mais resultados.</p>
              </div>
            }
          </div>
        </div>
      </main>

      <ProductFormDialog
        open={isDialogOpen}
        onOpenChange={setIsDialogOpen}
        formData={formData}
        onChange={setFormData}
        editingProduct={editingProduct}
        categories={categories}
        newCategory={newCategory}
        onNewCategoryChange={setNewCategory}
        onAddCategory={addCategory}
        uploading={uploading}
        onImageUpload={handleImageUpload}
        onSubmit={handleSubmit}
        onSaveAndNew={handleSaveAndNew}
        onDuplicate={handleDuplicateFromDialog}
        onDelete={handleDeleteFromDialog}
        isSaving={createMutation.isPending || updateMutation.isPending}
        canEditCost={canEditCost}
        costReason={costReason}
        onCostReasonChange={setCostReason} />
      
    </div>);

}