import React, { useState, useMemo } from 'react';
import { useQuery } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { useAuth } from '@/lib/AuthContext';
import {
  Users, UserCheck, Package, PackageX, ShoppingCart, Clock,
  DollarSign, TrendingUp, Receipt,
} from 'lucide-react';
import AdminSidebar from '@/components/admin/AdminSidebar';
import AdminTopbar from '@/components/admin/AdminTopbar';
import StatCard from '@/components/admin/dashboard/StatCard';
import ChartsSection from '@/components/admin/dashboard/ChartsSection';
import QuickActions from '@/components/admin/dashboard/QuickActions';
import ProfitOverview from '@/components/admin/dashboard/ProfitOverview';
import { computeDashboardKpis } from '@/lib/dashboardKpis';
import { isStaffRole } from '@/lib/userRoles';

const fmtMoney = (v) =>
  (Number(v) || 0).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });

export default function Dashboard() {
  const { user } = useAuth();
  const [mobileOpen, setMobileOpen] = useState(false);
  const [search, setSearch] = useState('');

  const { data: products = [] } = useQuery({
    queryKey: ['products'],
    queryFn: () => base44.entities.Product.list(),
    staleTime: 60 * 1000,
  });
  const { data: orders = [] } = useQuery({
    queryKey: ['orders'],
    queryFn: () => base44.entities.Order.list(),
    staleTime: 60 * 1000,
  });
  const { data: users = [] } = useQuery({
    queryKey: ['users'],
    queryFn: () => base44.entities.User.list(),
    staleTime: 60 * 1000,
  });

  const kpis = useMemo(
    () => computeDashboardKpis({ products, orders, users }),
    [products, orders, users]
  );

  if (user && !isStaffRole(user.role)) {
    return (
      <div className="min-h-screen flex items-center justify-center p-6 text-center">
        <div>
          <h1 className="text-xl font-bold text-foreground">Acesso restrito</h1>
          <p className="text-muted-foreground mt-2">Você não tem permissão para acessar o painel administrativo.</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background flex">
      {/* Sidebar desktop */}
      <aside className="hidden lg:block w-64 flex-shrink-0 sticky top-0 h-screen">
        <AdminSidebar search={search} />
      </aside>

      {/* Sidebar mobile */}
      {mobileOpen && (
        <div className="lg:hidden fixed inset-0 z-50 flex">
          <div className="absolute inset-0 bg-black/40" onClick={() => setMobileOpen(false)} />
          <div className="relative w-72 max-w-[80%] h-full shadow-xl">
            <AdminSidebar search={search} onClose={() => setMobileOpen(false)} />
          </div>
        </div>
      )}

      <div className="flex-1 min-w-0 flex flex-col">
        <AdminTopbar onMenuClick={() => setMobileOpen(true)} search={search} onSearchChange={setSearch} />

        <main className="flex-1 p-4 sm:p-6 lg:p-8 space-y-6 overflow-y-auto">
          {/* Header */}
          <div>
            <h1 className="text-2xl font-bold text-foreground">Visão geral</h1>
            <p className="text-sm text-muted-foreground mt-1">
              Monitoramento e gerenciamento centralizado do sistema.
            </p>
          </div>

          {/* KPIs */}
          <div className="grid grid-cols-2 md:grid-cols-3 xl:grid-cols-4 gap-3 sm:gap-4">
            <StatCard icon={Users} label="Total de usuários" value={kpis.totalUsers} sub={`${kpis.newSignups} novos (30d)`} trend="up" accent="blue" />
            <StatCard icon={ShoppingCart} label="Pedidos realizados" value={kpis.totalOrders} sub="catálogo completo" trend="up" accent="blue" />
            <StatCard icon={Clock} label="Pedidos pendentes" value={kpis.pending} sub="aguardando confirmação" trend={kpis.pending > 0 ? 'down' : 'up'} accent="yellow" />
            <StatCard icon={DollarSign} label="Faturamento total" value={fmtMoney(kpis.revenue)} sub="todos os pedidos" trend="up" accent="green" />
            <StatCard icon={TrendingUp} label="Faturamento diário" value={fmtMoney(kpis.dailyRevenue)} sub="hoje" trend="up" accent="blue" />
            <StatCard icon={TrendingUp} label="Faturamento mensal" value={fmtMoney(kpis.monthRevenue)} sub="mês atual" trend="up" accent="violet" />
            <StatCard icon={Receipt} label="Ticket médio" value={fmtMoney(kpis.avgTicket)} sub="por pedido" trend="up" accent="green" />
            <StatCard icon={UserCheck} label="Pedidos entregues" value={kpis.delivered} sub="concluídos" trend="up" accent="green" />
            <StatCard icon={Users} label="Clientes ativos" value={kpis.activeCustomers} sub="com pedidos" trend="up" accent="violet" />
            <StatCard icon={Package} label="Produtos cadastrados" value={kpis.totalProducts} sub="catálogo ativo" trend="up" accent="blue" />
            <StatCard icon={PackageX} label="Produtos em falta" value={kpis.outOfStock} sub={kpis.outOfStock > 0 ? 'requer atenção' : 'tudo ok'} trend={kpis.outOfStock > 0 ? 'down' : 'up'} accent="red" />
          </div>

          {/* Profit overview */}
          <div>
            <h2 className="text-lg font-semibold text-foreground mb-3">Lucratividade</h2>
            <ProfitOverview products={products} />
          </div>

          {/* Charts */}
          <ChartsSection orders={orders} users={users} />

          {/* Quick actions */}
          <QuickActions />
        </main>
      </div>
    </div>
  );
}