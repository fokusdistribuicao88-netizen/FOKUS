import React, { useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import FinancialOverview from "@/components/financial/FinancialOverview";
import EntriesTab from "@/components/financial/EntriesTab";
import CashFlowTab from "@/components/financial/CashFlowTab";
import { Button } from "@/components/ui/button";
import { useToast } from "@/components/ui/use-toast";
import { Download } from "lucide-react";
import { exportXlsx } from "@/lib/xlsxExport";
import ExportImportMenu from "@/components/admin/ExportImportMenu";

export default function Financial() {
  const { toast } = useToast();
  const qc = useQueryClient();
  const [tab, setTab] = useState("overview");

  const entriesQ = useQuery({
    queryKey: ["financialEntries"],
    queryFn: () => base44.entities.FinancialEntry.list("-due_date", 500),
  });
  const customersQ = useQuery({
    queryKey: ["customers"],
    queryFn: () => base44.entities.Customer.list(),
  });

  const entries = entriesQ.data || [];
  const customers = customersQ.data || [];

  const exportAll = () => {
    const rows = entries.map((e) => ({
      Tipo: e.direction === "receivable" ? "Receber" : "Pagar",
      ClienteFornecedor: e.party_name,
      Descrição: e.description,
      Categoria: e.category,
      Valor: e.amount,
      Pago: e.paid_amount || 0,
      Vencimento: e.due_date,
      Status: e.status,
    }));
    exportXlsx("Relatorio_Financeiro.xlsx", "Financeiro", rows);
    toast({ title: "Relatório financeiro exportado." });
  };

  return (
    <div className="min-h-screen bg-background">
      <div className="border-b bg-card">
        <div className="max-w-7xl mx-auto px-4 py-4 flex items-center gap-4">
          <div>
            <h1 className="text-xl font-bold">Financeiro</h1>
          </div>
        </div>
      </div>
      <div className="max-w-7xl mx-auto px-4 py-6 space-y-6">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <p className="text-muted-foreground text-sm">
            Controle financeiro: contas a receber, contas a pagar e fluxo de caixa.
          </p>
          <ExportImportMenu
            items={[
              { label: 'Exportar Relatório', icon: Download, onClick: exportAll },
            ]}
          />
        </div>

        <Tabs value={tab} onValueChange={setTab}>
          <TabsList className="flex flex-wrap h-auto">
            <TabsTrigger value="overview">Visão Geral</TabsTrigger>
            <TabsTrigger value="payable">Contas a Pagar</TabsTrigger>
            <TabsTrigger value="cashflow">Fluxo de Caixa</TabsTrigger>
            <TabsTrigger value="reports">Relatórios</TabsTrigger>
          </TabsList>

          <TabsContent value="overview" className="mt-4">
            <FinancialOverview entries={entries} />
          </TabsContent>
          <TabsContent value="payable" className="mt-4">
            <EntriesTab entries={entries} direction="payable" customers={customers} />
          </TabsContent>
          <TabsContent value="cashflow" className="mt-4">
            <CashFlowTab entries={entries} />
          </TabsContent>
          <TabsContent value="reports" className="mt-4">
            <div className="flex flex-col items-center justify-center py-16 gap-4">
              <p className="text-muted-foreground">Exporte relatórios financeiros completos em Excel.</p>
              <Button onClick={exportAll} size="lg"><Download className="h-5 w-5" /> Gerar Relatório Financeiro</Button>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}