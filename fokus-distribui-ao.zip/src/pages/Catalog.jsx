import React, { useState, useEffect, useMemo, useCallback } from 'react';
// Catalog page — public product showcase (v2)
import { base44 } from '@/api/base44Client';
import { useQuery } from '@tanstack/react-query';

import { useToast } from '@/components/ui/use-toast';
import { useAuth } from '@/lib/AuthContext';
import ProductCard from '@/components/catalog/ProductCard';
import CartSidebar from '@/components/catalog/CartSidebar';
import FilterBar from '@/components/catalog/FilterBar';
import HeroCarousel from '@/components/catalog/HeroCarousel';
import ChatBot from '@/components/catalog/ChatBot';
import CatalogHero from '@/components/catalog/CatalogHero';
import CategoryStrip from '@/components/catalog/CategoryStrip';
import CatalogFooter from '@/components/catalog/CatalogFooter';
import CatalogHeader from '@/components/catalog/CatalogHeader';
import CatalogEmptyState from '@/components/catalog/CatalogEmptyState';
import PullToRefresh from '@/components/PullToRefresh';
import { resolveCatalogTable } from '@/lib/priceRules';
import { resolveProductPrice } from '@/lib/posPriceTables';

export default function Catalog() {
  const [searchTerm, setSearchTerm] = useState('');
  const [debouncedSearch, setDebouncedSearch] = useState('');
  const [activeCategory, setActiveCategory] = useState(null);
  const [cartOpen, setCartOpen] = useState(false);
  const [visibleCount, setVisibleCount] = useState(20);
  const [selectedBrand, setSelectedBrand] = useState('');
  const [priceMin, setPriceMin] = useState('');
  const [priceMax, setPriceMax] = useState('');
  const [appliedFilters, setAppliedFilters] = useState({ brand: '', priceMin: '', priceMax: '' });
  const { toast } = useToast();
  const { user, isAuthenticated } = useAuth();
  const [cartItems, setCartItems] = useState(() => {
    try {
      const saved = localStorage.getItem('cart');
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  useEffect(() => {
    const timer = setTimeout(() => {
      setDebouncedSearch(searchTerm);
      setVisibleCount(20);
    }, 300);
    return () => clearTimeout(timer);
  }, [searchTerm]);

  useEffect(() => {
    setVisibleCount(20);
  }, [activeCategory]);

  useEffect(() => {
    setVisibleCount(20);
  }, [appliedFilters]);

  const { data: products = [], isLoading, refetch: refetchProducts } = useQuery({
    queryKey: ['products'],
    queryFn: () => base44.entities.Product.list(),
    staleTime: 5 * 60 * 1000,
  });

  const { data: settings, refetch: refetchSettings } = useQuery({
    queryKey: ['settings'],
    queryFn: async () => {
      const list = await base44.entities.Settings.list('-updated_date', 1);
      return list[0] || null;
    },
    staleTime: 10 * 60 * 1000,
  });

  const { data: priceTables = [] } = useQuery({
    queryKey: ['price-tables'],
    queryFn: () => base44.entities.PriceTable.list('-updated_date'),
    staleTime: 5 * 60 * 1000,
  });

  // Resolve a tabela do catálogo a partir das regras configuradas
  const catalogTable = useMemo(() => resolveCatalogTable(settings?.price_rules, priceTables), [settings, priceTables]);
  const catalogTableEntity = catalogTable?.selection?.table || null;

  const { data: catalogTableItems = [] } = useQuery({
    queryKey: ['price-table-items', catalogTableEntity?.id],
    queryFn: () => base44.entities.PriceTableItem.filter({ price_table_id: catalogTableEntity.id }),
    enabled: !!catalogTableEntity?.id,
    staleTime: 5 * 60 * 1000,
  });

  const catalogItemsByProduct = useMemo(() => {
    const m = {};
    catalogTableItems.forEach((it) => { m[it.product_id] = it; });
    return m;
  }, [catalogTableItems]);

  const catalogPriceOf = useCallback((product) => {
    if (product.price_promo) return product.price_promo;
    if (catalogTable) return resolveProductPrice(product, catalogTable.selection, catalogItemsByProduct);
    return product.price ?? 0;
  }, [catalogTable, catalogItemsByProduct]);

  const categories = useMemo(() => {
    const defaultCategories = ['Cervejas', 'Refrigerantes', 'Águas', 'Sucos', 'Energéticos', 'Destilados', 'Vinhos', 'Outros'];
    const productCategories = [...new Set(products.map((p) => p.category).filter(Boolean))];
    return [...new Set([...defaultCategories, ...productCategories])].filter(
      (cat) => products.some((p) => p.category === cat)
    );
  }, [products]);

  const brands = useMemo(() => {
    return [...new Set(products.map((p) => p.brand).filter(Boolean))].sort((a, b) => a.localeCompare(b));
  }, [products]);

  const filteredProducts = useMemo(() => {
    const search = debouncedSearch.toLowerCase();
    const minPrice = parseFloat(appliedFilters.priceMin);
    const maxPrice = parseFloat(appliedFilters.priceMax);
    return products
      .filter((product) => product.status !== 'inactive')
      .filter((product) => {
        const matchesSearch =
          !search ||
          product.name?.toLowerCase().includes(search) ||
          product.brand?.toLowerCase().includes(search) ||
          product.description?.toLowerCase().includes(search);
        const matchesCategory = !activeCategory || product.category === activeCategory;
        const matchesBrand = !appliedFilters.brand || product.brand === appliedFilters.brand;
        const effectivePrice = catalogPriceOf(product);
        const matchesPriceMin = isNaN(minPrice) || effectivePrice >= minPrice;
        const matchesPriceMax = isNaN(maxPrice) || effectivePrice <= maxPrice;
        return matchesSearch && matchesCategory && matchesBrand && matchesPriceMin && matchesPriceMax;
      })
      .sort((a, b) => (a.name || '').localeCompare(b.name || '', 'pt-BR'));
  }, [products, debouncedSearch, activeCategory, appliedFilters, catalogPriceOf]);

  const featuredProducts = useMemo(() => filteredProducts.filter((p) => p.featured), [filteredProducts]);
  const regularProducts = useMemo(() => filteredProducts.filter((p) => !p.featured), [filteredProducts]);

  const addToCart = useCallback((product) => {
    const minOrder = product.min_order || 1;
    const resolvedPrice = catalogPriceOf(product);
    setCartItems((prev) => {
      const existing = prev.find((item) => item.id === product.id);
      if (existing) {
        return prev.map((item) =>
          item.id === product.id ? { ...item, quantity: item.quantity + 1 } : item
        );
      }
      return [...prev, { ...product, quantity: minOrder, originalPrice: product.price, price_wholesale: product.price_wholesale, price_cash: product.price_cash, resolvedPrice, priceTableName: catalogTable?.selection?.table?.name }];
    });
  }, [catalogPriceOf, catalogTable]);

  const updateQuantity = useCallback((productId, quantity) => {
    setCartItems((prev) => {
      const product = prev.find((item) => item.id === productId);
      const minOrder = product?.min_order || 1;
      if (quantity < minOrder) return prev.filter((item) => item.id !== productId);
      return prev.map((item) => (item.id === productId ? { ...item, quantity } : item));
    });
  }, []);

  const removeFromCart = useCallback((productId) => {
    setCartItems((prev) => prev.filter((item) => item.id !== productId));
  }, []);

  const cartItemIds = useMemo(() => new Set(cartItems.map((i) => i.id)), [cartItems]);
  const isInCart = useCallback((productId) => cartItemIds.has(productId), [cartItemIds]);

  const totalItems = useMemo(() => cartItems.reduce((sum, item) => sum + item.quantity, 0), [cartItems]);
  const isWholesale = totalItems >= 10;
  const isSearching = searchTerm !== debouncedSearch;

  const handleApplyFilters = useCallback(() => {
    const min = parseFloat(priceMin);
    const max = parseFloat(priceMax);
    if (!isNaN(min) && !isNaN(max) && min > max) {
      toast({ title: 'Faixa de preço inválida', description: 'O preço mínimo não pode ser maior que o máximo.', variant: 'destructive' });
      return;
    }
    setAppliedFilters({ brand: selectedBrand, priceMin, priceMax });
  }, [selectedBrand, priceMin, priceMax, toast]);

  const handleClearFilters = useCallback(() => {
    setSearchTerm('');
    setActiveCategory(null);
    setSelectedBrand('');
    setPriceMin('');
    setPriceMax('');
    setAppliedFilters({ brand: '', priceMin: '', priceMax: '' });
    setVisibleCount(20);
  }, []);

  const hasActiveFilters = !!(debouncedSearch || activeCategory || appliedFilters.brand || appliedFilters.priceMin || appliedFilters.priceMax || selectedBrand || priceMin || priceMax);

  useEffect(() => {
    localStorage.setItem('cart', JSON.stringify(cartItems));
    localStorage.setItem('isWholesale', JSON.stringify(isWholesale));
  }, [cartItems, isWholesale]);

  const scrollToProducts = useCallback(() => {
    document.getElementById('produtos')?.scrollIntoView({ behavior: 'smooth' });
  }, []);

  const handlePullRefresh = useCallback(async () => {
    await Promise.all([refetchProducts(), refetchSettings()]);
  }, [refetchProducts, refetchSettings]);

  return (
    <div className="min-h-screen bg-background pb-16 md:pb-0">
      <PullToRefresh onRefresh={handlePullRefresh} />
      <CatalogHeader
        settings={settings}
        searchTerm={searchTerm}
        onSearchChange={setSearchTerm}
        isAuthenticated={isAuthenticated}
        user={user}
        totalItems={totalItems}
        onOpenCart={() => setCartOpen(true)} />

      {/* Hero / Cover */}
      <CatalogHero settings={settings} onSeeProducts={scrollToProducts} />

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 lg:py-12">
        {/* Carousel */}
        {settings?.carousel_images?.length > 0 && <HeroCarousel images={settings.carousel_images} />}

        {/* Categories */}
        {!isLoading && products.length > 0 && (
          <CategoryStrip
            categories={categories}
            activeCategory={activeCategory}
            onCategoryChange={setActiveCategory}
          />
        )}

        {/* Filters */}
        {!isLoading && products.length > 0 && (
          <div className="mt-6">
            <FilterBar
              categories={categories}
              selectedCategory={activeCategory}
              onCategoryChange={setActiveCategory}
              brands={brands}
              selectedBrand={selectedBrand}
              onBrandChange={setSelectedBrand}
              priceMin={priceMin}
              priceMax={priceMax}
              onPriceMinChange={setPriceMin}
              onPriceMaxChange={setPriceMax}
              onApply={handleApplyFilters}
              onClear={handleClearFilters}
              resultsCount={filteredProducts.length}
              hasActiveFilters={hasActiveFilters}
              isFiltering={isSearching}
            />
          </div>
        )}

        {/* Loading */}
        {isLoading && (
          <div className="grid grid-cols-2 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-3 sm:gap-6">
            {[...Array(8)].map((_, i) => (
              <div key={i} className="animate-pulse">
                <div className="aspect-square bg-muted rounded-2xl mb-4" />
                <div className="h-4 bg-muted rounded w-1/3 mb-2" />
                <div className="h-6 bg-muted rounded w-2/3 mb-2" />
                <div className="h-4 bg-muted rounded w-full" />
              </div>
            ))}
          </div>
        )}

        {/* Featured */}
        {featuredProducts.length > 0 && (
          <section className="mt-10 mb-12">
            <div className="flex items-center gap-3 mb-6">
              <div className="w-1.5 h-7 rounded-full bg-yellow-400" />
              <h2 className="text-xl lg:text-2xl font-bold text-blue-900 dark:text-foreground">
                Ofertas da Semana
              </h2>
              <div className="h-px flex-1 bg-border" />
            </div>
            <div className="grid grid-cols-2 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-3 sm:gap-6">
              {featuredProducts.map((product) => (
                <ProductCard
                  key={product.id}
                  product={product}
                  onAddToCart={addToCart}
                  isInCart={isInCart(product.id)}
                  priceOf={catalogPriceOf}
                  tableName={catalogTable?.selection?.table?.name}
                />
              ))}
            </div>
          </section>
        )}

        {/* Regular products */}
        {regularProducts.length > 0 && (
          <section>
            {featuredProducts.length > 0 && (
              <div className="flex items-center gap-3 mb-6">
                <div className="w-1.5 h-7 rounded-full bg-blue-700" />
                <h2 className="text-xl lg:text-2xl font-bold text-blue-900 dark:text-foreground">Todos os Produtos</h2>
                <div className="h-px flex-1 bg-border" />
              </div>
            )}
            <div className="grid grid-cols-2 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-3 sm:gap-6">
              {regularProducts.slice(0, visibleCount).map((product) => (
                <ProductCard
                  key={product.id}
                  product={product}
                  onAddToCart={addToCart}
                  isInCart={isInCart(product.id)}
                  priceOf={catalogPriceOf}
                  tableName={catalogTable?.selection?.table?.name}
                />
              ))}
            </div>
            {visibleCount < regularProducts.length && (
              <div className="flex justify-center mt-10">
                <button
                  onClick={() => setVisibleCount((prev) => prev + 20)}
                  className="px-8 py-3 bg-blue-700 text-white rounded-full font-semibold hover:bg-blue-800 transition-colors shadow-sm"
                >
                  Ver mais ({regularProducts.length - visibleCount} produtos)
                </button>
              </div>
            )}
          </section>
        )}

        {/* Empty state */}
        {!isLoading && filteredProducts.length === 0 && (
          <CatalogEmptyState hasActiveFilters={hasActiveFilters} onClearFilters={handleClearFilters} />
        )}
      </main>

      <CatalogFooter settings={settings} />

      <ChatBot products={products} />

      <CartSidebar
        isOpen={cartOpen}
        onClose={() => setCartOpen(false)}
        items={cartItems}
        onUpdateQuantity={updateQuantity}
        onRemoveItem={removeFromCart}
      />
    </div>
  );
}