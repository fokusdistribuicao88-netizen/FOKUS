import React, { useState } from 'react';
import { Navigate, Link } from 'react-router-dom';
import { useAuth } from '@/lib/AuthContext';
import { Package, User, LogOut, Loader2, Store } from 'lucide-react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Button } from '@/components/ui/button';
import AccountOrders from '@/components/account/AccountOrders';
import AccountProfile from '@/components/account/AccountProfile';

export default function MyAccount() {
  const { user, logout } = useAuth();
  const [tab, setTab] = useState('orders');

  const role = user?.role || user?.data?.role;

  if (role === 'admin') return <Navigate to="/Dashboard" replace />;

  return (
    <div className="min-h-screen bg-muted/20">
      {/* Header */}
      <header className="bg-gradient-to-r from-blue-900 via-blue-800 to-blue-900 text-white">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 py-8">
          <div className="flex items-center justify-between gap-4 flex-wrap">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-2xl bg-yellow-400/20 border border-yellow-400/30 flex items-center justify-center">
                <Store className="w-6 h-6 text-yellow-300" />
              </div>
              <div>
                <h1 className="text-xl font-bold">Minha Conta</h1>
                <p className="text-blue-100/80 text-sm">Olá, {user?.full_name || user?.email}</p>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <Link to="/">
                <Button variant="outline" className="bg-white/10 border-white/20 text-white hover:bg-white/20 hover:text-white">
                  <Store className="w-4 h-4" /> Voltar à loja
                </Button>
              </Link>
              <Button variant="outline" onClick={() => logout()} className="bg-white/10 border-white/20 text-white hover:bg-white/20 hover:text-white">
                <LogOut className="w-4 h-4" /> Sair
              </Button>
            </div>
          </div>
        </div>
      </header>

      {/* Body */}
      <main className="max-w-4xl mx-auto px-4 sm:px-6 py-6">
        <Tabs value={tab} onValueChange={setTab}>
          <TabsList className="grid grid-cols-2 w-full mb-6">
            <TabsTrigger value="orders"><Package className="w-4 h-4 mr-2" />Meus pedidos</TabsTrigger>
            <TabsTrigger value="profile"><User className="w-4 h-4 mr-2" />Meus dados</TabsTrigger>
          </TabsList>
          <TabsContent value="orders">
            <AccountOrders />
          </TabsContent>
          <TabsContent value="profile">
            <div className="rounded-2xl border border-border bg-card p-5 sm:p-6 shadow-sm">
              <AccountProfile user={user} />
            </div>
          </TabsContent>
        </Tabs>
      </main>
    </div>
  );
}