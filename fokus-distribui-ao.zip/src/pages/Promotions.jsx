import React, { useState, useMemo } from 'react';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { useAuth } from '@/lib/AuthContext';
import { useToast } from '@/components/ui/use-toast';
import { Loader2, Plus, Pencil, Trash2, Copy, Power, PowerOff, Tag, Boxes, Search } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import PromotionFormDialog from '@/components/promotions/PromotionFormDialog';
import PromotionHighlights from '@/components/promotions/PromotionHighlights';
import PromotionFilters from '@/components/promotions/PromotionFilters';
import { effectiveStatus, PROMO_STATUS_INFO, fmtMoney, applyPromotionPrice, clearPromotionPrice } from '@/lib/promotions';
import { logActivity } from '@/lib/activityLog';

export default function Promotions() {
  const queryClient = useQueryClient();
  const { user } = useAuth();
  const { toast } = useToast();
  const canEdit = user?.role === 'admin' || user?.role === 'gerente';

  const [formOpen, setFormOpen] = useState(false);
  const [editing, setEditing] = useState(null);
  const [saving, setSaving] = useState(false);
  const [deleteId, setDeleteId] = useState(null);
  const [search, setSearch] = useState('');
  const [filter, setFilter] = useState('all');
  const [sort, setSort] = useState('date');
  const [viewPromo, setViewPromo] = useState(null);

  const { data: promotions = [], isLoading } = useQuery({ queryKey: ['promotions'], queryFn: () => base44.entities.Promotion.list(), staleTime: 30000 });
  const { data: products = [] } = useQuery({ queryKey: ['products'], queryFn: () => base44.entities.Product.list(), staleTime: 60000 });

  const enriched = useMemo(() => promotions.map((p) => ({ ...p, _effective: effectiveStatus(p) })), [promotions]);

  const filtered = useMemo(() => {
    const q = search.toLowerCase().trim();
    let list = enriched.filter((p) => {
      if (q && !(p.name?.toLowerCase().includes(q) || p.product_name?.toLowerCase().includes(q) || p.description?.toLowerCase().includes(q))) return false;
      if (filter === 'all') return true;
      if (filter === 'combo' || filter === 'product') return p.type === filter;
      return p._effective === filter;
    });
    list.sort((a, b) => {
      if (sort === 'name') return (a.name || '').localeCompare(b.name || '', 'pt-BR');
      if (sort === 'discount') return (b.discount_percent || 0) - (a.discount_percent || 0);
      if (sort === 'status') return (a._effective || '').localeCompare(b._effective || '');
      return new Date(b.start_date || 0).getTime() - new Date(a.start_date || 0).getTime();
    });
    return list;
  }, [enriched, search, filter, sort]);

  const counts = useMemo(() => ({
    total: promotions.length,
    active: enriched.filter((p) => p._effective === 'active').length,
    scheduled: enriched.filter((p) => p._effective === 'scheduled').length,
    ended: enriched.filter((p) => p._effective === 'ended').length,
  }), [enriched, promotions]);

  const invalidate = () => { queryClient.invalidateQueries({ queryKey: ['promotions'] }); queryClient.invalidateQueries({ queryKey: ['products'] }); };

  const handleSave = async (payload) => {
    setSaving(true);
    try {
      let saved;
      if (editing) {
        saved = await base44.entities.Promotion.update(editing.id, payload);
        logActivity({ action: 'promotion_update', description: `Promoção "${payload.name}" editada`, user, entityType: 'Promotion', entityId: editing.id });
      } else {
        saved = await base44.entities.Promotion.create(payload);
        logActivity({ action: 'promotion_create', description: `Promoção "${payload.name}" criada`, user, entityType: 'Promotion', entityId: saved?.id });
      }
      await applyPromotionPrice(saved || { ...payload, id: editing?.id });
      invalidate();
      toast({ title: editing ? 'Promoção atualizada' : 'Promoção criada', description: 'Preço do catálogo sincronizado.' });
      setFormOpen(false);
      setEditing(null);
    } catch (e) {
      toast({ title: 'Erro', description: e.message, variant: 'destructive' });
    } finally {
      setSaving(false);
    }
  };

  const handleDuplicate = (p) => {
    const { id, created_date, updated_date, created_by_id, ...rest } = p;
    setEditing({ ...rest, name: `${p.name} (cópia)`, status: 'scheduled' });
    setFormOpen(true);
  };

  const handleToggle = async (p) => {
    const next = p.status === 'inactive' ? 'scheduled' : 'inactive';
    try {
      const updated = await base44.entities.Promotion.update(p.id, { status: next });
      if (next === 'inactive') await clearPromotionPrice(p);
      else await applyPromotionPrice(updated);
      invalidate();
      logActivity({ action: 'promotion_toggle', description: `Promoção "${p.name}" ${next === 'inactive' ? 'desativada' : 'ativada'}`, user, entityType: 'Promotion', entityId: p.id });
      toast({ title: next === 'inactive' ? 'Promoção desativada' : 'Promoção ativada' });
    } catch (e) {
      toast({ title: 'Erro', description: e.message, variant: 'destructive' });
    }
  };

  const handleDelete = async () => {
    const p = promotions.find((x) => x.id === deleteId);
    try {
      await clearPromotionPrice(p);
      await base44.entities.Promotion.delete(deleteId);
      invalidate();
      logActivity({ action: 'promotion_delete', description: `Promoção "${p?.name}" excluída`, user, entityType: 'Promotion', entityId: deleteId });
      toast({ title: 'Promoção excluída' });
    } catch (e) {
      toast({ title: 'Erro', description: e.message, variant: 'destructive' });
    } finally {
      setDeleteId(null);
    }
  };

  const summaryCards = [
    { label: 'Total', value: counts.total, icon: Tag, accent: 'text-blue-600' },
    { label: 'Ativas', value: counts.active, icon: Power, accent: 'text-green-600' },
    { label: 'Agendadas', value: counts.scheduled, icon: Boxes, accent: 'text-violet-600' },
    { label: 'Encerradas', value: counts.ended, icon: PowerOff, accent: 'text-slate-500' },
  ];

  return (
    <div className="min-h-screen bg-background">
      <header className="sticky top-0 z-40 bg-card/95 backdrop-blur-md border-b border-border shadow-sm">
        <div className="max-w-[1600px] mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center gap-3 h-16">
            <div className="w-9 h-9 bg-gradient-to-br from-yellow-500 to-orange-600 rounded-lg flex items-center justify-center">
              <Tag className="w-5 h-5 text-white" />
            </div>
            <div className="min-w-0">
              <h1 className="text-base font-bold text-foreground leading-tight truncate">Promoções</h1>
              <p className="text-xs text-muted-foreground">Gerencie promoções e combos</p>
            </div>
            {canEdit && (
              <Button onClick={() => { setEditing(null); setFormOpen(true); }} className="ml-auto gap-2">
                <Plus className="w-4 h-4" /> Nova Promoção
              </Button>
            )}
          </div>
        </div>
      </header>

      <main className="max-w-[1600px] mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-5">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
          {summaryCards.map((c) => {
            const Icon = c.icon;
            return (
              <div key={c.label} className="bg-card rounded-xl border border-border p-4 flex items-center gap-3">
                <div className={`w-10 h-10 rounded-lg bg-muted/60 flex items-center justify-center ${c.accent}`}><Icon className="w-5 h-5" /></div>
                <div><p className="text-xs text-muted-foreground">{c.label}</p><p className="text-xl font-bold text-foreground">{c.value}</p></div>
              </div>
            );
          })}
        </div>

        <PromotionHighlights promotions={enriched} onView={setViewPromo} />

        <PromotionFilters search={search} onSearch={setSearch} filter={filter} onFilter={setFilter} sort={sort} onSort={setSort} />

        {isLoading ? (
          <div className="flex justify-center py-20"><Loader2 className="w-8 h-8 animate-spin text-blue-600" /></div>
        ) : filtered.length === 0 ? (
          <div className="text-center py-20">
            <Tag className="w-12 h-12 text-muted-foreground mx-auto mb-3" />
            <p className="text-muted-foreground">Nenhuma promoção encontrada.</p>
          </div>
        ) : (
          <div className="overflow-x-auto bg-card rounded-xl border border-border">
            <table className="w-full text-sm">
              <thead className="bg-muted/50 text-muted-foreground text-xs uppercase">
                <tr>
                  <th className="text-left px-4 py-3">Nome</th>
                  <th className="text-left px-4 py-3">Tipo</th>
                  <th className="text-left px-4 py-3">Original</th>
                  <th className="text-left px-4 py-3">Promo</th>
                  <th className="text-left px-4 py-3">Desc.</th>
                  <th className="text-left px-4 py-3">Período</th>
                  <th className="text-left px-4 py-3">Status</th>
                  {canEdit && <th className="text-right px-4 py-3">Ações</th>}
                </tr>
              </thead>
              <tbody className="divide-y divide-border">
                {filtered.map((p) => {
                  const info = PROMO_STATUS_INFO[p._effective] || PROMO_STATUS_INFO.inactive;
                  return (
                    <tr key={p.id} className="hover:bg-accent/40">
                      <td className="px-4 py-3 font-medium text-foreground">{p.name}</td>
                      <td className="px-4 py-3"><span className="text-xs px-2 py-0.5 rounded-full bg-muted">{p.type === 'combo' ? 'Combo' : 'Produto'}</span></td>
                      <td className="px-4 py-3 text-muted-foreground line-through">{fmtMoney(p.original_price)}</td>
                      <td className="px-4 py-3 font-bold text-blue-900 dark:text-yellow-400">{fmtMoney(p.promo_price)}</td>
                      <td className="px-4 py-3"><span className="text-xs font-bold text-red-600">{p.discount_percent || 0}%</span></td>
                      <td className="px-4 py-3 text-xs text-muted-foreground">{new Date(p.start_date).toLocaleDateString('pt-BR')} → {new Date(p.end_date).toLocaleDateString('pt-BR')}</td>
                      <td className="px-4 py-3"><span className={`text-xs px-2 py-0.5 rounded-full ${info.badge}`}>{info.label}</span></td>
                      {canEdit && (
                        <td className="px-4 py-3">
                          <div className="flex justify-end gap-1">
                            <Button size="icon" variant="ghost" onClick={() => { setEditing(p); setFormOpen(true); }}><Pencil className="w-4 h-4" /></Button>
                            <Button size="icon" variant="ghost" onClick={() => handleDuplicate(p)}><Copy className="w-4 h-4" /></Button>
                            <Button size="icon" variant="ghost" onClick={() => handleToggle(p)}><Power className="w-4 h-4" /></Button>
                            <Button size="icon" variant="ghost" onClick={() => setDeleteId(p.id)}><Trash2 className="w-4 h-4 text-red-500" /></Button>
                          </div>
                        </td>
                      )}
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </main>

      <PromotionFormDialog open={formOpen} onClose={() => { setFormOpen(false); setEditing(null); }} onSave={handleSave} saving={saving} products={products} allPromotions={promotions} existing={editing} />

      <Dialog open={!!viewPromo} onOpenChange={(o) => !o && setViewPromo(null)}>
        <DialogContent className="max-w-md">
          <DialogHeader><DialogTitle>{viewPromo?.name}</DialogTitle></DialogHeader>
          {viewPromo?.image_url && <img src={viewPromo.image_url} alt={viewPromo.name} className="w-full rounded-lg" />}
          <p className="text-sm text-muted-foreground">{viewPromo?.description || 'Sem descrição.'}</p>
          <div className="flex items-end gap-3">
            <span className="line-through text-muted-foreground">{fmtMoney(viewPromo?.original_price)}</span>
            <span className="text-2xl font-extrabold text-blue-900 dark:text-yellow-400">{fmtMoney(viewPromo?.promo_price)}</span>
            <span className="text-sm font-bold text-red-600">-{viewPromo?.discount_percent || 0}%</span>
          </div>
          <p className="text-xs text-muted-foreground">Válido até {viewPromo && new Date(viewPromo.end_date).toLocaleString('pt-BR')}</p>
        </DialogContent>
      </Dialog>

      <Dialog open={!!deleteId} onOpenChange={(o) => !o && setDeleteId(null)}>
        <DialogContent className="max-w-sm">
          <DialogHeader><DialogTitle>Excluir promoção?</DialogTitle></DialogHeader>
          <p className="text-sm text-muted-foreground">O preço original do produto será restaurado no catálogo. Esta ação não pode ser desfeita.</p>
          <DialogFooter>
            <Button variant="outline" onClick={() => setDeleteId(null)}>Cancelar</Button>
            <Button variant="destructive" onClick={handleDelete}>Excluir</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}