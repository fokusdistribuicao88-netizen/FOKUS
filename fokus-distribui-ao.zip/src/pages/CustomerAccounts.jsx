import React, { useState, useMemo } from 'react';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { useAuth } from '@/lib/AuthContext';
import { useToast } from '@/components/ui/use-toast';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card } from '@/components/ui/card';
import { Plus, Search, Download, Handshake, BarChart3, FileText, UserSearch } from 'lucide-react';

import CustomerAccountsDashboard from '@/components/customeraccounts/CustomerAccountsDashboard';
import CustomerAccountsList from '@/components/customeraccounts/CustomerAccountsList';
import CustomerAccountFormDialog from '@/components/customeraccounts/CustomerAccountFormDialog';
import CustomerAccountDetailDialog from '@/components/customeraccounts/CustomerAccountDetailDialog';
import CustomerAccountPaymentDialog from '@/components/customeraccounts/CustomerAccountPaymentDialog';
import NegotiateDebtDialog from '@/components/customeraccounts/NegotiateDebtDialog';
import CustomerAccountsReminders from '@/components/customeraccounts/CustomerAccountsReminders';
import CustomerAccountsReport from '@/components/customeraccounts/CustomerAccountsReport';
import CustomerConsultationDialog from '@/components/customeraccounts/CustomerConsultationDialog';

import { createAccount, registerPayment, cancelAccount } from '@/lib/customerAccountService';
import { recomputeAccountTotals } from '@/lib/customerAccountCalc';
import { printPaymentReceipt, printInstallmentPlan } from '@/lib/customerAccountPdf';
import { canCancelAccount, canNegotiateDebt, canViewCustomerAccountReports } from '@/lib/userRoles';
import { downloadCsv } from '@/lib/csvExport';
import CancelReasonDialog from '@/components/CancelReasonDialog';

const STATUS_FILTERS = [
  { value: 'all', label: 'Todas' },
  { value: 'open', label: 'Em aberto' },
  { value: 'overdue', label: 'Vencidas' },
  { value: 'partial', label: 'Parciais' },
  { value: 'paid', label: 'Quitadas' },
];

export default function CustomerAccounts() {
  const { user } = useAuth();
  const { toast } = useToast();
  const qc = useQueryClient();
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [formOpen, setFormOpen] = useState(false);
  const [detail, setDetail] = useState(null);
  const [payTarget, setPayTarget] = useState(null);
  const [payInstallment, setPayInstallment] = useState(null);
  const [selected, setSelected] = useState(new Set());
  const [negotiateOpen, setNegotiateOpen] = useState(false);
  const [showReport, setShowReport] = useState(false);
  const [cancelTarget, setCancelTarget] = useState(null);
  const [consultationOpen, setConsultationOpen] = useState(false);
  const role = user?.role;
  const canCancel = canCancelAccount(role);
  const canNegotiate = canNegotiateDebt(role);
  const canReports = canViewCustomerAccountReports(role);

  const { data: accounts = [], isLoading } = useQuery({
    queryKey: ['customerAccounts'],
    queryFn: async () => {
      const list = await base44.entities.CustomerAccount.list('-created_date', 500);
      return (list || []).map((a) => recomputeAccountTotals(a));
    },
  });

  const { data: customers = [] } = useQuery({
    queryKey: ['customers'],
    queryFn: async () => base44.entities.Customer.list('name', 500),
  });

  const filtered = useMemo(() => {
    let r = accounts;
    if (statusFilter !== 'all') r = r.filter((a) => a.status === statusFilter);
    if (search.trim()) {
      const q = search.toLowerCase();
      r = r.filter((a) =>
        (a.customer_name || '').toLowerCase().includes(q) ||
        (a.account_number || '').toLowerCase().includes(q) ||
        (a.order_code || '').toLowerCase().includes(q)
      );
    }
    return r;
  }, [accounts, statusFilter, search]);

  const handleCreate = async (data) => {
    try {
      await createAccount(data, user);
      toast({ title: 'Conta criada com sucesso' });
      qc.invalidateQueries({ queryKey: ['customerAccounts'] });
    } catch (e) {
      toast({ title: 'Erro ao criar conta', description: String(e.message || e), variant: 'destructive' });
      throw e;
    }
  };

  const handlePay = async ({ installmentNumber, amount, method, notes }) => {
    try {
      const updated = await registerPayment({ account: payTarget, installmentNumber, amount, method, responsible: user?.full_name || user?.email, notes, user });
      toast({ title: 'Pagamento registrado', description: 'Convênio e Financeiro atualizados.' });
      qc.invalidateQueries({ queryKey: ['customerAccounts'] });
      qc.invalidateQueries({ queryKey: ['financialEntries'] });
      setDetail(null);
      // Oferecer recibo de pagamento via PDF Editor
      const lastPayment = (updated.payment_history || []).slice(-1)[0];
      if (lastPayment) {
        try { await printPaymentReceipt({ account: updated, payment: lastPayment, user }); }
        catch { /* best-effort */ }
      }
    } catch (e) {
      if (e?.name === 'PaymentPropagationError') {
        toast({ title: 'Atenção: propagação financeira falhou', description: e.message, variant: 'destructive' });
        qc.invalidateQueries({ queryKey: ['customerAccounts'] });
        qc.invalidateQueries({ queryKey: ['financialEntries'] });
        setDetail(null);
        setPayTarget(null);
        setPayInstallment(null);
        return;
      }
      toast({ title: 'Erro no pagamento', description: String(e.message || e), variant: 'destructive' });
      throw e;
    }
  };

  const toggleSelect = (id) => {
    setSelected((s) => {
      const next = new Set(s);
      if (next.has(id)) next.delete(id); else next.add(id);
      return next;
    });
  };
  const toggleAll = () => {
    const eligible = filtered.filter((a) => a.status !== 'cancelled' && a.status !== 'paid' && a.status !== 'negotiated');
    setSelected((s) => {
      if (eligible.every((a) => s.has(a.id))) return new Set();
      return new Set(eligible.map((a) => a.id));
    });
  };
  const selectedAccounts = useMemo(
    () => accounts.filter((a) => selected.has(a.id)),
    [accounts, selected]
  );

  const handleCancel = (account) => setCancelTarget(account);

  const confirmCancel = async (reason) => {
    if (!cancelTarget) return;
    try {
      await cancelAccount({ account: cancelTarget, reason, user });
      toast({ title: 'Conta cancelada', description: 'Lançamentos financeiros vinculados foram estornados.' });
      qc.invalidateQueries({ queryKey: ['customerAccounts'] });
      qc.invalidateQueries({ queryKey: ['financialEntries'] });
      setDetail(null);
    } catch (e) {
      toast({ title: 'Erro ao cancelar', description: String(e.message || e), variant: 'destructive' });
    } finally {
      setCancelTarget(null);
    }
  };

  const openPay = (account, installment) => {
    setPayTarget(account);
    setPayInstallment(installment || null);
  };

  const exportCsv = () => {
    const rows = filtered.map((a) => ({
      Conta: a.account_number, Cliente: a.customer_name, Origem: a.origin,
      'Valor Atual': a.current_amount, Pago: a.paid_amount, Saldo: a.balance,
      Vencimento: a.due_date, Status: a.status, Parcelas: (a.installments || []).length,
      Pedido: a.order_code || '',
    }));
    downloadCsv(rows, `contas-receber-${new Date().toISOString().slice(0, 10)}.csv`);
  };

  return (
    <div className="p-4 md:p-6 space-y-4 max-w-7xl mx-auto">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="text-xl font-bold">Convênio</h1>
          <p className="text-sm text-muted-foreground">Controle completo das contas, crediário e convênio dos clientes.</p>
        </div>
        <div className="flex gap-2 flex-wrap">
          {canReports && (
            <Button variant="outline" size="sm" onClick={() => setShowReport((v) => !v)}>
              <BarChart3 className="h-4 w-4 mr-1" /> Relatórios
            </Button>
          )}
          <Button variant="outline" size="sm" onClick={() => setConsultationOpen(true)}>
            <UserSearch className="h-4 w-4 mr-1" /> Consultar Cliente
          </Button>
          <Button variant="outline" size="sm" onClick={exportCsv}>
            <Download className="h-4 w-4 mr-1" /> Exportar
          </Button>
          {canNegotiate && selectedAccounts.length > 0 && (
            <Button variant="outline" size="sm" className="text-amber-700 border-amber-300" onClick={() => setNegotiateOpen(true)}>
              <Handshake className="h-4 w-4 mr-1" /> Negociar ({selectedAccounts.length})
            </Button>
          )}
          <Button size="sm" onClick={() => setFormOpen(true)}>
            <Plus className="h-4 w-4 mr-1" /> Nova Conta
          </Button>
        </div>
      </div>

      <CustomerAccountsReminders accounts={accounts} onView={setDetail} />
      <CustomerAccountsDashboard accounts={accounts} onFilter={(f) => setStatusFilter(f)} />
      {showReport && canReports && <CustomerAccountsReport accounts={accounts} user={user} />}

      <Card className="p-3">
        <div className="flex flex-wrap items-center gap-2 mb-3">
          <div className="relative flex-1 min-w-[200px]">
            <Search className="h-4 w-4 absolute left-2 top-1/2 -translate-y-1/2 text-muted-foreground" />
            <Input className="pl-8" placeholder="Buscar por cliente, conta ou pedido..." value={search} onChange={(e) => setSearch(e.target.value)} />
          </div>
          <div className="flex gap-1 flex-wrap">
            {STATUS_FILTERS.map((f) => (
              <Button
                key={f.value}
                size="sm"
                variant={statusFilter === f.value ? 'default' : 'outline'}
                onClick={() => setStatusFilter(f.value)}
                className="h-8"
              >
                {f.label}
              </Button>
            ))}
          </div>
        </div>
        <CustomerAccountsList
          accounts={filtered}
          loading={isLoading}
          onView={setDetail}
          onPay={(a) => openPay(a, null)}
          onCancel={canCancel ? handleCancel : undefined}
          selected={canNegotiate ? selected : undefined}
          onToggleSelect={canNegotiate ? toggleSelect : undefined}
          onToggleAll={canNegotiate ? toggleAll : undefined}
          allSelected={canNegotiate && filtered.filter((a) => a.status !== 'cancelled' && a.status !== 'paid' && a.status !== 'negotiated').every((a) => selected.has(a.id))}
        />
      </Card>

      <CustomerAccountFormDialog open={formOpen} onClose={() => setFormOpen(false)} onSaved={handleCreate} customers={customers} user={user} />
      <CustomerAccountDetailDialog
        open={!!detail}
        account={detail}
        onClose={() => setDetail(null)}
        onPay={openPay}
        onCancel={handleCancel}
        onRefresh={() => qc.invalidateQueries({ queryKey: ['customerAccounts'] })}
        user={user}
      />
      <CustomerAccountPaymentDialog
        open={!!payTarget}
        account={payTarget}
        installment={payInstallment}
        onClose={() => { setPayTarget(null); setPayInstallment(null); }}
        onConfirm={handlePay}
        user={user}
      />
      <NegotiateDebtDialog
        open={negotiateOpen}
        accounts={selectedAccounts}
        onClose={() => setNegotiateOpen(false)}
        onDone={() => {
          setSelected(new Set());
          qc.invalidateQueries({ queryKey: ['customerAccounts'] });
          qc.invalidateQueries({ queryKey: ['financialEntries'] });
        }}
        user={user}
      />
      <CustomerConsultationDialog
        open={consultationOpen}
        onClose={() => setConsultationOpen(false)}
        customers={customers}
        user={user}
      />
      <CancelReasonDialog
        open={!!cancelTarget}
        onOpenChange={(v) => !v && setCancelTarget(null)}
        onConfirm={confirmCancel}
        title="Cancelar conta"
        confirmLabel="Cancelar conta"
      />
    </div>
  );
}