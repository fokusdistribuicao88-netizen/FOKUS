import React, { useState, useMemo } from 'react';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { useAuth } from '@/lib/AuthContext';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Bell, CheckCheck, Info, CheckCircle2, AlertTriangle, XCircle, Trash2 } from 'lucide-react';

const TYPE_META = {
  info: { icon: Info, color: 'text-blue-600', bg: 'bg-blue-50', border: 'border-blue-200' },
  success: { icon: CheckCircle2, color: 'text-green-600', bg: 'bg-green-50', border: 'border-green-200' },
  warning: { icon: AlertTriangle, color: 'text-amber-600', bg: 'bg-amber-50', border: 'border-amber-200' },
  destructive: { icon: XCircle, color: 'text-red-600', bg: 'bg-red-50', border: 'border-red-200' },
};

export default function Notifications() {
  const { user } = useAuth();
  const qc = useQueryClient();
  const [filter, setFilter] = useState('all');

  const { data: notifications = [], isLoading } = useQuery({
    queryKey: ['notifications'],
    queryFn: () => base44.entities.Notification.list('-created_date', 200),
  });

  const unreadCount = useMemo(() => (notifications || []).filter((n) => !n.read).length, [notifications]);

  const filtered = useMemo(() => {
    if (filter === 'unread') return (notifications || []).filter((n) => !n.read);
    if (filter !== 'all') return (notifications || []).filter((n) => n.type === filter);
    return notifications || [];
  }, [notifications, filter]);

  const markAsRead = async (id) => {
    await base44.entities.Notification.update(id, { read: true });
    qc.invalidateQueries({ queryKey: ['notifications'] });
  };

  const markAllAsRead = async () => {
    const unread = (notifications || []).filter((n) => !n.read);
    if (!unread.length) return;
    await base44.entities.Notification.bulkUpdate(unread.map((n) => ({ id: n.id, read: true })));
    qc.invalidateQueries({ queryKey: ['notifications'] });
  };

  const deleteNotification = async (id) => {
    await base44.entities.Notification.delete(id);
    qc.invalidateQueries({ queryKey: ['notifications'] });
  };

  const fmtDate = (d) => {
    if (!d) return '';
    const date = new Date(d);
    const now = new Date();
    const diff = (now - date) / (1000 * 60);
    if (diff < 1) return 'agora';
    if (diff < 60) return `${Math.floor(diff)}min atrás`;
    if (diff < 1440) return `${Math.floor(diff / 60)}h atrás`;
    return date.toLocaleDateString('pt-BR', { day: '2-digit', month: '2-digit', hour: '2-digit', minute: '2-digit' });
  };

  return (
    <div className="min-h-screen bg-background">
      <div className="max-w-3xl mx-auto px-4 sm:px-6 py-6 space-y-4">
        <div className="flex items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <Bell className="w-5 h-5 text-muted-foreground" />
            <h1 className="text-xl font-bold">Notificações</h1>
            {unreadCount > 0 && (
              <span className="bg-red-500 text-white text-xs font-bold px-2 py-0.5 rounded-full">{unreadCount}</span>
            )}
          </div>
          {unreadCount > 0 && (
            <Button variant="outline" size="sm" onClick={markAllAsRead} className="gap-1.5">
              <CheckCheck className="w-4 h-4" /> Marcar todas como lidas
            </Button>
          )}
        </div>

        <div className="flex gap-1.5 flex-wrap">
          {[
            { v: 'all', l: 'Todas' },
            { v: 'unread', l: 'Não lidas' },
            { v: 'info', l: 'Informação' },
            { v: 'success', l: 'Sucesso' },
            { v: 'warning', l: 'Aviso' },
            { v: 'destructive', l: 'Erro' },
          ].map((f) => (
            <Button
              key={f.v}
              size="sm"
              variant={filter === f.v ? 'default' : 'outline'}
              onClick={() => setFilter(f.v)}
              className="h-8"
            >
              {f.l}
            </Button>
          ))}
        </div>

        {isLoading && <p className="text-sm text-muted-foreground text-center py-10">Carregando...</p>}

        {!isLoading && filtered.length === 0 && (
          <Card className="p-8 text-center">
            <Bell className="w-10 h-10 mx-auto mb-2 text-muted-foreground opacity-40" />
            <p className="text-sm text-muted-foreground">Nenhuma notificação.</p>
          </Card>
        )}

        <div className="space-y-2">
          {filtered.map((n) => {
            const meta = TYPE_META[n.type] || TYPE_META.info;
            return (
              <Card
                key={n.id}
                className={`p-3 flex items-start gap-3 transition-colors ${n.read ? 'opacity-60' : ''} ${meta.border}`}
              >
                <div className={`w-9 h-9 rounded-full ${meta.bg} flex items-center justify-center shrink-0`}>
                  <meta.icon className={`w-4 h-4 ${meta.color}`} />
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2">
                    <p className="text-sm font-semibold truncate">{n.title}</p>
                    {!n.read && <span className="w-2 h-2 rounded-full bg-blue-500 shrink-0" />}
                  </div>
                  {n.description && <p className="text-xs text-muted-foreground mt-0.5 break-words">{n.description}</p>}
                  <p className="text-[10px] text-muted-foreground mt-1">{fmtDate(n.created_date)}</p>
                </div>
                <div className="flex items-center gap-1 shrink-0">
                  {!n.read && (
                    <Button variant="ghost" size="icon" className="h-7 w-7" onClick={() => markAsRead(n.id)} title="Marcar como lida">
                      <CheckCheck className="w-3.5 h-3.5" />
                    </Button>
                  )}
                  <Button variant="ghost" size="icon" className="h-7 w-7 text-muted-foreground hover:text-red-600" onClick={() => deleteNotification(n.id)} title="Excluir">
                    <Trash2 className="w-3.5 h-3.5" />
                  </Button>
                </div>
              </Card>
            );
          })}
        </div>
      </div>
    </div>
  );
}