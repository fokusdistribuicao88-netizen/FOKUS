import React, { useState, useMemo, useEffect, useRef } from 'react';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { useAuth } from '@/lib/AuthContext';
import { useToast } from '@/components/ui/use-toast';
import { Button } from '@/components/ui/button';
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs';
import { ShoppingCart, Wallet, History, BarChart3, Trash2 } from 'lucide-react';

import ProductGrid from '@/components/pos/ProductGrid';
import PosCart from '@/components/pos/PosCart';
import PaymentDialog from '@/components/pos/PaymentDialog';
import PrintSaleDialog from '@/components/pos/PrintSaleDialog';
import PixPaymentNotifier from '@/components/pos/PixPaymentNotifier';
import PosAccessDenied from '@/components/pos/PosAccessDenied';
import PosSaleSuccessCard from '@/components/pos/PosSaleSuccessCard';
import CashControl from '@/components/pos/CashControl';
import PosHistory from '@/components/pos/PosHistory';
import PosReports from '@/components/pos/PosReports';
import { hasPosAccess, canPos, getPosPerms } from '@/lib/posPermissions';
import { logActivity } from '@/lib/activityLog';
import { finalizeSale } from '@/lib/posSaleService';
import { InsufficientStockError } from '@/lib/stockValidation';
import InsufficientStockDialog from '@/components/pos/InsufficientStockDialog';
import CreditLimitDialog from '@/components/customeraccounts/CreditLimitDialog';
import { checkCreditForSale } from '@/lib/customerAccountService';
import { canOverrideCreditLimit } from '@/lib/userRoles';

const TERM_METHODS = ['contas_receber', 'convenio', 'crediario', 'credit', 'boleto', 'transfer', 'cheque'];
const termAmountOf = (payments) => (payments || []).filter((p) => TERM_METHODS.includes(p.method)).reduce((s, p) => s + (Number(p.amount) || 0), 0);
import {
  SYSTEM_TABLES, isSystemCode, resolveProductPrice } from
'@/lib/posPriceTables';
import {
  AUTO_TABLE_VALUE, resolveAutoTable, selectionFor, tableLabel, isSystemId as isSystemTableId,
} from '@/lib/priceRules';

const fmt = (v) => `R$ ${(Number(v) || 0).toFixed(2).replace('.', ',')}`;
const DELIV_LABELS = { retirada: 'Retirada no local', empresa: 'Entrega pela empresa', transportadora: 'Transportadora', motoboy: 'Motoboy', agendada: 'Entrega agendada' };

export default function POS() {
  const { user } = useAuth();
  const { toast } = useToast();
  const qc = useQueryClient();
  const [tab, setTab] = useState('sale');
  const [cart, setCart] = useState([]);
  const [customer, setCustomer] = useState(null);
  const [discount, setDiscount] = useState(0);
  const [notes, setNotes] = useState('');
  const [priceTableId, setPriceTableId] = useState('PADRAO');
  const [tableManual, setTableManual] = useState(false);

  const [payOpen, setPayOpen] = useState(false);
  const [finishing, setFinishing] = useState(false);
  const [lastSale, setLastSale] = useState(null);
  const [printOpen, setPrintOpen] = useState(false);
  const [lastSaleIsDelivery, setLastSaleIsDelivery] = useState(false);
  const [printSale, setPrintSale] = useState(null);
  const [printIsDelivery, setPrintIsDelivery] = useState(false);
  const [stockIssue, setStockIssue] = useState(null);
  const [creditIssue, setCreditIssue] = useState(null);
  const creditBypass = useRef(false);
  const lastArgs = useRef(null);
  const canOverride = canOverrideCreditLimit(user?.role);

  const handlePrePrint = (preSale, isDelivery) => {
    setPrintSale(preSale);
    setPrintIsDelivery(isDelivery);
    setPrintOpen(true);
  };

  const { data: products = [] } = useQuery({ queryKey: ['products'], queryFn: () => base44.entities.Product.list(), staleTime: 60 * 1000 });
  const productMap = useMemo(() => { const m = {}; products.forEach((p) => { m[p.id] = p; }); return m; }, [products]);
  const { data: customers = [] } = useQuery({ queryKey: ['customers'], queryFn: () => base44.entities.Customer.list(), staleTime: 60 * 1000 });
  const { data: employees = [] } = useQuery({ queryKey: ['employees'], queryFn: () => base44.entities.Employee.list(), staleTime: 60 * 1000 });
  const { data: priceTables = [], isLoading: priceTablesLoading } = useQuery({
    queryKey: ['price-tables'],
    queryFn: () => base44.entities.PriceTable.list('-updated_date'),
    staleTime: 30 * 1000
  });

  const { data: settings } = useQuery({
    queryKey: ['settings'],
    queryFn: async () => { const l = await base44.entities.Settings.list(); return l[0] || null; },
    staleTime: 30 * 1000,
  });

  const totalQty = useMemo(() => cart.reduce((s, i) => s + (Number(i.quantity) || 0), 0), [cart]);

  const isAuto = priceTableId === AUTO_TABLE_VALUE;
  const autoResolved = useMemo(() => {
    if (!isAuto) return null;
    return resolveAutoTable({ rules: settings?.price_rules, priceTables, customer, totalQty });
  }, [isAuto, settings, priceTables, customer, totalQty]);

  const effectiveTableId = isAuto ? (autoResolved?.priceTableId || 'PADRAO') : priceTableId;
  const isSystem = isSystemCode(effectiveTableId);
  const activeTable = priceTables.find((t) => t.id === effectiveTableId || (t.code && t.code === effectiveTableId)) || null;
  const { data: tableItems = [] } = useQuery({
    queryKey: ['price-table-items', activeTable?.id],
    queryFn: () => base44.entities.PriceTableItem.filter({ price_table_id: activeTable.id }),
    enabled: !!activeTable?.id,
    staleTime: 30 * 1000
  });
  const itemsByProduct = useMemo(() => {
    const m = {};
    tableItems.forEach((it) => {m[it.product_id] = it;});
    return m;
  }, [tableItems]);

  const selection = useMemo(() => selectionFor(effectiveTableId, priceTables), [effectiveTableId, priceTables]);



  // Se a tabela selecionada foi excluída no gerenciador, volta para Padrão
  useEffect(() => {
    if (isAuto || isSystem) return;
    if (!priceTablesLoading && !priceTables.some((t) => t.id === effectiveTableId)) {
      setPriceTableId('PADRAO');
    }
  }, [effectiveTableId, priceTables, priceTablesLoading, isAuto, isSystem]);

  const priceOf = (p) => resolveProductPrice(p, selection, itemsByProduct);

  const productsById = useMemo(() => {
    const m = {};
    products.forEach((p) => {m[p.id] = p;});
    return m;
  }, [products]);

  const manualEdits = useRef(new Set());

  const recalcCartPrices = ({ skipManual = false } = {}) => {
    setCart((prev) => prev.map((it) => {
      if (skipManual && manualEdits.current.has(it.product_id)) return it;
      const p = productsById[it.product_id];
      if (!p) return it;
      const up = resolveProductPrice(p, selection, itemsByProduct);
      return { ...it, unit_price: up, subtotal: it.quantity * up };
    }));
  };

  // Trocar de tabela de preço (ou regra automática) reprecifica todos os itens do carrinho
  useEffect(() => {
    manualEdits.current.clear();
    recalcCartPrices();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [effectiveTableId]);

  // Quando os itens de uma tabela (personalizada ou do sistema) terminam de carregar, ajusta os preços (sem sobrescrever edições manuais)
  useEffect(() => {
    recalcCartPrices({ skipManual: true });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [itemsByProduct]);

  const { data: myPerm } = useQuery({
    queryKey: ['myPermission', user?.id],
    queryFn: () => base44.entities.UserPermission.filter({ user_id: user?.id }),
    enabled: !!user?.id
  });
  const perm = myPerm?.[0];

  const access = hasPosAccess(user);
  const perms = getPosPerms(user, perm);
  const canSell = canPos(user, perm, 'Realizar vendas');
  const canDiscount = canPos(user, perm, 'Aplicar desconto');
  const canEditPrice = canPos(user, perm, 'Alterar preço manualmente');
  const canCash = canPos(user, perm, 'Abrir e fechar caixa');
  const canCancel = canPos(user, perm, 'Cancelar venda');
  const canReports = canPos(user, perm, 'Visualizar relatórios de vendas');
  const canPartial = user?.role === 'admin' || user?.role === 'gerente';

  const gross = useMemo(() => cart.reduce((s, i) => s + i.subtotal, 0), [cart]);
  const total = useMemo(() => Math.max(0, gross - (Number(discount) || 0)), [gross, discount]);

  const addToCart = (p, qty = 1) => {
    const n = Number(qty) || 1;
    setCart((prev) => {
      const idx = prev.findIndex((i) => i.product_id === p.id);
      if (idx >= 0) {
        return prev.map((it, i) => i === idx ? { ...it, quantity: it.quantity + n, subtotal: (it.quantity + n) * it.unit_price } : it);
      }
      const up = priceOf(p);
      return [...prev, { product_id: p.id, product_name: p.name, quantity: n, unit_price: up, subtotal: up * n, unit_type: p.unit_type }];
    });
  };

  const clearCart = () => {setCart([]);setCustomer(null);setDiscount(0);setNotes('');};

  const handleOpenPay = async () => {
    if (!cart.length) return;
    try {
      const regs = await base44.entities.CashRegister.filter({ status: 'open', operator_email: user?.email });
      if (!regs || regs.length === 0) {
        toast({ title: 'Caixa fechado', description: 'Abra o caixa na aba "Caixa" antes de vender.', variant: 'destructive' });
        setTab('cash');
        return;
      }
      setPayOpen(true);
    } catch (e) {
      toast({ title: 'Erro ao verificar caixa', description: String(e.message || e), variant: 'destructive' });
    }
  };

  const finalize = async (payments, delivery, finalTotal, payrollDiscount) => {
    if (!cart.length) return;
    // Verificação de limite de crédito (venda a prazo para cliente — não funcionário/crediário)
    const isEmployeeCrediario = !!payrollDiscount?.enabled && payrollDiscount?.type === 'crediario' && payrollDiscount?.employee;
    const termAmount = termAmountOf(payments);
    if (termAmount > 0 && !isEmployeeCrediario && !creditBypass.current && customer?.id && customer?.credit_limit > 0) {
      const check = await checkCreditForSale({ customer, termAmount });
      if (!check.ok) {
        lastArgs.current = { payments, delivery, finalTotal, payrollDiscount };
        setCreditIssue(check);
        return;
      }
    }
    setFinishing(true);
    try {
      const { order, saleCode, lowStockAlerts, partialRemaining, isDelivery, payrollDiscount: isPayroll, crediario: isCrediario, customerAccountError } = await finalizeSale({
        cart, customer, payments, total: finalTotal, discount, freight: delivery?.freight || 0,
        notes, delivery, user, settings, payrollDiscount,
        priceTableId: effectiveTableId,
        priceTableName: tableLabel(effectiveTableId, priceTables),
      });

      const delivDesc = isDelivery ? ` — Entrega: ${delivery.type}${delivery.address ? ` (${delivery.address})` : ''}` : '';
      const partialDesc = partialRemaining > 0 ? ` — Parcial (saldo ${fmt(partialRemaining)})` : '';
      const payrollDesc = isPayroll ? ` — Desconto em folha (${payrollDiscount?.competence})` : '';
      const crediarioDesc = isCrediario ? ` — Crediário (funcionário: ${payrollDiscount?.employee?.name || customer?.name}${payrollDiscount?.competence ? `, folha ${payrollDiscount.competence}` : ''})` : '';
      logActivity({
        action: isPayroll ? 'pos_sale_payroll_discount' : isCrediario ? 'pos_sale_crediario' : 'pos_sale',
        description: `Venda PDV #${saleCode} - ${fmt(finalTotal)} — Cliente: ${customer?.name || 'Consumidor Final'} — Pag: ${isPayroll ? 'Desconto em folha' : isCrediario ? 'Crediário' : payments.map((p) => p.label).join(', ')}${delivDesc}${partialDesc}${payrollDesc}${crediarioDesc}`,
        user, entityType: 'Order', entityId: order.id,
        metadata: JSON.stringify({ total: finalTotal, discount, freight: delivery?.freight || 0, payments: (isPayroll || isCrediario) ? [] : payments.map((p) => p.method), delivery: delivery?.type || 'retirada', partial: partialRemaining > 0, payroll_discount: !!isPayroll, payroll_competence: payrollDiscount?.competence || '', crediario: !!isCrediario })
      });

      if (lowStockAlerts.length) {
        const names = lowStockAlerts.map((a) => `${a.product_name} (${a.newQty})`).join(', ');
        toast({ title: '⚠️ Alerta de estoque baixo', description: names, variant: 'destructive' });
        logActivity({ action: 'low_stock_alert', description: `Estoque baixo após venda #${saleCode}: ${names}`, user, entityType: 'Product' });
      }

      if (customerAccountError) {
        toast({ title: 'Atenção: conta a receber não criada', description: 'A gestão de parcelas do cliente pode estar incompleta. Verifique o Contas a Receber.', variant: 'destructive' });
      }

      qc.invalidateQueries({ queryKey: ['orders'] });
      qc.invalidateQueries({ queryKey: ['products'] });
      qc.invalidateQueries({ queryKey: ['financialEntries'] });
      qc.invalidateQueries({ queryKey: ['cashRegisters'] });
      qc.invalidateQueries({ queryKey: ['customers'] });
      if (isPayroll || isCrediario) qc.invalidateQueries({ queryKey: ['employee-purchases'] });

      const enrichedSale = {
        ...order, payments, operator_name: user?.full_name || user?.email,
        delivery_type_label: delivery?.type ? DELIV_LABELS[delivery.type] || delivery.type : 'Retirada',
        delivery_address: delivery?.address || order.customer_address,
        delivery_notes: delivery?.notes || order.delivery_notes
      };
      setLastSale(enrichedSale);
      setLastSaleIsDelivery(isDelivery);
      setPrintSale(enrichedSale);
      setPrintIsDelivery(isDelivery);
      setPayOpen(false);
      clearCart();
      const msg = isPayroll ?
      `#${saleCode} — ${fmt(finalTotal)} (desconto em folha — ${payrollDiscount?.competence})` :
      isCrediario ?
      `#${saleCode} — ${fmt(finalTotal)} (crediário — ${payrollDiscount?.employee?.name || customer?.name}${payrollDiscount?.competence ? `, folha ${payrollDiscount.competence}` : ''})` :
      isDelivery ?
      `#${saleCode} — ${fmt(finalTotal)} (entrega encaminhada para Logística)` :
      partialRemaining > 0 ?
      `#${saleCode} — Recebido ${fmt(payments.reduce((s, p) => s + p.amount, 0))} / ${fmt(finalTotal)} (saldo em Contas a Receber)` :
      `#${saleCode} — Total: ${fmt(finalTotal)}`;
      toast({ title: isPayroll ? 'Compra lançada para desconto em folha!' : isCrediario ? 'Crediário lançado para o funcionário!' : 'Venda concluída!', description: msg });

      // Abrir tela de impressão automaticamente conforme configuração
      const mode = settings?.auto_print_mode || 'always';
      const minVal = Number(settings?.auto_print_min_value) || 0;
      const shouldPrint = mode === 'always' ||
      mode === 'delivery_only' && isDelivery ||
      mode === 'above_value' && finalTotal >= minVal;
      if (shouldPrint) {
        setTimeout(() => setPrintOpen(true), 300);
      }
    } catch (e) {
      if (e instanceof InsufficientStockError) {
        setStockIssue(e.insufficient);
      } else {
        toast({ title: 'Erro ao finalizar venda', description: String(e.message || e), variant: 'destructive' });
      }
    } finally {
      setFinishing(false);
      creditBypass.current = false;
    }
  };

  if (!access) return <PosAccessDenied />;

  return (
    <div className="min-h-screen bg-muted/30">
      <div className="max-w-[1600px] mx-auto px-3 sm:px-4 lg:px-6 space-y-3 py-4">
        <div className="flex items-center justify-between gap-2">
          <h1 className="text-lg font-bold flex items-center gap-2"><ShoppingCart className="w-5 h-5 text-blue-700" /> PDV — Ponto de Venda</h1>
          <div className="text-xs text-muted-foreground hidden sm:block">{user?.full_name || user?.email}</div>
        </div>

        <Tabs value={tab} onValueChange={setTab}>
          <TabsList className="grid grid-cols-4 w-full max-w-md">
            <TabsTrigger value="sale" className="gap-1"><ShoppingCart className="w-4 h-4" /> Venda</TabsTrigger>
            <TabsTrigger value="cash" className="gap-1"><Wallet className="w-4 h-4" /> Caixa</TabsTrigger>
            <TabsTrigger value="history" className="gap-1"><History className="w-4 h-4" /> Histórico</TabsTrigger>
            <TabsTrigger value="reports" className="gap-1" disabled={!canReports}><BarChart3 className="w-4 h-4" /> Relatórios</TabsTrigger>
          </TabsList>

          <TabsContent value="sale" className="mt-4">
            <div className="grid lg:grid-cols-3 lg:grid-rows-1 gap-3 lg:h-[calc(100vh-140px)] lg:min-h-[600px]">
              <div className="lg:col-span-2 bg-card rounded-2xl border border-border p-3 flex flex-col min-h-0 h-[55vh] lg:h-full">
                <ProductGrid products={products} onAdd={addToCart} priceOf={priceOf} />
              </div>
              <div className="bg-card rounded-2xl border border-border flex flex-col min-h-0 overflow-hidden h-[55vh] lg:h-full">
                <div className="flex items-center justify-between p-2 border-b border-border">
                  <span className="text-sm font-semibold flex items-center gap-2"><ShoppingCart className="w-4 h-4" /> Carrinho</span>
                  {cart.length > 0 &&
                  <Button size="sm" variant="ghost" onClick={clearCart} className="text-red-500 gap-1 h-7">
                      <Trash2 className="w-3 h-3" /> Limpar
                    </Button>
                  }
                </div>
                <PosCart
                  cart={cart} setCart={setCart}
                  customers={customers} customer={customer} setCustomer={setCustomer}
                  employees={employees}
                  gross={gross} discount={discount} setDiscount={setDiscount} total={total}
                  canDiscount={canDiscount} notes={notes} setNotes={setNotes}
                  priceTableId={priceTableId}
                  setPriceTableId={(v) => { setTableManual(v !== AUTO_TABLE_VALUE); setPriceTableId(v); }}
                  canEditPrice={canEditPrice}
                  onPriceEdit={(pid) => pid && manualEdits.current.add(pid)}
                  autoLabel={isAuto ? `Automática · ${tableLabel(effectiveTableId, priceTables)}` : null}
                  priceTableOptions={[
                  ...SYSTEM_TABLES.map((s) => ({ value: s.code, label: s.name })),
                  ...priceTables.filter((t) => t.status !== 'inactive' && !SYSTEM_TABLES.some((s) => s.code === t.code)).map((t) => ({ value: t.id, label: t.name }))]
                  } />
                
                <div className="border-t border-border px-2 py-3">
                  <Button
                    onClick={handleOpenPay}
                    disabled={!cart.length || !canSell}
                    className="w-full h-12 text-base bg-green-600 hover:bg-green-700 gap-2">
                    
                    {canSell ? <><ShoppingCart className="w-5 h-5" /> Finalizar venda — {fmt(total)}</> : 'Sem permissão para vender'}
                  </Button>
                </div>
              </div>
            </div>
          </TabsContent>

          <TabsContent value="cash" className="mt-4"><CashControl canCash={canCash} settings={settings} /></TabsContent>
          <TabsContent value="history" className="mt-4"><PosHistory canCancel={canCancel} settings={settings} /></TabsContent>
          <TabsContent value="reports" className="mt-4">{canReports ? <PosReports /> : null}</TabsContent>
        </Tabs>
      </div>

      <PaymentDialog
        open={payOpen}
        onClose={() => setPayOpen(false)}
        cart={cart}
        customer={customer}
        gross={gross}
        discount={discount}
        notes={notes}
        total={total}
        canCredit={user?.role === 'admin' || user?.role === 'gerente' || user?.role === 'operador'}
        canPartial={canPartial}
        onConfirm={finalize}
        onPrePrint={handlePrePrint}
        operatorName={user?.full_name || user?.email}
        busy={finishing} />
      

      <PrintSaleDialog
        open={printOpen}
        onClose={() => setPrintOpen(false)}
        sale={printSale}
        settings={settings}
        productMap={productMap}
        isDelivery={printIsDelivery} />

      <PixPaymentNotifier />
      

      <PosSaleSuccessCard
        sale={lastSale && !printOpen ? lastSale : null}
        onPrint={() => setPrintOpen(true)}
        onClose={() => setLastSale(null)} />

      <InsufficientStockDialog
        open={!!stockIssue}
        items={stockIssue}
        onClose={() => setStockIssue(null)} />

      <CreditLimitDialog
        open={!!creditIssue}
        info={creditIssue}
        canOverride={canOverride}
        onClose={() => setCreditIssue(null)}
        onOverride={async () => {
          creditBypass.current = true;
          setCreditIssue(null);
          if (lastArgs.current) {
            const { payments, delivery, finalTotal, payrollDiscount } = lastArgs.current;
            lastArgs.current = null;
            await finalize(payments, delivery, finalTotal, payrollDiscount);
          }
        }} />
    </div>);

}