import React, { useState } from 'react';
import { useAuth } from '@/lib/AuthContext';
import { Mail, Shield } from 'lucide-react';
import AdminSidebar from '@/components/admin/AdminSidebar';
import AdminTopbar from '@/components/admin/AdminTopbar';
import FeatureMonitor from '@/components/admin/dashboard/FeatureMonitor';
import SettingsPanel from '@/components/admin/SettingsPanel';

export default function AdminProfile() {
  const { user } = useAuth();
  const [mobileOpen, setMobileOpen] = useState(false);
  const [search, setSearch] = useState('');

  const initials = (user?.full_name || user?.email || 'A')
    .split(' ')
    .map((p) => p[0])
    .slice(0, 2)
    .join('')
    .toUpperCase();

  return (
    <div className="min-h-screen bg-background flex">
      <aside className="hidden lg:block w-64 flex-shrink-0 sticky top-0 h-screen">
        <AdminSidebar search={search} />
      </aside>

      {mobileOpen && (
        <div className="lg:hidden fixed inset-0 z-50 flex">
          <div className="absolute inset-0 bg-black/40" onClick={() => setMobileOpen(false)} />
          <div className="relative w-72 max-w-[80%] h-full shadow-xl">
            <AdminSidebar search={search} onClose={() => setMobileOpen(false)} />
          </div>
        </div>
      )}

      <div className="flex-1 min-w-0 flex flex-col">
        <AdminTopbar onMenuClick={() => setMobileOpen(true)} search={search} onSearchChange={setSearch} />

        <main className="flex-1 p-4 sm:p-6 lg:p-8 space-y-6 overflow-y-auto">
          <div>
            <h1 className="text-2xl font-bold text-foreground">Perfil</h1>
            <p className="text-sm text-muted-foreground mt-1">
              Suas informações e configurações do sistema.
            </p>
          </div>

          <div className="rounded-2xl border border-border bg-card p-5 sm:p-6 shadow-sm flex flex-col sm:flex-row sm:items-center gap-4">
            <div className="w-16 h-16 rounded-full bg-gradient-to-br from-blue-600 to-blue-800 text-white text-xl font-bold flex items-center justify-center flex-shrink-0">
              {initials}
            </div>
            <div className="space-y-1">
              <h2 className="text-lg font-semibold text-foreground">{user?.full_name || 'Administrador'}</h2>
              <div className="flex flex-wrap items-center gap-x-4 gap-y-1 text-sm text-muted-foreground">
                {user?.email && (
                  <span className="inline-flex items-center gap-1.5">
                    <Mail className="w-4 h-4" />
                    {user.email}
                  </span>
                )}
                <span className="inline-flex items-center gap-1.5 capitalize">
                  <Shield className="w-4 h-4" />
                  {user?.role || 'admin'}
                </span>
              </div>
            </div>
          </div>

          <FeatureMonitor />
          <SettingsPanel />
        </main>
      </div>
    </div>
  );
}