import React, { useMemo } from 'react';
import { useQuery } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Contact, UserCheck, UserX, UserPlus } from 'lucide-react';
import ClientsTab from '@/components/users/ClientsTab';

export default function Clients() {
  const { data: customers = [] } = useQuery({ queryKey: ['customers'], queryFn: () => base44.entities.Customer.list(), staleTime: 30000 });

  const stats = useMemo(() => {
    const active = customers.filter((c) => (c.status || 'active') === 'active').length;
    const inactive = customers.length - active;
    const now = new Date();
    const newThisMonth = customers.filter((c) => {
      if (!c.created_date) return false;
      const d = new Date(c.created_date);
      return d.getMonth() === now.getMonth() && d.getFullYear() === now.getFullYear();
    }).length;
    return { total: customers.length, active, inactive, newThisMonth };
  }, [customers]);

  const cards = [
    { label: 'Total de clientes', value: stats.total, icon: Contact, accent: 'text-violet-600' },
    { label: 'Clientes ativos', value: stats.active, icon: UserCheck, accent: 'text-green-600' },
    { label: 'Clientes inativos', value: stats.inactive, icon: UserX, accent: 'text-amber-600' },
    { label: 'Novos clientes (mês)', value: stats.newThisMonth, icon: UserPlus, accent: 'text-blue-600' },
  ];

  return (
    <div className="min-h-screen bg-background">
      <header className="sticky top-0 z-40 bg-card/95 backdrop-blur-md border-b border-border shadow-sm">
        <div className="max-w-[1600px] mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center gap-3 h-16">
            <div className="w-9 h-9 bg-gradient-to-br from-violet-600 to-indigo-800 rounded-lg flex items-center justify-center">
              <Contact className="w-5 h-5 text-white" />
            </div>
            <div className="min-w-0">
              <h1 className="text-base font-bold text-foreground leading-tight truncate">Clientes</h1>
              <p className="text-xs text-muted-foreground">Cadastro e gestão de clientes</p>
            </div>
          </div>
        </div>
      </header>

      <main className="max-w-[1600px] mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-5">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
          {cards.map((c) => {
            const Icon = c.icon;
            return (
              <div key={c.label} className="bg-card rounded-xl border border-border p-4 flex items-center gap-3">
                <div className={`w-10 h-10 rounded-lg bg-muted/60 flex items-center justify-center ${c.accent}`}><Icon className="w-5 h-5" /></div>
                <div className="min-w-0"><p className="text-xs text-muted-foreground truncate">{c.label}</p><p className="text-xl font-bold text-foreground">{c.value}</p></div>
              </div>
            );
          })}
        </div>

        <ClientsTab />
      </main>
    </div>
  );
}