import React, { useState, useMemo } from 'react';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { useAuth } from '@/lib/AuthContext';
import { isStaffRole } from '@/lib/userRoles';
import { getHrPerms, canHr, hasHrAccess } from '@/lib/hrPermissions';
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs';
import { Users, Wallet, Clock, FileText, Gift, ShoppingCart } from 'lucide-react';
import EmployeeList from '@/components/hr/EmployeeList';
import EmployeeFormDialog from '@/components/hr/EmployeeFormDialog';
import EmployeeDetailDialog from '@/components/hr/EmployeeDetailDialog';
import AdvancesTab from '@/components/hr/AdvancesTab';
import OvertimeTab from '@/components/hr/OvertimeTab';
import BonificationsTab from '@/components/hr/BonificationsTab';
import PayrollTab from '@/components/hr/PayrollTab';
import PurchasesTab from '@/components/hr/PurchasesTab';

export default function Employees() {
  const { user } = useAuth();
  const qc = useQueryClient();
  const [tab, setTab] = useState('list');
  const [formOpen, setFormOpen] = useState(false);
  const [editing, setEditing] = useState(null);
  const [viewing, setViewing] = useState(null);

  const { data: perm } = useQuery({
    queryKey: ['perm', user?.id],
    queryFn: () => base44.entities.UserPermission.filter({ user_id: user?.id }).then((r) => r[0]),
    enabled: !!user,
  });

  const { data: employees = [], refetch: refEmp } = useQuery({
    queryKey: ['employees'],
    queryFn: () => base44.entities.Employee.list(),
  });
  const { data: advances = [], refetch: refAdv } = useQuery({
    queryKey: ['employee-advances'],
    queryFn: () => base44.entities.EmployeeAdvance.list(),
  });
  const { data: purchases = [], refetch: refPur } = useQuery({
    queryKey: ['employee-purchases'],
    queryFn: () => base44.entities.EmployeePurchase.list(),
  });
  const { data: overtimes = [], refetch: refOvt } = useQuery({
    queryKey: ['overtimes'],
    queryFn: () => base44.entities.Overtime.list(),
  });
  const { data: payrolls = [], refetch: refPay } = useQuery({
    queryKey: ['payrolls'],
    queryFn: () => base44.entities.Payroll.list(),
  });
  const { data: bonifications = [], refetch: refBon } = useQuery({
    queryKey: ['bonifications'],
    queryFn: () => base44.entities.Bonification.list(),
  });

  const reload = () => {
    qc.invalidateQueries(['employees']);
    qc.invalidateQueries(['employee-advances']);
    qc.invalidateQueries(['employee-purchases']);
    qc.invalidateQueries(['overtimes']);
    qc.invalidateQueries(['payrolls']);
    qc.invalidateQueries(['bonifications']);
  };

  const can = (action) => canHr(user, perm, action);

  if (user && !hasHrAccess(user) && !isStaffRole(user.role)) {
    return (
      <div className="min-h-screen flex items-center justify-center p-6 text-center">
        <div>
          <h1 className="text-xl font-bold">Acesso restrito</h1>
          <p className="text-muted-foreground mt-2">Você não tem permissão para acessar o módulo de Funcionários.</p>
        </div>
      </div>
    );
  }

  const empAdvances = (emp) => advances.filter((a) => a.employee_id === emp.id && a.status !== 'cancelled');
  const empPurchases = (emp) => purchases.filter((p) => p.employee_id === emp.id && p.status !== 'cancelled');
  const empOvertimes = (emp) => overtimes.filter((o) => o.employee_id === emp.id);

  const toggleStatus = async (emp) => {
    const next = emp.status === 'active' ? 'inactive' : 'active';
    await base44.entities.Employee.update(emp.id, { status: next });
    reload();
  };

  return (
    <div className="min-h-screen bg-background">
      <main className="p-4 sm:p-6 lg:p-8 space-y-4 max-w-7xl mx-auto">
          <div>
            <h1 className="text-2xl font-bold text-foreground">Funcionários</h1>
            <p className="text-sm text-muted-foreground mt-1">Gestão de funcionários, adiantamentos, compras, horas extras e folha de pagamento.</p>
          </div>

          <Tabs value={tab} onValueChange={setTab}>
            <TabsList className="flex flex-wrap h-auto">
              <TabsTrigger value="list" className="gap-1.5"><Users className="w-4 h-4" /> Funcionários</TabsTrigger>
              <TabsTrigger value="advances" className="gap-1.5"><Wallet className="w-4 h-4" /> Adiantamentos</TabsTrigger>
              <TabsTrigger value="purchases" className="gap-1.5"><ShoppingCart className="w-4 h-4" /> Compras</TabsTrigger>
              <TabsTrigger value="overtime" className="gap-1.5"><Clock className="w-4 h-4" /> Horas Extras</TabsTrigger>
              <TabsTrigger value="bonifications" className="gap-1.5"><Gift className="w-4 h-4" /> Bonificações</TabsTrigger>
              <TabsTrigger value="payroll" className="gap-1.5"><FileText className="w-4 h-4" /> Folha</TabsTrigger>
            </TabsList>

            <TabsContent value="list" className="mt-4">
              <EmployeeList
                employees={employees}
                advances={advances}
                purchases={purchases}
                overtimes={overtimes}
                onNew={() => can('Cadastrar funcionários') && (setEditing(null), setFormOpen(true))}
                onEdit={(e) => can('Editar funcionários') && (setEditing(e), setFormOpen(true))}
                onView={setViewing}
                onToggle={toggleStatus}
                onHistory={(e) => (setViewing(e), setTab('advances'))}
              />
            </TabsContent>

            <TabsContent value="advances" className="mt-4">
              <AdvancesTab employees={employees} advances={advances} can={can} onReload={reload} />
            </TabsContent>

            <TabsContent value="purchases" className="mt-4">
              <PurchasesTab employees={employees} purchases={purchases} can={can} onReload={reload} />
            </TabsContent>

            <TabsContent value="overtime" className="mt-4">
              <OvertimeTab employees={employees} overtimes={overtimes} can={can} onReload={reload} />
            </TabsContent>

            <TabsContent value="bonifications" className="mt-4">
              <BonificationsTab employees={employees} bonifications={bonifications} can={can} onReload={reload} />
            </TabsContent>

            <TabsContent value="payroll" className="mt-4">
              <PayrollTab employees={employees} advances={advances} purchases={purchases} overtimes={overtimes} bonifications={bonifications} payrolls={payrolls} can={can} onReload={reload} />
            </TabsContent>
          </Tabs>
        </main>

      <EmployeeFormDialog open={formOpen} employee={editing} onClose={() => setFormOpen(false)} onSaved={reload} />
      <EmployeeDetailDialog
        open={!!viewing}
        employee={viewing}
        advances={viewing ? empAdvances(viewing) : []}
        purchases={viewing ? empPurchases(viewing) : []}
        overtimes={viewing ? empOvertimes(viewing) : []}
        onEdit={(e) => { setViewing(null); setEditing(e); setFormOpen(true); }}
        onClose={() => setViewing(null)}
      />
    </div>
  );
}