import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { useMutation, useQuery } from '@tanstack/react-query';
import { motion } from 'framer-motion';
import { Link, useNavigate } from 'react-router-dom';
import { createPageUrl } from '@/utils';

import { 
  ArrowLeft, 
  ShoppingBag, 
  User, 
  Phone, 
  Mail, 
  MapPin, 
  MessageSquare,
  CheckCircle2,
  Loader2,
  Building2,
  Beer,
  CreditCard,
  Send,
  Truck,
  Store
} from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { useToast } from '@/components/ui/use-toast';
import { useCartRulePricing } from '@/lib/useCartRulePricing';

export default function Checkout() {
  const navigate = useNavigate();
  const [cartItems, setCartItems] = useState([]);
  const [orderComplete, setOrderComplete] = useState(false);
  const [formData, setFormData] = useState({
    customer_name: '',
    customer_email: '',
    customer_phone: '',
    customer_address: '',
    notes: '',
    payment_method: 'pix',
    delivery_method: 'entrega'
  });
  
  useEffect(() => {
    try {
      const saved = localStorage.getItem('cart');
      if (saved) {
        setCartItems(JSON.parse(saved));
      }
    } catch {
      setCartItems([]);
    }
  }, []);

  const totalItems = cartItems.reduce((sum, item) => sum + item.quantity, 0);
  const { getUnitPrice, isWholesale, wholesaleMinQty } = useCartRulePricing(cartItems, formData.payment_method);

  // Calcular preço baseado na forma de pagamento (regras do catálogo)
  const getItemPrice = (item) => getUnitPrice(item);

  const total = cartItems.reduce((sum, item) => sum + (getItemPrice(item) * item.quantity), 0);

  const { data: settings } = useQuery({
    queryKey: ['settings'],
    queryFn: async () => {
      const list = await base44.entities.Settings.list();
      return list[0] || null;
    }
  });
  const { toast } = useToast();
  


  const createOrderMutation = useMutation({
    mutationFn: (orderData) => base44.entities.Order.create(orderData),
    onSuccess: () => {
      localStorage.removeItem('cart');
      setOrderComplete(true);
    },
    onError: (err) => {
      toast({ title: 'Erro ao enviar pedido', description: err.message, variant: 'destructive' });
    }
  });
  


  const generateWhatsAppMessage = (pdfUrl) => {
    let message = `*🍺 NOVO PEDIDO - FOKUS DISTRIBUIÇÃO*\n\n`;
    message += `*Cliente:* ${formData.customer_name}\n`;
    message += `*Telefone:* ${formData.customer_phone}\n`;
    if (formData.customer_email) message += `*Email:* ${formData.customer_email}\n`;
    message += `*Entrega:* ${formData.delivery_method === 'retirada' ? 'Retirada no local' : 'Entrega'}\n`;
    if (formData.delivery_method !== 'retirada' && formData.customer_address) message += `*Endereço:* ${formData.customer_address}\n`;
    if (isWholesale) message += `\n⭐ *PREÇO ATACADO APLICADO*\n`;
    if (formData.payment_method === 'cash') message += `💵 *DESCONTO À VISTA APLICADO*\n`;
    message += `\n*━━━ ITENS DO PEDIDO ━━━*\n\n`;
    
    cartItems.forEach(item => {
      const unitLabel = item.unit_type === 'unidade' ? 'un' : item.unit_type;
      const itemPrice = getItemPrice(item);
      message += `• ${item.name}\n`;
      message += `  Qtd: ${item.quantity} ${unitLabel} x R$ ${itemPrice.toFixed(2).replace('.', ',')} = *R$ ${(itemPrice * item.quantity).toFixed(2).replace('.', ',')}*\n\n`;
    });
    
    message += `*━━━━━━━━━━━━━━━━━━━━*\n`;
    message += `*TOTAL: R$ ${total.toFixed(2).replace('.', ',')}*\n`;
    message += `*Pagamento:* ${formData.payment_method === 'pix' ? 'PIX' : 'Dinheiro'}\n\n`;
    
    if (formData.notes) message += `*Observações:* ${formData.notes}\n\n`;
    
    if (pdfUrl) message += `📄 *PDF do pedido:* ${pdfUrl}\n`;
    
    return encodeURIComponent(message);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    const orderData = {
      ...formData,
      items: cartItems.map(item => ({
        product_id: item.id,
        product_name: item.name,
        quantity: item.quantity,
        unit_price: getItemPrice(item),
        subtotal: getItemPrice(item) * item.quantity
      })),
      total,
      status: 'pending'
    };

    try {
      await createOrderMutation.mutateAsync(orderData);
      const whatsappNumber = settings?.whatsapp_number || '5511999999999';
      const message = generateWhatsAppMessage(null);
      window.open(`https://wa.me/${whatsappNumber}?text=${message}`, '_blank');
    } catch {
      // erro já tratado pelo onError da mutação
    }
  };
  
  const handleChange = (e) => {
    setFormData(prev => ({
      ...prev,
      [e.target.name]: e.target.value
    }));
  };
  
  if (orderComplete) {
    return (
      <div className="min-h-screen bg-gradient-to-b from-blue-50 to-white flex items-center justify-center p-4">
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          className="bg-white rounded-3xl p-8 md:p-12 max-w-md w-full text-center shadow-xl border border-blue-100"
        >
          <motion.div
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            transition={{ delay: 0.2, type: 'spring' }}
            className="w-20 h-20 bg-emerald-100 rounded-full flex items-center justify-center mx-auto mb-6"
          >
            <CheckCircle2 className="w-10 h-10 text-emerald-600" />
          </motion.div>
          
          <h1 className="text-2xl font-semibold text-gray-900 mb-2">
            Pedido Recebido!
          </h1>
          <p className="text-gray-500 mb-8">
            Seu pedido foi enviado com sucesso. Nossa equipe entrará em contato em breve para confirmar disponibilidade, valores e forma de entrega.
          </p>
          
          <Link to={createPageUrl('Catalog')}>
            <Button className="w-full h-12 bg-blue-600 hover:bg-blue-700 text-white rounded-full text-base font-medium">
              Voltar ao Catálogo
            </Button>
          </Link>
        </motion.div>
      </div>
    );
  }
  
  if (cartItems.length === 0) {
    return (
      <div className="min-h-screen bg-gradient-to-b from-blue-50 to-white flex items-center justify-center p-4">
        <div className="text-center">
          <div className="w-20 h-20 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
            <Beer className="w-8 h-8 text-blue-600" />
          </div>
          <h2 className="text-xl font-semibold text-gray-900 mb-2">Carrinho vazio</h2>
          <p className="text-gray-500 mb-6">Adicione bebidas ao carrinho para fazer seu pedido</p>
          <Link to={createPageUrl('Catalog')}>
            <Button className="bg-blue-600 hover:bg-blue-700 text-white rounded-full px-6">
              Ver Catálogo
            </Button>
          </Link>
        </div>
      </div>
    );
  }
  
  return (
    <div className="min-h-screen bg-gradient-to-b from-blue-50 to-white pb-16 md:pb-0">
      {/* Header */}
      <header className="bg-white border-b border-blue-100" style={{ paddingTop: 'env(safe-area-inset-top)' }}>
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center h-16">
            <Link
              to={createPageUrl('Catalog')}
              className="flex items-center gap-2 text-blue-600 hover:text-blue-700 transition-colors min-h-11 px-2 -ml-2 touch-manipulation"
            >
              <ArrowLeft className="w-4 h-4" />
              <span className="text-sm font-medium">Voltar</span>
            </Link>
            <h1 className="flex-1 text-center text-lg font-semibold">Finalizar Pedido</h1>
            <div className="w-16" />
          </div>
        </div>
      </header>
      
      <main className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid md:grid-cols-5 gap-8">
          {/* Form */}
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            className="md:col-span-3"
          >
            <div className="bg-white rounded-2xl p-6 md:p-8 shadow-sm">
              <h2 className="text-xl font-semibold mb-6 flex items-center gap-2">
                <Building2 className="w-5 h-5 text-blue-500" />
                Dados para Contato
              </h2>
              
              <form onSubmit={handleSubmit} className="space-y-5">
                <div>
                  <Label htmlFor="customer_name" className="text-sm font-medium text-gray-700 flex items-center gap-2 mb-2">
                    <User className="w-4 h-4 text-blue-500" />
                    Nome / Razão Social *
                  </Label>
                  <Input
                    id="customer_name"
                    name="customer_name"
                    value={formData.customer_name}
                    onChange={handleChange}
                    required
                    className="h-12 rounded-xl border-blue-200 focus:border-blue-300 focus:ring-blue-200"
                    placeholder="Nome ou nome do estabelecimento"
                  />
                </div>
                
                <div className="grid sm:grid-cols-2 gap-5">
                  <div>
                    <Label htmlFor="customer_email" className="text-sm font-medium text-gray-700 flex items-center gap-2 mb-2">
                      <Mail className="w-4 h-4 text-blue-500" />
                      Email
                    </Label>
                    <Input
                      id="customer_email"
                      name="customer_email"
                      type="email"
                      value={formData.customer_email}
                      onChange={handleChange}
                      className="h-12 rounded-xl border-blue-200 focus:border-blue-300 focus:ring-blue-200"
                      placeholder="seu@email.com"
                    />
                  </div>
                  
                  <div>
                    <Label htmlFor="customer_phone" className="text-sm font-medium text-gray-700 flex items-center gap-2 mb-2">
                      <Phone className="w-4 h-4 text-blue-500" />
                      WhatsApp / Telefone *
                    </Label>
                    <Input
                      id="customer_phone"
                      name="customer_phone"
                      value={formData.customer_phone}
                      onChange={handleChange}
                      required
                      className="h-12 rounded-xl border-blue-200 focus:border-blue-300 focus:ring-blue-200"
                      placeholder="(00) 00000-0000"
                    />
                  </div>
                </div>
                
                <div>
                  <Label className="text-sm font-medium text-gray-700 flex items-center gap-2 mb-2">
                    <Truck className="w-4 h-4 text-blue-500" />
                    Tipo de Entrega *
                  </Label>
                  <div className="grid grid-cols-2 gap-3">
                    <button
                      type="button"
                      onClick={() => setFormData(prev => ({ ...prev, delivery_method: 'entrega' }))}
                      className={`p-4 rounded-xl border-2 transition-all flex flex-col items-center gap-2 ${
                        formData.delivery_method === 'entrega'
                          ? 'border-blue-500 bg-blue-50 text-blue-700'
                          : 'border-gray-200 hover:border-blue-200'
                      }`}
                    >
                      <Truck className="w-6 h-6" />
                      <span className="font-medium">Entrega</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => setFormData(prev => ({ ...prev, delivery_method: 'retirada' }))}
                      className={`p-4 rounded-xl border-2 transition-all flex flex-col items-center gap-2 ${
                        formData.delivery_method === 'retirada'
                          ? 'border-blue-500 bg-blue-50 text-blue-700'
                          : 'border-gray-200 hover:border-blue-200'
                      }`}
                    >
                      <Store className="w-6 h-6" />
                      <span className="font-medium">Retirada</span>
                    </button>
                  </div>
                </div>

                {formData.delivery_method === 'entrega' && (
                  <div>
                    <Label htmlFor="customer_address" className="text-sm font-medium text-gray-700 flex items-center gap-2 mb-2">
                      <MapPin className="w-4 h-4 text-blue-500" />
                      Endereço de Entrega *
                    </Label>
                    <Input
                      id="customer_address"
                      name="customer_address"
                      value={formData.customer_address}
                      onChange={handleChange}
                      required
                      className="h-12 rounded-xl border-blue-200 focus:border-blue-300 focus:ring-blue-200"
                      placeholder="Rua, número, bairro, cidade"
                    />
                  </div>
                )}
                
                <div>
                  <Label htmlFor="notes" className="text-sm font-medium text-gray-700 flex items-center gap-2 mb-2">
                    <MessageSquare className="w-4 h-4 text-blue-500" />
                    Observações
                  </Label>
                  <Textarea
                    id="notes"
                    name="notes"
                    value={formData.notes}
                    onChange={handleChange}
                    className="min-h-[100px] rounded-xl border-blue-200 focus:border-blue-300 focus:ring-blue-200 resize-none"
                    placeholder="Data preferencial de entrega, horário, etc."
                  />
                </div>

                <div>
                  <Label className="text-sm font-medium text-gray-700 flex items-center gap-2 mb-3">
                    <CreditCard className="w-4 h-4 text-blue-500" />
                    Forma de Pagamento *
                  </Label>
                  <div className="grid grid-cols-2 gap-3">
                    <button
                      type="button"
                      onClick={() => setFormData(prev => ({ ...prev, payment_method: 'pix' }))}
                      className={`p-4 rounded-xl border-2 transition-all flex flex-col items-center gap-2 ${
                        formData.payment_method === 'pix'
                          ? 'border-blue-500 bg-blue-50 text-blue-700'
                          : 'border-gray-200 hover:border-blue-200'
                      }`}
                    >
                      <span className="text-2xl">💳</span>
                      <span className="font-medium">PIX</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => setFormData(prev => ({ ...prev, payment_method: 'cash' }))}
                      className={`p-4 rounded-xl border-2 transition-all flex flex-col items-center gap-2 ${
                        formData.payment_method === 'cash'
                          ? 'border-blue-500 bg-blue-50 text-blue-700'
                          : 'border-gray-200 hover:border-blue-200'
                      }`}
                    >
                      <span className="text-2xl">💵</span>
                      <span className="font-medium">Dinheiro</span>
                    </button>
                  </div>
                </div>
                
                <Button
                   type="submit"
                  disabled={createOrderMutation.isPending}
                  className="w-full h-12 bg-blue-600 hover:bg-blue-700 text-white rounded-full text-base font-medium mt-6"
                >
                  {createOrderMutation.isPending ? (
                    <>
                      <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                      Enviando...
                    </>
                  ) : (
                    <>
                      <Send className="w-4 h-4 mr-2" />
                      Enviar Pedido via WhatsApp
                    </>
                  )}
                </Button>
              </form>
            </div>
          </motion.div>
          
          {/* Order Summary */}
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            className="md:col-span-2"
          >
            <div className="bg-white rounded-2xl p-6 shadow-sm sticky top-24 border border-blue-100">
              <h2 className="text-lg font-semibold mb-4 flex items-center gap-2">
                <ShoppingBag className="w-5 h-5 text-blue-500" />
                Resumo do Pedido
              </h2>
              
              <div className="space-y-3 max-h-64 overflow-y-auto">
                {cartItems.map((item) => (
                  <div key={item.id} className="flex gap-3">
                    <div className="w-12 h-12 rounded-lg overflow-hidden bg-gray-100 flex-shrink-0">
                      {item.image_url ? (
                        <img
                          src={item.image_url}
                          alt={item.name}
                          className="w-full h-full object-cover"
                        />
                      ) : (
                        <div className="w-full h-full flex items-center justify-center">
                          <span className="text-lg font-light text-gray-300">
                            {item.name?.charAt(0)}
                          </span>
                        </div>
                      )}
                    </div>
                    <div className="flex-1 min-w-0">
                      <h3 className="text-sm font-medium text-gray-900 truncate">{item.name}</h3>
                      <p className="text-xs text-gray-500">Qtd: {item.quantity}</p>
                    </div>
                    <span className="text-sm font-medium text-gray-900">
                      R$ {(getItemPrice(item) * item.quantity).toFixed(2).replace('.', ',')}
                    </span>
                  </div>
                ))}
              </div>
              
              <div className="border-t border-blue-100 mt-4 pt-4 bg-blue-50 -mx-6 -mb-6 px-6 pb-6 rounded-b-2xl">
                {isWholesale && (
                  <div className="flex items-center gap-2 text-emerald-600 text-xs font-medium mb-2">
                    <span>⭐</span> Preço atacado aplicado ({wholesaleMinQty}+ itens)
                  </div>
                )}
                {formData.payment_method === 'cash' && (
                  <div className="flex items-center gap-2 text-emerald-600 text-xs font-medium mb-2">
                    <span>💵</span> Tabela Dinheiro aplicada
                  </div>
                )}
                {formData.payment_method === 'pix' && (
                  <div className="flex items-center gap-2 text-emerald-600 text-xs font-medium mb-2">
                    <span>💳</span> Tabela PIX aplicada
                  </div>
                )}
                <div className="flex items-center justify-between">
                  <span className="text-gray-500">Total Estimado</span>
                  <span className="text-2xl font-bold text-blue-700">
                    R$ {total.toFixed(2).replace('.', ',')}
                  </span>
                </div>
                <p className="text-xs text-gray-500 mt-2">
                  *Valores sujeitos a confirmação
                </p>
              </div>
            </div>
          </motion.div>
        </div>
      </main>
    </div>
  );
}