import React, { useState, useMemo } from 'react';
import { useQuery } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { useAuth } from '@/lib/AuthContext';
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs';
import { Button } from '@/components/ui/button';
import { Select, SelectTrigger, SelectValue, SelectContent, SelectItem } from '@/components/ui/select';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { useToast } from '@/components/ui/use-toast';
import { BarChart3, FileText, Calendar, Printer, Download, Share2 } from 'lucide-react';
import { MANAGERIAL_PERIODS, managerialRange, buildManagerialResult, managerialReportToSections } from '@/lib/managerialCalc';
import { generatePDF, sharePDF } from '@/lib/pdfService';
import { logActivity } from '@/lib/activityLog';
import ExecutiveSummary from '@/components/reports/ExecutiveSummary';
import ResultDashboard from '@/components/reports/ResultDashboard';
import SalesAnalysis from '@/components/reports/SalesAnalysis';
import PriceAnalysis from '@/components/reports/PriceAnalysis';
import CostAnalysis from '@/components/reports/CostAnalysis';
import ExpenseAnalysis from '@/components/reports/ExpenseAnalysis';
import EmployeeAnalysis from '@/components/reports/EmployeeAnalysis';
import CashFlowAnalysis from '@/components/reports/CashFlowAnalysis';
import QuotesAnalysis from '@/components/reports/QuotesAnalysis';

const todayStr = () => new Date().toISOString().slice(0, 10);

export default function Reports() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [period, setPeriod] = useState('month');
  const [customStart, setCustomStart] = useState('');
  const [customEnd, setCustomEnd] = useState(todayStr());
  const [tab, setTab] = useState('result');
  const [exporting, setExporting] = useState(false);

  const ordersQ = useQuery({ queryKey: ['orders'], queryFn: () => base44.entities.Order.list('-created_date', 2000) });
  const productsQ = useQuery({ queryKey: ['products'], queryFn: () => base44.entities.Product.list() });
  const expensesQ = useQuery({ queryKey: ['expenses'], queryFn: () => base44.entities.Expense.list() });
  const expCatsQ = useQuery({ queryKey: ['expense-categories'], queryFn: () => base44.entities.ExpenseCategory.list() });
  const payrollsQ = useQuery({ queryKey: ['payrolls'], queryFn: () => base44.entities.Payroll.list() });
  const employeesQ = useQuery({ queryKey: ['employees'], queryFn: () => base44.entities.Employee.list() });
  const entriesQ = useQuery({ queryKey: ['financialEntries'], queryFn: () => base44.entities.FinancialEntry.list('-due_date', 1000) });
  const settingsQ = useQuery({ queryKey: ['settings'], queryFn: () => base44.entities.Settings.list() });

  const settings = (settingsQ.data && settingsQ.data[0]) || null;

  const { start, end } = useMemo(() => managerialRange(period, customStart, customEnd), [period, customStart, customEnd]);

  const result = useMemo(() => buildManagerialResult({
    orders: ordersQ.data || [],
    products: productsQ.data || [],
    expenses: expensesQ.data || [],
    expenseCategories: expCatsQ.data || [],
    payrolls: payrollsQ.data || [],
    financialEntries: entriesQ.data || [],
    start, end,
  }), [ordersQ.data, productsQ.data, expensesQ.data, expCatsQ.data, payrollsQ.data, entriesQ.data, start, end]);

  const loading = ordersQ.isLoading || productsQ.isLoading || expensesQ.isLoading || expCatsQ.isLoading || payrollsQ.isLoading || entriesQ.isLoading;

  const periodLabel = useMemo(() => {
    if (period === 'custom') return `${customStart || 'início'} até ${customEnd || 'hoje'}`;
    return MANAGERIAL_PERIODS.find((p) => p.key === period)?.label || 'Período';
  }, [period, customStart, customEnd]);

  const handleSharePDF = async () => {
    setExporting(true);
    try {
      const { data, sections, meta } = managerialReportToSections(result, user, periodLabel);
      const { shared } = await sharePDF({
        documentType: 'dashboard_report',
        data: { ...data, company: { name: settings?.company_name || 'FOKUS DISTRIBUIÇÃO', cnpj: settings?.company_cnpj || '', address: settings?.company_address || '', phones: settings?.phone_display || '', email: '', site: '' } },
        sections,
        module: 'Relatórios',
        user,
        fileName: `relatorio-gerencial-${todayStr()}.pdf`,
      });
      toast({ title: shared ? 'Compartilhando PDF' : 'PDF baixado', description: shared ? 'Escolha o aplicativo para enviar.' : 'Compartilhamento não suportado — PDF baixado.' });
    } catch (e) {
      if (e?.name !== 'AbortError') toast({ title: 'Erro ao compartilhar', description: e.message, variant: 'destructive' });
    } finally {
      setExporting(false);
    }
  };

  const handleExportPDF = async () => {
    setExporting(true);
    try {
      const { data, sections, meta } = managerialReportToSections(result, user, periodLabel);
      await generatePDF({
        documentType: 'dashboard_report',
        data: { ...data, company: { name: settings?.company_name || 'FOKUS DISTRIBUIÇÃO', cnpj: settings?.company_cnpj || '', address: settings?.company_address || '', phones: settings?.phone_display || '', email: '', site: '' } },
        sections,
        module: 'Relatórios',
        user,
        fileName: `relatorio-gerencial-${todayStr()}.pdf`,
      });
      await logActivity({ action: 'report_export', description: `Relatório gerencial exportado (${periodLabel})`, user });
      toast({ title: 'PDF gerado', description: 'Relatório gerencial baixado.' });
    } catch (e) {
      toast({ title: 'Erro ao gerar PDF', description: e.message, variant: 'destructive' });
    } finally {
      setExporting(false);
    }
  };

  return (
    <div className="min-h-screen bg-muted/30">
      <div className="sticky top-0 z-20 bg-background/80 backdrop-blur border-b border-border">
        <div className="max-w-7xl mx-auto px-4 py-3 flex items-center justify-between gap-3 flex-wrap">
          <div>
            <h1 className="text-lg font-bold flex items-center gap-2"><BarChart3 className="h-5 w-5 text-blue-600" /> Relatórios Gerenciais</h1>
            <p className="text-xs text-muted-foreground">Centro de inteligência financeira e gerencial</p>
          </div>
          <div className="flex items-center gap-2">
            <Select value={period} onValueChange={setPeriod}>
              <SelectTrigger className="w-44 h-9"><SelectValue /></SelectTrigger>
              <SelectContent>
                {MANAGERIAL_PERIODS.map((p) => <SelectItem key={p.key} value={p.key}>{p.label}</SelectItem>)}
              </SelectContent>
            </Select>
            <Button variant="outline" size="sm" onClick={handleSharePDF} disabled={exporting || loading}>
              <Share2 className="w-4 h-4" /> {exporting ? 'Gerando...' : 'Compartilhar'}
            </Button>
            <Button variant="outline" size="sm" onClick={handleExportPDF} disabled={exporting || loading}>
              <FileText className="w-4 h-4" /> {exporting ? 'Gerando...' : 'Exportar PDF'}
            </Button>
          </div>
        </div>
        {period === 'custom' && (
          <div className="max-w-7xl mx-auto px-4 pb-3 flex flex-wrap items-end gap-3">
            <div className="space-y-1">
              <Label className="text-xs text-muted-foreground flex items-center gap-1"><Calendar className="w-3 h-3" /> Data inicial</Label>
              <Input type="date" value={customStart} onChange={(e) => setCustomStart(e.target.value)} className="h-9 w-44" />
            </div>
            <div className="space-y-1">
              <Label className="text-xs text-muted-foreground flex items-center gap-1"><Calendar className="w-3 h-3" /> Data final</Label>
              <Input type="date" value={customEnd} max={todayStr()} onChange={(e) => setCustomEnd(e.target.value)} className="h-9 w-44" />
            </div>
          </div>
        )}
      </div>

      <div className="max-w-7xl mx-auto px-4 py-6 space-y-4">
        {loading ? (
          <div className="flex items-center justify-center py-20">
            <div className="w-8 h-8 border-4 border-slate-200 border-t-slate-800 rounded-full animate-spin"></div>
          </div>
        ) : (
          <>
            <ExecutiveSummary result={result} />

            <Tabs value={tab} onValueChange={setTab} className="w-full">
              <TabsList className="flex flex-wrap h-auto w-full">
                <TabsTrigger value="result">Resultado</TabsTrigger>
                <TabsTrigger value="sales">Vendas</TabsTrigger>
                <TabsTrigger value="prices">Preços & Margem</TabsTrigger>
                <TabsTrigger value="costs">Custos</TabsTrigger>
                <TabsTrigger value="expenses">Despesas</TabsTrigger>
                <TabsTrigger value="employees">Funcionários</TabsTrigger>
                <TabsTrigger value="cashflow">Fluxo de Caixa</TabsTrigger>
                <TabsTrigger value="quotes">Orçamentos</TabsTrigger>
              </TabsList>
              <TabsContent value="result" className="mt-4"><ResultDashboard result={result} /></TabsContent>
              <TabsContent value="sales" className="mt-4"><SalesAnalysis result={result} /></TabsContent>
              <TabsContent value="prices" className="mt-4"><PriceAnalysis result={result} /></TabsContent>
              <TabsContent value="costs" className="mt-4"><CostAnalysis result={result} /></TabsContent>
              <TabsContent value="expenses" className="mt-4"><ExpenseAnalysis result={result} /></TabsContent>
              <TabsContent value="employees" className="mt-4"><EmployeeAnalysis result={result} payrolls={payrollsQ.data || []} employees={employeesQ.data || []} /></TabsContent>
              <TabsContent value="cashflow" className="mt-4"><CashFlowAnalysis result={result} /></TabsContent>
              <TabsContent value="quotes" className="mt-4"><QuotesAnalysis start={start} end={end} /></TabsContent>
            </Tabs>
          </>
        )}
      </div>
    </div>
  );
}