import React, { useState, useMemo } from 'react';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { useAuth } from '@/lib/AuthContext';
import { useToast } from '@/components/ui/use-toast';
import { FileText, Plus, Eye, Pencil, Copy, Printer, ArrowRightLeft, Ban, AlertTriangle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import {
  quoteStatusInfo, formatCurrency, daysUntilExpiry, expiryWarningLevel, isExpired,
} from '@/components/quotes/quoteStatus';
import QuoteFormDialog from '@/components/quotes/QuoteFormDialog';
import QuoteDetailDialog from '@/components/quotes/QuoteDetailDialog';
import QuotePrintDialog from '@/components/quotes/QuotePrintDialog';
import QuoteFilters from '@/components/quotes/QuoteFilters';
import {
  convertQuoteToOrder, duplicateQuote, cancelQuote, updateQuoteStatus, buildWhatsAppLink,
} from '@/lib/quoteService';
import { useNavigate } from 'react-router-dom';

const emptyFilters = {
  search: '', status: '', price_table_name: '', responsible: '',
  expiring: 'all', dateFrom: '', dateTo: '', valueMin: '', valueMax: '',
};

export default function Quotes() {
  const { user } = useAuth();
  const { toast } = useToast();
  const navigate = useNavigate();
  const qc = useQueryClient();

  const [filters, setFilters] = useState(emptyFilters);
  const [formOpen, setFormOpen] = useState(false);
  const [editing, setEditing] = useState(null);
  const [detail, setDetail] = useState(null);
  const [printQuote, setPrintQuote] = useState(null);
  const [converting, setConverting] = useState(null);

  const quotesQ = useQuery({
    queryKey: ['quotes'],
    queryFn: () => base44.entities.Quote.list('-created_date', 2000),
  });
  const productsQ = useQuery({ queryKey: ['products'], queryFn: () => base44.entities.Product.list() });
  const settingsQ = useQuery({ queryKey: ['settings'], queryFn: () => base44.entities.Settings.list() });

  const settings = (settingsQ.data && settingsQ.data[0]) || null;
  const defaultValidityDays = settings?.quote_validity_days || 30;

  const productMap = useMemo(() => {
    const m = {};
    (productsQ.data || []).forEach((p) => { m[p.id] = p; });
    return m;
  }, [productsQ.data]);

  const allQuotes = quotesQ.data || [];

  const filtered = useMemo(() => {
    return allQuotes.filter((q) => {
      if (filters.search) {
        const s = filters.search.toLowerCase();
        const hit = [q.quote_number, q.customer_name, q.cpf_cnpj, q.customer_phone, q.customer_email]
          .some((f) => String(f || '').toLowerCase().includes(s));
        if (!hit) return false;
      }
      if (filters.status && q.status !== filters.status) return false;
      if (filters.price_table_name && !String(q.price_table_name || '').toLowerCase().includes(filters.price_table_name.toLowerCase())) return false;
      if (filters.responsible && !String(q.responsible || '').toLowerCase().includes(filters.responsible.toLowerCase())) return false;
      if (filters.dateFrom && (q.created_date || '').slice(0, 10) < filters.dateFrom) return false;
      if (filters.dateTo && (q.created_date || '').slice(0, 10) > filters.dateTo) return false;
      if (filters.valueMin && Number(q.total) < Number(filters.valueMin)) return false;
      if (filters.valueMax && Number(q.total) > Number(filters.valueMax)) return false;
      if (filters.expiring === 'expiring' && !expiryWarningLevel(q)) return false;
      if (filters.expiring === 'expired' && !isExpired(q)) return false;
      if (filters.expiring === 'valid' && (isExpired(q) || !q.valid_until)) return false;
      return true;
    });
  }, [allQuotes, filters]);

  const handleSave = async (payload) => {
    try {
      if (editing) {
        await base44.entities.Quote.update(editing.id, {
          ...payload,
          timeline: [
            ...(editing.timeline || []),
            { date: new Date().toISOString(), event: 'Orçamento editado', author: user?.full_name || user?.email || '—' },
          ],
        });
        toast({ title: 'Orçamento atualizado', description: payload.quote_number });
      } else {
        await base44.entities.Quote.create({
          ...payload,
          status: 'salvo',
          timeline: [
            { date: new Date().toISOString(), event: 'Orçamento criado', author: user?.full_name || user?.email || '—' },
          ],
        });
        toast({ title: 'Orçamento criado', description: payload.quote_number });
      }
      qc.invalidateQueries({ queryKey: ['quotes'] });
      setEditing(null);
    } catch (e) {
      toast({ title: 'Erro ao salvar orçamento', description: String(e.message || e), variant: 'destructive' });
    }
  };

  const handleConvert = async (quote) => {
    if (!window.confirm(`Transformar o orçamento ${quote.quote_number} em pedido? O orçamento será vinculado ao novo pedido e não poderá ser convertido novamente.`)) return;
    setConverting(quote.id);
    try {
      const { order, orderCode } = await convertQuoteToOrder({ quote, user });
      toast({ title: 'Orçamento transformado em pedido com sucesso', description: `Pedido gerado: #${orderCode}` });
      qc.invalidateQueries({ queryKey: ['quotes'] });
      qc.invalidateQueries({ queryKey: ['orders'] });
      if (window.confirm('Orçamento transformado em pedido! Deseja ir para a página de Pedidos para finalizar a venda?')) {
        navigate('/Orders');
      }
    } catch (e) {
      toast({ title: 'Erro ao transformar orçamento', description: String(e.message || e), variant: 'destructive' });
    } finally {
      setConverting(null);
      setDetail(null);
    }
  };

  const handleDuplicate = async (quote) => {
    try {
      const dup = await duplicateQuote({ quote, user, validityDays: defaultValidityDays });
      toast({ title: 'Orçamento duplicado', description: dup.quote_number });
      qc.invalidateQueries({ queryKey: ['quotes'] });
      setDetail(null);
    } catch (e) {
      toast({ title: 'Erro ao duplicar', description: String(e.message || e), variant: 'destructive' });
    }
  };

  const handleCancel = async (quote) => {
    const reason = window.prompt('Motivo do cancelamento (opcional):') || '';
    try {
      await cancelQuote({ quote, user, reason });
      toast({ title: 'Orçamento cancelado' });
      qc.invalidateQueries({ queryKey: ['quotes'] });
      setDetail(null);
    } catch (e) {
      toast({ title: 'Erro ao cancelar', description: String(e.message || e), variant: 'destructive' });
    }
  };

  const handleStatusChange = async (quote, status) => {
    try {
      await updateQuoteStatus({ quote, status, user });
      toast({ title: 'Status atualizado' });
      qc.invalidateQueries({ queryKey: ['quotes'] });
    } catch (e) {
      toast({ title: 'Erro ao atualizar status', description: String(e.message || e), variant: 'destructive' });
    }
  };

  const handleWhatsApp = (quote) => {
    const link = buildWhatsAppLink(quote, settings?.whatsapp_number);
    window.open(link, '_blank');
    updateQuoteStatus({ quote, status: 'enviado', user }).then(() => qc.invalidateQueries({ queryKey: ['quotes'] }));
  };

  const loading = quotesQ.isLoading;

  return (
    <div className="min-h-screen bg-muted/30">
      <div className="sticky top-0 z-20 bg-background/80 backdrop-blur border-b border-border">
        <div className="max-w-7xl mx-auto px-4 py-3 flex items-center justify-between gap-3 flex-wrap">
          <div>
            <h1 className="text-lg font-bold flex items-center gap-2"><FileText className="h-5 w-5 text-blue-600" /> Orçamentos</h1>
            <p className="text-xs text-muted-foreground">Crie orçamentos, acompanhe a validade e transforme em pedidos</p>
          </div>
          <Button onClick={() => { setEditing(null); setFormOpen(true); }} className="gap-1.5 bg-blue-700 hover:bg-blue-800">
            <Plus className="h-4 w-4" /> Novo Orçamento
          </Button>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 py-4 space-y-4">
        {/* Avisos de expiração próximos */}
        {(() => {
          const expiring = allQuotes.filter((q) => expiryWarningLevel(q) && !['transformado', 'cancelado'].includes(q.status));
          if (expiring.length === 0) return null;
          return (
            <div className="rounded-lg p-3 bg-amber-50 border border-amber-200 text-amber-800 text-sm flex items-start gap-2">
              <AlertTriangle className="w-4 h-4 mt-0.5 flex-shrink-0" />
              <div>
                <strong>{expiring.length} orçamento(s) próximo(s) da expiração.</strong> Transforme em pedido para evitar a exclusão automática.
              </div>
            </div>
          );
        })()}

        <QuoteFilters
          filters={filters}
          setFilters={setFilters}
          onClear={() => setFilters(emptyFilters)}
          totalCount={allQuotes.length}
          filteredCount={filtered.length}
        />

        {loading ? (
          <div className="flex items-center justify-center py-20">
            <div className="w-8 h-8 border-4 border-slate-200 border-t-slate-800 rounded-full animate-spin"></div>
          </div>
        ) : (
          <div className="border border-border rounded-xl overflow-x-auto bg-background">
            <table className="w-full text-sm min-w-[900px]">
              <thead className="bg-muted/50 text-muted-foreground">
                <tr>
                  <th className="text-left px-3 py-2.5 font-medium">Nº</th>
                  <th className="text-left px-3 py-2.5 font-medium">Cliente</th>
                  <th className="text-left px-3 py-2.5 font-medium">Data</th>
                  <th className="text-left px-3 py-2.5 font-medium">Validade</th>
                  <th className="text-right px-3 py-2.5 font-medium">Valor</th>
                  <th className="text-left px-3 py-2.5 font-medium">Tabela</th>
                  <th className="text-left px-3 py-2.5 font-medium">Status</th>
                  <th className="text-left px-3 py-2.5 font-medium">Responsável</th>
                  <th className="text-center px-3 py-2.5 font-medium">Dias</th>
                  <th className="text-right px-3 py-2.5 font-medium">Ações</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-border">
                {filtered.length === 0 && (
                  <tr>
                    <td colSpan={10} className="text-center py-12 text-muted-foreground">
                      <FileText className="h-10 w-10 mx-auto mb-2 opacity-40" />
                      Nenhum orçamento encontrado.
                    </td>
                  </tr>
                )}
                {filtered.map((q) => {
                  const s = quoteStatusInfo(q.status);
                  const days = daysUntilExpiry(q);
                  const warn = expiryWarningLevel(q);
                  const locked = ['transformado', 'cancelado'].includes(q.status);
                  return (
                    <tr key={q.id} className="hover:bg-muted/30">
                      <td className="px-3 py-2 font-mono text-xs font-medium">{q.quote_number || '—'}</td>
                      <td className="px-3 py-2">{q.customer_name || '—'}</td>
                      <td className="px-3 py-2 text-xs">{q.created_date ? new Date(q.created_date).toLocaleDateString('pt-BR') : '—'}</td>
                      <td className="px-3 py-2 text-xs">{q.valid_until ? new Date(q.valid_until + 'T00:00:00').toLocaleDateString('pt-BR') : '—'}</td>
                      <td className="px-3 py-2 text-right font-medium">{formatCurrency(q.total)}</td>
                      <td className="px-3 py-2 text-xs">{q.price_table_name || '—'}</td>
                      <td className="px-3 py-2">
                        <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs font-medium ${s.badge}`}>{s.label}</span>
                      </td>
                      <td className="px-3 py-2 text-xs">{q.responsible || '—'}</td>
                      <td className="px-3 py-2 text-center text-xs">
                        {locked ? '—' : days === null ? '—' : days < 0 ? (
                          <span className="text-red-600 font-medium">expirado</span>
                        ) : warn ? (
                          <span className={`font-medium ${warn <= 1 ? 'text-red-600' : warn <= 3 ? 'text-orange-600' : 'text-amber-600'}`}>{days}d</span>
                        ) : (
                          <span className="text-muted-foreground">{days}d</span>
                        )}
                      </td>
                      <td className="px-3 py-2">
                        <div className="flex items-center justify-end gap-1">
                          <Button variant="ghost" size="icon" className="h-7 w-7" title="Visualizar" onClick={() => setDetail(q)}><Eye className="w-4 h-4" /></Button>
                          {!locked && (
                            <Button variant="ghost" size="icon" className="h-7 w-7" title="Editar" onClick={() => { setEditing(q); setFormOpen(true); }}><Pencil className="w-4 h-4" /></Button>
                          )}
                          <Button variant="ghost" size="icon" className="h-7 w-7" title="Gerar PDF" onClick={() => setPrintQuote(q)}><Printer className="w-4 h-4" /></Button>
                          {!locked && (
                            <>
                              <Button variant="ghost" size="icon" className="h-7 w-7" title="Duplicar" onClick={() => handleDuplicate(q)}><Copy className="w-4 h-4" /></Button>
                              <Button variant="ghost" size="icon" className="h-7 w-7 text-emerald-600" title="Transformar em pedido" disabled={converting === q.id} onClick={() => handleConvert(q)}><ArrowRightLeft className="w-4 h-4" /></Button>
                              <Button variant="ghost" size="icon" className="h-7 w-7 text-red-600" title="Cancelar" onClick={() => handleCancel(q)}><Ban className="w-4 h-4" /></Button>
                            </>
                          )}
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>

      <QuoteFormDialog
        open={formOpen}
        quote={editing}
        products={productsQ.data || []}
        defaultValidityDays={defaultValidityDays}
        onClose={() => { setFormOpen(false); setEditing(null); }}
        onSave={handleSave}
      />

      <QuoteDetailDialog
        quote={detail}
        productMap={productMap}
        onClose={() => setDetail(null)}
        onEdit={(q) => { setDetail(null); setEditing(q); setFormOpen(true); }}
        onDuplicate={handleDuplicate}
        onPrint={(q) => { setDetail(null); setPrintQuote(q); }}
        onConvert={handleConvert}
        onCancel={handleCancel}
      />

      <QuotePrintDialog
        open={!!printQuote}
        quote={printQuote}
        settings={settings}
        productMap={productMap}
        onClose={() => setPrintQuote(null)}
      />
    </div>
  );
}