import React, { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { useToast } from "@/components/ui/use-toast";
import InventoryOverview from "@/components/inventory/InventoryOverview";
import InventoryCurrentTable from "@/components/inventory/InventoryCurrentTable";
import InventoryMovementForm from "@/components/inventory/InventoryMovementForm";
import InventoryHistory from "@/components/inventory/InventoryHistory";
import BatchEntryDialog from "@/components/inventory/BatchEntryDialog";
import MassStocktakingDialog from "@/components/inventory/MassStocktakingDialog";
import { Plus, Download, ArrowDownToLine, ArrowUpFromLine, SlidersHorizontal, Boxes, ClipboardCheck } from "lucide-react";
import { exportXlsx } from "@/lib/xlsxExport";
import ExportImportMenu from "@/components/admin/ExportImportMenu";

export default function Inventory() {
  const { toast } = useToast();
  const [tab, setTab] = useState("overview");
  const [formOpen, setFormOpen] = useState(false);
  const [formType, setFormType] = useState("entry");
  const [batchOpen, setBatchOpen] = useState(false);
  const [stocktakingOpen, setStocktakingOpen] = useState(false);

  const productsQ = useQuery({
    queryKey: ["products"],
    queryFn: () => base44.entities.Product.list(),
  });
  const movementsQ = useQuery({
    queryKey: ["inventory-movements"],
    queryFn: () => base44.entities.InventoryMovement.list("-created_date", 500),
  });

  const products = productsQ.data || [];
  const movements = movementsQ.data || [];

  const openForm = (type) => {
    setFormType(type);
    setFormOpen(true);
  };

  const exportCurrentStock = () => {
    const rows = products.map((p) => ({
      Código: p.code || "",
      Nome: p.name,
      Categoria: p.category || "",
      Marca: p.brand || "",
      "Tipo de Unidade": p.unit_type || "",
      "Quantidade": p.stock_quantity ?? 0,
      "Estoque Mínimo": p.low_stock_threshold ?? "",
      "Custo": p.cost ?? 0,
      "Preço Venda": p.price ?? 0,
      "Status": !p.stock_quantity ? "Sem estoque" : p.stock_quantity <= (p.low_stock_threshold || 0) ? "Baixo" : "OK",
    }));
    exportXlsx("Estoque_Atual.xlsx", "Estoque Atual", rows);
    toast({ title: "Estoque exportado em Excel." });
  };

  return (
    <div className="min-h-screen bg-background">
      <div className="border-b bg-card">
        <div className="max-w-7xl mx-auto px-4 py-4 flex items-center gap-4">
          <div>
            <h1 className="text-xl font-bold">Gerenciamento de Estoque</h1>
          </div>
        </div>
      </div>
      <div className="max-w-7xl mx-auto px-4 py-6 space-y-6">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <p className="text-muted-foreground text-sm">
            Controle de estoque, movimentações, ajustes e inventário.
          </p>
          <div className="flex flex-wrap gap-2">
            <ExportImportMenu
              items={[
                { label: 'Exportar Estoque', icon: Download, onClick: exportCurrentStock },
              ]}
            />
            <Button variant="outline" size="sm" onClick={() => openForm("adjustment")}>
              <SlidersHorizontal className="h-4 w-4" /> Ajuste
            </Button>
            <Button variant="outline" size="sm" onClick={() => openForm("exit")}>
              <ArrowUpFromLine className="h-4 w-4" /> Saída
            </Button>
            <Button size="sm" onClick={() => openForm("entry")}>
              <ArrowDownToLine className="h-4 w-4" /> Entrada
            </Button>
            <Button size="sm" variant="secondary" onClick={() => setBatchOpen(true)}>
              <Boxes className="h-4 w-4" /> Nova Entrada em Lote
            </Button>
          </div>
        </div>

        <Tabs value={tab} onValueChange={setTab}>
          <TabsList className="flex flex-wrap h-auto">
            <TabsTrigger value="overview">Visão Geral</TabsTrigger>
            <TabsTrigger value="current">Estoque Atual</TabsTrigger>
            <TabsTrigger value="entry">Entrada</TabsTrigger>
            <TabsTrigger value="exit">Saída</TabsTrigger>
            <TabsTrigger value="adjustments">Ajustes</TabsTrigger>
            <TabsTrigger value="history">Histórico</TabsTrigger>
          </TabsList>

          <TabsContent value="overview" className="mt-4">
            <InventoryOverview products={products} movements={movements} />
          </TabsContent>
          <TabsContent value="current" className="mt-4">
            <InventoryCurrentTable products={products} />
          </TabsContent>
          <TabsContent value="entry" className="mt-4">
            <div className="flex flex-col sm:flex-row justify-center gap-3 py-10">
              <Button onClick={() => openForm("entry")} size="lg">
                <Plus className="h-5 w-5" /> Entrada Simples
              </Button>
              <Button onClick={() => setBatchOpen(true)} size="lg" variant="secondary">
                <Boxes className="h-5 w-5" /> Nova Entrada em Lote
              </Button>
            </div>
          </TabsContent>
          <TabsContent value="exit" className="mt-4">
            <div className="flex justify-center py-10">
              <Button onClick={() => openForm("exit")} size="lg" variant="outline">
                <Plus className="h-5 w-5" /> Registrar Saída de Estoque
              </Button>
            </div>
          </TabsContent>
          <TabsContent value="adjustments" className="mt-4">
            <div className="flex flex-col sm:flex-row justify-center gap-3 py-10">
              <Button onClick={() => openForm("adjustment")} size="lg" variant="outline">
                <Plus className="h-5 w-5" /> Ajuste Individual
              </Button>
              <Button onClick={() => setStocktakingOpen(true)} size="lg" variant="secondary">
                <ClipboardCheck className="h-5 w-5" /> Balanço em Massa
              </Button>
            </div>
          </TabsContent>
          <TabsContent value="history" className="mt-4">
            <InventoryHistory movements={movements} />
          </TabsContent>
        </Tabs>
      </div>

      <InventoryMovementForm
        open={formOpen}
        onOpenChange={setFormOpen}
        type={formType}
        products={products}
      />

      <BatchEntryDialog
        open={batchOpen}
        onOpenChange={setBatchOpen}
        products={products}
      />

      <MassStocktakingDialog
        open={stocktakingOpen}
        onOpenChange={setStocktakingOpen}
        products={products}
      />
    </div>
  );
}