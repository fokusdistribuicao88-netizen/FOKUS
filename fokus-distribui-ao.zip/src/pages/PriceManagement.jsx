import React, { useState, useMemo, useCallback } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { useAuth } from '@/lib/AuthContext';

import { ArrowLeft, Download, FileSpreadsheet, DollarSign, Loader2, History, Undo2, Upload, Save } from 'lucide-react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { Button } from '@/components/ui/button';
import { useToast } from '@/components/ui/use-toast';
import PriceFilters from '@/components/pricemgmt/PriceFilters';
import PriceTable from '@/components/pricemgmt/PriceTable';
import BulkAdjustPanel from '@/components/pricemgmt/BulkAdjustPanel';
import PriceHistoryDialog from '@/components/pricemgmt/PriceHistoryDialog';
import ImportPricesDialog from '@/components/pricemgmt/ImportPricesDialog';
import ExportImportMenu from '@/components/admin/ExportImportMenu';
import { ALL_PRICE_FIELDS, FIELD_LABELS, computeMargin, computeNewValue } from '@/components/pricemgmt/constants';

const PAGE_SIZE = 50;

export default function PriceManagement() {
  const queryClient = useQueryClient();
  const { toast } = useToast();
  const { user } = useAuth();
  const canEdit = user?.role === 'admin' || user?.role === 'gerente';
  const [historyOpen, setHistoryOpen] = useState(false);
  const [importOpen, setImportOpen] = useState(false);
  const [reverting, setReverting] = useState(false);

  const [search, setSearch] = useState('');
  const [category, setCategory] = useState('');
  const [brand, setBrand] = useState('');
  const [supplier, setSupplier] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [stockFilter, setStockFilter] = useState('all');
  const [priceMin, setPriceMin] = useState('');
  const [priceMax, setPriceMax] = useState('');
  const [sortField, setSortField] = useState('name');
  const [sortDir, setSortDir] = useState('asc');
  const [page, setPage] = useState(1);
  const [selectedIds, setSelectedIds] = useState(new Set());
  const [saving, setSaving] = useState(false);
  const [pending, setPending] = useState({});
  const pendingCount = Object.values(pending).reduce((s, f) => s + Object.keys(f).length, 0);

  const { data: products = [], isLoading } = useQuery({
    queryKey: ['products'],
    queryFn: () => base44.entities.Product.list(),
    staleTime: 60 * 1000,
  });

  const categories = useMemo(() => [...new Set(products.map((p) => p.category).filter(Boolean))].sort(), [products]);
  const brands = useMemo(() => [...new Set(products.map((p) => p.brand).filter(Boolean))].sort(), [products]);
  const suppliers = useMemo(() => [...new Set(products.map((p) => p.supplier).filter(Boolean))].sort(), [products]);

  const hasActiveFilters = !!(search || category || brand || supplier || statusFilter !== 'all' || stockFilter !== 'all' || priceMin || priceMax);

  const filtered = useMemo(() => {
    const q = search.toLowerCase().trim();
    const min = parseFloat(priceMin);
    const max = parseFloat(priceMax);
    let result = products.filter((p) => {
      if (q && !(p.name?.toLowerCase().includes(q) || p.code?.toLowerCase().includes(q) || p.brand?.toLowerCase().includes(q))) return false;
      if (category && p.category !== category) return false;
      if (brand && p.brand !== brand) return false;
      if (supplier && p.supplier !== supplier) return false;
      if (statusFilter !== 'all' && (p.status || 'active') !== statusFilter) return false;
      if (stockFilter !== 'all') {
        const out = !p.in_stock || p.stock_quantity === 0;
        if (stockFilter === 'in' && out) return false;
        if (stockFilter === 'out' && !out) return false;
      }
      const eff = p.price ?? 0;
      if (!isNaN(min) && eff < min) return false;
      if (!isNaN(max) && eff > max) return false;
      return true;
    });

    result.sort((a, b) => {
      let av = a[sortField];
      let bv = b[sortField];
      if (sortField === 'margin') {
        av = computeMargin(a.price, a.cost);
        bv = computeMargin(b.price, b.cost);
      }
      if (typeof av === 'string') {
        return sortDir === 'asc' ? (av || '').localeCompare(bv || '', 'pt-BR') : (bv || '').localeCompare(av || '', 'pt-BR');
      }
      av = Number(av) || 0;
      bv = Number(bv) || 0;
      return sortDir === 'asc' ? av - bv : bv - av;
    });
    return result;
  }, [products, search, category, brand, supplier, statusFilter, stockFilter, priceMin, priceMax, sortField, sortDir]);

  const totalPages = Math.max(1, Math.ceil(filtered.length / PAGE_SIZE));
  const currentPage = Math.min(page, totalPages);
  const pageItems = filtered.slice((currentPage - 1) * PAGE_SIZE, currentPage * PAGE_SIZE);

  const selectedProducts = useMemo(
    () => filtered.filter((p) => selectedIds.has(p.id)),
    [filtered, selectedIds]
  );

  const allPageSelected = pageItems.length > 0 && pageItems.every((p) => selectedIds.has(p.id));

  const toggleSelect = useCallback((id) => {
    setSelectedIds((prev) => {
      const n = new Set(prev);
      n.has(id) ? n.delete(id) : n.add(id);
      return n;
    });
  }, []);

  const toggleSelectPage = useCallback(() => {
    setSelectedIds((prev) => {
      const n = new Set(prev);
      if (pageItems.every((p) => n.has(p.id))) {
        pageItems.forEach((p) => n.delete(p.id));
      } else {
        pageItems.forEach((p) => n.add(p.id));
      }
      return n;
    });
  }, [pageItems]);

  const selectAllFiltered = useCallback(() => {
    setSelectedIds(new Set(filtered.map((p) => p.id)));
  }, [filtered]);

  const clearSelection = useCallback(() => setSelectedIds(new Set()), []);

  const handleSort = useCallback((field) => {
    setSortField((prevField) => {
      if (prevField === field) {
        setSortDir((d) => (d === 'asc' ? 'desc' : 'asc'));
        return field;
      }
      setSortDir('asc');
      return field;
    });
  }, []);

  const stageChange = useCallback((productId, field, value) => {
    const product = products.find((p) => p.id === productId);
    const original = product?.[field];
    setPending((prev) => {
      const n = { ...prev };
      if (value === original) {
        if (n[productId]) {
          delete n[productId][field];
          if (Object.keys(n[productId]).length === 0) delete n[productId];
        }
      } else {
        n[productId] = { ...(n[productId] || {}), [field]: value };
      }
      return n;
    });
  }, [products]);

  const handleDiscard = useCallback(() => setPending({}), []);

  const handleSaveAll = useCallback(async () => {
    if (pendingCount === 0) return;
    setSaving(true);
    const updates = [];
    const history = [];
    Object.entries(pending).forEach(([productId, fields]) => {
      const product = products.find((p) => p.id === productId);
      const upd = { id: productId };
      Object.entries(fields).forEach(([field, newVal]) => {
        const oldVal = product?.[field] ?? 0;
        upd[field] = newVal;
        if (oldVal !== newVal) {
          history.push({
            product_id: productId,
            product_name: product?.name || '',
            field,
            old_value: oldVal,
            new_value: newVal,
            percent: oldVal > 0 ? Math.round(((newVal - oldVal) / oldVal) * 10000) / 100 : null,
            action_type: 'single',
          });
        }
      });
      updates.push(upd);
    });
    try {
      await base44.entities.Product.bulkUpdate(updates);
      if (history.length) await base44.entities.PriceHistory.bulkCreate(history);
      queryClient.invalidateQueries({ queryKey: ['products'] });
      toast({ title: 'Alterações salvas', description: `${history.length} preço(s) atualizado(s) com sucesso.` });
      setPending({});
    } catch (e) {
      toast({ title: 'Erro ao salvar', description: e.message, variant: 'destructive' });
    } finally {
      setSaving(false);
    }
  }, [pending, pendingCount, products, queryClient, toast]);

  const handleStatusToggle = useCallback(async (product) => {
    const next = product.status === 'inactive' ? 'active' : 'inactive';
    try {
      await base44.entities.Product.update(product.id, { status: next });
      queryClient.invalidateQueries({ queryKey: ['products'] });
    } catch (e) {
      toast({ title: 'Erro ao alterar status', description: e.message, variant: 'destructive' });
    }
  }, [queryClient, toast]);

  const handleBulkApply = useCallback(async (config) => {
    const targets = config.target === 'all' ? ALL_PRICE_FIELDS : [config.target];
    const batchId = (crypto?.randomUUID?.() || String(Date.now()));
    const description = `${config.operation}${config.value}${config.type === 'percent' ? '%' : ' R$'} em ${config.target === 'all' ? 'todos os preços' : FIELD_LABELS[config.target]}`;
    const updates = [];
    const history = [];
    selectedProducts.forEach((p) => {
      const updated = { id: p.id };
      targets.forEach((f) => {
        const oldVal = p[f] ?? 0;
        const newVal = computeNewValue(oldVal, config.operation, config.type, config.value);
        updated[f] = newVal;
        history.push({
          product_id: p.id,
          product_name: p.name || '',
          field: f,
          old_value: oldVal,
          new_value: newVal,
          percent: config.type === 'percent' ? (config.operation === '+' ? config.value : -config.value) : null,
          batch_id: batchId,
          batch_description: description,
          action_type: 'bulk',
        });
      });
      updates.push(updated);
    });

    try {
      await base44.entities.Product.bulkUpdate(updates);
      await base44.entities.PriceHistory.bulkCreate(history);
      queryClient.invalidateQueries({ queryKey: ['products'] });
      toast({
        title: 'Preços atualizados',
        description: `${selectedProducts.length} produto(s) — ${history.length} alteração(ões) registrada(s).`,
      });
      clearSelection();
    } catch (e) {
      toast({ title: 'Erro na atualização em massa', description: e.message, variant: 'destructive' });
    }
  }, [selectedProducts, queryClient, toast, clearSelection]);

  const exportExcel = useCallback(async () => {
    const XLSX = await import('xlsx');
    const rows = filtered.map((p) => ({
      'Código': p.code || '',
      'Produto': p.name,
      'Categoria': p.category || '',
      'Marca': p.brand || '',
      'Fornecedor': p.supplier || '',
      'Estoque': p.stock_quantity ?? '',
      'Custo': p.cost ?? '',
      'Venda': p.price ?? '',
      'Atacado': p.price_wholesale ?? '',
      'À Vista': p.price_cash ?? '',
      'Promo': p.price_promo ?? '',
      'Varejo': p.retail_price ?? '',
      'Tab 1': p.table_1 ?? '',
      'Tab 2': p.table_2 ?? '',
      'Tab 3': p.table_3 ?? '',
      'Tab 4': p.table_4 ?? '',
      'Tab 5': p.table_5 ?? '',
      'Status': p.status || 'active',
    }));
    const ws = XLSX.utils.json_to_sheet(rows);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'Preços');
    XLSX.writeFile(wb, 'gerenciamento-precos.xlsx');
  }, [filtered]);

  const exportCSV = useCallback(() => {
    const headers = ['Código', 'Produto', 'Categoria', 'Marca', 'Fornecedor', 'Estoque', 'Custo', 'Venda', 'Atacado', 'À Vista', 'Promo', 'Varejo', 'Tab 1', 'Tab 2', 'Tab 3', 'Tab 4', 'Tab 5', 'Status'];
    const rows = filtered.map((p) => [p.code || '', p.name, p.category || '', p.brand || '', p.supplier || '', p.stock_quantity ?? '', p.cost ?? '', p.price ?? '', p.price_wholesale ?? '', p.price_cash ?? '', p.price_promo ?? '', p.retail_price ?? '', p.table_1 ?? '', p.table_2 ?? '', p.table_3 ?? '', p.table_4 ?? '', p.table_5 ?? '', p.status || 'active']);
    const csv = [headers, ...rows].map((r) => r.map((c) => `"${String(c).replace(/"/g, '""')}"`).join(',')).join('\n');
    const blob = new Blob(['\ufeff' + csv], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'precos.csv';
    a.click();
    URL.revokeObjectURL(url);
  }, [filtered]);

  const handleRevert = useCallback(async (batch) => {
    setReverting(true);
    try {
      const items = batch.items;
      const updates = items.map((r) => ({ id: r.product_id, [r.field]: r.old_value }));
      const history = items.map((r) => ({
        product_id: r.product_id,
        product_name: r.product_name || '',
        field: r.field,
        old_value: r.new_value,
        new_value: r.old_value,
        percent: r.new_value > 0 ? Math.round(((r.old_value - r.new_value) / r.new_value) * 10000) / 100 : null,
        batch_id: crypto?.randomUUID?.() || String(Date.now()),
        batch_description: `Reversão: ${batch.description}`,
        action_type: 'bulk',
      }));
      await base44.entities.Product.bulkUpdate(updates);
      await base44.entities.PriceHistory.bulkCreate(history);
      queryClient.invalidateQueries({ queryKey: ['products'] });
      queryClient.invalidateQueries({ queryKey: ['price-history'] });
      toast({ title: 'Atualização revertida', description: `${items.length} preço(s) restaurado(s) ao valor anterior.` });
      setHistoryOpen(false);
    } catch (e) {
      toast({ title: 'Erro ao reverter', description: e.message, variant: 'destructive' });
    } finally {
      setReverting(false);
    }
  }, [queryClient, toast]);

  return (
    <div className="min-h-screen bg-background">
      <header className="sticky top-0 z-40 bg-card/95 backdrop-blur-md border-b border-border shadow-sm">
        <div className="max-w-[1600px] mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center gap-2 sm:gap-3 h-16">
            <div className="w-9 h-9 bg-gradient-to-br from-blue-600 to-blue-800 rounded-lg flex items-center justify-center shrink-0">
              <DollarSign className="w-5 h-5 text-white" />
            </div>
            <div className="min-w-0">
              <h1 className="text-sm sm:text-base font-bold text-foreground leading-tight truncate">Gerenciamento de Preços</h1>
              <p className="text-xs text-muted-foreground hidden sm:block">Edição em massa e tabelas de valores</p>
            </div>
            <div className="ml-auto flex items-center gap-1.5 sm:gap-2 shrink-0">
              <Button variant="outline" size="icon" onClick={() => setHistoryOpen(true)} className="h-9 w-9">
                <History className="w-4 h-4" />
              </Button>
              <ExportImportMenu
                items={[
                  ...(canEdit ? [{ label: 'Importar', icon: Upload, onClick: () => setImportOpen(true), disabled: products.length === 0 }] : []),
                  { label: 'Exportar CSV', icon: Download, onClick: exportCSV, disabled: filtered.length === 0 },
                  { label: 'Exportar Excel', icon: FileSpreadsheet, onClick: exportExcel, disabled: filtered.length === 0 },
                ]}
              />
              <Link to={createPageUrl('AdminProducts')}>
                <Button variant="outline" size="icon" className="h-9 w-9">
                  <ArrowLeft className="w-4 h-4" />
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </header>

      <main className="max-w-[1600px] mx-auto px-4 sm:px-6 lg:px-8 py-6">
        {!canEdit && (
          <div className="mb-4 rounded-lg border border-amber-200 dark:border-amber-800 bg-amber-50 dark:bg-amber-950/30 px-4 py-2 text-sm text-amber-800 dark:text-amber-400">
            Você tem permissão somente leitura. Apenas administradores e gerentes podem alterar preços.
          </div>
        )}
        <PriceFilters
          search={search}
          onSearchChange={(v) => { setSearch(v); setPage(1); }}
          categories={categories}
          selectedCategory={category}
          onCategoryChange={(v) => { setCategory(v); setPage(1); }}
          brands={brands}
          selectedBrand={brand}
          onBrandChange={(v) => { setBrand(v); setPage(1); }}
          suppliers={suppliers}
          selectedSupplier={supplier}
          onSupplierChange={(v) => { setSupplier(v); setPage(1); }}
          statusFilter={statusFilter}
          onStatusChange={(v) => { setStatusFilter(v); setPage(1); }}
          stockFilter={stockFilter}
          onStockChange={(v) => { setStockFilter(v); setPage(1); }}
          priceMin={priceMin}
          priceMax={priceMax}
          onPriceMinChange={setPriceMin}
          onPriceMaxChange={setPriceMax}
          onClear={() => {
            setSearch(''); setCategory(''); setBrand(''); setSupplier('');
            setStatusFilter('all'); setStockFilter('all'); setPriceMin(''); setPriceMax(''); setPage(1);
          }}
          resultsCount={filtered.length}
          totalCount={products.length}
          hasActiveFilters={hasActiveFilters}
        />

        {canEdit && (
          <BulkAdjustPanel
            selectedCount={selectedIds.size}
            selectedProducts={selectedProducts}
            onApply={handleBulkApply}
            onClear={clearSelection}
            onSelectAll={selectAllFiltered}
          />
        )}

        {canEdit && pendingCount > 0 && (
          <div className="sticky top-16 z-30 mb-4 flex items-center justify-between gap-2 rounded-xl border border-amber-300 bg-amber-50 dark:bg-amber-950/40 dark:border-amber-800 px-3 sm:px-4 py-2.5 shadow-sm">
            <span className="text-xs sm:text-sm font-medium text-amber-800 dark:text-amber-400">
              {pendingCount} alteração(ões) não salva(s)
            </span>
            <div className="flex items-center gap-2 shrink-0">
              <Button size="sm" variant="outline" onClick={handleDiscard} disabled={saving} className="h-8">
                Descartar
              </Button>
              <Button size="sm" onClick={handleSaveAll} disabled={saving} className="h-8 bg-blue-600 hover:bg-blue-700 text-white">
                {saving ? <Loader2 className="w-4 h-4 animate-spin" /> : <Save className="w-4 h-4" />}
                Salvar
              </Button>
            </div>
          </div>
        )}

        {isLoading ? (
          <div className="flex items-center justify-center py-20">
            <Loader2 className="w-8 h-8 animate-spin text-blue-600" />
          </div>
        ) : filtered.length === 0 ? (
          <div className="text-center py-20">
            <div className="w-16 h-16 bg-muted rounded-full flex items-center justify-center mx-auto mb-4">
              <DollarSign className="w-8 h-8 text-muted-foreground" />
            </div>
            <h3 className="text-lg font-semibold text-foreground mb-1">Nenhum produto encontrado</h3>
            <p className="text-muted-foreground">Ajuste os filtros para ver os produtos.</p>
          </div>
        ) : (
          <>
            <PriceTable
              products={pageItems}
              selectedIds={selectedIds}
              onToggleSelect={toggleSelect}
              onToggleSelectPage={toggleSelectPage}
              allPageSelected={allPageSelected}
              sortField={sortField}
              sortDir={sortDir}
              onSort={handleSort}
              onPriceSave={stageChange}
              onStatusToggle={handleStatusToggle}
              canEdit={canEdit}
              pending={pending}
            />

            <div className="flex flex-col sm:flex-row items-center justify-between gap-3 mt-4">
              <span className="text-xs text-muted-foreground">
                Página {currentPage} de {totalPages} — {filtered.length} produtos
                {saving && <span className="ml-2 text-blue-600">● salvando…</span>}
              </span>
              <div className="flex items-center gap-2">
                <Button variant="outline" size="sm" disabled={currentPage <= 1} onClick={() => setPage((p) => p - 1)}>
                  Anterior
                </Button>
                <span className="text-xs text-muted-foreground px-2">{currentPage} / {totalPages}</span>
                <Button variant="outline" size="sm" disabled={currentPage >= totalPages} onClick={() => setPage((p) => p + 1)}>
                  Próxima
                </Button>
              </div>
            </div>
          </>
        )}
      </main>

      <PriceHistoryDialog open={historyOpen} onClose={() => setHistoryOpen(false)} onRevert={handleRevert} />
      <ImportPricesDialog
        open={importOpen}
        onClose={() => setImportOpen(false)}
        products={products}
        onDone={() => queryClient.invalidateQueries({ queryKey: ['products'] })}
      />
    </div>
  );
}