import React, { useEffect, useMemo, useRef, useState } from 'react';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { Link, useNavigate, useSearchParams } from 'react-router-dom';
import { base44 } from '@/api/base44Client';
import { useAuth } from '@/lib/AuthContext';
import { useToast } from '@/components/ui/use-toast';
import { Button } from '@/components/ui/button';
import { Switch } from '@/components/ui/switch';
import { AlertDialog, AlertDialogContent, AlertDialogHeader, AlertDialogTitle, AlertDialogDescription, AlertDialogFooter, AlertDialogCancel, AlertDialogAction } from '@/components/ui/alert-dialog';
import {
  ArrowLeft, FileText, Save, Upload, Download, RotateCcw, Eye, Printer,
  History, Send, Loader2, LayoutGrid, CloudUpload, Check, Copy, Droplet, Trash2,
} from 'lucide-react';
import { logActivity } from '@/lib/activityLog';
import { defaultConfig, sampleDataFor, sampleSectionsFor, PDF_DOCUMENTS, REPORT_DOC_TYPES } from '@/lib/pdfTemplateDefaults';
import { buildTemplatePdf, buildReportPdf } from '@/lib/pdfTemplateRender';
import { generatePixBrCode } from '@/lib/pixBrCode';
import QRCode from 'qrcode';
import { loadImageDataUrlsForConfig } from '@/lib/pdfTemplateImages';
import TemplateOverview from '@/components/pdftemplates/TemplateOverview';
import TemplatePreview from '@/components/pdftemplates/TemplatePreview';
import EditorSidebar from '@/components/pdftemplates/EditorSidebar';
import EditorProperties from '@/components/pdftemplates/EditorProperties';
import ApplyToOthersDialog from '@/components/pdftemplates/ApplyToOthersDialog';
import WatermarkLibrary from '@/components/pdftemplates/WatermarkLibrary';
import CreateDocTypeDialog from '@/components/pdftemplates/CreateDocTypeDialog';
import ExportImportMenu from '@/components/admin/ExportImportMenu';

// Merge profundo: preserva campos novos do padrão ao reabrir um modelo antigo.
function deepMergeConfig(base, saved) {
  const out = { ...base };
  for (const k of Object.keys(saved || {})) {
    const bv = base[k], sv = saved[k];
    if (bv && typeof bv === 'object' && !Array.isArray(bv) && sv && typeof sv === 'object' && !Array.isArray(sv)) {
      out[k] = { ...bv, ...sv };
      for (const sk of Object.keys(sv)) {
        if (bv[sk] && typeof bv[sk] === 'object' && !Array.isArray(bv[sk]) && sv[sk] && typeof sv[sk] === 'object' && !Array.isArray(sv[sk])) {
          out[k][sk] = { ...bv[sk], ...sv[sk] };
        }
      }
    } else {
      out[k] = sv;
    }
  }
  return out;
}

export default function PdfTemplateManagement() {
  const { user } = useAuth();
  const { toast } = useToast();
  const qc = useQueryClient();
  const navigate = useNavigate();
  const [searchParams, setSearchParams] = useSearchParams();
  const [selectedType, setSelectedType] = useState(null);
  const [config, setConfig] = useState(null);
  const [dirty, setDirty] = useState(false);
  const [saving, setSaving] = useState(false);
  const [saveState, setSaveState] = useState('idle'); // idle | saving | saved
  const [autoSave, setAutoSave] = useState(() => { try { return localStorage.getItem('pdf-autosave') === 'true'; } catch { return false; } });
  const [propsOpen, setPropsOpen] = useState(() => { try { return localStorage.getItem('pdf-editor-props') !== 'false'; } catch { return true; } });
  const [mobileTools, setMobileTools] = useState(false);
  const [confirmExit, setConfirmExit] = useState(false);
  const [applyOpen, setApplyOpen] = useState(false);
  const [applying, setApplying] = useState(false);
  const [confirmDelete, setConfirmDelete] = useState(false);
  const [deleting, setDeleting] = useState(false);
  const [createOpen, setCreateOpen] = useState(false);
  const [creating, setCreating] = useState(false);
  const [deletingType, setDeletingType] = useState(null);
  const importFileRef = useRef(null);
  const [view, setView] = useState('templates');

  const { data: templates = [], isLoading } = useQuery({
    queryKey: ['pdf-templates'],
    queryFn: () => base44.entities.PdfTemplate.list('-updated_date'),
    staleTime: 30 * 1000,
  });

  const { data: customDocTypes = [] } = useQuery({
    queryKey: ['pdf-document-types'],
    queryFn: () => base44.entities.PdfDocumentType.list('-updated_date'),
    staleTime: 30 * 1000,
  });

  // Todos os documentos do sistema: tipos embutidos (PDF_DOCUMENTS) + tipos personalizados + modelos salvos.
  const allDocs = useMemo(() => {
    const map = {};
    PDF_DOCUMENTS.forEach((d) => { map[d.type] = { type: d.type, label: d.label, category: d.category, size: d.size, orientation: d.orientation }; });
    customDocTypes.forEach((d) => { map[d.type] = { type: d.type, label: d.label, category: d.category, size: d.size, orientation: d.orientation, _custom: true }; });
    templates.forEach((t) => { if (t.document_type && !map[t.document_type]) map[t.document_type] = { type: t.document_type, label: t.document_label || t.document_type, category: t.category }; });
    return Object.values(map);
  }, [templates, customDocTypes]);

  const selectedDoc = useMemo(() => allDocs.find((d) => d.type === selectedType), [allDocs, selectedType]);
  const currentTemplate = useMemo(() => templates.find((t) => t.document_type === selectedType), [templates, selectedType]);
  const sampleData = useMemo(() => (selectedDoc ? sampleDataFor(selectedDoc) : null), [selectedDoc]);

  const { data: versions = [] } = useQuery({
    queryKey: ['pdf-template-versions', selectedType],
    queryFn: () => base44.entities.PdfTemplateVersion.filter({ document_type: selectedType }, '-version'),
    enabled: !!selectedType,
    staleTime: 30 * 1000,
  });

  const { data: globalRec = [] } = useQuery({
    queryKey: ['pdf-global-header'],
    queryFn: () => base44.entities.PdfTemplate.filter({ document_type: '__global_header' }),
    staleTime: 30 * 1000,
  });

  const [globalHeader, setGlobalHeader] = useState(null);
  const [dirtyGlobal, setDirtyGlobal] = useState(false);

  useEffect(() => {
    if (globalRec.length && globalHeader === null) {
      try {
        const parsed = JSON.parse(globalRec[0].config);
        if (parsed?.header) setGlobalHeader(parsed.header);
      } catch { /* ignore */ }
    }
  }, [globalRec, globalHeader]);

  useEffect(() => { localStorage.setItem('pdf-editor-props', String(propsOpen)); }, [propsOpen]);
  useEffect(() => { localStorage.setItem('pdf-autosave', String(autoSave)); }, [autoSave]);

  // Deep-link: ?doc=TYPE abre automaticamente o modelo correspondente (vindo do PDV/pedidos).
  useEffect(() => {
    const docType = searchParams.get('doc');
    if (!docType || selectedType || isLoading) return;
    const doc = allDocs.find((d) => d.type === docType);
    if (doc) openDoc(doc);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [searchParams, selectedType, isLoading]);

  const effectiveHeader = config?.header?.useGlobal ? (globalHeader || config?.header) : config?.header;
  const effectiveConfig = config ? { ...config, header: effectiveHeader } : config;

  const openDoc = (doc) => {
    setSelectedType(doc.type);
    const existing = templates.find((t) => t.document_type === doc.type);
    const base = defaultConfig(doc);
    let loaded = base;
    try {
      loaded = existing?.config ? deepMergeConfig(base, JSON.parse(existing.config)) : base;
    } catch {
      loaded = base;
    }
    setConfig(loaded);
    setDirty(false);
    setSaveState('idle');
    setMobileTools(false);
  };

  const onChange = (c) => { setConfig(c); setDirty(true); };

  const handleHeaderChange = (updater) => {
    if (config?.header?.useGlobal) {
      setGlobalHeader((prev) => (typeof updater === 'function' ? updater(prev || config?.header) : updater));
      setDirtyGlobal(true);
    } else {
      setConfig((c) => ({ ...c, header: typeof updater === 'function' ? updater(c.header) : updater }));
      setDirty(true);
    }
  };

  const onUseGlobalChange = (v) => {
    setConfig((c) => ({ ...c, header: { ...c.header, useGlobal: v } }));
    setDirty(true);
    if (v && !globalHeader) { setGlobalHeader({ ...config.header, useGlobal: true }); setDirtyGlobal(true); }
  };

  const handleSave = async (publish = false, opts = {}) => {
    const { silent = false } = opts;
    if (!selectedDoc || !config) return;
    setSaving(true);
    if (silent) setSaveState('saving');
    try {
      const payload = {
        document_type: selectedDoc.type,
        document_label: selectedDoc.label,
        category: selectedDoc.category,
        config: JSON.stringify(config),
        theme: config.theme || '',
        is_published: publish ? true : (currentTemplate?.is_published || false),
        version: (currentTemplate?.version || 0) + 1,
        last_updated_by: user?.email,
        status: 'active',
      };
      let saved;
      if (currentTemplate) {
        saved = await base44.entities.PdfTemplate.update(currentTemplate.id, payload);
      } else {
        saved = await base44.entities.PdfTemplate.create(payload);
      }
      await base44.entities.PdfTemplateVersion.create({
        template_id: saved.id,
        document_type: selectedDoc.type,
        version: payload.version,
        config: JSON.stringify(config),
        description: publish ? 'Versão publicada' : 'Versão salva',
        published: !!publish,
        user_email: user?.email,
      });
      logActivity({
        action: publish ? 'pdf_template_publish' : 'pdf_template_save',
        description: `Modelo PDF "${selectedDoc.label}" ${publish ? 'publicado' : 'salvo'} (v${payload.version})`,
        user, entityType: 'PdfTemplate', entityId: saved.id,
      });
      qc.invalidateQueries({ queryKey: ['pdf-templates'] });
      qc.invalidateQueries({ queryKey: ['pdf-template-versions', selectedType] });

      if (dirtyGlobal && globalHeader) {
        const existing = globalRec[0];
        const gpayload = {
          document_type: '__global_header',
          document_label: 'Cabeçalho Global',
          category: 'dashboard',
          config: JSON.stringify({ header: globalHeader }),
          is_published: true,
          version: (existing?.version || 0) + 1,
          last_updated_by: user?.email,
          status: 'active',
        };
        let gsaved;
        if (existing) gsaved = await base44.entities.PdfTemplate.update(existing.id, gpayload);
        else gsaved = await base44.entities.PdfTemplate.create(gpayload);
        await base44.entities.PdfTemplateVersion.create({
          template_id: gsaved.id,
          document_type: '__global_header',
          version: gpayload.version,
          config: JSON.stringify({ header: globalHeader }),
          description: 'Cabeçalho global atualizado',
          published: true,
          user_email: user?.email,
        });
        logActivity({ action: 'pdf_template_publish', description: `Cabeçalho global atualizado (v${gpayload.version})`, user, entityType: 'PdfTemplate', entityId: gsaved.id });
        qc.invalidateQueries({ queryKey: ['pdf-global-header'] });
        setDirtyGlobal(false);
      }

      setDirty(false);
      if (silent) {
        setSaveState('saved');
        setTimeout(() => setSaveState('idle'), 2500);
      } else {
        setSaveState('idle');
        toast({ title: 'Modelo de PDF salvo com sucesso.', description: `${selectedDoc.label} — versão ${payload.version}` });
      }
      return saved;
    } catch (e) {
      setSaveState('idle');
      if (!silent) toast({ title: 'Erro ao salvar', description: String(e.message || e), variant: 'destructive' });
      throw e;
    } finally {
      setSaving(false);
    }
  };

  const handleRestoreDefault = () => {
    if (!selectedDoc) return;
    setConfig(defaultConfig(selectedDoc));
    setDirty(true);
    toast({ title: 'Modelo padrão restaurado', description: 'Clique em Salvar para aplicar.' });
  };

  const handleExport = () => {
    if (!config) return;
    const blob = new Blob([JSON.stringify({ document_type: selectedType, document_label: selectedDoc?.label, config }, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url; a.download = `modelo-${selectedType}.json`; a.click();
    URL.revokeObjectURL(url);
    logActivity({ action: 'pdf_template_export', description: `Modelo PDF "${selectedDoc?.label}" exportado`, user });
  };

  const handleImport = (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      try {
        const parsed = JSON.parse(reader.result);
        setConfig(parsed.config || parsed);
        setDirty(true);
        toast({ title: 'Modelo importado', description: 'Clique em Salvar para aplicar.' });
      } catch {
        toast({ title: 'Arquivo inválido', variant: 'destructive' });
      }
    };
    reader.readAsText(file);
    e.target.value = '';
  };

  const collectImageConfigs = (cfg) => {
    const make = (i) => (i && i.url ? { url: i.url, rotation: i.rotation || 0 } : null);
    return [make(cfg?.header?.leftImage), make(cfg?.header?.rightImage)].filter(Boolean);
  };

  const handleTest = async (print = false) => {
    try {
      const timgs = collectImageConfigs(effectiveConfig);
      const timages = timgs.length ? await loadImageDataUrlsForConfig(timgs) : {};
      // Gera QR Code PIX de exemplo para a pré-visualização da folha
      if (sampleData?.pixPayment?.pixKey) {
        try {
          const brCode = generatePixBrCode({ key: sampleData.pixPayment.pixKey, amount: sampleData.pixPayment.amount, beneficiary: sampleData.pixPayment.employeeName, city: 'SAO PAULO' });
          timages['__pix_qr__'] = { dataURL: await QRCode.toDataURL(brCode, { width: 300, margin: 1 }), w: 300, h: 300 };
        } catch { /* skip */ }
      }
      const isReport = selectedDoc ? REPORT_DOC_TYPES.includes(selectedDoc.type) : false;
      const pdfDoc = isReport
        ? buildReportPdf(effectiveConfig, sampleSectionsFor(selectedDoc), { title: effectiveConfig?.body?.title || selectedDoc?.label }, timages, null, sampleData || {})
        : buildTemplatePdf(effectiveConfig, sampleData, timages);
      if (print) pdfDoc.autoPrint();
      const url = pdfDoc.output('bloburl');
      window.open(url, '_blank');
      logActivity({ action: 'pdf_template_test', description: `Teste do modelo PDF "${selectedDoc?.label}"`, user });
    } catch (e) {
      toast({ title: 'Erro ao gerar teste', description: String(e.message || e), variant: 'destructive' });
    }
  };

  const handleRestoreVersion = (version) => {
    try {
      const base = defaultConfig(selectedDoc);
      setConfig(deepMergeConfig(base, JSON.parse(version.config)));
      setDirty(true);
      setPropsOpen(false);
      toast({ title: 'Versão restaurada', description: `v${version.version} — clique em Salvar para aplicar.` });
    } catch {
      toast({ title: 'Falha ao restaurar versão', variant: 'destructive' });
    }
  };

  const handlePublishVersion = async (version) => {
    try {
      if (currentTemplate) {
        await base44.entities.PdfTemplate.update(currentTemplate.id, {
          config: version.config,
          is_published: true,
          version: version.version,
          last_updated_by: user?.email,
        });
      }
      await base44.entities.PdfTemplateVersion.update(version.id, { published: true });
      logActivity({
        action: 'pdf_template_publish',
        description: `Versão v${version.version} de "${selectedDoc?.label}" publicada`,
        user, entityType: 'PdfTemplate', entityId: currentTemplate?.id,
      });
      qc.invalidateQueries({ queryKey: ['pdf-templates'] });
      qc.invalidateQueries({ queryKey: ['pdf-template-versions', selectedType] });
      toast({ title: 'Versão publicada' });
    } catch (e) {
      toast({ title: 'Erro ao publicar', description: String(e.message || e), variant: 'destructive' });
    }
  };

  // Remove totalmente um documento do sistema: versões + modelo + tipo personalizado (se aplicável)
  const purgeDocType = async (docType, label, isCustom) => {
    const linked = templates.filter((t) => t.document_type === docType);
    for (const t of linked) {
      await base44.entities.PdfTemplateVersion.deleteMany({ template_id: t.id });
      await base44.entities.PdfTemplate.delete(t.id);
    }
    if (isCustom) {
      const customRecs = customDocTypes.filter((d) => d.type === docType);
      for (const d of customRecs) await base44.entities.PdfDocumentType.delete(d.id);
    }
    logActivity({
      action: 'pdf_template_delete',
      description: `Documento "${label}" removido do sistema${isCustom ? ' (tipo personalizado)' : ''}`,
      user, entityType: 'PdfTemplate',
    });
  };

  const handleDelete = async () => {
    if (!currentTemplate) { setConfirmDelete(false); return; }
    setDeleting(true);
    try {
      const isCustom = !!selectedDoc?._custom;
      await purgeDocType(selectedType, selectedDoc?.label, isCustom);
      qc.invalidateQueries({ queryKey: ['pdf-templates'] });
      qc.invalidateQueries({ queryKey: ['pdf-template-versions'] });
      qc.invalidateQueries({ queryKey: ['pdf-document-types'] });
      toast({ title: isCustom ? 'Documento removido do sistema' : 'Modelo deletado', description: isCustom ? `${selectedDoc?.label} foi removido de todo o sistema.` : `${selectedDoc?.label} voltou ao padrão do sistema.` });
      setConfirmDelete(false);
      setSelectedType(null);
      setConfig(null);
    } catch (e) {
      toast({ title: 'Erro ao deletar', description: String(e.message || e), variant: 'destructive' });
    } finally {
      setDeleting(false);
    }
  };

  // Deletar direto da lista (visão geral) — remove de todo o sistema
  const handleDeleteFromOverview = async (doc, template) => {
    const isCustom = !!doc._custom;
    setDeletingType(doc.type);
    try {
      await purgeDocType(doc.type, doc.label, isCustom);
      qc.invalidateQueries({ queryKey: ['pdf-templates'] });
      qc.invalidateQueries({ queryKey: ['pdf-template-versions'] });
      qc.invalidateQueries({ queryKey: ['pdf-document-types'] });
      toast({ title: isCustom ? 'Documento removido do sistema' : 'Modelo deletado', description: isCustom ? `${doc.label} foi removido de todo o sistema.` : `${doc.label} voltou ao padrão do sistema.` });
    } catch (e) {
      toast({ title: 'Erro ao deletar', description: String(e.message || e), variant: 'destructive' });
    } finally {
      setDeletingType(null);
    }
  };

  const handleCreate = async (data) => {
    setCreating(true);
    try {
      // Cria o tipo de documento personalizado
      await base44.entities.PdfDocumentType.create({
        type: data.type,
        label: data.label,
        category: data.category,
        size: data.size,
        orientation: data.orientation,
        is_custom: true,
        created_by_name: user?.full_name || user?.email,
      });
      // Cria um modelo inicial com a configuração padrão
      const docObj = { type: data.type, label: data.label, category: data.category, size: data.size, orientation: data.orientation };
      const cfg = defaultConfig(docObj);
      const saved = await base44.entities.PdfTemplate.create({
        document_type: data.type,
        document_label: data.label,
        category: data.category,
        config: JSON.stringify(cfg),
        theme: cfg.theme || '',
        is_published: false,
        version: 1,
        last_updated_by: user?.email,
        status: 'active',
      });
      await base44.entities.PdfTemplateVersion.create({
        template_id: saved.id,
        document_type: data.type,
        version: 1,
        config: JSON.stringify(cfg),
        description: 'Versão inicial',
        published: false,
        user_email: user?.email,
      });
      logActivity({
        action: 'pdf_template_create',
        description: `Novo tipo de documento PDF criado: "${data.label}"`,
        user, entityType: 'PdfTemplate', entityId: saved.id,
      });
      qc.invalidateQueries({ queryKey: ['pdf-document-types'] });
      qc.invalidateQueries({ queryKey: ['pdf-templates'] });
      toast({ title: 'Documento criado', description: `${data.label} foi adicionado ao sistema.` });
      setCreateOpen(false);
    } catch (e) {
      toast({ title: 'Erro ao criar documento', description: String(e.message || e), variant: 'destructive' });
    } finally {
      setCreating(false);
    }
  };

  const goDashboard = () => { if (dirty) setConfirmExit(true); else navigate('/Dashboard'); };

  // Auto Save: salva automaticamente após 1,5s sem interação
  const saveRef = useRef();
  saveRef.current = { save: (p, o) => handleSave(p, o) };
  useEffect(() => {
    if (!autoSave || !dirty || !selectedDoc || !config || saving) return;
    setSaveState('saving');
    const t = setTimeout(() => {
      saveRef.current.save(false, { silent: true }).catch(() => {});
    }, 1500);
    return () => clearTimeout(t);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [autoSave, dirty, selectedType, config]);

  // Proteção contra perda ao fechar/atualizar
  useEffect(() => {
    const onBeforeUnload = (e) => {
      if (dirty) { e.preventDefault(); e.returnValue = ''; }
    };
    window.addEventListener('beforeunload', onBeforeUnload);
    return () => window.removeEventListener('beforeunload', onBeforeUnload);
  }, [dirty]);

  useEffect(() => {
    const onKey = (e) => {
      if (e.altKey && e.key === 'ArrowLeft') {
        e.preventDefault();
        if (dirty) setConfirmExit(true); else navigate('/Dashboard');
      }
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [dirty, navigate]);

  const handleApplyToOthers = async (types) => {
    if (!types.length || !selectedDoc || !config) return;
    setApplying(true);
    try {
      const { fields: _f, ...styleConfig } = config;
      let ok = 0;
      for (const type of types) {
        const doc = allDocs.find((d) => d.type === type);
        if (!doc) continue;
        const targetDefault = defaultConfig(doc);
        const merged = { ...styleConfig, fields: targetDefault.fields };
        const existing = templates.find((t) => t.document_type === type);
        const payload = {
          document_type: doc.type,
          document_label: doc.label,
          category: doc.category,
          config: JSON.stringify(merged),
          theme: merged.theme || '',
          is_published: existing?.is_published || false,
          version: (existing?.version || 0) + 1,
          last_updated_by: user?.email,
          status: 'active',
        };
        let saved;
        if (existing) saved = await base44.entities.PdfTemplate.update(existing.id, payload);
        else saved = await base44.entities.PdfTemplate.create(payload);
        await base44.entities.PdfTemplateVersion.create({
          template_id: saved.id,
          document_type: doc.type,
          version: payload.version,
          config: JSON.stringify(merged),
          description: `Configuração aplicada de "${selectedDoc.label}"`,
          published: false,
          user_email: user?.email,
        });
        ok++;
      }
      logActivity({
        action: 'pdf_template_apply_to_others',
        description: `Configuração de "${selectedDoc.label}" aplicada em ${ok} modelo(s)`,
        user, entityType: 'PdfTemplate',
      });
      qc.invalidateQueries({ queryKey: ['pdf-templates'] });
      qc.invalidateQueries({ queryKey: ['pdf-template-versions'] });
      toast({ title: 'Configuração aplicada', description: `${ok} modelo(s) atualizado(s) com o estilo de "${selectedDoc.label}".` });
      setApplyOpen(false);
    } catch (e) {
      toast({ title: 'Erro ao aplicar', description: String(e.message || e), variant: 'destructive' });
    } finally {
      setApplying(false);
    }
  };

  const handleExitSave = async () => {
    try { await saveRef.current.save(false, { silent: true }); } catch { /* ignore */ }
    setConfirmExit(false);
    navigate('/Dashboard');
  };

  if (user && user.role !== 'admin' && user.role !== 'gerente') {
    return (
      <div className="min-h-screen flex items-center justify-center p-6 text-center">
        <div>
          <FileText className="w-12 h-12 text-amber-500 mx-auto mb-3" />
          <h2 className="text-xl font-semibold mb-2">Acesso restrito</h2>
          <p className="text-muted-foreground mb-6">Apenas administradores e gerentes podem gerenciar os modelos de PDF.</p>
          <Link to="/Dashboard"><Button variant="outline" className="gap-2"><ArrowLeft className="w-4 h-4" /> Dashboard</Button></Link>
        </div>
      </div>
    );
  }

  if (view === 'watermarks') {
    return (
      <div className="min-h-screen bg-muted/30">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 py-6">
          <div className="flex items-center gap-2 mb-4">
            <Button variant="outline" size="sm" onClick={() => setView('templates')} className="gap-1.5"><ArrowLeft className="w-4 h-4" /> Modelos PDF</Button>
            <h1 className="text-2xl font-bold flex items-center gap-2"><Droplet className="w-6 h-6 text-violet-700" /> Gerenciador de Marcas d'Água</h1>
          </div>
          <WatermarkLibrary />
        </div>
      </div>
    );
  }

  if (!selectedDoc) {
    return (
      <>
        <TemplateOverview
          templates={templates}
          loading={isLoading}
          onSelect={openDoc}
          onManageWatermarks={() => setView('watermarks')}
          customDocs={customDocTypes}
          onCreate={() => setCreateOpen(true)}
          onDelete={handleDeleteFromOverview}
          deletingId={deletingType}
        />
        <CreateDocTypeDialog
          open={createOpen}
          onOpenChange={setCreateOpen}
          onCreate={handleCreate}
          creating={creating}
          existingTypes={allDocs.map((d) => d.type)}
        />
      </>
    );
  }

  return (
    <div className="h-screen flex flex-col bg-muted/30 overflow-hidden">
      <header className="flex items-center justify-between gap-2 flex-wrap px-3 sm:px-4 py-2.5 bg-card border-b border-border z-20">
        <div className="flex items-center gap-2 flex-wrap min-w-0">
          <Button variant="ghost" size="sm" onClick={() => { setSelectedType(null); setConfig(null); }} className="gap-2 shrink-0"><ArrowLeft className="w-4 h-4" /> Modelos</Button>
          <h1 className="text-base font-bold flex items-center gap-2 min-w-0"><FileText className="w-5 h-5 text-violet-700 shrink-0" /><span className="truncate">{selectedDoc.label}</span></h1>
          <span className="text-[10px] px-1.5 py-0.5 rounded-full bg-violet-100 text-violet-700 capitalize">{selectedDoc.category}</span>
          {currentTemplate?.is_published && <span className="text-xs px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-700">Publicada</span>}
          {dirty && !autoSave && <span className="text-xs px-2 py-0.5 rounded-full bg-amber-100 text-amber-700">Não salvo</span>}
          {saveState === 'saving' && <span className="text-xs px-2 py-0.5 rounded-full bg-blue-100 text-blue-700 flex items-center gap-1"><Loader2 className="w-3 h-3 animate-spin" /> Salvando...</span>}
          {saveState === 'saved' && <span className="text-xs px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-700 flex items-center gap-1"><Check className="w-3 h-3" /> Todas as alterações foram salvas.</span>}
        </div>
        <div className="flex items-center gap-1.5 flex-wrap">
          <label className="flex items-center gap-1.5 text-xs text-muted-foreground cursor-pointer select-none px-2" title="Salvar automaticamente a cada alteração">
            <CloudUpload className="w-4 h-4" /> Auto Save
            <Switch checked={autoSave} onCheckedChange={setAutoSave} />
          </label>
          <Button variant="outline" size="sm" className="gap-1.5 md:hidden" onClick={() => setMobileTools(true)}><LayoutGrid className="w-4 h-4" /> Ferramentas</Button>
          <Button variant="outline" size="sm" onClick={() => setPropsOpen((v) => !v)} className="gap-1.5"><History className="w-4 h-4" /> Histórico ({versions.length})</Button>
          <Button variant="outline" size="sm" onClick={handleRestoreDefault} className="gap-1.5"><RotateCcw className="w-4 h-4" /> Padrão</Button>
          <ExportImportMenu
            items={[
              { label: 'Importar', icon: Upload, onClick: () => importFileRef.current?.click() },
              { label: 'Exportar', icon: Download, onClick: handleExport },
            ]}
          />
          <input ref={importFileRef} type="file" accept=".json" className="hidden" onChange={handleImport} />
          {currentTemplate && (
            <Button variant="outline" size="sm" onClick={() => setConfirmDelete(true)} disabled={deleting} className="gap-1.5 text-destructive border-destructive/30 hover:bg-destructive/10">{deleting ? <Loader2 className="w-4 h-4 animate-spin" /> : <Trash2 className="w-4 h-4" />} Deletar</Button>
          )}
          <Button variant="outline" size="sm" onClick={() => setApplyOpen(true)} className="gap-1.5 text-violet-700 border-violet-200 hover:bg-violet-50"><Copy className="w-4 h-4" /> Aplicar a outros</Button>
          <Button variant="outline" size="sm" onClick={() => handleTest(false)} className="gap-1.5"><Eye className="w-4 h-4" /> Teste</Button>
          <Button variant="outline" size="sm" onClick={() => handleTest(true)} className="gap-1.5"><Printer className="w-4 h-4" /> Imprimir</Button>
          <Button size="sm" onClick={() => handleSave(false)} disabled={saving} className="gap-1.5">{saving ? <Loader2 className="w-4 h-4 animate-spin" /> : <Save className="w-4 h-4" />} Salvar</Button>
          <Button size="sm" onClick={() => handleSave(true)} disabled={saving} className="gap-1.5 bg-emerald-600 hover:bg-emerald-700"><Send className="w-4 h-4" /> Publicar</Button>
        </div>
      </header>

      <div className="flex-1 flex min-h-0 relative">
        <aside className="hidden md:flex w-80 shrink-0 border-r border-border bg-card flex-col min-h-0">
          <EditorSidebar config={config} onChange={onChange} header={effectiveHeader} onHeaderChange={handleHeaderChange} useGlobal={!!config?.header?.useGlobal} onUseGlobalChange={onUseGlobalChange} />
        </aside>

        {mobileTools && (
          <div className="md:hidden fixed inset-0 z-40 flex">
            <div className="absolute inset-0 bg-black/40" onClick={() => setMobileTools(false)} />
            <aside className="relative w-80 max-w-[85%] h-full bg-card border-r border-border flex flex-col min-h-0">
              <EditorSidebar config={config} onChange={onChange} header={effectiveHeader} onHeaderChange={handleHeaderChange} useGlobal={!!config?.header?.useGlobal} onUseGlobalChange={onUseGlobalChange} />
            </aside>
          </div>
        )}

        <main className="flex-1 min-w-0 min-h-0 bg-muted/40 overflow-hidden">
          <TemplatePreview config={effectiveConfig} sampleData={sampleData} doc={selectedDoc} />
        </main>

        <aside className={`hidden lg:flex shrink-0 border-l border-border bg-card flex-col min-h-0 transition-all ${propsOpen ? 'w-72' : 'w-0 overflow-hidden'}`}>
          {propsOpen && <EditorProperties doc={selectedDoc} template={currentTemplate} versions={versions} currentVersion={currentTemplate?.version} onRestore={handleRestoreVersion} onPublish={handlePublishVersion} onClose={() => setPropsOpen(false)} />}
        </aside>

        {propsOpen && !mobileTools && (
          <div className="lg:hidden fixed inset-0 z-40 flex justify-end">
            <div className="absolute inset-0 bg-black/40" onClick={() => setPropsOpen(false)} />
            <aside className="relative w-80 max-w-[85%] h-full bg-card border-l border-border flex flex-col min-h-0">
              <EditorProperties doc={selectedDoc} template={currentTemplate} versions={versions} currentVersion={currentTemplate?.version} onRestore={handleRestoreVersion} onPublish={handlePublishVersion} onClose={() => setPropsOpen(false)} />
            </aside>
          </div>
        )}
      </div>

      <ApplyToOthersDialog
        open={applyOpen}
        onOpenChange={setApplyOpen}
        currentType={selectedType}
        currentLabel={selectedDoc?.label}
        onApply={handleApplyToOthers}
        applying={applying}
      />

      <AlertDialog open={confirmDelete} onOpenChange={setConfirmDelete}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Deletar modelo</AlertDialogTitle>
            <AlertDialogDescription>
              Tem certeza que deseja deletar <strong>{selectedDoc?.label}</strong>?
              {selectedDoc?._custom
                ? ' Como é um documento personalizado, ele será removido de todo o sistema (modelo, versões e tipo de documento).'
                : ' Todas as versões salvas serão removidas e o documento voltará ao padrão do sistema.'}
              {' '}Esta ação não pode ser desfeita.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter className="sm:justify-end gap-2">
            <AlertDialogCancel disabled={deleting}>Cancelar</AlertDialogCancel>
            <AlertDialogAction onClick={handleDelete} disabled={deleting} className="bg-destructive text-destructive-foreground hover:bg-destructive/90">{deleting ? <Loader2 className="w-4 h-4 animate-spin" /> : <Trash2 className="w-4 h-4" />} Deletar</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      <AlertDialog open={confirmExit} onOpenChange={setConfirmExit}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Alterações não salvas</AlertDialogTitle>
            <AlertDialogDescription>Existem alterações não salvas. Deseja salvar antes de sair?</AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter className="sm:justify-between gap-2">
            <AlertDialogCancel>Cancelar</AlertDialogCancel>
            <div className="flex gap-2">
              <AlertDialogAction onClick={() => { setConfirmExit(false); navigate('/Dashboard'); }} className="bg-muted text-foreground hover:bg-muted/80">Sair sem salvar</AlertDialogAction>
              <AlertDialogAction onClick={handleExitSave} className="bg-emerald-600 hover:bg-emerald-700">Salvar e sair</AlertDialogAction>
            </div>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}