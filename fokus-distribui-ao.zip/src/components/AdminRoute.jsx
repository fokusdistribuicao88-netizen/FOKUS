import { Outlet, Navigate, useLocation } from 'react-router-dom';
import { useAuth } from '@/lib/AuthContext';
import { isStaffRole, isLogisticsOnlyRole } from '@/lib/userRoles';

const DefaultFallback = () => (
  <div className="fixed inset-0 flex items-center justify-center">
    <div className="w-8 h-8 border-4 border-slate-200 border-t-slate-800 rounded-full animate-spin"></div>
  </div>
);

export default function AdminRoute() {
  const { isAuthenticated, isLoadingAuth, user } = useAuth();
  const location = useLocation();

  if (isLoadingAuth) return <DefaultFallback />;

  if (!isAuthenticated) return <Navigate to="/login" replace />;

  const role = user?.role || user?.data?.role;
  if (!isStaffRole(role)) {
    return <Navigate to="/MinhaConta" replace />;
  }

  // Motoristas e auxiliares só podem acessar a Logística dentro da área admin
  if (isLogisticsOnlyRole(role) && location.pathname !== '/logistics') {
    return <Navigate to="/logistics" replace />;
  }

  return <Outlet />;
}