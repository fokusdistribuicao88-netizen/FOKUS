import React, { useState, useRef } from 'react';
import * as XLSX from 'xlsx';
import { Download, Upload, Loader2, Database } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { DropdownMenu, DropdownMenuTrigger, DropdownMenuContent, DropdownMenuItem } from '@/components/ui/dropdown-menu';
import { useToast } from '@/components/ui/use-toast';

const COLUMN_MAP = [
{ key: 'id', label: 'ID (não editar)' },
{ key: 'name', label: 'Nome *' },
{ key: 'brand', label: 'Marca' },
{ key: 'category', label: 'Categoria *' },
{ key: 'price', label: 'Preço Padrão *' },
{ key: 'price_promo', label: 'Preço Promocional' },
{ key: 'price_wholesale', label: 'Preço Atacado' },
{ key: 'price_cash', label: 'Preço à Vista' },
{ key: 'unit_type', label: 'Tipo de Unidade' },
{ key: 'units_per_pack', label: 'Unidades por Pack' },
{ key: 'volume_ml', label: 'Volume (ml)' },
{ key: 'min_order', label: 'Pedido Mínimo' },
{ key: 'in_stock', label: 'Em Estoque (true/false)' },
{ key: 'featured', label: 'Destaque (true/false)' },
{ key: 'stock_quantity', label: 'Estoque (Qtd)' },
{ key: 'low_stock_threshold', label: 'Limite Estoque Baixo' },
{ key: 'image_url', label: 'URL da Imagem' },
{ key: 'description', label: 'Descrição' }];


const VALID_CATEGORIES = ['Cervejas', 'Refrigerantes', 'Águas', 'Sucos', 'Energéticos', 'Destilados', 'Vinhos', 'Outros'];
const VALID_UNIT_TYPES = ['unidade', 'pack', 'fardo', 'caixa', 'engradado'];

export default function ExcelToolbar({ products, onImport }) {
  const { toast } = useToast();
  const [importing, setImporting] = useState(false);
  const fileRef = useRef(null);

  const handleExport = () => {
    if (!products.length) {
      toast({ title: 'Nenhum produto para exportar', variant: 'destructive' });
      return;
    }

    const rows = products.map((p) => {
      const row = {};
      COLUMN_MAP.forEach(({ key, label }) => {
        row[label] = p[key] ?? '';
      });
      return row;
    });

    const ws = XLSX.utils.json_to_sheet(rows, {
      header: COLUMN_MAP.map((c) => c.label)
    });
    ws['!cols'] = COLUMN_MAP.map(({ label }) => ({ wch: label.length + 8 }));

    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'Produtos');
    XLSX.writeFile(wb, 'produtos_fokus.xlsx');
    toast({ title: 'Produtos exportados com sucesso!' });
  };

  const parseValue = (val, key) => {
    if (val === undefined || val === null || val === '') return null;
    if (['price', 'price_promo', 'price_wholesale', 'price_cash'].includes(key)) {
      const n = parseFloat(String(val).replace(',', '.'));
      return isNaN(n) ? null : n;
    }
    if (['units_per_pack', 'volume_ml', 'min_order', 'stock_quantity', 'low_stock_threshold'].includes(key)) {
      const n = parseInt(String(val));
      return isNaN(n) ? null : n;
    }
    if (['in_stock', 'featured'].includes(key)) {
      const s = String(val).toLowerCase().trim();
      return s === 'true' || s === '1' || s === 'sim' || s === 'verdadeiro';
    }
    return String(val);
  };

  const handleImport = async (e) => {
    const file = e.target.files[0];
    if (!file) return;
    e.target.value = '';

    setImporting(true);
    try {
      const buf = await file.arrayBuffer();
      const wb = XLSX.read(buf);
      const ws = wb.Sheets[wb.SheetNames[0]];
      const rows = XLSX.utils.sheet_to_json(ws, { defval: '' });

      if (!rows.length) {
        toast({ title: 'Planilha vazia ou sem dados', variant: 'destructive' });
        setImporting(false);
        return;
      }

      const labelToKey = {};
      COLUMN_MAP.forEach(({ key, label }) => {labelToKey[label] = key;});

      const existingByName = {};
      products.forEach((p) => {
        if (p.name) existingByName[p.name.toLowerCase().trim()] = p;
      });

      const toCreate = [];
      const toUpdate = [];
      const errors = [];

      rows.forEach((row, idx) => {
        const parsed = {};
        COLUMN_MAP.forEach(({ key, label }) => {
          const raw = row[label] ?? row[key] ?? '';
          parsed[key] = parseValue(raw, key);
        });

        if (!parsed.name) {
          errors.push(`Linha ${idx + 2}: sem nome`);
          return;
        }
        if (!parsed.price || parsed.price <= 0) {
          errors.push(`Linha ${idx + 2}: preço inválido`);
          return;
        }
        if (!parsed.category || !VALID_CATEGORIES.includes(parsed.category)) {
          errors.push(`Linha ${idx + 2}: categoria "${parsed.category}" inválida`);
          return;
        }
        if (parsed.unit_type && !VALID_UNIT_TYPES.includes(parsed.unit_type)) {
          errors.push(`Linha ${idx + 2}: tipo de unidade "${parsed.unit_type}" inválido`);
          return;
        }

        const clean = {
          name: parsed.name,
          description: parsed.description || '',
          price: parsed.price,
          price_promo: parsed.price_promo,
          price_wholesale: parsed.price_wholesale,
          price_cash: parsed.price_cash,
          image_url: parsed.image_url || '',
          category: parsed.category,
          brand: parsed.brand || '',
          unit_type: parsed.unit_type || 'unidade',
          units_per_pack: parsed.units_per_pack,
          volume_ml: parsed.volume_ml,
          min_order: parsed.min_order || 1,
          in_stock: parsed.in_stock !== false,
          featured: parsed.featured || false,
          stock_quantity: parsed.stock_quantity,
          low_stock_threshold: parsed.low_stock_threshold ?? 5
        };

        const existing = existingByName[parsed.name.toLowerCase().trim()];
        if (existing) {
          toUpdate.push({ id: existing.id, ...clean });
        } else {
          toCreate.push(clean);
        }
      });

      await onImport(toCreate, toUpdate);

      const msg = `${toCreate.length} criados, ${toUpdate.length} atualizados${errors.length ? `, ${errors.length} erros` : ''}`;
      toast({ title: 'Importação concluída', description: msg });
      if (errors.length) console.warn('Erros de importação:', errors);
    } catch (err) {
      console.error(err);
      toast({ title: 'Erro ao importar arquivo', description: String(err.message || err), variant: 'destructive' });
    } finally {
      setImporting(false);
    }
  };

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button variant="outline" size="icon" disabled={importing} aria-label="Exportar / Importar Excel">
          {importing ? <Loader2 className="w-4 h-4 animate-spin" /> : <Database className="w-4 h-4" />}
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end">
        <DropdownMenuItem onClick={handleExport} disabled={!products.length}>
          <Download className="w-4 h-4 mr-2" /> Exportar Excel
        </DropdownMenuItem>
        <DropdownMenuItem onClick={() => fileRef.current?.click()} disabled={importing}>
          <Upload className="w-4 h-4 mr-2" /> Importar Excel
        </DropdownMenuItem>
      </DropdownMenuContent>
      <input
        ref={fileRef}
        type="file"
        accept=".xlsx,.xls"
        onChange={handleImport}
        className="hidden" />
      
    </DropdownMenu>);

}