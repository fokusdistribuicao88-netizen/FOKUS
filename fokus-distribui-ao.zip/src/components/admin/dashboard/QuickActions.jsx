import React, { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { UserPlus, FileText, Tag, Boxes, Wallet, Loader2, ShoppingCart, DollarSign, Contact, Briefcase, Receipt, Tags, Share2 } from 'lucide-react';
import { Link } from 'react-router-dom';
import { useToast } from '@/components/ui/use-toast';
import { useAuth } from '@/lib/AuthContext';
import { generatePDF, sharePDF } from '@/lib/pdfService';
import { generalReportToSections } from '@/lib/pdfAdapters';
import { logActivity } from '@/lib/activityLog';

const ACTIONS = [
  { label: 'PDV - Ponto de Venda', icon: ShoppingCart, accent: 'blue', to: '/pos', featured: true },
  { label: 'Gerar Relatório', icon: FileText, accent: 'violet', action: 'report' },
  { label: 'Compartilhar Relatório', icon: Share2, accent: 'violet', action: 'share-report' },
  { label: 'Modelos PDF', icon: FileText, accent: 'violet', to: '/pdf-template-management' },
  { label: 'Criar Promoção', icon: Tag, accent: 'yellow', to: '/promotions' },
  { label: 'Novo Usuário', icon: UserPlus, accent: 'blue', to: '/users' },
  { label: 'Clientes', icon: Contact, accent: 'violet', to: '/clients' },
  { label: 'Gerenciar Estoque', icon: Boxes, accent: 'emerald', to: '/inventory' },
  { label: 'Gerenciador Dinâmico de Tabelas', icon: Tags, accent: 'emerald', to: '/price-management' },
  { label: 'Preços do Catálogo', icon: DollarSign, accent: 'violet', to: '/PriceManagement' },
  { label: 'Financeiro', icon: Wallet, accent: 'emerald', to: '/financial' },
  { label: 'Funcionários', icon: Briefcase, accent: 'blue', to: '/employees' },
  { label: 'Despesas', icon: Receipt, accent: 'yellow', to: '/expenses' },
];

const ACCENT = {
  blue: 'bg-blue-50 dark:bg-blue-950/40 text-blue-600 dark:text-blue-400 hover:bg-blue-100 dark:hover:bg-blue-900/50',
  yellow: 'bg-yellow-50 dark:bg-yellow-950/30 text-yellow-600 dark:text-yellow-500 hover:bg-yellow-100 dark:hover:bg-yellow-900/40',
  violet: 'bg-violet-50 dark:bg-violet-950/40 text-violet-600 dark:text-violet-400 hover:bg-violet-100 dark:hover:bg-violet-900/50',
  emerald: 'bg-emerald-50 dark:bg-emerald-950/40 text-emerald-600 dark:text-emerald-400 hover:bg-emerald-100 dark:hover:bg-emerald-900/50',
};

export default function QuickActions() {
  const { toast } = useToast();
  const { user } = useAuth();
  const [generating, setGenerating] = useState(false);

  const { data: products = [] } = useQuery({ queryKey: ['products'], queryFn: () => base44.entities.Product.list(), staleTime: 60000 });
  const { data: orders = [] } = useQuery({ queryKey: ['orders'], queryFn: () => base44.entities.Order.list(), staleTime: 60000 });
  const { data: settingsList = [] } = useQuery({ queryKey: ['settings'], queryFn: () => base44.entities.Settings.list(), staleTime: 60000 });

  const handleReport = async () => {
    setGenerating(true);
    try {
      const { sections, data } = generalReportToSections(products, orders, user);
      await generatePDF({ documentType: 'dashboard_report', data, sections, module: 'Dashboard', user, fileName: `relatorio-geral-${new Date().toISOString().slice(0, 10)}.pdf` });
      toast({ title: 'Relatório gerado', description: 'PDF gerado a partir do modelo central do sistema.' });
      logActivity({ action: 'report_generate', description: 'Relatório Geral do Sistema gerado (modelo central)', user });
    } catch (e) {
      toast({ title: 'Erro ao gerar relatório', description: e.message, variant: 'destructive' });
    } finally {
      setGenerating(false);
    }
  };

  const handleShareReport = async () => {
    setGenerating(true);
    try {
      const { sections, data } = generalReportToSections(products, orders, user);
      const { shared } = await sharePDF({ documentType: 'dashboard_report', data, sections, module: 'Dashboard', user, fileName: `relatorio-geral-${new Date().toISOString().slice(0, 10)}.pdf` });
      toast({ title: shared ? 'Compartilhando PDF' : 'PDF baixado', description: shared ? 'Escolha o aplicativo para enviar.' : 'Compartilhamento não suportado — PDF baixado.' });
      logActivity({ action: 'report_share', description: 'Relatório Geral do Sistema compartilhado (modelo central)', user });
    } catch (e) {
      if (e?.name !== 'AbortError') toast({ title: 'Erro ao compartilhar', description: e.message, variant: 'destructive' });
    } finally {
      setGenerating(false);
    }
  };

  return (
    <div className="bg-card rounded-2xl border border-border p-4 sm:p-5 shadow-sm">
      <h3 className="text-sm font-semibold text-foreground mb-4">Ações rápidas</h3>
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-6 gap-3">
        {ACTIONS.map((a) => {
          const Icon = a.icon;
          const isReport = a.action === 'report' || a.action === 'share-report';
          const handler = a.action === 'share-report' ? handleShareReport : handleReport;
          const inner = (
            <div className={`flex flex-col items-center gap-2 p-3 rounded-xl border border-transparent transition-colors ${ACCENT[a.accent]} ${isReport && generating ? 'opacity-60' : ''}`}>
              {isReport && generating ? <Loader2 className="w-5 h-5 animate-spin" /> : <Icon className="w-5 h-5" />}
              <span className="text-xs font-medium text-center leading-tight">{a.label}</span>
            </div>
          );
          return a.to ? (
            <Link key={a.label} to={a.to}>{inner}</Link>
          ) : (
            <button key={a.label} onClick={handler} disabled={generating} className="text-left">{inner}</button>
          );
        })}
      </div>
    </div>
  );
}