import React, { useState } from 'react';
import { Eye, Settings, RotateCw } from 'lucide-react';
import { useToast } from '@/components/ui/use-toast';

const MODULES = [
  { name: 'Autenticação', status: 'active', updated: 'há 2 min', response: 42, resource: 18, errors: 0 },
  { name: 'Cadastro de usuários', status: 'active', updated: 'há 5 min', response: 88, resource: 12, errors: 0 },
  { name: 'Banco de dados', status: 'active', updated: 'há 1 min', response: 24, resource: 47, errors: 0 },
  { name: 'API', status: 'active', updated: 'agora', response: 36, resource: 31, errors: 0 },
  { name: 'Sistema de pedidos', status: 'maintenance', updated: 'há 12 min', response: 120, resource: 28, errors: 2 },
  { name: 'Estoque', status: 'active', updated: 'há 3 min', response: 55, resource: 22, errors: 0 },
  { name: 'Upload de arquivos', status: 'active', updated: 'há 8 min', response: 210, resource: 35, errors: 0 },
  { name: 'Notificações', status: 'active', updated: 'há 4 min', response: 64, resource: 9, errors: 0 },
  { name: 'E-mails', status: 'error', updated: 'há 22 min', response: 0, resource: 6, errors: 14 },
  { name: 'Chat', status: 'active', updated: 'há 6 min', response: 95, resource: 41, errors: 0 },
  { name: 'Segurança', status: 'active', updated: 'há 1 min', response: 18, resource: 15, errors: 0 },
  { name: 'Cache', status: 'active', updated: 'agora', response: 8, resource: 53, errors: 0 },
  { name: 'Backup', status: 'maintenance', updated: 'há 30 min', response: 0, resource: 12, errors: 0 },
  { name: 'Inteligência Artificial', status: 'active', updated: 'há 2 min', response: 480, resource: 62, errors: 1 },
  { name: 'Sistema de permissões', status: 'active', updated: 'há 7 min', response: 30, resource: 8, errors: 0 },
  { name: 'Integrações', status: 'active', updated: 'há 5 min', response: 72, resource: 26, errors: 0 },
  { name: 'Sistema de pagamentos', status: 'inactive', updated: 'há 1 h', response: 0, resource: 0, errors: 3 },
  { name: 'Logs', status: 'active', updated: 'agora', response: 14, resource: 19, errors: 0 },
];

const STATUS = {
  active: { label: 'Ativo', cls: 'bg-emerald-100 text-emerald-700 dark:bg-emerald-950/40 dark:text-emerald-400', dot: 'bg-emerald-500' },
  inactive: { label: 'Inativo', cls: 'bg-muted text-muted-foreground', dot: 'bg-muted-foreground' },
  maintenance: { label: 'Em manutenção', cls: 'bg-amber-100 text-amber-700 dark:bg-amber-950/40 dark:text-amber-400', dot: 'bg-amber-500' },
  error: { label: 'Com erro', cls: 'bg-red-100 text-red-700 dark:bg-red-950/40 dark:text-red-400', dot: 'bg-red-500' },
};

const ResourceBar = ({ value }) => (
  <div className="flex items-center gap-2">
    <div className="flex-1 h-1.5 rounded-full bg-muted overflow-hidden min-w-[40px]">
      <div
        className={`h-full rounded-full ${value > 60 ? 'bg-red-500' : value > 40 ? 'bg-amber-500' : 'bg-blue-600'}`}
        style={{ width: `${value}%` }}
      />
    </div>
    <span className="text-[11px] text-muted-foreground tabular-nums w-8 text-right">{value}%</span>
  </div>
);

export default function FeatureMonitor() {
  const { toast } = useToast();
  const [restarting, setRestarting] = useState(null);

  const action = (name, verb) =>
    toast({ title: `${verb}: ${name}`, description: 'Operação registrada no painel.' });

  const restart = (name) => {
    setRestarting(name);
    setTimeout(() => {
      setRestarting(null);
      toast({ title: `${name} reiniciado`, description: 'Serviço em execução novamente.' });
    }, 1200);
  };

  return (
    <div className="bg-card rounded-2xl border border-border shadow-sm overflow-hidden">
      <div className="p-4 sm:p-5 border-b border-border">
        <h3 className="text-sm font-semibold text-foreground">Monitoramento de funcionalidades</h3>
        <p className="text-xs text-muted-foreground mt-0.5">Status dos módulos do sistema em tempo real</p>
      </div>
      <div className="overflow-x-auto">
        <table className="w-full text-sm">
          <thead>
            <tr className="bg-muted/40 text-left">
              <th className="px-4 py-2.5 text-xs font-semibold text-muted-foreground">Funcionalidade</th>
              <th className="px-4 py-2.5 text-xs font-semibold text-muted-foreground">Status</th>
              <th className="px-4 py-2.5 text-xs font-semibold text-muted-foreground hidden md:table-cell">Atualizado</th>
              <th className="px-4 py-2.5 text-xs font-semibold text-muted-foreground hidden md:table-cell">Resposta</th>
              <th className="px-4 py-2.5 text-xs font-semibold text-muted-foreground hidden lg:table-cell">Recursos</th>
              <th className="px-4 py-2.5 text-xs font-semibold text-muted-foreground hidden lg:table-cell">Erros</th>
              <th className="px-4 py-2.5 text-xs font-semibold text-muted-foreground text-right">Ações</th>
            </tr>
          </thead>
          <tbody>
            {MODULES.map((m) => {
              const s = STATUS[m.status];
              return (
                <tr key={m.name} className="border-t border-border hover:bg-accent/40 transition-colors">
                  <td className="px-4 py-3 font-medium text-foreground">{m.name}</td>
                  <td className="px-4 py-3">
                    <span className={`inline-flex items-center gap-1.5 px-2 py-0.5 rounded-full text-xs font-medium ${s.cls}`}>
                      <span className={`w-1.5 h-1.5 rounded-full ${s.dot}`} />
                      {s.label}
                    </span>
                  </td>
                  <td className="px-4 py-3 text-xs text-muted-foreground hidden md:table-cell">{m.updated}</td>
                  <td className="px-4 py-3 text-xs text-muted-foreground tabular-nums hidden md:table-cell">
                    {m.response > 0 ? `${m.response} ms` : '—'}
                  </td>
                  <td className="px-4 py-3 hidden lg:table-cell">
                    <ResourceBar value={m.resource} />
                  </td>
                  <td className="px-4 py-3 text-xs tabular-nums hidden lg:table-cell">
                    {m.errors > 0 ? <span className="text-red-600 font-medium">{m.errors}</span> : <span className="text-muted-foreground">0</span>}
                  </td>
                  <td className="px-4 py-3">
                    <div className="flex items-center justify-end gap-1">
                      <button onClick={() => action(m.name, 'Detalhes')} className="p-1.5 rounded-lg hover:bg-accent transition-colors" title="Detalhes">
                        <Eye className="w-4 h-4 text-muted-foreground" />
                      </button>
                      <button onClick={() => action(m.name, 'Configurar')} className="p-1.5 rounded-lg hover:bg-accent transition-colors" title="Configurar">
                        <Settings className="w-4 h-4 text-muted-foreground" />
                      </button>
                      <button
                        onClick={() => restart(m.name)}
                        disabled={restarting === m.name}
                        className="p-1.5 rounded-lg hover:bg-accent transition-colors disabled:opacity-50"
                        title="Reiniciar"
                      >
                        <RotateCw className={`w-4 h-4 text-muted-foreground ${restarting === m.name ? 'animate-spin' : ''}`} />
                      </button>
                    </div>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
}