import React, { useMemo } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { TrendingUp, TrendingDown, AlertTriangle, Percent } from 'lucide-react';
import { grossProfit, grossMargin, formatBRL } from '@/lib/profitCalc';

export default function ProfitOverview({ products }) {
  const data = useMemo(() => {
    const withCost = (products || []).filter((p) => Number(p.cost) > 0 && Number(p.price) > 0);
    const margins = withCost.map((p) => ({
      id: p.id,
      name: p.name,
      cost: Number(p.cost),
      price: Number(p.price),
      profit: grossProfit(p.price, p.cost),
      margin: grossMargin(p.price, p.cost),
    }));
    const avgMargin = margins.length
      ? Math.round((margins.reduce((s, m) => s + (m.margin || 0), 0) / margins.length) * 10) / 10
      : null;
    const totalGrossProfit = margins.reduce((s, m) => s + m.profit, 0);

    const mostProfitable = [...margins]
      .filter((m) => m.margin != null)
      .sort((a, b) => b.margin - a.margin)
      .slice(0, 5);
    const leastProfitable = [...margins]
      .filter((m) => m.margin != null)
      .sort((a, b) => a.margin - b.margin)
      .slice(0, 5);

    const belowCost = (products || []).filter(
      (p) => Number(p.cost) > 0 && Number(p.price) > 0 && Number(p.price) < Number(p.cost)
    );

    return {
      avgMargin, totalGrossProfit, mostProfitable, leastProfitable, belowCost,
      hasCostCount: withCost.length,
    };
  }, [products]);

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-xs font-medium text-muted-foreground">Margem média (catálogo)</CardTitle>
            <Percent className="h-4 w-4 text-blue-600" />
          </CardHeader>
          <CardContent>
            <div className="text-xl font-bold">{data.avgMargin == null ? '-' : `${data.avgMargin}%`}</div>
            <p className="text-xs text-muted-foreground">{data.hasCostCount} produto(s) com custo</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-xs font-medium text-muted-foreground">Lucro bruto unit. total</CardTitle>
            <TrendingUp className="h-4 w-4 text-emerald-600" />
          </CardHeader>
          <CardContent>
            <div className="text-xl font-bold">{formatBRL(data.totalGrossProfit)}</div>
            <p className="text-xs text-muted-foreground">soma por unidade</p>
          </CardContent>
        </Card>
        <Card className="border-red-200">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-xs font-medium text-muted-foreground">Abaixo do custo</CardTitle>
            <AlertTriangle className="h-4 w-4 text-red-600" />
          </CardHeader>
          <CardContent>
            <div className="text-xl font-bold text-red-600">{data.belowCost.length}</div>
            <p className="text-xs text-muted-foreground">produtos vendendo com prejuízo</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-xs font-medium text-muted-foreground">Produtos analisados</CardTitle>
            <TrendingDown className="h-4 w-4 text-violet-600" />
          </CardHeader>
          <CardContent>
            <div className="text-xl font-bold">{data.hasCostCount}</div>
            <p className="text-xs text-muted-foreground">com custo cadastrado</p>
          </CardContent>
        </Card>
      </div>

      {data.belowCost.length > 0 && (
        <Card className="border-red-200 bg-red-50">
          <CardContent className="p-4">
            <div className="flex items-center gap-2 text-red-700 font-semibold mb-2">
              <AlertTriangle className="h-4 w-4" /> Produtos vendidos abaixo do custo
            </div>
            <div className="flex flex-wrap gap-2">
              {data.belowCost.map((p) => (
                <Badge key={p.id} variant="destructive">
                  {p.name} · {formatBRL(p.price)} / custo {formatBRL(p.cost)}
                </Badge>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      <div className="grid lg:grid-cols-2 gap-4">
        <Card>
          <CardHeader>
            <CardTitle className="text-base flex items-center gap-2"><TrendingUp className="h-4 w-4 text-emerald-600" /> Produtos mais lucrativos</CardTitle>
          </CardHeader>
          <CardContent>
            {data.mostProfitable.length === 0 ? (
              <p className="text-sm text-muted-foreground">Cadastre preços de custo para visualizar.</p>
            ) : (
              <div className="space-y-2">
                {data.mostProfitable.map((m) => (
                  <div key={m.id} className="flex items-center justify-between text-sm border-b pb-1.5 gap-2">
                    <span className="truncate min-w-0">{m.name}</span>
                    <span className="flex items-center gap-3 shrink-0">
                      <span className="text-muted-foreground whitespace-nowrap">{formatBRL(m.profit)}</span>
                      <Badge className="bg-emerald-100 text-emerald-700">{m.margin}%</Badge>
                    </span>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-base flex items-center gap-2"><TrendingDown className="h-4 w-4 text-amber-600" /> Menor margem</CardTitle>
          </CardHeader>
          <CardContent>
            {data.leastProfitable.length === 0 ? (
              <p className="text-sm text-muted-foreground">Cadastre preços de custo para visualizar.</p>
            ) : (
              <div className="space-y-2">
                {data.leastProfitable.map((m) => (
                  <div key={m.id} className="flex items-center justify-between text-sm border-b pb-1.5 gap-2">
                    <span className="truncate min-w-0">{m.name}</span>
                    <span className="flex items-center gap-3 shrink-0">
                      <span className="text-muted-foreground whitespace-nowrap">{formatBRL(m.profit)}</span>
                      <Badge className={m.margin < 0 ? 'bg-red-100 text-red-700' : 'bg-amber-100 text-amber-700'}>{m.margin}%</Badge>
                    </span>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}