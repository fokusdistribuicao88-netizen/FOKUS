import React from 'react';
import { ArrowUp, ArrowDown } from 'lucide-react';

const ACCENTS = {
  blue: { bg: 'bg-blue-50 dark:bg-blue-950/40', text: 'text-blue-600 dark:text-blue-400', ring: 'ring-blue-100 dark:ring-blue-900/40' },
  yellow: { bg: 'bg-yellow-50 dark:bg-yellow-950/30', text: 'text-yellow-600 dark:text-yellow-400', ring: 'ring-yellow-100 dark:ring-yellow-900/30' },
  green: { bg: 'bg-emerald-50 dark:bg-emerald-950/40', text: 'text-emerald-600 dark:text-emerald-400', ring: 'ring-emerald-100 dark:ring-emerald-900/40' },
  red: { bg: 'bg-red-50 dark:bg-red-950/40', text: 'text-red-600 dark:text-red-400', ring: 'ring-red-100 dark:ring-red-900/40' },
  violet: { bg: 'bg-violet-50 dark:bg-violet-950/40', text: 'text-violet-600 dark:text-violet-400', ring: 'ring-violet-100 dark:ring-violet-900/40' },
};

export default function StatCard({ icon: Icon, label, value, sub, trend, accent = 'blue' }) {
  const a = ACCENTS[accent] || ACCENTS.blue;
  const TrendIcon = trend === 'up' ? ArrowUp : trend === 'down' ? ArrowDown : null;
  const trendColor = trend === 'up' ? 'text-emerald-600' : trend === 'down' ? 'text-red-600' : 'text-muted-foreground';

  return (
    <div className="bg-card rounded-2xl border border-border p-4 sm:p-5 shadow-sm hover:shadow-md transition-shadow">
      <div className="flex items-start justify-between gap-2 sm:gap-3">
        <div className="min-w-0 flex-1">
          <p className="text-xs font-medium text-muted-foreground leading-tight">{label}</p>
          <p className="mt-1 text-base sm:text-2xl font-bold text-foreground tabular-nums whitespace-nowrap">{value}</p>
        </div>
        <div className={`w-8 h-8 sm:w-10 sm:h-10 rounded-xl flex items-center justify-center ${a.bg} ${a.text} ring-1 ${a.ring} flex-shrink-0`}>
          <Icon className="w-4 h-4 sm:w-5 sm:h-5" />
        </div>
      </div>
      {sub && (
        <div className={`mt-3 flex items-center gap-1 text-xs font-medium ${trendColor}`}>
          {TrendIcon && <TrendIcon className="w-3 h-3" />}
          <span>{sub}</span>
        </div>
      )}
    </div>
  );
}