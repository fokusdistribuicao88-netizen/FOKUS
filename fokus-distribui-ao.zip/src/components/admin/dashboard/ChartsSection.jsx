import React, { useMemo } from 'react';
import {
  AreaChart, Area, BarChart, Bar, LineChart, Line,
  XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
} from 'recharts';
import { PAYMENT_METHODS } from '@/components/orders/orderStatus';

const MONTH_LABELS = ['Jan', 'Fev', 'Mar', 'Abr', 'Mai', 'Jun', 'Jul', 'Ago', 'Set', 'Out', 'Nov', 'Dez'];
const DAY_LABELS = ['Dom', 'Seg', 'Ter', 'Qua', 'Qui', 'Sex', 'Sáb'];

const tooltipStyle = {
  backgroundColor: 'hsl(var(--card))',
  border: '1px solid hsl(var(--border))',
  borderRadius: 12,
  fontSize: 12,
  color: 'hsl(var(--foreground))',
};

const Card = ({ title, subtitle, children }) => (
  <div className="bg-card rounded-2xl border border-border p-4 sm:p-5 shadow-sm">
    <div className="mb-4">
      <h3 className="text-sm font-semibold text-foreground">{title}</h3>
      {subtitle && <p className="text-xs text-muted-foreground mt-0.5">{subtitle}</p>}
    </div>
    {children}
  </div>
);

const fmtMoney = (v) =>
  (Number(v) || 0).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });

export default function ChartsSection({ orders = [], users = [] }) {
  const { usersData, revenueData, ordersData, payData } = useMemo(() => {
    const now = new Date();
    const p2 = (n) => String(n).padStart(2, '0');

    // últimos 7 meses (faturamento + usuários)
    const revMap = new Map();
    const usrMap = new Map();
    const keys = [];
    for (let i = 6; i >= 0; i--) {
      const d = new Date(now.getFullYear(), now.getMonth() - i, 1);
      const key = `${d.getFullYear()}-${p2(d.getMonth() + 1)}`;
      keys.push(key);
      revMap.set(key, { m: MONTH_LABELS[d.getMonth()], valor: 0 });
      usrMap.set(key, { m: MONTH_LABELS[d.getMonth()], total: 0, novos: 0 });
    }
    orders.forEach((o) => {
      const k = String(o.created_date || '').slice(0, 7);
      if (revMap.has(k)) revMap.get(k).valor += Number(o.total) || 0;
    });
    users.forEach((u) => {
      const k = String(u.created_date || '').slice(0, 7);
      if (usrMap.has(k)) usrMap.get(k).novos += 1;
    });
    const priorCount = users.filter((u) => {
      const k = String(u.created_date || '').slice(0, 7);
      return k && k < keys[0];
    }).length;
    let cumulative = priorCount;
    keys.forEach((k) => {
      cumulative += usrMap.get(k).novos;
      usrMap.get(k).total = cumulative;
    });

    // últimos 7 dias (pedidos)
    const ordersData = [];
    for (let i = 6; i >= 0; i--) {
      const d = new Date(now);
      d.setDate(d.getDate() - i);
      const key = `${d.getFullYear()}-${p2(d.getMonth() + 1)}-${p2(d.getDate())}`;
      const count = orders.filter((o) => String(o.created_date || '').slice(0, 10) === key).length;
      ordersData.push({ m: DAY_LABELS[d.getDay()], pedidos: count });
    }

    // vendas por forma de pagamento (mês atual)
    const monthKey = `${now.getFullYear()}-${p2(now.getMonth() + 1)}`;
    const payMap = new Map();
    orders
      .filter((o) => String(o.created_date || '').slice(0, 7) === monthKey)
      .forEach((o) => {
        const m = o.payment_method || 'nao_informado';
        payMap.set(m, (payMap.get(m) || 0) + (Number(o.total) || 0));
      });
    const payData = [...payMap.entries()]
      .map(([k, v]) => ({ m: PAYMENT_METHODS[k] || k, valor: v }))
      .sort((a, b) => b.valor - a.valor);

    return {
      usersData: [...usrMap.values()],
      revenueData: [...revMap.values()],
      ordersData,
      payData,
    };
  }, [orders, users]);

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 sm:gap-6">
      <Card title="Crescimento de usuários" subtitle="Total acumulado por mês">
        <ResponsiveContainer width="100%" height={240}>
          <AreaChart data={usersData} margin={{ left: -20, right: 8, top: 8 }}>
            <defs>
              <linearGradient id="gUsers" x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%" stopColor="#2563eb" stopOpacity={0.35} />
                <stop offset="95%" stopColor="#2563eb" stopOpacity={0} />
              </linearGradient>
            </defs>
            <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
            <XAxis dataKey="m" tick={{ fontSize: 11, fill: 'hsl(var(--muted-foreground))' }} axisLine={false} tickLine={false} />
            <YAxis tick={{ fontSize: 11, fill: 'hsl(var(--muted-foreground))' }} axisLine={false} tickLine={false} />
            <Tooltip contentStyle={tooltipStyle} />
            <Area type="monotone" dataKey="total" stroke="#2563eb" strokeWidth={2} fill="url(#gUsers)" />
          </AreaChart>
        </ResponsiveContainer>
      </Card>

      <Card title="Faturamento" subtitle="Receita mensal (R$)">
        <ResponsiveContainer width="100%" height={240}>
          <BarChart data={revenueData} margin={{ left: -20, right: 8, top: 8 }}>
            <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
            <XAxis dataKey="m" tick={{ fontSize: 11, fill: 'hsl(var(--muted-foreground))' }} axisLine={false} tickLine={false} />
            <YAxis tick={{ fontSize: 11, fill: 'hsl(var(--muted-foreground))' }} axisLine={false} tickLine={false} />
            <Tooltip contentStyle={tooltipStyle} formatter={(v) => fmtMoney(v)} />
            <Bar dataKey="valor" fill="#facc15" radius={[6, 6, 0, 0]} />
          </BarChart>
        </ResponsiveContainer>
      </Card>

      <Card title="Pedidos por período" subtitle="Últimos 7 dias">
        <ResponsiveContainer width="100%" height={240}>
          <LineChart data={ordersData} margin={{ left: -20, right: 8, top: 8 }}>
            <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
            <XAxis dataKey="m" tick={{ fontSize: 11, fill: 'hsl(var(--muted-foreground))' }} axisLine={false} tickLine={false} />
            <YAxis allowDecimals={false} tick={{ fontSize: 11, fill: 'hsl(var(--muted-foreground))' }} axisLine={false} tickLine={false} />
            <Tooltip contentStyle={tooltipStyle} />
            <Line type="monotone" dataKey="pedidos" stroke="#2563eb" strokeWidth={2.5} dot={{ r: 3 }} activeDot={{ r: 5 }} />
          </LineChart>
        </ResponsiveContainer>
      </Card>

      <Card title="Vendas por forma de pagamento" subtitle="Mês atual (R$)">
        <ResponsiveContainer width="100%" height={240}>
          <BarChart data={payData} margin={{ left: -20, right: 8, top: 8 }}>
            <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
            <XAxis dataKey="m" tick={{ fontSize: 11, fill: 'hsl(var(--muted-foreground))' }} axisLine={false} tickLine={false} />
            <YAxis tick={{ fontSize: 11, fill: 'hsl(var(--muted-foreground))' }} axisLine={false} tickLine={false} />
            <Tooltip contentStyle={tooltipStyle} formatter={(v) => fmtMoney(v)} />
            <Bar dataKey="valor" fill="#16a34a" radius={[6, 6, 0, 0]} />
          </BarChart>
        </ResponsiveContainer>
      </Card>
    </div>
  );
}