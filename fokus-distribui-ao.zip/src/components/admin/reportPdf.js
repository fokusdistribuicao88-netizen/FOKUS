// Relatório Geral do Sistema — agora gerado pelo Gerenciador de Modelos PDF.
// Toda geração passa pelo pdfService central (modelo "dashboard_report" configurável no Editor).
import { generatePDF } from '@/lib/pdfService';
import { generalReportToSections } from '@/lib/pdfAdapters';

const pad = (n) => String(n).padStart(2, '0');

// Gera o relatório geral usando o modelo central do sistema.
export async function generateGeneralReportPDF({ products = [], orders = [], settings, user }) {
  const { data, sections } = generalReportToSections(products, orders, user);
  const now = new Date();
  const fileName = `Relatorio_Geral_${pad(now.getDate())}-${pad(now.getMonth() + 1)}-${now.getFullYear()}_${pad(now.getHours())}-${pad(now.getMinutes())}.pdf`;
  await generatePDF({
    documentType: 'dashboard_report',
    data: { ...data, company: { name: settings?.company_name || 'FOKUS DISTRIBUIÇÃO', cnpj: settings?.company_cnpj || '', address: settings?.company_address || '', phones: settings?.phone_display || '', email: '', site: '' } },
    sections,
    module: 'Dashboard',
    user,
    fileName,
  });
}