import React, { useMemo } from 'react';
import { NavLink, useLocation, useNavigate } from 'react-router-dom';
import { LayoutDashboard, LogOut } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { useAuth } from '@/lib/AuthContext';
import { getNavSections } from '@/lib/adminNav';
import { useToast } from '@/components/ui/use-toast';

export default function AdminSidebar({ search, onClose, onLogout }) {
  const location = useLocation();
  const navigate = useNavigate();
  const { toast } = useToast();

  const { user } = useAuth();

  const sections = useMemo(() => {
    const q = search.trim().toLowerCase();
    const base = getNavSections(user?.role);
    if (!q) return base;
    return base.map((s) => ({
      ...s,
      items: s.items.filter((i) => i.label.toLowerCase().includes(q)),
    })).filter((s) => s.items.length > 0);
  }, [search, user?.role]);

  const handleSoon = (label) => {
    toast({ title: `${label} em breve`, description: 'Este módulo ainda não está disponível.' });
    onClose?.();
  };

  const handleScroll = (id) => {
    onClose?.();
    const onProfile = location.pathname === '/admin-profile';
    if (onProfile) {
      setTimeout(() => {
        document.getElementById(id)?.scrollIntoView({ behavior: 'smooth' });
      }, 100);
    } else {
      navigate('/admin-profile');
      setTimeout(() => {
        document.getElementById(id)?.scrollIntoView({ behavior: 'smooth' });
      }, 400);
    }
  };

  const handleLogout = async () => {
    try {
      await base44.auth.logout();
    } catch {
      window.location.href = '/';
    }
  };

  return (
    <div className="flex h-full flex-col bg-card border-r border-border">
      <div className="flex items-center gap-2.5 h-16 px-5 border-b border-border flex-shrink-0">
        <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-blue-600 to-blue-800 flex items-center justify-center shadow-md">
          <LayoutDashboard className="w-5 h-5 text-yellow-400" />
        </div>
        <div className="leading-tight">
          <span className="block text-sm font-bold text-blue-900 dark:text-foreground">Fokus Admin</span>
          <span className="text-[10px] text-muted-foreground uppercase tracking-wider">Painel</span>
        </div>
      </div>

      <nav className="flex-1 overflow-y-auto px-3 py-4 space-y-5">
        {sections.length === 0 && (
          <p className="text-xs text-muted-foreground px-2">Nenhum módulo encontrado.</p>
        )}
        {sections.map((section) => (
          <div key={section.title}>
            <p className="px-2 mb-1.5 text-[10px] font-semibold uppercase tracking-wider text-muted-foreground">
              {section.title}
            </p>
            <ul className="space-y-0.5">
              {section.items.map((item) => {
                const Icon = item.icon;
                if (item.to && item.scroll) {
                  return (
                    <li key={item.label}>
                      <NavLink
                        to={item.to}
                        onClick={() => {
                          onClose?.();
                          setTimeout(() => {
                            document.getElementById(item.scroll)?.scrollIntoView({ behavior: 'smooth' });
                          }, 350);
                        }}
                        className={({ isActive }) =>
                          `flex items-center gap-3 px-2.5 py-2 rounded-lg text-sm font-medium transition-colors ${
                            isActive
                              ? 'bg-blue-700 text-white shadow-sm'
                              : 'text-muted-foreground hover:bg-accent hover:text-foreground'
                          }`
                        }
                      >
                        <Icon className="w-4 h-4 flex-shrink-0" />
                        <span className="truncate">{item.label}</span>
                      </NavLink>
                    </li>
                  );
                }
                if (item.to) {
                  return (
                    <li key={item.label}>
                      <NavLink
                        to={item.to}
                        onClick={onClose}
                        className={({ isActive }) =>
                          `flex items-center gap-3 px-2.5 py-2 rounded-lg text-sm font-medium transition-colors ${
                            isActive
                              ? 'bg-blue-700 text-white shadow-sm'
                              : 'text-muted-foreground hover:bg-accent hover:text-foreground'
                          }`
                        }
                      >
                        <Icon className="w-4 h-4 flex-shrink-0" />
                        <span className="truncate">{item.label}</span>
                      </NavLink>
                    </li>
                  );
                }
                if (item.scroll) {
                  return (
                    <li key={item.label}>
                      <button
                        onClick={() => handleScroll(item.scroll)}
                        className="w-full flex items-center gap-3 px-2.5 py-2 rounded-lg text-sm font-medium text-muted-foreground hover:bg-accent hover:text-foreground transition-colors"
                      >
                        <Icon className="w-4 h-4 flex-shrink-0" />
                        <span className="truncate">{item.label}</span>
                      </button>
                    </li>
                  );
                }
                return (
                  <li key={item.label}>
                    <button
                      onClick={() => handleSoon(item.label)}
                      className="w-full flex items-center gap-3 px-2.5 py-2 rounded-lg text-sm font-medium text-muted-foreground hover:bg-accent hover:text-foreground transition-colors"
                    >
                      <Icon className="w-4 h-4 flex-shrink-0" />
                      <span className="truncate flex-1 text-left">{item.label}</span>
                      <span className="text-[9px] px-1.5 py-0.5 rounded-full bg-muted text-muted-foreground">em breve</span>
                    </button>
                  </li>
                );
              })}
            </ul>
          </div>
        ))}
      </nav>

      <div className="border-t border-border p-3 flex-shrink-0">
        <button
          onClick={handleLogout}
          className="w-full flex items-center gap-3 px-2.5 py-2 rounded-lg text-sm font-medium text-red-600 hover:bg-red-50 dark:hover:bg-red-950/30 transition-colors"
        >
          <LogOut className="w-4 h-4" /> Sair
        </button>
      </div>
    </div>
  );
}