import { Checkbox } from '@/components/ui/checkbox';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import { Pencil, Copy, Trash2, Package } from 'lucide-react';

export default function ProductListView({ products, selectedIds, onToggleSelect, onToggleSelectAll, onEdit, onDuplicate, onDelete, isLoading, density = 'comfortable' }) {
  const cellPad = density === 'compact' ? 'p-2' : 'p-3';

  if (isLoading) {
    return (
      <div className="bg-white rounded-xl border overflow-hidden">
        {[...Array(6)].map((_, i) => (
          <div key={i} className="flex items-center gap-3 p-3 border-b last:border-0">
            <Skeleton className="w-5 h-5" />
            <Skeleton className="w-10 h-10 rounded-lg" />
            <Skeleton className="h-4 flex-1" />
            <Skeleton className="w-20 h-4" />
            <Skeleton className="w-16 h-8" />
          </div>
        ))}
      </div>
    );
  }

  const allSelected = products.length > 0 && products.every(p => selectedIds.has(p.id));

  return (
    <div className="bg-white rounded-xl border overflow-hidden">
      <div className="overflow-x-auto">
        <table className="w-full text-sm">
          <thead className="bg-muted/50 border-b">
            <tr>
              <th className={`${cellPad} w-10`}><Checkbox checked={allSelected} onCheckedChange={onToggleSelectAll} /></th>
              <th className={`${cellPad} text-left font-medium`}>Produto</th>
              <th className={`${cellPad} text-left font-medium hidden md:table-cell`}>Categoria</th>
              <th className={`${cellPad} text-left font-medium hidden md:table-cell`}>Marca</th>
              <th className={`${cellPad} text-right font-medium`}>Preço</th>
              <th className={`${cellPad} text-center font-medium hidden sm:table-cell`}>Status</th>
              <th className={`${cellPad} text-right font-medium`}>Ações</th>
            </tr>
          </thead>
          <tbody>
            {products.map(p => (
              <tr key={p.id} className="border-b last:border-0 hover:bg-muted/30 transition-colors">
                <td className={cellPad}><Checkbox checked={selectedIds.has(p.id)} onCheckedChange={() => onToggleSelect(p.id)} /></td>
                <td className={cellPad}>
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-lg overflow-hidden bg-muted flex-shrink-0">
                      {p.image_url ? <img src={p.image_url} alt={p.name} className="w-full h-full object-cover" /> : <div className="w-full h-full flex items-center justify-center"><Package className="w-5 h-5 text-muted-foreground" /></div>}
                    </div>
                    <div className="min-w-0">
                      <p className="font-medium truncate max-w-[180px]">{p.name}</p>
                      {p.price_promo && <Badge className="bg-red-500 text-white text-xs mt-0.5">Promo</Badge>}
                    </div>
                  </div>
                </td>
                <td className={`${cellPad} hidden md:table-cell text-muted-foreground`}>{p.category}</td>
                <td className={`${cellPad} hidden md:table-cell text-muted-foreground`}>{p.brand || '—'}</td>
                <td className={`${cellPad} text-right font-semibold`}>R$ {p.price?.toFixed(2).replace('.', ',')}</td>
                <td className={`${cellPad} text-center hidden sm:table-cell`}>
                  <Badge variant={p.in_stock !== false ? 'default' : 'secondary'}>{p.in_stock !== false ? 'Ativo' : 'Inativo'}</Badge>
                </td>
                <td className={cellPad}>
                  <div className="flex items-center justify-end gap-1">
                    <Button variant="ghost" size="icon" onClick={() => onEdit(p)} title="Editar"><Pencil className="w-4 h-4" /></Button>
                    <Button variant="ghost" size="icon" onClick={() => onDuplicate(p)} title="Duplicar"><Copy className="w-4 h-4" /></Button>
                    <Button variant="ghost" size="icon" className="text-red-500" onClick={() => onDelete(p.id)} title="Excluir"><Trash2 className="w-4 h-4" /></Button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}