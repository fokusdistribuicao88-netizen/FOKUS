import { Package, CheckCircle, XCircle, AlertTriangle } from 'lucide-react';

export default function StatsBar({ stats }) {
  const items = [
    { label: 'Total', value: stats.total, icon: Package, color: 'text-blue-600', bg: 'bg-blue-50' },
    { label: 'Ativos', value: stats.active, icon: CheckCircle, color: 'text-green-600', bg: 'bg-green-50' },
    { label: 'Inativos', value: stats.inactive, icon: XCircle, color: 'text-red-600', bg: 'bg-red-50' },
    { label: 'Estoque Baixo', value: stats.lowStock, icon: AlertTriangle, color: 'text-amber-600', bg: 'bg-amber-50' },
  ];
  return (
    <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
      {items.map(item => (
        <div key={item.label} className="bg-white rounded-xl border p-3 flex items-center gap-3">
          <div className={`w-10 h-10 rounded-lg ${item.bg} flex items-center justify-center flex-shrink-0`}>
            <item.icon className={`w-5 h-5 ${item.color}`} />
          </div>
          <div className="min-w-0">
            <p className="text-xl font-bold leading-tight">{item.value}</p>
            <p className="text-xs text-muted-foreground truncate">{item.label}</p>
          </div>
        </div>
      ))}
    </div>
  );
}