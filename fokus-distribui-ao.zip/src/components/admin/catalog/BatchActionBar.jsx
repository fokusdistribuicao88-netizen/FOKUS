import { Button } from '@/components/ui/button';
import { CheckCircle, XCircle, Trash2, X } from 'lucide-react';

export default function BatchActionBar({ selectedCount, onActivate, onDeactivate, onDelete, onClear }) {
  return (
    <div className="flex items-center gap-2 p-3 bg-blue-50 border border-blue-200 rounded-xl mb-4 flex-wrap">
      <span className="text-sm font-medium">{selectedCount} selecionado(s)</span>
      <div className="flex-1" />
      <Button size="sm" variant="outline" onClick={onActivate}><CheckCircle className="w-4 h-4 mr-1" /> Ativar</Button>
      <Button size="sm" variant="outline" onClick={onDeactivate}><XCircle className="w-4 h-4 mr-1" /> Inativar</Button>
      <Button size="sm" variant="destructive" onClick={onDelete}><Trash2 className="w-4 h-4 mr-1" /> Excluir</Button>
      <Button size="sm" variant="ghost" onClick={onClear}><X className="w-4 h-4" /></Button>
    </div>
  );
}