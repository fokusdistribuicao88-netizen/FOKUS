import { Checkbox } from '@/components/ui/checkbox';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import { Pencil, Copy, Trash2, Package } from 'lucide-react';

export default function ProductGridView({ products, selectedIds, onToggleSelect, onToggleSelectAll, onEdit, onDuplicate, onDelete, isLoading }) {
  if (isLoading) {
    return (
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {[...Array(6)].map((_, i) => (
          <div key={i} className="bg-white rounded-xl border p-4 space-y-3">
            <Skeleton className="w-5 h-5" />
            <Skeleton className="w-full aspect-square rounded-lg" />
            <Skeleton className="h-4 w-3/4" />
            <Skeleton className="h-4 w-1/2" />
          </div>
        ))}
      </div>
    );
  }

  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
      {products.map(p => (
        <div key={p.id} className={`bg-white rounded-xl border p-4 transition-all ${selectedIds.has(p.id) ? 'ring-2 ring-blue-500' : ''}`}>
          <div className="flex items-start justify-between mb-3">
            <Checkbox checked={selectedIds.has(p.id)} onCheckedChange={() => onToggleSelect(p.id)} />
            <div className="flex gap-1">
              <Button variant="ghost" size="icon" onClick={() => onEdit(p)} title="Editar"><Pencil className="w-4 h-4" /></Button>
              <Button variant="ghost" size="icon" onClick={() => onDuplicate(p)} title="Duplicar"><Copy className="w-4 h-4" /></Button>
              <Button variant="ghost" size="icon" className="text-red-500" onClick={() => onDelete(p.id)} title="Excluir"><Trash2 className="w-4 h-4" /></Button>
            </div>
          </div>
          <div className="w-full aspect-square rounded-lg overflow-hidden bg-muted mb-3">
            {p.image_url ? <img src={p.image_url} alt={p.name} className="w-full h-full object-cover" /> : <div className="w-full h-full flex items-center justify-center"><Package className="w-12 h-12 text-muted-foreground" /></div>}
          </div>
          <h3 className="font-medium truncate">{p.name}</h3>
          <p className="text-sm text-muted-foreground truncate">{p.category} • {p.brand || '—'}</p>
          <div className="flex items-center justify-between mt-2">
            <p className="font-semibold text-blue-600">R$ {p.price?.toFixed(2).replace('.', ',')}</p>
            <Badge variant={p.in_stock !== false ? 'default' : 'secondary'}>{p.in_stock !== false ? 'Ativo' : 'Inativo'}</Badge>
          </div>
        </div>
      ))}
    </div>
  );
}