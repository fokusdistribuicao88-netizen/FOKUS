import { Filter, X } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';

export default function FilterPanel({
  filters, onFilterChange, onClear, categories, brands, hasActiveFilters
}) {
  return (
    <div className="w-full lg:w-60 bg-white rounded-xl border p-4 space-y-3 shrink-0 lg:max-h-[calc(100vh-12rem)] lg:overflow-y-auto">
      <div className="flex items-center justify-between">
        <h3 className="font-medium text-sm flex items-center gap-2"><Filter className="w-4 h-4" /> Filtros</h3>
        {hasActiveFilters && (
          <button onClick={onClear} className="text-xs text-blue-600 hover:underline flex items-center gap-1">
            <X className="w-3 h-3" /> Limpar
          </button>
        )}
      </div>

      <div>
        <Label className="text-xs mb-1 block">Status</Label>
        <Select value={filters.status} onValueChange={v => onFilterChange('status', v)}>
          <SelectTrigger><SelectValue /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">Todos</SelectItem>
            <SelectItem value="active">Ativos</SelectItem>
            <SelectItem value="inactive">Inativos</SelectItem>
          </SelectContent>
        </Select>
      </div>

      <div>
        <Label className="text-xs mb-1 block">Estoque</Label>
        <Select value={filters.stock} onValueChange={v => onFilterChange('stock', v)}>
          <SelectTrigger><SelectValue /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">Todos</SelectItem>
            <SelectItem value="in_stock">Com estoque</SelectItem>
            <SelectItem value="out_of_stock">Sem estoque</SelectItem>
            <SelectItem value="low">Estoque baixo</SelectItem>
            <SelectItem value="negative">Estoque negativo</SelectItem>
          </SelectContent>
        </Select>
      </div>

      <div>
        <Label className="text-xs mb-1 block">Promoções</Label>
        <Select value={filters.promo} onValueChange={v => onFilterChange('promo', v)}>
          <SelectTrigger><SelectValue /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">Todas</SelectItem>
            <SelectItem value="on_promo">Em promoção</SelectItem>
            <SelectItem value="no_promo">Fora de promoção</SelectItem>
          </SelectContent>
        </Select>
      </div>

      <div>
        <Label className="text-xs mb-1 block">Categoria</Label>
        <Select value={filters.category} onValueChange={v => onFilterChange('category', v)}>
          <SelectTrigger><SelectValue placeholder="Todas" /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">Todas</SelectItem>
            {categories.map(c => <SelectItem key={c} value={c}>{c}</SelectItem>)}
          </SelectContent>
        </Select>
      </div>

      <div>
        <Label className="text-xs mb-1 block">Marca</Label>
        <Select value={filters.brand} onValueChange={v => onFilterChange('brand', v)}>
          <SelectTrigger><SelectValue placeholder="Todas" /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">Todas</SelectItem>
            {brands.map(b => <SelectItem key={b} value={b}>{b}</SelectItem>)}
          </SelectContent>
        </Select>
      </div>

      <div>
        <Label className="text-xs mb-1 block">Faixa de Preço (R$)</Label>
        <div className="flex items-center gap-2">
          <Input type="number" placeholder="Mín" value={filters.priceMin} onChange={e => onFilterChange('priceMin', e.target.value)} className="h-8 text-sm" min="0" />
          <span className="text-muted-foreground">—</span>
          <Input type="number" placeholder="Máx" value={filters.priceMax} onChange={e => onFilterChange('priceMax', e.target.value)} className="h-8 text-sm" min="0" />
        </div>
      </div>

      <div>
        <Label className="text-xs mb-1 block">Data</Label>
        <Select value={filters.dateType} onValueChange={v => onFilterChange('dateType', v)}>
          <SelectTrigger><SelectValue /></SelectTrigger>
          <SelectContent>
            <SelectItem value="created">Cadastro</SelectItem>
            <SelectItem value="updated">Última alteração</SelectItem>
          </SelectContent>
        </Select>
        <div className="flex items-center gap-2 mt-2">
          <Input type="date" value={filters.dateFrom} onChange={e => onFilterChange('dateFrom', e.target.value)} className="h-8 text-sm" />
          <Input type="date" value={filters.dateTo} onChange={e => onFilterChange('dateTo', e.target.value)} className="h-8 text-sm" />
        </div>
      </div>
    </div>
  );
}