import { Search, SlidersHorizontal, List, LayoutGrid, ArrowUpDown } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';

export default function CatalogToolbar({
  search, onSearchChange, viewMode, onViewModeChange,
  sortField, onSortChange, sortDir, onToggleSortDir,
  onToggleFilters, showFilters, hasActiveFilters
}) {
  return (
    <div className="flex flex-wrap items-center gap-2">
      <div className="relative flex-1 min-w-[200px]">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
        <Input placeholder="Buscar por nome, marca ou descrição..." value={search} onChange={e => onSearchChange(e.target.value)} className="pl-10" />
      </div>
      <div className="relative">
        <Button variant={showFilters ? 'default' : 'outline'} size="icon" onClick={onToggleFilters} title="Filtros">
          <SlidersHorizontal className="w-4 h-4" />
        </Button>
        {hasActiveFilters && <span className="absolute top-1 right-1 w-2 h-2 bg-blue-500 rounded-full" />}
      </div>
      <Select value={sortField} onValueChange={onSortChange}>
        <SelectTrigger className="w-36"><ArrowUpDown className="w-4 h-4 mr-1" /><SelectValue /></SelectTrigger>
        <SelectContent>
          <SelectItem value="name">Nome</SelectItem>
          <SelectItem value="price">Preço</SelectItem>
          <SelectItem value="category">Categoria</SelectItem>
          <SelectItem value="brand">Marca</SelectItem>
          <SelectItem value="created_date">Cadastro</SelectItem>
          <SelectItem value="updated_date">Alteração</SelectItem>
        </SelectContent>
      </Select>
      <Button variant="outline" size="icon" onClick={onToggleSortDir} title={sortDir === 'asc' ? 'Crescente' : 'Decrescente'}>
        <span className={`text-xs font-bold transition-transform ${sortDir === 'desc' ? 'rotate-180' : ''}`}>↑↓</span>
      </Button>
      <div className="flex rounded-lg border overflow-hidden">
        <Button variant={viewMode === 'list' ? 'default' : 'ghost'} size="sm" onClick={() => onViewModeChange('list')} title="Lista">
          <List className="w-4 h-4" />
        </Button>
        <Button variant={viewMode === 'grid' ? 'default' : 'ghost'} size="sm" onClick={() => onViewModeChange('grid')} title="Grade">
          <LayoutGrid className="w-4 h-4" />
        </Button>
      </div>
    </div>
  );
}