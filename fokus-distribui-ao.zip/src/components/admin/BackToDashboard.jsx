import React from 'react';
import { Link } from 'react-router-dom';
import { ArrowLeft } from 'lucide-react';
import { Button } from '@/components/ui/button';

export default function BackToDashboard() {
  return (
    <Link to="/Dashboard" className="inline-flex">
      <Button variant="outline" size="sm" className="gap-2 cursor-pointer transition-all hover:bg-accent hover:shadow-sm">
        <ArrowLeft className="w-4 h-4" />
    
      </Button>
    </Link>
  );
}