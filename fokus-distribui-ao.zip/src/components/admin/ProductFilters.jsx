import React from 'react';
import { Search, Filter, X } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';

export default function ProductFilters({
  filters,
  onSearchChange,
  onFilterChange,
  onApply,
  onClear,
  categories,
  brands,
  resultsCount,
  totalCount,
  hasActiveFilters
}) {
  return (
    <div className="bg-white rounded-xl border border-blue-100 p-4 mb-6 space-y-4">
      <div className="relative">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
        <Input
          placeholder="Buscar por nome, marca ou código..."
          value={filters.search}
          onChange={(e) => onSearchChange(e.target.value)}
          className="pl-10"
        />
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
        <div>
          <Label className="text-xs mb-1 block">Categoria</Label>
          <Select value={filters.category} onValueChange={(v) => onFilterChange('category', v)}>
            <SelectTrigger><SelectValue placeholder="Todas" /></SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Todas</SelectItem>
              {categories.map(cat => <SelectItem key={cat} value={cat}>{cat}</SelectItem>)}
            </SelectContent>
          </Select>
        </div>

        <div>
          <Label className="text-xs mb-1 block">Marca</Label>
          <Select value={filters.brand} onValueChange={(v) => onFilterChange('brand', v)}>
            <SelectTrigger><SelectValue placeholder="Todas" /></SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Todas</SelectItem>
              {brands.map(b => <SelectItem key={b} value={b}>{b}</SelectItem>)}
            </SelectContent>
          </Select>
        </div>

        <div>
          <Label className="text-xs mb-1 block">Status</Label>
          <Select value={filters.status} onValueChange={(v) => onFilterChange('status', v)}>
            <SelectTrigger><SelectValue /></SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Todos</SelectItem>
              <SelectItem value="active">Ativo (em estoque)</SelectItem>
              <SelectItem value="out_of_stock">Em Falta</SelectItem>
              <SelectItem value="featured">Em Destaque</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <div>
          <Label className="text-xs mb-1 block">Faixa de Preço (R$)</Label>
          <div className="flex items-center gap-2">
            <Input
              type="number"
              placeholder="Mín"
              value={filters.priceMin}
              onChange={(e) => onFilterChange('priceMin', e.target.value)}
              className="h-9"
              min="0"
            />
            <span className="text-gray-400">-</span>
            <Input
              type="number"
              placeholder="Máx"
              value={filters.priceMax}
              onChange={(e) => onFilterChange('priceMax', e.target.value)}
              className="h-9"
              min="0"
            />
          </div>
        </div>
      </div>

      <div className="flex items-center justify-between flex-wrap gap-3">
        <div className="flex gap-2">
          <Button onClick={onApply} className="bg-blue-600 hover:bg-blue-700">
            <Filter className="w-4 h-4 mr-2" />
            Filtrar
          </Button>
          <Button variant="outline" onClick={onClear} disabled={!hasActiveFilters}>
            <X className="w-4 h-4 mr-2" />
            Limpar Filtros
          </Button>
        </div>
        <p className="text-sm text-gray-500">
          {resultsCount} de {totalCount} produto(s) encontrado(s)
        </p>
      </div>
    </div>
  );
}