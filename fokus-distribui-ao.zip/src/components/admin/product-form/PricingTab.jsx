import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { DollarSign, TrendingDown, TrendingUp, Lock } from 'lucide-react';
import { grossProfit, grossMargin, formatBRL } from '@/lib/profitCalc';

export default function PricingTab({
  formData, onChange, editingProduct, canEditCost, costReason, onCostReasonChange,
}) {
  const set = (k, v) => onChange(prev => ({ ...prev, [k]: v }));
  const cost = parseFloat(formData.cost) || 0;
  const price = parseFloat(formData.price) || 0;
  const promo = parseFloat(formData.price_promo) || 0;
  const wholesale = parseFloat(formData.price_wholesale) || 0;
  const cash = parseFloat(formData.price_cash) || 0;

  const discountPct = (base, val) =>
    base > 0 && val > 0 && val < base ? ((base - val) / base * 100).toFixed(1) + '%' : null;

  const promoDisc = discountPct(price, promo);
  const wholeDisc = discountPct(price, wholesale);
  const cashDisc = discountPct(price, cash);

  const gp = grossProfit(price, cost);
  const gm = grossMargin(price, cost);
  const costChanged = !!editingProduct && Number(editingProduct.cost ?? 0) !== cost;

  return (
    <div className="space-y-4">
      <Card>
        <CardHeader>
          <CardTitle className="text-sm flex items-center gap-2"><DollarSign className="w-4 h-4" /> Preço de Custo</CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          <div>
            <Label>Preço de Custo (R$)</Label>
            <Input
              type="number"
              step="0.01"
              min="0"
              value={formData.cost ?? ''}
              onChange={e => set('cost', e.target.value === '' ? '' : Math.max(0, parseFloat(e.target.value) || 0))}
              disabled={!canEditCost}
              placeholder="0,00"
            />
            {!canEditCost && (
              <p className="text-xs text-muted-foreground mt-1 flex items-center gap-1">
                <Lock className="w-3 h-3" /> Apenas gerentes e administradores podem editar o custo.
              </p>
            )}
          </div>

          {costChanged && canEditCost && (
            <div>
              <Label>Motivo da alteração (opcional)</Label>
              <Textarea
                rows={2}
                value={costReason || ''}
                onChange={e => onCostReasonChange?.(e.target.value)}
                placeholder="Ex: reajuste de fornecedor, nova negociação..."
              />
              <p className="text-xs text-muted-foreground mt-1">Será registrado no histórico de custos.</p>
            </div>
          )}

          {price > 0 && (
            <div className="grid grid-cols-2 gap-3 pt-2 border-t">
              <div>
                <span className="text-xs text-muted-foreground">Lucro bruto (padrão)</span>
                <p className={`text-sm font-semibold ${gp >= 0 ? 'text-emerald-600' : 'text-red-600'}`}>
                  {formatBRL(gp)}
                </p>
              </div>
              <div>
                <span className="text-xs text-muted-foreground">Margem bruta</span>
                <p className={`text-sm font-semibold ${gm == null ? 'text-muted-foreground' : gm >= 0 ? 'text-emerald-600' : 'text-red-600'}`}>
                  {gm == null ? '—' : `${gm}%`}
                </p>
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="text-sm flex items-center gap-2"><DollarSign className="w-4 h-4" /> Preços de Venda</CardTitle>
        </CardHeader>
        <CardContent className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div>
            <Label>Preço Padrão (R$) *</Label>
            <Input type="number" step="0.01" min="0" value={formData.price} onChange={e => set('price', e.target.value)} required />
          </div>
          <div>
            <Label>Preço Promocional (R$)</Label>
            <Input type="number" step="0.01" min="0" value={formData.price_promo} onChange={e => set('price_promo', e.target.value)} placeholder="Opcional" />
            {promoDisc && <p className="text-xs text-green-600 mt-1 flex items-center gap-1"><TrendingDown className="w-3 h-3" /> {promoDisc} de desconto</p>}
          </div>
          <div>
            <Label>Preço Atacado (10+ itens)</Label>
            <Input type="number" step="0.01" min="0" value={formData.price_wholesale} onChange={e => set('price_wholesale', e.target.value)} placeholder="Opcional" />
            {wholeDisc && <p className="text-xs text-green-600 mt-1 flex items-center gap-1"><TrendingDown className="w-3 h-3" /> {wholeDisc} de desconto</p>}
          </div>
          <div>
            <Label>Preço à Vista (Dinheiro)</Label>
            <Input type="number" step="0.01" min="0" value={formData.price_cash} onChange={e => set('price_cash', e.target.value)} placeholder="Opcional" />
            {cashDisc && <p className="text-xs text-green-600 mt-1 flex items-center gap-1"><TrendingDown className="w-3 h-3" /> {cashDisc} de desconto</p>}
          </div>
        </CardContent>
      </Card>

      {price > 0 && (
        <Card className="bg-muted/40">
          <CardHeader>
            <CardTitle className="text-sm flex items-center gap-2"><TrendingUp className="w-4 h-4" /> Resumo</CardTitle>
          </CardHeader>
          <CardContent className="grid grid-cols-2 sm:grid-cols-5 gap-3 text-sm">
            <div><span className="text-muted-foreground">Custo</span><p className="font-semibold">{cost ? formatBRL(cost) : '—'}</p></div>
            <div><span className="text-muted-foreground">Padrão</span><p className="font-semibold">{formatBRL(price)}</p></div>
            <div><span className="text-muted-foreground">Promo</span><p className="font-semibold">{promo ? formatBRL(promo) : '—'}</p></div>
            <div><span className="text-muted-foreground">Atacado</span><p className="font-semibold">{wholesale ? formatBRL(wholesale) : '—'}</p></div>
            <div><span className="text-muted-foreground">À vista</span><p className="font-semibold">{cash ? formatBRL(cash) : '—'}</p></div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}