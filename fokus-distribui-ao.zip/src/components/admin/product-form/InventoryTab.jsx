import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Package } from 'lucide-react';

export default function InventoryTab({ formData, onChange }) {
  const set = (k, v) => onChange(prev => ({ ...prev, [k]: v }));
  return (
    <div className="space-y-4">
      <Card>
        <CardHeader>
          <CardTitle className="text-sm flex items-center gap-2"><Package className="w-4 h-4" /> Disponibilidade</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center gap-3 p-3 rounded-lg bg-muted">
            <Switch checked={formData.in_stock} onCheckedChange={v => set('in_stock', v)} />
            <div>
              <Label className="font-medium">Disponível em estoque</Label>
              <p className="text-xs text-muted-foreground">Quando desativado, o produto aparece como esgotado no catálogo</p>
            </div>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <Label>Qtd. em Estoque</Label>
              <Input type="number" value={formData.stock_quantity} onChange={e => set('stock_quantity', e.target.value)} placeholder="—" />
              <p className="text-xs text-muted-foreground mt-1">Deixe vazio para não rastrear</p>
            </div>
            <div>
              <Label>Alerta de Estoque Baixo</Label>
              <Input type="number" value={formData.low_stock_threshold} onChange={e => set('low_stock_threshold', e.target.value)} />
              <p className="text-xs text-muted-foreground mt-1">Avisa quando atingir este limite</p>
            </div>
          </div>
          <div>
            <Label>Pedido Mínimo</Label>
            <Input type="number" value={formData.min_order} onChange={e => set('min_order', e.target.value)} />
            <p className="text-xs text-muted-foreground mt-1">Quantidade mínima por pedido</p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}