import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Switch } from '@/components/ui/switch';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Button } from '@/components/ui/button';
import { Plus } from 'lucide-react';

const unitTypes = [
  { value: 'unidade', label: 'Unidade' },
  { value: 'pack', label: 'Pack' },
  { value: 'fardo', label: 'Fardo' },
  { value: 'caixa', label: 'Caixa' },
  { value: 'engradado', label: 'Engradado' }
];

export default function GeneralTab({ formData, onChange, categories, newCategory, onNewCategoryChange, onAddCategory }) {
  const set = (k, v) => onChange(prev => ({ ...prev, [k]: v }));
  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
      <div className="sm:col-span-2">
        <Label>Nome *</Label>
        <Input value={formData.name} onChange={e => set('name', e.target.value)} required />
      </div>
      <div>
        <Label>Marca</Label>
        <Input value={formData.brand} onChange={e => set('brand', e.target.value)} />
      </div>
      <div>
        <Label>Categoria *</Label>
        <Select value={formData.category} onValueChange={v => set('category', v)}>
          <SelectTrigger><SelectValue /></SelectTrigger>
          <SelectContent>
            {categories.map(cat => <SelectItem key={cat} value={cat}>{cat}</SelectItem>)}
          </SelectContent>
        </Select>
        <div className="flex gap-2 mt-2">
          <Input placeholder="Nova categoria..." value={newCategory} onChange={e => onNewCategoryChange(e.target.value)} className="h-8 text-sm" onKeyDown={e => e.key === 'Enter' && (e.preventDefault(), onAddCategory())} />
          <Button type="button" size="sm" variant="outline" onClick={onAddCategory} className="h-8"><Plus className="w-3 h-3" /></Button>
        </div>
      </div>
      <div>
        <Label>Tipo de Unidade</Label>
        <Select value={formData.unit_type} onValueChange={v => set('unit_type', v)}>
          <SelectTrigger><SelectValue /></SelectTrigger>
          <SelectContent>
            {unitTypes.map(ut => <SelectItem key={ut.value} value={ut.value}>{ut.label}</SelectItem>)}
          </SelectContent>
        </Select>
      </div>
      <div>
        <Label>Unidades por Pack</Label>
        <Input type="number" value={formData.units_per_pack} onChange={e => set('units_per_pack', e.target.value)} />
      </div>
      <div>
        <Label>Volume (ml)</Label>
        <Input type="number" value={formData.volume_ml} onChange={e => set('volume_ml', e.target.value)} />
      </div>
      <div className="sm:col-span-2">
        <Label>Descrição</Label>
        <Textarea value={formData.description} onChange={e => set('description', e.target.value)} rows={3} />
      </div>
      <div className="flex items-center gap-2 sm:col-span-2 pt-1">
        <Switch checked={formData.featured} onCheckedChange={v => set('featured', v)} />
        <Label>Produto em destaque</Label>
      </div>
    </div>
  );
}