import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Button } from '@/components/ui/button';
import { Package, Upload, Loader2, X } from 'lucide-react';

export default function ImagesTab({ formData, onChange, uploading, onImageUpload }) {
  const set = (k, v) => onChange(prev => ({ ...prev, [k]: v }));
  return (
    <div className="space-y-4">
      <div className="flex flex-col items-center gap-4">
        <div className="w-40 h-40 rounded-xl border-2 border-dashed border-gray-200 overflow-hidden flex items-center justify-center bg-gray-50">
          {formData.image_url ? (
            <img src={formData.image_url} alt="Preview" className="w-full h-full object-cover" />
          ) : (
            <Package className="w-12 h-12 text-gray-300" />
          )}
        </div>
        <div className="flex items-center gap-3">
          <label className="cursor-pointer">
            <input type="file" accept="image/*" onChange={onImageUpload} className="hidden" />
            <div className="flex items-center gap-2 px-4 py-2 bg-blue-50 text-blue-600 rounded-lg hover:bg-blue-100 transition-colors">
              {uploading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Upload className="w-4 h-4" />}
              {uploading ? 'Enviando...' : 'Enviar imagem'}
            </div>
          </label>
          {formData.image_url && (
            <Button type="button" variant="outline" size="sm" onClick={() => set('image_url', '')}>
              <X className="w-4 h-4 mr-1" /> Remover
            </Button>
          )}
        </div>
      </div>
      <div>
        <Label>Ou cole a URL da imagem</Label>
        <Input value={formData.image_url} onChange={e => set('image_url', e.target.value)} placeholder="https://..." />
      </div>
    </div>
  );
}