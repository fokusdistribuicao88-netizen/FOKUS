import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { motion } from 'framer-motion';
import {
  Settings, Phone, MessageCircle, MapPin, Save, Loader2,
  CheckCircle2, Beer, Upload, Image, X, Plus, Images, Instagram, QrCode, Shield, FileText,
} from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import {
  Select, SelectTrigger, SelectValue, SelectContent, SelectItem,
} from '@/components/ui/select';
import { useAuth } from '@/lib/AuthContext';
import { logActivity } from '@/lib/activityLog';

export default function SettingsPanel() {
  const queryClient = useQueryClient();
  const { user } = useAuth();
  const [saved, setSaved] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [uploadingCarousel, setUploadingCarousel] = useState(false);

  const [formData, setFormData] = useState({
    whatsapp_number: '',
    phone_display: '',
    delivery_info: 'Entrega para toda região',
    logo_url: '',
    carousel_images: [],
    instagram_url: '',
    pix_key: '',
    pix_beneficiary_name: '',
    pix_city: '',
    inss_calc_mode: 'progressive',
    inss_percent: 0,
    inss_fixed_value: 0,
    quote_validity_days: 30,
    quote_auto_delete_days: 30,
  });

  const { data: settings } = useQuery({
    queryKey: ['settings'],
    queryFn: async () => {
      const list = await base44.entities.Settings.list('-updated_date', 1);
      return list[0] || null;
    },
  });

  useEffect(() => {
    if (settings) {
      setFormData({
        whatsapp_number: settings.whatsapp_number || '',
        phone_display: settings.phone_display || '',
        delivery_info: settings.delivery_info || 'Entrega para toda região',
        logo_url: settings.logo_url || '',
        carousel_images: settings.carousel_images || [],
        instagram_url: settings.instagram_url || '',
        pix_key: settings.pix_key || '',
        pix_beneficiary_name: settings.pix_beneficiary_name || '',
        pix_city: settings.pix_city || '',
        inss_calc_mode: settings.inss_calc_mode || 'progressive',
        inss_percent: settings.inss_percent || 0,
        inss_fixed_value: settings.inss_fixed_value || 0,
        quote_validity_days: settings.quote_validity_days || 30,
        quote_auto_delete_days: settings.quote_auto_delete_days || 30,
      });
    }
  }, [settings]);

  const handleLogoUpload = async (e) => {
    const file = e.target.files[0];
    if (!file) return;
    setUploading(true);
    const { file_url } = await base44.integrations.Core.UploadFile({ file });
    setFormData((prev) => ({ ...prev, logo_url: file_url }));
    setUploading(false);
  };

  const handleCarouselUpload = async (e) => {
    const file = e.target.files[0];
    if (!file) return;
    setUploadingCarousel(true);
    const { file_url } = await base44.integrations.Core.UploadFile({ file });
    setFormData((prev) => ({
      ...prev,
      carousel_images: [...(prev.carousel_images || []), file_url],
    }));
    setUploadingCarousel(false);
  };

  const removeCarouselImage = (index) => {
    setFormData((prev) => ({
      ...prev,
      carousel_images: prev.carousel_images.filter((_, i) => i !== index),
    }));
  };

  const saveMutation = useMutation({
    mutationFn: async (data) => {
      const list = await base44.entities.Settings.list('-updated_date', 1);
      const existing = list[0];
      // Detecta alterações na configuração de INSS para registrar no histórico.
      const inssChanges = [];
      const oldMode = existing?.inss_calc_mode || 'progressive';
      const oldPct = Number(existing?.inss_percent) || 0;
      const oldFixed = Number(existing?.inss_fixed_value) || 0;
      if (oldMode !== data.inss_calc_mode) {
        inssChanges.push(`Tipo de cálculo: ${oldMode} → ${data.inss_calc_mode}`);
      }
      if (oldPct !== Number(data.inss_percent)) {
        inssChanges.push(`Percentual: ${oldPct}% → ${Number(data.inss_percent)}%`);
      }
      if (oldFixed !== Number(data.inss_fixed_value)) {
        inssChanges.push(`Valor fixo: R$ ${oldFixed} → R$ ${Number(data.inss_fixed_value)}`);
      }
      let saved;
      if (existing?.id) {
        saved = await base44.entities.Settings.update(existing.id, data);
      } else {
        saved = await base44.entities.Settings.create(data);
      }
      if (inssChanges.length) {
        await logActivity({
          action: 'inss_config_change',
          description: `Configuração de INSS alterada: ${inssChanges.join('; ')}`,
          user,
          entityType: 'Settings',
          entityId: saved?.id || '',
          metadata: JSON.stringify({ previous: { mode: oldMode, percent: oldPct, fixed: oldFixed }, current: { mode: data.inss_calc_mode, percent: Number(data.inss_percent), fixed: Number(data.inss_fixed_value) } }),
        });
      }
      return saved;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['settings'] });
      setSaved(true);
      setTimeout(() => setSaved(false), 3000);
    },
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    saveMutation.mutate(formData);
  };

  return (
    <section id="configuracoes" className="scroll-mt-24">
      <div className="flex items-center gap-3 mb-4">
        <div className="w-1.5 h-7 rounded-full bg-blue-700" />
        <h2 className="text-xl lg:text-2xl font-bold text-foreground">Configurações Gerais</h2>
        <div className="h-px flex-1 bg-border" />
      </div>

      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}>
        <div className="bg-card rounded-2xl border border-border shadow-sm p-5 sm:p-6">
          <div className="flex items-center gap-2 mb-1">
            <Settings className="w-5 h-5 text-blue-600 dark:text-blue-400" />
            <h3 className="text-sm font-semibold text-foreground">Configurações de contato e marca</h3>
          </div>
          <p className="text-xs text-muted-foreground mb-5">
            Configure os números de telefone, WhatsApp, logo e banners exibidos no catálogo.
          </p>

          <form onSubmit={handleSubmit} className="space-y-5">
            {/* Logo */}
            <div className="space-y-2">
              <Label className="flex items-center gap-2">
                <Image className="w-4 h-4 text-blue-600 dark:text-blue-400" /> Logo da Empresa
              </Label>
              <div className="flex items-center gap-4">
                <div className="w-20 h-20 rounded-xl border-2 border-dashed border-border overflow-hidden flex items-center justify-center bg-muted/50">
                  {formData.logo_url ? (
                    <img src={formData.logo_url} alt="Logo" className="w-full h-full object-contain p-1" />
                  ) : (
                    <Beer className="w-8 h-8 text-muted-foreground/40" />
                  )}
                </div>
                <div className="flex-1">
                  <label className="cursor-pointer">
                    <input type="file" accept="image/*" onChange={handleLogoUpload} className="hidden" />
                    <div className="flex items-center gap-2 px-4 py-2 bg-blue-50 dark:bg-blue-950/40 text-blue-600 dark:text-blue-400 rounded-lg hover:bg-blue-100 dark:hover:bg-blue-900/50 transition-colors w-fit">
                      {uploading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Upload className="w-4 h-4" />}
                      {uploading ? 'Enviando...' : 'Enviar logo'}
                    </div>
                  </label>
                  {formData.logo_url && (
                    <button
                      type="button"
                      onClick={() => setFormData((prev) => ({ ...prev, logo_url: '' }))}
                      className="text-xs text-red-500 mt-2 hover:underline"
                    >
                      Remover logo
                    </button>
                  )}
                </div>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="whatsapp_number" className="flex items-center gap-2">
                  <MessageCircle className="w-4 h-4 text-emerald-600" /> Número do WhatsApp (pedidos)
                </Label>
                <Input
                  id="whatsapp_number"
                  name="whatsapp_number"
                  value={formData.whatsapp_number}
                  onChange={handleChange}
                  placeholder="5511999999999"
                />
                <p className="text-xs text-muted-foreground">Apenas números, com DDI (55) e DDD. Ex: 5511999999999</p>
              </div>

              <div className="space-y-2">
                <Label htmlFor="phone_display" className="flex items-center gap-2">
                  <Phone className="w-4 h-4 text-blue-600 dark:text-blue-400" /> Telefone para exibição
                </Label>
                <Input
                  id="phone_display"
                  name="phone_display"
                  value={formData.phone_display}
                  onChange={handleChange}
                  placeholder="(11) 99999-9999"
                />
                <p className="text-xs text-muted-foreground">Exibido no cabeçalho do catálogo.</p>
              </div>

              <div className="space-y-2">
                <Label htmlFor="delivery_info" className="flex items-center gap-2">
                  <MapPin className="w-4 h-4 text-blue-600 dark:text-blue-400" /> Informação de entrega
                </Label>
                <Input
                  id="delivery_info"
                  name="delivery_info"
                  value={formData.delivery_info}
                  onChange={handleChange}
                  placeholder="Entrega para toda região"
                />
                <p className="text-xs text-muted-foreground">Texto exibido no cabeçalho sobre a área de entrega.</p>
              </div>

              <div className="space-y-2">
                <Label htmlFor="instagram_url" className="flex items-center gap-2">
                  <Instagram className="w-4 h-4 text-pink-500" /> Link do Instagram
                </Label>
                <Input
                  id="instagram_url"
                  name="instagram_url"
                  value={formData.instagram_url}
                  onChange={handleChange}
                  placeholder="https://instagram.com/suapagina"
                />
                <p className="text-xs text-muted-foreground">Link completo do seu perfil no Instagram.</p>
              </div>
            </div>

            {/* PIX */}
            <div className="rounded-lg border border-blue-200 dark:border-blue-900/50 bg-blue-50/50 dark:bg-blue-950/20 p-4 space-y-4">
              <div className="flex items-center gap-2">
                <QrCode className="w-4 h-4 text-blue-600 dark:text-blue-400" />
                <h4 className="text-sm font-semibold text-foreground">Configuração do PIX</h4>
              </div>
              <p className="text-xs text-muted-foreground -mt-2">
                Chave e dados do beneficiário usados para gerar o QR Code PIX no PDV.
              </p>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="pix_key" className="flex items-center gap-2 text-xs">
                    <QrCode className="w-3.5 h-3.5 text-blue-600" /> Chave PIX
                  </Label>
                  <Input
                    id="pix_key"
                    name="pix_key"
                    value={formData.pix_key}
                    onChange={handleChange}
                    placeholder="CPF, CNPJ, email, telefone ou aleatória"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="pix_beneficiary_name" className="text-xs">Nome do beneficiário</Label>
                  <Input
                    id="pix_beneficiary_name"
                    name="pix_beneficiary_name"
                    value={formData.pix_beneficiary_name}
                    onChange={handleChange}
                    placeholder="Nome ou razão social (máx 25)"
                    maxLength={25}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="pix_city" className="text-xs">Cidade</Label>
                  <Input
                    id="pix_city"
                    name="pix_city"
                    value={formData.pix_city}
                    onChange={handleChange}
                    placeholder="Cidade (máx 15)"
                    maxLength={15}
                  />
                </div>
              </div>
            </div>

            {/* INSS */}
            <div className="rounded-lg border border-blue-200 dark:border-blue-900/50 bg-blue-50/50 dark:bg-blue-950/20 p-4 space-y-4">
              <div className="flex items-center gap-2">
                <Shield className="w-4 h-4 text-blue-600 dark:text-blue-400" />
                <h4 className="text-sm font-semibold text-foreground">Configuração do INSS</h4>
              </div>
              <p className="text-xs text-muted-foreground -mt-2">
                Define como o desconto de INSS é calculado para todos os funcionários. Funcionários com configuração específica ignoram estes valores.
              </p>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div className="space-y-2">
                  <Label className="text-xs">Tipo de cálculo do INSS</Label>
                  <Select
                    value={formData.inss_calc_mode}
                    onValueChange={(v) => setFormData((prev) => ({ ...prev, inss_calc_mode: v }))}
                  >
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="progressive">Faixas progressivas (tabela INSS)</SelectItem>
                      <SelectItem value="percent">Por porcentagem (%)</SelectItem>
                      <SelectItem value="fixed">Por valor fixo (R$)</SelectItem>
                      <SelectItem value="manual">Manual (informado na folha)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                {formData.inss_calc_mode === 'percent' && (
                  <div className="space-y-2">
                    <Label className="text-xs">Percentual do INSS (%)</Label>
                    <Input
                      type="number"
                      step="0.01"
                      name="inss_percent"
                      value={formData.inss_percent}
                      onChange={handleChange}
                      placeholder="Ex: 8"
                    />
                    <p className="text-xs text-muted-foreground">Aplicado sobre a base de cálculo.</p>
                  </div>
                )}
                {formData.inss_calc_mode === 'fixed' && (
                  <div className="space-y-2">
                    <Label className="text-xs">Valor fixo do INSS (R$)</Label>
                    <Input
                      type="number"
                      step="0.01"
                      name="inss_fixed_value"
                      value={formData.inss_fixed_value}
                      onChange={handleChange}
                      placeholder="Ex: 180.00"
                    />
                    <p className="text-xs text-muted-foreground">Desconto fixo para todos os funcionários.</p>
                  </div>
                )}
                {formData.inss_calc_mode === 'manual' && (
                  <div className="sm:col-span-2 space-y-2">
                    <p className="text-xs text-blue-700 dark:text-blue-400 bg-blue-50 dark:bg-blue-950/40 rounded px-3 py-2">
                      No modo manual, o valor do INSS é informado individualmente na folha de cada funcionário, substituindo o cálculo automático somente naquela competência.
                    </p>
                  </div>
                )}
              </div>
            </div>

            {/* Orçamentos */}
            <div className="rounded-lg border border-violet-200 bg-violet-50/50 p-4 space-y-4">
              <div className="flex items-center gap-2">
                <FileText className="w-4 h-4 text-violet-600" />
                <h4 className="text-sm font-semibold text-foreground">Configuração de Orçamentos</h4>
              </div>
              <p className="text-xs text-muted-foreground -mt-2">
                Define a validade padrão e o prazo para exclusão automática de orçamentos não convertidos.
              </p>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label className="text-xs">Validade padrão (dias)</Label>
                  <Input
                    type="number"
                    name="quote_validity_days"
                    value={formData.quote_validity_days}
                    onChange={handleChange}
                    placeholder="30"
                  />
                  <p className="text-xs text-muted-foreground">Dias de validade ao criar um novo orçamento.</p>
                </div>
                <div className="space-y-2">
                  <Label className="text-xs">Exclusão automática (dias)</Label>
                  <Input
                    type="number"
                    name="quote_auto_delete_days"
                    value={formData.quote_auto_delete_days}
                    onChange={handleChange}
                    placeholder="30"
                  />
                  <p className="text-xs text-muted-foreground">Orçamentos não convertidos após este prazo vão para a lixeira.</p>
                </div>
              </div>
            </div>

            {/* Carousel */}
            <div className="space-y-2">
              <Label className="flex items-center gap-2">
                <Images className="w-4 h-4 text-blue-600 dark:text-blue-400" /> Imagens do Carrossel
              </Label>
              <p className="text-xs text-muted-foreground mb-2">
                Banners exibidos no topo do catálogo.
              </p>
              <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                {formData.carousel_images?.map((url, index) => (
                  <div key={index} className="relative aspect-video rounded-lg overflow-hidden border border-border group">
                    <img src={url} alt={`Banner ${index + 1}`} className="w-full h-full object-cover" />
                    <button
                      type="button"
                      onClick={() => removeCarouselImage(index)}
                      className="absolute top-1 right-1 p-1 bg-red-500 text-white rounded-full opacity-0 group-hover:opacity-100 transition-opacity"
                    >
                      <X className="w-3 h-3" />
                    </button>
                  </div>
                ))}
                <label className="cursor-pointer">
                  <input type="file" accept="image/*" onChange={handleCarouselUpload} className="hidden" />
                  <div className="aspect-video rounded-lg border-2 border-dashed border-border flex flex-col items-center justify-center gap-1 hover:bg-accent transition-colors">
                    {uploadingCarousel ? (
                      <Loader2 className="w-5 h-5 animate-spin text-blue-600" />
                    ) : (
                      <>
                        <Plus className="w-5 h-5 text-muted-foreground" />
                        <span className="text-xs text-muted-foreground">Adicionar</span>
                      </>
                    )}
                  </div>
                </label>
              </div>
            </div>

            <Button
              type="submit"
              disabled={saveMutation.isPending}
              className="w-full sm:w-auto h-11 bg-blue-700 hover:bg-blue-800 text-white rounded-xl px-6"
            >
              {saveMutation.isPending ? (
                <>
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" /> Salvando...
                </>
              ) : saved ? (
                <>
                  <CheckCircle2 className="w-4 h-4 mr-2" /> Salvo com sucesso!
                </>
              ) : (
                <>
                  <Save className="w-4 h-4 mr-2" /> Salvar Configurações
                </>
              )}
            </Button>
          </form>
        </div>
      </motion.div>
    </section>
  );
}