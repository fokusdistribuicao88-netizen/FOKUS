import React from 'react';
import { Link } from 'react-router-dom';
import { useQuery } from '@tanstack/react-query';
import { Search, Menu, Bell } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { useAuth } from '@/lib/AuthContext';
import { Input } from '@/components/ui/input';

export default function AdminTopbar({ onMenuClick, search, onSearchChange }) {
  const { user } = useAuth();
  const { data: unread = 0 } = useQuery({
    queryKey: ['notifications-unread'],
    queryFn: async () => {
      const list = await base44.entities.Notification.list('-created_date', 200);
      return (list || []).filter((n) => !n.read).length;
    },
    refetchInterval: 15000,
  });

  const initials = (user?.full_name || user?.email || 'A')
    .split(' ')
    .map((p) => p[0])
    .slice(0, 2)
    .join('')
    .toUpperCase();

  return (
    <header className="sticky top-0 z-20 h-16 bg-card/95 backdrop-blur-md border-b border-border flex items-center gap-3 px-4 sm:px-6">
      <button
        onClick={onMenuClick}
        className="lg:hidden p-2 rounded-lg hover:bg-accent transition-colors"
        aria-label="Abrir menu">
        <Menu className="w-5 h-5" />
      </button>

      <div className="relative flex-1 max-w-md">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
        <Input
          type="text"
          placeholder="Buscar módulos..."
          value={search}
          onChange={(e) => onSearchChange(e.target.value)}
          className="pl-9 h-10 rounded-lg bg-muted/50" />
      </div>

      <div className="flex items-center gap-1">
        <Link to="/notifications" className="relative p-2 rounded-lg hover:bg-accent transition-colors" aria-label="Notificações">
          <Bell className="w-5 h-5 text-muted-foreground" />
          {unread > 0 && (
            <span className="absolute -top-0.5 -right-0.5 bg-red-500 text-white text-[10px] font-bold min-w-[16px] h-[16px] px-1 rounded-full flex items-center justify-center">
              {unread > 99 ? '99+' : unread}
            </span>
          )}
        </Link>
        <Link to="/admin-profile" className="flex items-center gap-2.5 pl-2 ml-1 border-l border-border rounded-lg hover:bg-accent transition-colors -mr-1 py-1">
          <div className="w-9 h-9 rounded-full bg-gradient-to-br from-blue-600 to-blue-800 text-white text-xs font-bold flex items-center justify-center">
            {initials}
          </div>
          <div className="hidden sm:block leading-tight">
            <p className="text-sm font-semibold text-foreground truncate max-w-[140px]">
              {user?.full_name || 'Administrador'}
            </p>
            <p className="text-[11px] text-muted-foreground capitalize">{user?.role || 'admin'}</p>
          </div>
        </Link>
      </div>
    </header>
  );
}