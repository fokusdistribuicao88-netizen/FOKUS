import { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Save, Copy, Trash2, Loader2 } from 'lucide-react';
import GeneralTab from './product-form/GeneralTab';
import PricingTab from './product-form/PricingTab';
import InventoryTab from './product-form/InventoryTab';
import ImagesTab from './product-form/ImagesTab';

export default function ProductFormDialog({
  open, onOpenChange, formData, onChange, editingProduct,
  categories, newCategory, onNewCategoryChange, onAddCategory,
  uploading, onImageUpload, onSubmit, onSaveAndNew, onDuplicate, onDelete, isSaving,
  canEditCost, costReason, onCostReasonChange,
}) {
  const [activeTab, setActiveTab] = useState('general');
  const isNew = !editingProduct;

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-3xl max-h-[92vh] flex flex-col p-0">
        <DialogHeader className="px-6 pt-6 pb-4 border-b">
          <div className="flex items-center justify-between gap-4">
            <div>
              <DialogTitle className="text-lg">
                {isNew ? 'Novo Produto' : 'Editar Produto'}
              </DialogTitle>
              {editingProduct && (
                <p className="text-xs text-muted-foreground mt-1">ID: {editingProduct.id}</p>
              )}
            </div>
            {!isNew && (
              <Badge variant={formData.in_stock ? 'default' : 'secondary'}>
                {formData.in_stock ? 'Ativo' : 'Inativo'}
              </Badge>
            )}
          </div>
        </DialogHeader>

        <form onSubmit={onSubmit} className="flex-1 flex flex-col overflow-hidden">
          <Tabs value={activeTab} onValueChange={setActiveTab} className="flex-1 flex flex-col overflow-hidden px-6 pt-4">
            <TabsList className="w-full justify-start">
              <TabsTrigger value="general">Geral</TabsTrigger>
              <TabsTrigger value="pricing">Preços</TabsTrigger>
              <TabsTrigger value="inventory">Estoque</TabsTrigger>
              <TabsTrigger value="images">Imagem</TabsTrigger>
            </TabsList>
            <div className="flex-1 overflow-y-auto py-4 min-h-0">
              <TabsContent value="general">
                <GeneralTab formData={formData} onChange={onChange} categories={categories} newCategory={newCategory} onNewCategoryChange={onNewCategoryChange} onAddCategory={onAddCategory} />
              </TabsContent>
              <TabsContent value="pricing">
                <PricingTab
                  formData={formData}
                  onChange={onChange}
                  editingProduct={editingProduct}
                  canEditCost={canEditCost}
                  costReason={costReason}
                  onCostReasonChange={onCostReasonChange}
                />
              </TabsContent>
              <TabsContent value="inventory">
                <InventoryTab formData={formData} onChange={onChange} />
              </TabsContent>
              <TabsContent value="images">
                <ImagesTab formData={formData} onChange={onChange} uploading={uploading} onImageUpload={onImageUpload} />
              </TabsContent>
            </div>
          </Tabs>

          <div className="flex flex-wrap items-center gap-2 px-6 py-4 border-t">
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>Cancelar</Button>
            {!isNew && (
              <>
                <Button type="button" variant="outline" onClick={onDuplicate}><Copy className="w-4 h-4 mr-1" /> Duplicar</Button>
                <Button type="button" variant="destructive" onClick={onDelete}><Trash2 className="w-4 h-4 mr-1" /> Excluir</Button>
              </>
            )}
            <div className="flex-1" />
            <Button type="button" variant="secondary" onClick={onSaveAndNew} disabled={isSaving}>
              {isSaving && <Loader2 className="w-4 h-4 mr-1 animate-spin" />} Salvar e Novo
            </Button>
            <Button type="submit" className="bg-blue-600 hover:bg-blue-700" disabled={isSaving}>
              {isSaving ? <Loader2 className="w-4 h-4 mr-1 animate-spin" /> : <Save className="w-4 h-4 mr-1" />}
              {isNew ? 'Criar' : 'Salvar'}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}