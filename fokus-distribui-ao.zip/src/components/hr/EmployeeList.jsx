import React, { useMemo, useState } from 'react';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import {
  Select, SelectTrigger, SelectValue, SelectContent, SelectItem,
} from '@/components/ui/select';
import { Search, Plus, Eye, Pencil, Power, History, Gift, Plane } from 'lucide-react';
import { formatBRL, formatDate } from '@/lib/format';

const STATUS = {
  active: { label: 'Ativo', cls: 'bg-green-100 text-green-800' },
  inactive: { label: 'Inativo', cls: 'bg-gray-100 text-gray-600' },
};

const VACATION_WARN_DAYS = 30;

function getVacationStatus(e) {
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  const start = e.vacation_start ? new Date(e.vacation_start) : null;
  const end = e.vacation_end ? new Date(e.vacation_end) : null;
  if (start) start.setHours(0, 0, 0, 0);
  if (end) end.setHours(0, 0, 0, 0);
  if (start && end && today >= start && today <= end) {
    return { label: 'Em férias', cls: 'bg-blue-100 text-blue-800', icon: Plane };
  }
  if (end) {
    const diff = Math.ceil((end - today) / (1000 * 60 * 60 * 24));
    if (diff >= 0 && diff <= VACATION_WARN_DAYS) {
      return { label: `Férias vencem em ${diff}d`, cls: 'bg-amber-100 text-amber-800', icon: Plane };
    }
  }
  if (start) {
    const diff = Math.ceil((start - today) / (1000 * 60 * 60 * 24));
    if (diff >= 0 && diff <= VACATION_WARN_DAYS) {
      return { label: `Férias em ${diff}d`, cls: 'bg-violet-100 text-violet-800', icon: Plane };
    }
  }
  return null;
}

export default function EmployeeList({ employees, advances, purchases, overtimes, onNew, onEdit, onView, onToggle, onHistory }) {
  const [q, setQ] = useState('');
  const [status, setStatus] = useState('all');
  const [sort, setSort] = useState('name');

  const totalsByEmployee = useMemo(() => {
    const map = {};
    for (const a of advances || []) {
      if (a.status === 'cancelled') continue;
      if (!map[a.employee_id]) map[a.employee_id] = { advances: 0, purchases: 0, overtime: 0 };
      map[a.employee_id].advances += Number(a.amount) || 0;
    }
    for (const p of purchases || []) {
      if (p.status === 'cancelled') continue;
      if (!map[p.employee_id]) map[p.employee_id] = { advances: 0, purchases: 0, overtime: 0 };
      map[p.employee_id].purchases += Number(p.total) || 0;
    }
    for (const o of overtimes || []) {
      if (o.status !== 'approved' && o.status !== 'paid') continue;
      if (!map[o.employee_id]) map[o.employee_id] = { advances: 0, purchases: 0, overtime: 0 };
      map[o.employee_id].overtime += Number(o.amount) || 0;
    }
    return map;
  }, [advances, purchases, overtimes]);

  const filtered = useMemo(() => {
    let list = [...(employees || [])];
    if (status !== 'all') list = list.filter((e) => e.status === status);
    const query = q.trim().toLowerCase();
    if (query) {
      list = list.filter((e) =>
        (e.name || '').toLowerCase().includes(query) ||
        (e.role || '').toLowerCase().includes(query) ||
        (e.cpf || '').toLowerCase().includes(query)
      );
    }
    list.sort((a, b) => {
      if (sort === 'name') return (a.name || '').localeCompare(b.name || '');
      if (sort === 'salary') return (Number(b.base_salary) || 0) - (Number(a.base_salary) || 0);
      if (sort === 'admission') return new Date(b.admission_date || 0) - new Date(a.admission_date || 0);
      return 0;
    });
    return list;
  }, [employees, q, status, sort]);

  return (
    <div className="space-y-3">
      <div className="flex flex-col md:flex-row gap-2 md:items-center">
        <div className="relative flex-1">
          <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
          <Input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Buscar por nome, cargo ou CPF..." className="pl-9" />
        </div>
        <Select value={status} onValueChange={setStatus}>
          <SelectTrigger className="md:w-40"><SelectValue /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">Todos status</SelectItem>
            <SelectItem value="active">Ativos</SelectItem>
            <SelectItem value="inactive">Inativos</SelectItem>
          </SelectContent>
        </Select>
        <Select value={sort} onValueChange={setSort}>
          <SelectTrigger className="md:w-44"><SelectValue /></SelectTrigger>
          <SelectContent>
            <SelectItem value="name">Nome (A-Z)</SelectItem>
            <SelectItem value="salary">Maior salário</SelectItem>
            <SelectItem value="admission">Admissão recente</SelectItem>
          </SelectContent>
        </Select>
        <Button onClick={onNew} className="md:w-auto">
          <Plus className="w-4 h-4" /> Novo funcionário
        </Button>
      </div>

      <div className="overflow-x-auto rounded-lg border border-border">
        <table className="w-full text-sm">
          <thead className="bg-muted/50 text-muted-foreground">
            <tr>
              <th className="text-left px-3 py-2 font-medium">Nome</th>
              <th className="text-left px-3 py-2 font-medium hidden md:table-cell">Cargo</th>
              <th className="text-right px-3 py-2 font-medium">Salário base</th>
              <th className="text-center px-3 py-2 font-medium">Status</th>
              <th className="text-left px-3 py-2 font-medium hidden lg:table-cell">Admissão</th>
              <th className="text-right px-3 py-2 font-medium hidden md:table-cell">Adiant.</th>
              <th className="text-right px-3 py-2 font-medium hidden md:table-cell">Compras</th>
              <th className="text-right px-3 py-2 font-medium hidden lg:table-cell">H. extras</th>
              <th className="text-right px-3 py-2 font-medium">Líquido est.</th>
              <th className="text-center px-3 py-2 font-medium">Ações</th>
            </tr>
          </thead>
          <tbody>
            {filtered.length === 0 && (
              <tr><td colSpan={10} className="text-center py-8 text-muted-foreground">Nenhum funcionário encontrado.</td></tr>
            )}
            {filtered.map((e) => {
              const t = totalsByEmployee[e.id] || { advances: 0, purchases: 0, overtime: 0 };
              const discounts = t.advances + t.purchases;
              const net = (Number(e.base_salary) || 0) + t.overtime - discounts;
              const st = STATUS[e.status] || STATUS.inactive;
              return (
                <tr key={e.id} className="border-t border-border hover:bg-muted/30">
                  <td className="px-3 py-2 font-medium">
                    <div className="flex items-center gap-1.5">
                      {e.name}
                      {e.bonus_enabled && <Gift className="w-3.5 h-3.5 text-amber-600" title="Recebe bonificação" />}
                      {(() => {
                        const vs = getVacationStatus(e);
                        if (!vs) return null;
                        return (
                          <span className={`inline-flex items-center gap-0.5 text-[10px] px-1.5 py-0.5 rounded-full ${vs.cls}`} title={vs.label}>
                            <vs.icon className="w-3 h-3" /> {vs.label}
                          </span>
                        );
                      })()}
                    </div>
                  </td>
                  <td className="px-3 py-2 hidden md:table-cell text-muted-foreground">{e.role || '—'}</td>
                  <td className="px-3 py-2 text-right">{formatBRL(e.base_salary)}</td>
                  <td className="px-3 py-2 text-center"><span className={`text-xs px-2 py-0.5 rounded-full ${st.cls}`}>{st.label}</span></td>
                  <td className="px-3 py-2 hidden lg:table-cell text-muted-foreground">{formatDate(e.admission_date)}</td>
                  <td className="px-3 py-2 text-right hidden md:table-cell">{formatBRL(t.advances)}</td>
                  <td className="px-3 py-2 text-right hidden md:table-cell">{formatBRL(t.purchases)}</td>
                  <td className="px-3 py-2 text-right hidden lg:table-cell">{formatBRL(t.overtime)}</td>
                  <td className="px-3 py-2 text-right font-semibold">{formatBRL(net)}</td>
                  <td className="px-3 py-2">
                    <div className="flex items-center justify-center gap-1">
                      <Button variant="ghost" size="icon" onClick={() => onView(e)} title="Detalhes"><Eye className="w-4 h-4" /></Button>
                      <Button variant="ghost" size="icon" onClick={() => onEdit(e)} title="Editar"><Pencil className="w-4 h-4" /></Button>
                      <Button variant="ghost" size="icon" onClick={() => onHistory(e)} title="Histórico financeiro"><History className="w-4 h-4" /></Button>
                      <Button variant="ghost" size="icon" onClick={() => onToggle(e)} title={e.status === 'active' ? 'Inativar' : 'Ativar'}>
                        <Power className={`w-4 h-4 ${e.status === 'active' ? 'text-green-600' : 'text-gray-400'}`} />
                      </Button>
                    </div>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
}