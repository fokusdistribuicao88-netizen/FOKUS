import React, { useState, useMemo } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter,
} from '@/components/ui/dialog';
import {
  Select, SelectTrigger, SelectValue, SelectContent, SelectItem,
} from '@/components/ui/select';
import { Plus, Pencil, Trash2, RotateCcw, Layers, Ban, CalendarClock, Eye, Printer, ChevronDown, ChevronRight, Share2 } from 'lucide-react';
import { useQuery } from '@tanstack/react-query';
import { useAuth } from '@/lib/AuthContext';
import { useToast } from '@/components/ui/use-toast';
import { base44 } from '@/api/base44Client';
import { logActivity } from '@/lib/activityLog';
import { syncAdvanceFinance } from '@/lib/expenseFinance';
import { currentCompetence } from '@/lib/payrollCalc';
import { formatBRL, formatDate } from '@/lib/format';
import { previewAdvancePdf, printAdvancePdf, shareAdvancePdf } from '@/lib/employeeReceiptPdf';
import EmployeePicker from './EmployeePicker';

const METHODS = ['Dinheiro', 'PIX', 'Transferência'];
const STATUS = {
  pending: { label: 'Pendente', cls: 'bg-yellow-100 text-yellow-800' },
  deducted: { label: 'Descontado', cls: 'bg-blue-100 text-blue-800' },
  cancelled: { label: 'Cancelado', cls: 'bg-gray-100 text-gray-600' },
};

function addMonthsToCompetence(competence, monthsToAdd) {
  if (!competence) return competence;
  const [y, m] = competence.split('-').map(Number);
  const d = new Date(y, m - 1 + monthsToAdd, 1);
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`;
}

const empty = { employee_id: '', date: new Date().toISOString().slice(0, 10), amount: '', payment_method: 'Dinheiro', reason: '', competence_month: currentCompetence(), mode: 'avista', installments: 2, interval_months: 1 };

export default function AdvancesTab({ employees, advances, can, onReload }) {
  const { user } = useAuth();
  const { toast } = useToast();
  const { data: settings } = useQuery({
    queryKey: ['settings'],
    queryFn: () => base44.entities.Settings.list('-updated_date', 1).then((r) => r[0]),
  });
  const [open, setOpen] = useState(false);
  const [editing, setEditing] = useState(null);
  const [form, setForm] = useState(empty);
  const [saving, setSaving] = useState(false);
  const [filterEmp, setFilterEmp] = useState('all');
  const [filterStatus, setFilterStatus] = useState('active');
  const [expandedGroups, setExpandedGroups] = useState({});

  const STATUS_FILTERS = [
    { value: 'active', label: 'Ativos' },
    { value: 'all', label: 'Todos' },
    { value: 'pending', label: 'Pendentes' },
    { value: 'deducted', label: 'Descontados' },
    { value: 'cancelled', label: 'Cancelados' },
  ];

  const filtered = useMemo(() => {
    let list = [...(advances || [])];
    if (filterEmp !== 'all') list = list.filter((a) => a.employee_id === filterEmp);
    if (filterStatus === 'active') list = list.filter((a) => a.status !== 'deducted');
    else if (filterStatus !== 'all') list = list.filter((a) => a.status === filterStatus);
    return list.sort((a, b) => new Date(b.date || 0) - new Date(a.date || 0));
  }, [advances, filterEmp, filterStatus]);

  // Agrupa adiantamentos parcelados por installment_group_id.
  // Retorna lista de exibição: { type: 'single', advance } | { type: 'group', groupId, parcels, ... }
  const displayList = useMemo(() => {
    const groups = new Map();
    const individuals = [];
    (filtered || []).forEach((a) => {
      if (a.installment_group_id) {
        if (!groups.has(a.installment_group_id)) groups.set(a.installment_group_id, []);
        groups.get(a.installment_group_id).push(a);
      } else {
        individuals.push(a);
      }
    });
    const items = [];
    individuals.forEach((a) => items.push({ type: 'single', advance: a, key: a.id, date: a.date }));
    groups.forEach((parcels, groupId) => {
      parcels.sort((a, b) => (a.installment_number || 0) - (b.installment_number || 0));
      const totalAmount = parcels.reduce((s, p) => s + (Number(p.amount) || 0), 0);
      const pending = parcels.filter((p) => p.status === 'pending');
      const deducted = parcels.filter((p) => p.status === 'deducted');
      const cancelled = parcels.filter((p) => p.status === 'cancelled');
      // Status do grupo: se todas pendentes → pending; se todas canceladas → cancelled; misto → partial
      let groupStatus = 'pending';
      if (pending.length === parcels.length) groupStatus = 'pending';
      else if (cancelled.length === parcels.length) groupStatus = 'cancelled';
      else if (deducted.length === parcels.length) groupStatus = 'deducted';
      else groupStatus = 'partial';
      items.push({
        type: 'group',
        groupId,
        parcels,
        advance: parcels[0],
        totalAmount,
        pendingCount: pending.length,
        deductedCount: deducted.length,
        cancelledCount: cancelled.length,
        groupStatus,
        key: groupId,
        date: parcels[0]?.date,
      });
    });
    items.sort((a, b) => new Date(b.date || 0) - new Date(a.date || 0));
    return items;
  }, [filtered]);

  const toggleGroup = (groupId) => setExpandedGroups((s) => ({ ...s, [groupId]: !s[groupId] }));

  const total = useMemo(() => filtered.filter((a) => a.status !== 'cancelled').reduce((s, a) => s + (Number(a.amount) || 0), 0), [filtered]);

  const set = (k, v) => setForm((f) => ({ ...f, [k]: v }));
  const openNew = () => { setEditing(null); setForm(empty); setOpen(true); };
  const openEdit = (a) => { setEditing(a); setForm({ ...empty, ...a, mode: 'avista', installments: 2, interval_months: 1 }); setOpen(true); };

  const submit = async (action = 'save') => {
    if (!form.employee_id) return toast({ title: 'Selecione o funcionário', variant: 'destructive' });
    if (!form.amount || Number(form.amount) <= 0) return toast({ title: 'Valor inválido', variant: 'destructive' });
    setSaving(true);
    try {
      const emp = employees.find((e) => e.id === form.employee_id);
      const isParcelado = form.mode === 'parcelado' && Number(form.installments) > 1 && !editing?.id;

      if (isParcelado) {
        const totalAmount = Number(form.amount);
        const numInst = Math.floor(Number(form.installments));
        const interval = Math.max(1, Math.floor(Number(form.interval_months) || 1));
        const parcelValue = Math.round((totalAmount / numInst) * 100) / 100;
        const groupId = `inst_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`;
        const baseCompetence = form.competence_month || currentCompetence(form.date);
        const records = [];
        for (let i = 0; i < numInst; i++) {
          const comp = addMonthsToCompetence(baseCompetence, i * interval);
          const isLast = i === numInst - 1;
          records.push({
            employee_id: form.employee_id,
            employee_name: emp?.name || '',
            date: form.date,
            amount: isLast ? Math.round((totalAmount - parcelValue * (numInst - 1)) * 100) / 100 : parcelValue,
            payment_method: form.payment_method,
            reason: form.reason ? `${form.reason} (Parcela ${i + 1}/${numInst})` : `Parcela ${i + 1}/${numInst}`,
            competence_month: comp,
            status: 'pending',
            registered_by: user?.email || '',
            installment_number: i + 1,
            installment_total: numInst,
            installment_group_id: groupId,
          });
        }
        const created = await base44.entities.EmployeeAdvance.bulkCreate(records);
        const feId = await syncAdvanceFinance({ id: created[0]?.id, employee_name: emp?.name, amount: totalAmount, date: form.date, payment_method: form.payment_method }, user);
        await logActivity({ action: 'advance_create', description: `Adiantamento parcelado de ${formatBRL(totalAmount)} em ${numInst}x para ${emp?.name}`, user, entityType: 'EmployeeAdvance', entityId: groupId });
        toast({ title: 'Adiantamento parcelado', description: `${numInst} parcelas de ${formatBRL(parcelValue)} criadas.` });
        if (action !== 'save' && created[0]) {
          try {
            const fn = action === 'preview' ? previewAdvancePdf : printAdvancePdf;
            await fn({ advance: created[0], employee: emp, settings, user });
          } catch { /* ignore PDF error */ }
        }
        setOpen(false);
        onReload?.();
        return;
      }

      const payload = {
        employee_id: form.employee_id,
        employee_name: emp?.name || '',
        date: form.date,
        amount: Number(form.amount),
        payment_method: form.payment_method,
        reason: form.reason,
        competence_month: form.competence_month || currentCompetence(form.date),
        status: form.status || 'pending',
        registered_by: user?.email || '',
      };
      let saved;
      if (editing?.id) {
        saved = await base44.entities.EmployeeAdvance.update(editing.id, payload);
        await logActivity({ action: 'advance_update', description: `Editou adiantamento de ${emp?.name}`, user, entityType: 'EmployeeAdvance', entityId: editing.id });
      } else {
        saved = await base44.entities.EmployeeAdvance.create(payload);
        const feId = await syncAdvanceFinance({ ...saved, employee_name: emp?.name }, user);
        if (feId) await base44.entities.EmployeeAdvance.update(saved.id, { financial_entry_id: feId });
        await logActivity({ action: 'advance_create', description: `Adiantamento de ${formatBRL(payload.amount)} para ${emp?.name}`, user, entityType: 'EmployeeAdvance', entityId: saved.id });
      }
      toast({ title: 'Adiantamento salvo' });
      if (action !== 'save' && saved) {
        try {
          const fn = action === 'preview' ? previewAdvancePdf : printAdvancePdf;
          await fn({ advance: saved, employee: emp, settings, user });
        } catch { /* ignore PDF error */ }
      }
      setOpen(false);
      onReload?.();
    } catch (e) {
      toast({ title: 'Erro', description: e.message, variant: 'destructive' });
    } finally {
      setSaving(false);
    }
  };

  const cancel = async (a) => {
    if (!confirm('Cancelar este adiantamento? Ele não será incluído na folha.')) return;
    try {
      await base44.entities.EmployeeAdvance.update(a.id, { status: 'cancelled' });
      await logActivity({ action: 'advance_cancel', description: `Cancelou adiantamento de ${a.employee_name} (${formatBRL(a.amount)})`, user, entityType: 'EmployeeAdvance', entityId: a.id });
      toast({ title: 'Adiantamento cancelado' });
      onReload?.();
    } catch (e) {
      toast({ title: 'Erro', description: e.message, variant: 'destructive' });
    }
  };

  const reactivate = async (a) => {
    if (!confirm('Reativar este adiantamento? Ele voltará a ser considerado na folha.')) return;
    try {
      await base44.entities.EmployeeAdvance.update(a.id, { status: 'pending' });
      await logActivity({ action: 'advance_reactivate', description: `Reativou adiantamento de ${a.employee_name} (${formatBRL(a.amount)})`, user, entityType: 'EmployeeAdvance', entityId: a.id });
      toast({ title: 'Adiantamento reativado' });
      onReload?.();
    } catch (e) {
      toast({ title: 'Erro', description: e.message, variant: 'destructive' });
    }
  };

  const pushNextMonth = async (a) => {
    const next = addMonthsToCompetence(a.competence_month || currentCompetence(a.date), 1);
    if (!confirm(`Jogar este adiantamento para a competência ${next}?`)) return;
    try {
      await base44.entities.EmployeeAdvance.update(a.id, { competence_month: next });
      await logActivity({ action: 'advance_push_month', description: `Adiantamento de ${a.employee_name} jogado para ${next}`, user, entityType: 'EmployeeAdvance', entityId: a.id });
      toast({ title: 'Adiantamento movido', description: `Nova competência: ${next}` });
      onReload?.();
    } catch (e) {
      toast({ title: 'Erro', description: e.message, variant: 'destructive' });
    }
  };

  const excludeAdvance = async (a) => {
    const isDeducted = a.status === 'deducted';
    if (isDeducted && user?.role !== 'admin') {
      toast({ title: 'Apenas administradores podem excluir adiantamentos já descontados em folha', variant: 'destructive' });
      return;
    }
    if (!confirm('Tem certeza que deseja excluir este adiantamento? Esta ação não pode ser desfeita.')) return;
    try {
      if (a.financial_entry_id) {
        try { await base44.entities.FinancialEntry.update(a.financial_entry_id, { status: 'cancelled' }); } catch { /* ignore */ }
      }
      await base44.entities.EmployeeAdvance.delete(a.id);
      await logActivity({ action: 'advance_delete', description: `Excluiu adiantamento de ${a.employee_name} (${formatBRL(a.amount)})`, user, entityType: 'EmployeeAdvance', entityId: a.id });
      toast({ title: 'Adiantamento excluído' });
      onReload?.();
    } catch (e) {
      toast({ title: 'Erro', description: e.message, variant: 'destructive' });
    }
  };

  const cancelInstallmentGroup = async (a) => {
    if (!a.installment_group_id) return;
    if (!confirm('Cancelar este parcelamento? As parcelas pendentes serão canceladas e o histórico será preservado.')) return;
    try {
      await base44.entities.EmployeeAdvance.updateMany(
        { installment_group_id: a.installment_group_id, status: 'pending' },
        { $set: { status: 'cancelled' } }
      );
      await logActivity({ action: 'advance_installment_cancel', description: `Cancelou parcelamento de ${a.employee_name} (grupo ${a.installment_group_id})`, user, entityType: 'EmployeeAdvance', entityId: a.id });
      toast({ title: 'Parcelamento cancelado', description: 'Parcelas pendentes foram canceladas.' });
      onReload?.();
    } catch (e) {
      toast({ title: 'Erro', description: e.message, variant: 'destructive' });
    }
  };

  const reactivateInstallmentGroup = async (a) => {
    if (!a.installment_group_id) return;
    if (!confirm('Reativar este parcelamento? As parcelas canceladas serão restauradas para pendente.')) return;
    try {
      await base44.entities.EmployeeAdvance.updateMany(
        { installment_group_id: a.installment_group_id, status: 'cancelled' },
        { $set: { status: 'pending' } }
      );
      await logActivity({ action: 'advance_installment_reactivate', description: `Reativou parcelamento de ${a.employee_name} (grupo ${a.installment_group_id})`, user, entityType: 'EmployeeAdvance', entityId: a.id });
      toast({ title: 'Parcelamento reativado' });
      onReload?.();
    } catch (e) {
      toast({ title: 'Erro', description: e.message, variant: 'destructive' });
    }
  };

  return (
    <div className="space-y-3">
      <div className="flex flex-col md:flex-row gap-2 md:items-center justify-between">
        <div className="flex flex-wrap gap-2">
          <Select value={filterEmp} onValueChange={setFilterEmp}>
            <SelectTrigger className="md:w-56 w-full"><SelectValue placeholder="Filtrar por funcionário" /></SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Todos funcionários</SelectItem>
              {employees.map((e) => <SelectItem key={e.id} value={e.id}>{e.name}</SelectItem>)}
            </SelectContent>
          </Select>
          <Select value={filterStatus} onValueChange={setFilterStatus}>
            <SelectTrigger className="md:w-40 w-full"><SelectValue placeholder="Status" /></SelectTrigger>
            <SelectContent>
              {STATUS_FILTERS.map((s) => <SelectItem key={s.value} value={s.value}>{s.label}</SelectItem>)}
            </SelectContent>
          </Select>
        </div>
        <div className="flex items-center gap-3">
          <span className="text-sm text-muted-foreground">Total: <strong className="text-foreground">{formatBRL(total)}</strong></span>
          {can('Registrar adiantamentos') && <Button onClick={openNew}><Plus className="w-4 h-4" /> Novo adiantamento</Button>}
        </div>
      </div>

      <div className="overflow-x-auto rounded-lg border border-border">
        <table className="w-full text-sm">
          <thead className="bg-muted/50 text-muted-foreground">
            <tr>
              <th className="text-left px-3 py-2 font-medium">Funcionário</th>
              <th className="text-left px-3 py-2 font-medium">Data</th>
              <th className="text-right px-3 py-2 font-medium">Valor</th>
              <th className="text-left px-3 py-2 font-medium hidden md:table-cell">Forma</th>
              <th className="text-left px-3 py-2 font-medium hidden lg:table-cell">Competência</th>
              <th className="text-left px-3 py-2 font-medium hidden md:table-cell">Motivo</th>
              <th className="text-center px-3 py-2 font-medium hidden lg:table-cell">Origem</th>
              <th className="text-center px-3 py-2 font-medium hidden lg:table-cell">Parcela</th>
              <th className="text-center px-3 py-2 font-medium">Status</th>
              <th className="text-center px-3 py-2 font-medium">Ações</th>
            </tr>
          </thead>
          <tbody>
            {displayList.length === 0 && <tr><td colSpan={10} className="text-center py-8 text-muted-foreground">Nenhum adiantamento registrado.</td></tr>}
            {displayList.map((item) => {
              if (item.type === 'single') {
                const a = item.advance;
                const st = STATUS[a.status] || STATUS.pending;
                return (
                  <tr key={a.id} className="border-t border-border hover:bg-muted/30">
                    <td className="px-3 py-2 font-medium">{a.employee_name || '—'}</td>
                    <td className="px-3 py-2">{formatDate(a.date)}</td>
                    <td className="px-3 py-2 text-right font-medium">{formatBRL(a.amount)}</td>
                    <td className="px-3 py-2 hidden md:table-cell text-muted-foreground">{a.payment_method}</td>
                    <td className="px-3 py-2 hidden lg:table-cell text-muted-foreground">{a.competence_month}</td>
                    <td className="px-3 py-2 hidden md:table-cell text-muted-foreground max-w-[200px] truncate">{a.reason}</td>
                    <td className="px-3 py-2 text-center hidden lg:table-cell">
                      {a.origin === 'folha_negativa' ? (
                        <span className="text-xs px-2 py-0.5 rounded-full bg-amber-100 text-amber-800" title="Origem: Folha de Pagamento">Folha</span>
                      ) : (
                        <span className="text-xs px-2 py-0.5 rounded-full bg-slate-100 text-slate-600">Manual</span>
                      )}
                    </td>
                    <td className="px-3 py-2 text-center hidden lg:table-cell">—</td>
                    <td className="px-3 py-2 text-center"><span className={`text-xs px-2 py-0.5 rounded-full ${st.cls}`}>{st.label}</span></td>
                    <td className="px-3 py-2">
                      <div className="flex items-center justify-center gap-1">
                        <Button variant="ghost" size="icon" onClick={() => previewAdvancePdf({ advance: a, employee: employees.find((e) => e.id === a.employee_id), settings, user })} title="Visualizar PDF"><Eye className="w-4 h-4" /></Button>
                        <Button variant="ghost" size="icon" onClick={() => printAdvancePdf({ advance: a, employee: employees.find((e) => e.id === a.employee_id), settings, user })} title="Imprimir PDF"><Printer className="w-4 h-4" /></Button>
                        <Button variant="ghost" size="icon" onClick={() => shareAdvancePdf({ advance: a, employee: employees.find((e) => e.id === a.employee_id), settings, user })} title="Compartilhar PDF"><Share2 className="w-4 h-4" /></Button>
                        {can('Registrar adiantamentos') && a.status === 'pending' && (
                          <Button variant="ghost" size="icon" onClick={() => openEdit(a)} title="Editar"><Pencil className="w-4 h-4" /></Button>
                        )}
                        {can('Registrar adiantamentos') && a.status === 'pending' && (
                          <Button variant="ghost" size="icon" onClick={() => pushNextMonth(a)} title="Jogar para próximo mês"><CalendarClock className="w-4 h-4 text-blue-600" /></Button>
                        )}
                        {can('Registrar adiantamentos') && a.status === 'pending' && (
                          <Button variant="ghost" size="icon" onClick={() => cancel(a)} title="Cancelar"><Ban className="w-4 h-4 text-red-600" /></Button>
                        )}
                        {can('Registrar adiantamentos') && a.status === 'cancelled' && (
                          <Button variant="ghost" size="icon" onClick={() => reactivate(a)} title="Reativar"><RotateCcw className="w-4 h-4 text-green-600" /></Button>
                        )}
                        {can('Registrar adiantamentos') && (
                          <Button variant="ghost" size="icon" onClick={() => excludeAdvance(a)} title="Excluir"><Trash2 className="w-4 h-4 text-red-700" /></Button>
                        )}
                      </div>
                    </td>
                  </tr>
                );
              }
              // Linha de grupo (parcelamento)
              const { parcels, groupId, totalAmount, groupStatus, pendingCount, deductedCount, cancelledCount } = item;
              const expanded = !!expandedGroups[groupId];
              const st = STATUS[groupStatus] || STATUS.pending;
              const a = item.advance;
              const emp = employees.find((e) => e.id === a.employee_id);
              const pushGroupNextMonth = async () => {
                const next = addMonthsToCompetence(a.competence_month || currentCompetence(a.date), 1);
                if (!confirm(`Jogar todas as ${pendingCount} parcela(s) pendente(s) para a competência ${next}?`)) return;
                try {
                  await base44.entities.EmployeeAdvance.updateMany(
                    { installment_group_id: groupId, status: 'pending' },
                    { $set: { competence_month: next } }
                  );
                  await logActivity({ action: 'advance_push_month', description: `Parcelamento de ${a.employee_name} jogado para ${next}`, user, entityType: 'EmployeeAdvance', entityId: groupId });
                  toast({ title: 'Parcelamento movido', description: `Nova competência: ${next}` });
                  onReload?.();
                } catch (e) { toast({ title: 'Erro', description: e.message, variant: 'destructive' }); }
              };
              return (
                <React.Fragment key={groupId}>
                  <tr className="border-t border-border bg-indigo-50/40 hover:bg-indigo-50 cursor-pointer" onClick={() => toggleGroup(groupId)}>
                    <td className="px-3 py-2 font-medium flex items-center gap-1.5">
                      {expanded ? <ChevronDown className="w-4 h-4 text-muted-foreground" /> : <ChevronRight className="w-4 h-4 text-muted-foreground" />}
                      <Layers className="w-4 h-4 text-indigo-600" />
                      {a.employee_name || '—'}
                    </td>
                    <td className="px-3 py-2">{formatDate(a.date)}</td>
                    <td className="px-3 py-2 text-right font-medium">{formatBRL(totalAmount)}</td>
                    <td className="px-3 py-2 hidden md:table-cell text-muted-foreground">{a.payment_method}</td>
                    <td className="px-3 py-2 hidden lg:table-cell text-muted-foreground">{a.competence_month}</td>
                    <td className="px-3 py-2 hidden md:table-cell text-muted-foreground max-w-[200px] truncate">
                      {a.reason?.replace(/ — Parcela \d+\/\d+/, '') || `Parcelamento ${parcels.length}x`}
                    </td>
                    <td className="px-3 py-2 text-center hidden lg:table-cell">
                      {a.origin === 'folha_negativa' ? (
                        <span className="text-xs px-2 py-0.5 rounded-full bg-amber-100 text-amber-800" title="Origem: Folha de Pagamento">Folha</span>
                      ) : (
                        <span className="text-xs px-2 py-0.5 rounded-full bg-slate-100 text-slate-600">Manual</span>
                      )}
                    </td>
                    <td className="px-3 py-2 text-center hidden lg:table-cell">
                      <span className="text-xs px-2 py-0.5 rounded-full bg-indigo-100 text-indigo-800">{parcels.length}x</span>
                    </td>
                    <td className="px-3 py-2 text-center">
                      <span className={`text-xs px-2 py-0.5 rounded-full ${st.cls}`}>
                        {st.label}{groupStatus === 'partial' ? ` (${pendingCount}p/${deductedCount}d/${cancelledCount}c)` : ''}
                      </span>
                    </td>
                    <td className="px-3 py-2" onClick={(e) => e.stopPropagation()}>
                      <div className="flex items-center justify-center gap-1">
                        <Button variant="ghost" size="icon" onClick={() => previewAdvancePdf({ advance: a, employee: emp, settings, user })} title="Visualizar PDF"><Eye className="w-4 h-4" /></Button>
                        <Button variant="ghost" size="icon" onClick={() => printAdvancePdf({ advance: a, employee: emp, settings, user })} title="Imprimir PDF"><Printer className="w-4 h-4" /></Button>
                        <Button variant="ghost" size="icon" onClick={() => shareAdvancePdf({ advance: a, employee: emp, settings, user })} title="Compartilhar PDF"><Share2 className="w-4 h-4" /></Button>
                        {can('Registrar adiantamentos') && pendingCount > 0 && (
                          <Button variant="ghost" size="icon" onClick={pushGroupNextMonth} title="Jogar pendentes para próximo mês"><CalendarClock className="w-4 h-4 text-blue-600" /></Button>
                        )}
                        {can('Registrar adiantamentos') && pendingCount > 0 && (
                          <Button variant="ghost" size="icon" onClick={() => cancelInstallmentGroup(a)} title="Cancelar parcelas pendentes"><Ban className="w-4 h-4 text-red-600" /></Button>
                        )}
                        {can('Registrar adiantamentos') && cancelledCount > 0 && (
                          <Button variant="ghost" size="icon" onClick={() => reactivateInstallmentGroup(a)} title="Reativar parcelas canceladas"><RotateCcw className="w-4 h-4 text-green-600" /></Button>
                        )}
                      </div>
                    </td>
                  </tr>
                  {expanded && parcels.map((p) => {
                    const pst = STATUS[p.status] || STATUS.pending;
                    return (
                      <tr key={p.id} className="border-t border-border bg-indigo-50/20">
                        <td className="px-3 py-1.5 pl-8 text-sm text-muted-foreground">↳ Parcela {p.installment_number}/{p.installment_total}</td>
                        <td className="px-3 py-1.5 text-sm text-muted-foreground">{formatDate(p.date)}</td>
                        <td className="px-3 py-1.5 text-right text-sm font-medium">{formatBRL(p.amount)}</td>
                        <td className="px-3 py-1.5 hidden md:table-cell text-sm text-muted-foreground">{p.payment_method}</td>
                        <td className="px-3 py-1.5 hidden lg:table-cell text-sm text-muted-foreground">{p.competence_month}</td>
                        <td className="px-3 py-1.5 hidden md:table-cell text-sm text-muted-foreground max-w-[200px] truncate">{p.reason}</td>
                        <td className="px-3 py-1.5 text-center hidden lg:table-cell text-sm">—</td>
                        <td className="px-3 py-1.5 text-center hidden lg:table-cell text-sm">
                          <span className="text-xs px-2 py-0.5 rounded-full bg-indigo-100 text-indigo-800">{p.installment_number}/{p.installment_total}</span>
                        </td>
                        <td className="px-3 py-1.5 text-center"><span className={`text-xs px-2 py-0.5 rounded-full ${pst.cls}`}>{pst.label}</span></td>
                        <td className="px-3 py-1.5">
                          <div className="flex items-center justify-center gap-1">
                            {can('Registrar adiantamentos') && p.status === 'pending' && (
                              <Button variant="ghost" size="icon" onClick={() => openEdit(p)} title="Editar parcela"><Pencil className="w-4 h-4" /></Button>
                            )}
                            {can('Registrar adiantamentos') && p.status === 'pending' && (
                              <Button variant="ghost" size="icon" onClick={() => pushNextMonth(p)} title="Jogar para próximo mês"><CalendarClock className="w-4 h-4 text-blue-600" /></Button>
                            )}
                            {can('Registrar adiantamentos') && p.status === 'pending' && (
                              <Button variant="ghost" size="icon" onClick={() => cancel(p)} title="Cancelar parcela"><Ban className="w-4 h-4 text-red-600" /></Button>
                            )}
                            {can('Registrar adiantamentos') && p.status === 'cancelled' && (
                              <Button variant="ghost" size="icon" onClick={() => reactivate(p)} title="Reativar parcela"><RotateCcw className="w-4 h-4 text-green-600" /></Button>
                            )}
                            {can('Registrar adiantamentos') && (
                              <Button variant="ghost" size="icon" onClick={() => excludeAdvance(p)} title="Excluir parcela"><Trash2 className="w-4 h-4 text-red-700" /></Button>
                            )}
                          </div>
                        </td>
                      </tr>
                    );
                  })}
                </React.Fragment>
              );
            })}
          </tbody>
        </table>
      </div>

      <Dialog open={open} onOpenChange={(op) => !op && setOpen(false)}>
        <DialogContent className="max-w-lg">
          <DialogHeader><DialogTitle>{editing?.id ? 'Editar adiantamento' : 'Novo adiantamento'}</DialogTitle></DialogHeader>
          <div className="space-y-3">
            <div>
              <Label>Funcionário *</Label>
              <EmployeePicker employees={employees} value={form.employee_id} onChange={(v) => set('employee_id', v)} />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div><Label>Data *</Label><Input type="date" value={form.date} onChange={(e) => set('date', e.target.value)} /></div>
              <div><Label>Valor *{form.mode === 'parcelado' && ' (total)'}</Label><Input type="number" step="0.01" value={form.amount} onChange={(e) => set('amount', e.target.value)} /></div>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <Label>Forma de pagamento</Label>
                <Select value={form.payment_method} onValueChange={(v) => set('payment_method', v)}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>{METHODS.map((m) => <SelectItem key={m} value={m}>{m}</SelectItem>)}</SelectContent>
                </Select>
              </div>
              <div><Label>Competência</Label><Input type="month" value={form.competence_month} onChange={(e) => set('competence_month', e.target.value)} /></div>
            </div>
            <div><Label>Motivo/observação</Label><Textarea rows={2} value={form.reason} onChange={(e) => set('reason', e.target.value)} /></div>
            {!editing?.id && (
              <div className="rounded-lg border border-border p-3 space-y-3">
                <div className="flex items-center gap-4">
                  <label className="flex items-center gap-2 text-sm cursor-pointer">
                    <input type="radio" checked={form.mode === 'avista'} onChange={() => set('mode', 'avista')} />
                    À vista
                  </label>
                  <label className="flex items-center gap-2 text-sm cursor-pointer">
                    <input type="radio" checked={form.mode === 'parcelado'} onChange={() => set('mode', 'parcelado')} />
                    Parcelado
                  </label>
                </div>
                {form.mode === 'parcelado' && (
                  <div className="grid grid-cols-3 gap-3">
                    <div>
                      <Label>Nº de parcelas</Label>
                      <Input type="number" min="2" value={form.installments} onChange={(e) => set('installments', e.target.value)} />
                    </div>
                    <div>
                      <Label>1ª competência</Label>
                      <Input type="month" value={form.competence_month} onChange={(e) => set('competence_month', e.target.value)} />
                    </div>
                    <div>
                      <Label>Intervalo (meses)</Label>
                      <Input type="number" min="1" value={form.interval_months} onChange={(e) => set('interval_months', e.target.value)} />
                    </div>
                    {form.amount && Number(form.installments) > 1 && (
                      <div className="col-span-3 text-xs text-muted-foreground bg-muted/40 rounded p-2">
                        {Number(form.installments)} parcelas de <strong>{formatBRL(Number(form.amount) / Number(form.installments))}</strong> — competências de {form.competence_month} a {addMonthsToCompetence(form.competence_month, (Number(form.installments) - 1) * Number(form.interval_months || 1))}
                      </div>
                    )}
                  </div>
                )}
              </div>
            )}
          </div>
          <DialogFooter className="flex-col sm:flex-row gap-2">
            <Button variant="outline" onClick={() => setOpen(false)} disabled={saving}>Cancelar</Button>
            <div className="flex gap-2 sm:ml-auto">
              <Button variant="secondary" onClick={() => submit('preview')} disabled={saving}>{saving ? 'Salvando...' : 'Salvar e Visualizar'}</Button>
              <Button variant="secondary" onClick={() => submit('print')} disabled={saving}>{saving ? 'Salvando...' : 'Salvar e Imprimir'}</Button>
              <Button onClick={() => submit('save')} disabled={saving}>{saving ? 'Salvando...' : 'Salvar'}</Button>
            </div>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}