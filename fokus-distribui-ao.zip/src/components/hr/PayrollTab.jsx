import React, { useState, useMemo, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import {
  Select, SelectTrigger, SelectValue, SelectContent, SelectItem,
} from '@/components/ui/select';
import { Lock, RefreshCw, FileText, Eye, History, Users, Loader2, Share2 } from 'lucide-react';
import { useAuth } from '@/lib/AuthContext';
import { useToast } from '@/components/ui/use-toast';
import { base44 } from '@/api/base44Client';
import { logActivity } from '@/lib/activityLog';
import { buildPayrollSummary, competenceKey, currentCompetence, resolveInssConfig, formatHoursMin, addMonthsToCompetence } from '@/lib/payrollCalc';
import { syncPayrollExpense } from '@/lib/payrollExpenseSync';
import { createPayrollSnapshot } from '@/lib/payrollSnapshot';
import { generateGeneralPayrollPdf, shareGeneralPayrollPdf, competenceLabel } from '@/lib/payrollPdf';
import { formatBRL } from '@/lib/format';
import EmployeePicker from './EmployeePicker';
import PayrollPreviewDialog from './PayrollPreviewDialog';
import PayrollHistoryDialog from './PayrollHistoryDialog';
import NegativePayrollDialog from './NegativePayrollDialog';

const INSS_MODE_LABELS = {
  progressive: 'Faixas progressivas (tabela INSS)',
  percent: 'Porcentagem (%)',
  fixed: 'Valor fixo (R$)',
  manual: 'Manual (informado na folha)',
};

const MONTHS = [
  { v: 1, label: 'Janeiro' }, { v: 2, label: 'Fevereiro' }, { v: 3, label: 'Março' },
  { v: 4, label: 'Abril' }, { v: 5, label: 'Maio' }, { v: 6, label: 'Junho' },
  { v: 7, label: 'Julho' }, { v: 8, label: 'Agosto' }, { v: 9, label: 'Setembro' },
  { v: 10, label: 'Outubro' }, { v: 11, label: 'Novembro' }, { v: 12, label: 'Dezembro' },
];

function Row({ label, value, strong = false, muted = false }) {
  return (
    <div className="flex justify-between py-1.5 border-b border-border last:border-0">
      <span className={`text-sm ${muted ? 'text-muted-foreground' : ''}`}>{label}</span>
      <span className={`text-sm tabular-nums ${strong ? 'font-bold' : 'font-medium'}`}>{value}</span>
    </div>
  );
}

export default function PayrollTab({ employees, advances, purchases, overtimes, bonifications, payrolls, can, onReload }) {
  const { user } = useAuth();
  const { toast } = useToast();
  const now = new Date();
  const [employeeId, setEmployeeId] = useState('');
  const [year, setYear] = useState(now.getFullYear());
  const [month, setMonth] = useState(now.getMonth() + 1);
  const [additions, setAdditions] = useState(0);
  const [otherDiscounts, setOtherDiscounts] = useState(0);
  const [notes, setNotes] = useState('');
  const [closing, setClosing] = useState(false);
  const [settings, setSettings] = useState(null);
  const [previewOpen, setPreviewOpen] = useState(false);
  const [historyOpen, setHistoryOpen] = useState(false);
  const [generalBusy, setGeneralBusy] = useState(false);
  const [negativeDialogOpen, setNegativeDialogOpen] = useState(false);
  const [negativeBusy, setNegativeBusy] = useState(false);

  useEffect(() => {
    base44.entities.Settings.list('-updated_date', 1).then((r) => setSettings(r[0] || null)).catch(() => {});
  }, []);

  const competence = competenceKey(year, month);

  const employee = useMemo(() => employees.find((e) => e.id === employeeId), [employees, employeeId]);

  const entries = useMemo(() => {
    if (!employeeId) return { advances: [], purchases: [], overtimes: [], bonifications: [] };
    const matchEmp = (r) => r.employee_id === employeeId;
    return {
      advances: (advances || []).filter((a) => matchEmp(a) && a.competence_month === competence),
      purchases: (purchases || []).filter((p) => matchEmp(p) && p.competence_month === competence),
      overtimes: (overtimes || []).filter((o) => matchEmp(o) && o.competence_month === competence),
      bonifications: (bonifications || []).filter((b) => matchEmp(b) && b.competence_month === competence),
    };
  }, [employeeId, advances, purchases, overtimes, bonifications, competence]);

  const inssConfig = useMemo(() => resolveInssConfig(employee, settings), [employee, settings]);

  const summary = useMemo(() => {
    if (!employee) return null;
    return buildPayrollSummary(employee, entries, {
      additions: Number(additions) || 0,
      otherDiscounts: Number(otherDiscounts) || 0,
      inssConfig,
    });
  }, [employee, entries, additions, otherDiscounts, inssConfig]);

  const existing = useMemo(() => (payrolls || []).find((p) => p.employee_id === employeeId && p.competence_month === competence), [payrolls, employeeId, competence]);

  const closePayroll = async (negativeAdvanceData = null) => {
    if (!employee) return toast({ title: 'Selecione o funcionário', variant: 'destructive' });
    if (!can('Fechar folha')) return toast({ title: 'Sem permissão', variant: 'destructive' });

    // Se o salário líquido for negativo e ainda não houver dados de transferência, abre o diálogo.
    if (summary.netSalary < 0 && !negativeAdvanceData) {
      setNegativeDialogOpen(true);
      return;
    }

    setClosing(true);
    try {
      let negativeAdvanceIds = [];
      let negativeBalance = 0;
      let negativeTransferred = false;

      // Cria adiantamento(s) de saldo negativo para a próxima competência.
      if (negativeAdvanceData && summary.netSalary < 0) {
        negativeBalance = Math.abs(summary.netSalary);
        negativeTransferred = true;
        const nextCompetence = addMonthsToCompetence(competence, 1);
        const todayStr = new Date().toISOString().slice(0, 10);
        const numInst = Math.max(1, Math.floor(Number(negativeAdvanceData.installments) || 1));

        if (numInst > 1) {
          const interval = Math.max(1, Math.floor(Number(negativeAdvanceData.intervalMonths) || 1));
          const groupId = `neg_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`;
          const parcelValue = Math.round((negativeBalance / numInst) * 100) / 100;
          const records = [];
          for (let i = 0; i < numInst; i++) {
            const comp = addMonthsToCompetence(nextCompetence, i * interval);
            const isLast = i === numInst - 1;
            records.push({
              employee_id: employee.id,
              employee_name: employee.name,
              date: todayStr,
              amount: isLast ? Math.round((negativeBalance - parcelValue * (numInst - 1)) * 100) / 100 : parcelValue,
              payment_method: 'Desconto em folha',
              reason: `Saldo negativo da folha anterior (${competence}) — Parcela ${i + 1}/${numInst}`,
              competence_month: comp,
              status: 'pending',
              registered_by: user?.email || '',
              origin: 'folha_negativa',
              installment_number: i + 1,
              installment_total: numInst,
              installment_group_id: groupId,
            });
          }
          const created = await base44.entities.EmployeeAdvance.bulkCreate(records);
          negativeAdvanceIds = created.map((c) => c.id);
        } else {
          const created = await base44.entities.EmployeeAdvance.create({
            employee_id: employee.id,
            employee_name: employee.name,
            date: todayStr,
            amount: negativeBalance,
            payment_method: 'Desconto em folha',
            reason: `Saldo negativo da folha anterior (${competence})`,
            competence_month: nextCompetence,
            status: 'pending',
            registered_by: user?.email || '',
            origin: 'folha_negativa',
          });
          negativeAdvanceIds = [created.id];
        }
      }

      const payload = {
        employee_id: employee.id,
        employee_name: employee.name,
        competence_month: competence,
        year, month,
        base_salary: summary.baseSalary,
        overtime_total: summary.overtimeTotal,
        bonus: summary.bonus,
        additions: summary.additions,
        gross_salary: summary.grossSalary,
        inss_base: summary.inssBase,
        inss: summary.inss,
        inss_mode: summary.inssMode,
        inss_percent: summary.inssPercent || 0,
        inss_fixed_value: summary.inssFixedValue || 0,
        inss_manual: summary.inssManual,
        inss_manual_by: summary.inssManual ? (user?.email || '') : '',
        inss_manual_at: summary.inssManual ? new Date().toISOString() : '',
        advances_total: summary.advancesTotal,
        purchases_total: summary.purchasesTotal,
        other_discounts: summary.otherDiscounts,
        total_discounts: summary.totalDiscounts,
        net_salary: summary.netSalary,
        negative_balance: negativeBalance,
        negative_balance_transferred: negativeTransferred,
        negative_advance_id: negativeAdvanceIds[0] || '',
        status: 'closed',
        closed_at: new Date().toISOString(),
        closed_by: user?.email || '',
        notes,
        advance_ids: summary.advanceIds,
        purchase_ids: summary.purchaseIds,
        overtime_ids: summary.overtimeIds,
        bonus_ids: summary.bonusIds,
      };
      let saved;
      if (existing?.id) {
        saved = await base44.entities.Payroll.update(existing.id, payload);
      } else {
        saved = await base44.entities.Payroll.create(payload);
      }
      // Vincula a folha de origem nos adiantamentos de saldo negativo criados.
      if (negativeAdvanceIds.length) {
        await base44.entities.EmployeeAdvance.updateMany(
          { id: { $in: negativeAdvanceIds } },
          { $set: { origin_payroll_id: saved.id } }
        );
      }
      // Marca adiantamentos e compras como descontados
      await base44.entities.EmployeeAdvance.updateMany(
        { id: { $in: summary.advanceIds } },
        { $set: { status: 'deducted' } }
      );
      await base44.entities.EmployeePurchase.updateMany(
        { id: { $in: summary.purchaseIds } },
        { $set: { status: 'paid', payroll_id: saved.id } }
      );
      // Marca bonificações como incluídas na folha
      if (summary.bonusIds?.length) {
        await base44.entities.Bonification.updateMany(
          { id: { $in: summary.bonusIds } },
          { $set: { status: 'included', payroll_id: saved.id } }
        );
      }
      // Gera/atualiza a despesa de salário automaticamente
      await syncPayrollExpense(saved, user);
      // Preserva snapshot da folha fechada para auditoria/histórico
      await createPayrollSnapshot({ payroll: saved, action: 'closed', user });
      const logDesc = negativeTransferred
        ? `Fechou folha de ${employee.name} (${competence}) — saldo negativo de ${formatBRL(negativeBalance)} transferido para adiantamento`
        : `Fechou folha de ${employee.name} (${competence}) — despesa de salário gerada`;
      await logActivity({ action: 'payroll_close', description: logDesc, user, entityType: 'Payroll', entityId: saved.id });
      toast({
        title: negativeTransferred ? 'Folha fechada com transferência' : 'Folha fechada',
        description: negativeTransferred
          ? `Saldo devedor de ${formatBRL(negativeBalance)} lançado como adiantamento para a próxima folha.`
          : `Líquido: ${formatBRL(summary.netSalary)} — despesa de salário gerada em Despesas.`,
      });
      onReload?.();
      // Avança automaticamente para o mês seguinte após o fechamento
      const nextM = month === 12 ? 1 : month + 1;
      const nextY = month === 12 ? year + 1 : year;
      setMonth(nextM);
      setYear(nextY);
      setAdditions(0);
      setOtherDiscounts(0);
      setNotes('');
    } catch (e) {
      toast({ title: 'Erro', description: e.message, variant: 'destructive' });
    } finally {
      setClosing(false);
      setNegativeBusy(false);
    }
  };

  const handleNegativeConfirm = async (negativeAdvanceData) => {
    setNegativeBusy(true);
    await closePayroll(negativeAdvanceData);
    setNegativeDialogOpen(false);
  };

  const markPaid = async () => {
    if (!existing) return;
    if (!confirm('Marcar folha como paga? Será gerado lançamento financeiro.')) return;
    setClosing(true);
    try {
      const updated = await base44.entities.Payroll.update(existing.id, { status: 'paid' });
      const merged = { ...existing, ...updated, status: 'paid' };
      // Atualiza a despesa de salário para 'paga' e gera o lançamento financeiro (sem duplicar)
      await syncPayrollExpense(merged, user);
      await createPayrollSnapshot({ payroll: merged, action: 'paid', user });
      await logActivity({ action: 'payroll_paid', description: `Folha paga: ${existing.employee_name} (${competence}) — despesa e financeiro atualizados`, user, entityType: 'Payroll', entityId: existing.id });
      toast({ title: 'Folha marcada como paga', description: 'Despesa e lançamento financeiro atualizados.' });
      onReload?.();
    } catch (e) {
      toast({ title: 'Erro', description: e.message, variant: 'destructive' });
    } finally {
      setClosing(false);
    }
  };

  // Reabrir folha — administrador only. Preserva versão anterior no histórico.
  const reopenPayroll = async (reason) => {
    if (user?.role !== 'admin') {
      toast({ title: 'Apenas administradores podem reabrir a folha', variant: 'destructive' });
      return;
    }
    if (!existing) return;
    setClosing(true);
    try {
      // 1. Snapshot da versão atual (antes de reabrir)
      await createPayrollSnapshot({ payroll: existing, action: 'reopened', user, reason });
      // 2. Reverte lançamentos vinculados para pendente
      if (existing.advance_ids?.length) {
        await base44.entities.EmployeeAdvance.updateMany(
          { id: { $in: existing.advance_ids } },
          { $set: { status: 'pending' } }
        );
      }
      if (existing.purchase_ids?.length) {
        await base44.entities.EmployeePurchase.updateMany(
          { id: { $in: existing.purchase_ids } },
          { $set: { status: 'pending', payroll_id: '' } }
        );
      }
      if (existing.bonus_ids?.length) {
        await base44.entities.Bonification.updateMany(
          { id: { $in: existing.bonus_ids } },
          { $set: { status: 'pending', payroll_id: '' } }
        );
      }
      // 3. Cancela o adiantamento de saldo negativo criado no fechamento (se houver)
      if (existing.negative_advance_id) {
        try {
          const negAdvance = await base44.entities.EmployeeAdvance.get(existing.negative_advance_id);
          if (negAdvance && negAdvance.status === 'pending') {
            if (negAdvance.installment_group_id) {
              await base44.entities.EmployeeAdvance.updateMany(
                { installment_group_id: negAdvance.installment_group_id, status: 'pending' },
                { $set: { status: 'cancelled' } }
              );
            } else {
              await base44.entities.EmployeeAdvance.update(existing.negative_advance_id, { status: 'cancelled' });
            }
          }
        } catch { /* ignore — adiantamento já pode ter sido removido/descontado */ }
      }
      // 4. Reabre a folha
      const reopened = await base44.entities.Payroll.update(existing.id, {
        status: 'open',
        closed_at: '',
        closed_by: '',
        negative_balance: 0,
        negative_balance_transferred: false,
        negative_advance_id: '',
        notes: `${existing.notes || ''}\n[Reaberta por ${user?.email || ''} em ${new Date().toLocaleString('pt-BR')}]: ${reason}`.trim(),
      });
      // 5. Cancela a despesa vinculada (será reativada no novo fechamento)
      try {
        const linked = await base44.entities.Expense.filter({ origin: 'folha', origin_id: existing.id });
        if (linked[0]) await base44.entities.Expense.update(linked[0].id, { status: 'cancelled' });
      } catch { /* ignore */ }
      await logActivity({ action: 'payroll_reopen', description: `Reabriu folha de ${existing.employee_name} (${competence}) — motivo: ${reason}`, user, entityType: 'Payroll', entityId: existing.id });
      toast({ title: 'Folha reaberta', description: 'Versão anterior preservada no histórico. Faça as correções e feche novamente.' });
      onReload?.();
    } catch (e) {
      toast({ title: 'Erro', description: e.message, variant: 'destructive' });
    } finally {
      setClosing(false);
    }
  };

  // Folha geral — gera PDF com todos os funcionários da competência.
  const generateGeneral = async () => {
    setGeneralBusy(true);
    try {
      const activeEmployees = (employees || []).filter((e) => e.status !== 'inactive');
      const payrollsForGeneral = [];
      for (const emp of activeEmployees) {
        const empConfig = resolveInssConfig(emp, settings);
        const empEntries = {
          advances: (advances || []).filter((a) => a.employee_id === emp.id && a.competence_month === competence),
          purchases: (purchases || []).filter((p) => p.employee_id === emp.id && p.competence_month === competence),
          overtimes: (overtimes || []).filter((o) => o.employee_id === emp.id && o.competence_month === competence),
          bonifications: (bonifications || []).filter((b) => b.employee_id === emp.id && b.competence_month === competence),
        };
        const s = buildPayrollSummary(emp, empEntries, { additions: 0, otherDiscounts: 0, inssConfig: empConfig });
        // Usa a folha fechada se existir (valores congelados), senão a prévia calculada
        const closed = (payrolls || []).find((p) => p.employee_id === emp.id && p.competence_month === competence);
        payrollsForGeneral.push(closed || {
          employee_name: emp.name,
          base_salary: s.baseSalary,
          overtime_total: s.overtimeTotal,
          bonus: s.bonus,
          additions: s.additions,
          gross_salary: s.grossSalary,
          inss: s.inss,
          advances_total: s.advancesTotal,
          purchases_total: s.purchasesTotal,
          other_discounts: s.otherDiscounts,
          total_discounts: s.totalDiscounts,
          net_salary: s.netSalary,
        });
      }
      if (!payrollsForGeneral.length) {
        toast({ title: 'Nenhum funcionário ativo', variant: 'destructive' });
        return;
      }
      await generateGeneralPayrollPdf({ payrolls: payrollsForGeneral, settings, competence, user, action: 'generate' });
      toast({ title: 'Folha geral gerada', description: `${payrollsForGeneral.length} funcionários — competência ${competenceLabel(competence)}` });
    } catch (e) {
      toast({ title: 'Erro', description: e.message, variant: 'destructive' });
    } finally {
      setGeneralBusy(false);
    }
  };

  const shareGeneral = async () => {
    setGeneralBusy(true);
    try {
      const activeEmployees = (employees || []).filter((e) => e.status !== 'inactive');
      const payrollsForGeneral = [];
      for (const emp of activeEmployees) {
        const empConfig = resolveInssConfig(emp, settings);
        const empEntries = {
          advances: (advances || []).filter((a) => a.employee_id === emp.id && a.competence_month === competence),
          purchases: (purchases || []).filter((p) => p.employee_id === emp.id && p.competence_month === competence),
          overtimes: (overtimes || []).filter((o) => o.employee_id === emp.id && o.competence_month === competence),
          bonifications: (bonifications || []).filter((b) => b.employee_id === emp.id && b.competence_month === competence),
        };
        const s = buildPayrollSummary(emp, empEntries, { additions: 0, otherDiscounts: 0, inssConfig: empConfig });
        const closed = (payrolls || []).find((p) => p.employee_id === emp.id && p.competence_month === competence);
        payrollsForGeneral.push(closed || {
          employee_name: emp.name,
          base_salary: s.baseSalary,
          overtime_total: s.overtimeTotal,
          bonus: s.bonus,
          additions: s.additions,
          gross_salary: s.grossSalary,
          inss: s.inss,
          advances_total: s.advancesTotal,
          purchases_total: s.purchasesTotal,
          other_discounts: s.otherDiscounts,
          total_discounts: s.totalDiscounts,
          net_salary: s.netSalary,
        });
      }
      if (!payrollsForGeneral.length) {
        toast({ title: 'Nenhum funcionário ativo', variant: 'destructive' });
        return;
      }
      const { shared } = await shareGeneralPayrollPdf({ payrolls: payrollsForGeneral, settings, competence, user });
      toast({ title: shared ? 'Compartilhando PDF' : 'PDF baixado', description: shared ? 'Escolha o aplicativo para enviar.' : 'Compartilhamento não suportado — PDF baixado.' });
    } catch (e) {
      if (e?.name !== 'AbortError') toast({ title: 'Erro', description: e.message, variant: 'destructive' });
    } finally {
      setGeneralBusy(false);
    }
  };

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-1 md:grid-cols-4 gap-3 bg-muted/30 p-3 rounded-lg">
        <div className="md:col-span-2">
          <Label>Funcionário</Label>
          <EmployeePicker employees={employees} value={employeeId} onChange={setEmployeeId} includeInactive />
        </div>
        <div>
          <Label>Mês</Label>
          <Select value={String(month)} onValueChange={(v) => setMonth(Number(v))}>
            <SelectTrigger><SelectValue /></SelectTrigger>
            <SelectContent>{MONTHS.map((m) => <SelectItem key={m.v} value={String(m.v)}>{m.label}</SelectItem>)}</SelectContent>
          </Select>
        </div>
        <div>
          <Label>Ano</Label>
          <Input type="number" value={year} onChange={(e) => setYear(Number(e.target.value))} />
        </div>
      </div>

      {existing && (
        <div className="flex items-center gap-2">
          <Badge variant={existing.status === 'paid' ? 'default' : 'secondary'}>
            {existing.status === 'closed' ? 'Fechada' : existing.status === 'paid' ? 'Paga' : 'Aberta'}
          </Badge>
          <span className="text-xs text-muted-foreground">Fechada em {new Date(existing.closed_at || existing.created_date).toLocaleString('pt-BR')}</span>
        </div>
      )}

      {!employee && <p className="text-center py-10 text-muted-foreground">Selecione um funcionário para visualizar a folha.</p>}

      {employee && summary && (
        <>
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
            <div className="rounded-lg border border-border p-4">
              <p className="text-sm font-semibold mb-2 text-green-700">Proventos</p>
              <Row label="Salário base" value={formatBRL(summary.baseSalary)} />
              <Row label="Horas extras" value={formatBRL(summary.overtimeTotal)} muted />
              {summary.overtimeTotal > 0 && (
                <p className="text-xs text-muted-foreground pl-3">
                  {formatHoursMin(summary.overtimeHours || 0)} · {summary.overtimePercent || 50}% · {formatBRL(summary.hourlyRate)}/h
                </p>
              )}
              {summary.fixedBonusValue > 0 && (
                <Row label="Bonificação fixa (cadastro)" value={formatBRL(summary.fixedBonusValue)} muted />
              )}
              {summary.variableBonusTotal > 0 && (
                <Row label="Bonificação variável (lançamento)" value={formatBRL(summary.variableBonusTotal)} muted />
              )}
              {summary.fixedBonusValue === 0 && summary.variableBonusTotal === 0 && (
                <Row label="Bonificação" value={formatBRL(0)} muted />
              )}
              <div className="mt-2">
                <Label className="text-xs">Outros acréscimos</Label>
                <Input type="number" step="0.01" value={additions} onChange={(e) => setAdditions(e.target.value)} disabled={existing?.status === 'closed'} />
              </div>
              <Row label="Salário bruto" value={formatBRL(summary.grossSalary)} strong />
              <div className="mt-2 rounded bg-amber-50 border border-amber-200 px-2 py-1.5 text-xs text-amber-800">
                <p><strong>Base de cálculo INSS:</strong> {formatBRL(summary.inssBase)}</p>
                <p><strong>Tipo de cálculo:</strong> {INSS_MODE_LABELS[summary.inssMode] || summary.inssMode}{summary.inssSource === 'employee' ? ' (específico do funcionário)' : ' (padrão do sistema)'}</p>
                <p className="text-amber-700/80">{summary.bonus > 0 ? (summary.bonusIncideINSS ? 'Bonificação incide sobre INSS.' : 'Bonificação NÃO incide sobre INSS (separada da base).') : 'Sem bonificação no período.'}</p>
              </div>
            </div>

            <div className="rounded-lg border border-border p-4">
              <p className="text-sm font-semibold mb-2 text-red-700">Descontos</p>
              <Row label="INSS" value={formatBRL(summary.inss)} muted />
              {summary.negativeBalanceTotal > 0 && (
                <Row label="Saldo negativo folha anterior" value={formatBRL(summary.negativeBalanceTotal)} muted />
              )}
              <Row label="Adiantamentos" value={formatBRL(summary.regularAdvancesTotal)} muted />
              <Row label="Compras" value={formatBRL(summary.purchasesTotal)} muted />
              <div className="mt-2">
                <Label className="text-xs">Outros descontos</Label>
                <Input type="number" step="0.01" value={otherDiscounts} onChange={(e) => setOtherDiscounts(e.target.value)} disabled={existing?.status === 'closed'} />
              </div>
              <Row label="Total de descontos" value={formatBRL(summary.totalDiscounts)} strong />
            </div>
          </div>

          <div className="rounded-lg border-2 border-blue-200 bg-blue-50 p-4 flex flex-col md:flex-row md:items-center justify-between gap-3">
            <div>
              <p className="text-sm text-muted-foreground">Salário líquido</p>
              <p className="text-2xl font-bold text-blue-900">{formatBRL(summary.netSalary)}</p>
            </div>
            <div className="flex flex-wrap gap-2">
              <Button onClick={() => setPreviewOpen(true)} disabled={closing}>
                <Eye className="w-4 h-4" /> {existing ? 'Visualizar Folha Fechada' : 'Visualizar Folha'}
              </Button>
              {existing && (
                <Button variant="outline" onClick={() => setHistoryOpen(true)} disabled={closing}>
                  <History className="w-4 h-4" /> Visualizar Histórico
                </Button>
              )}
              {can('Fechar folha') && existing?.status === 'closed' && (
                <Button onClick={markPaid} disabled={closing}><RefreshCw className="w-4 h-4" /> Marcar como paga</Button>
              )}
              <Button variant="outline" onClick={generateGeneral} disabled={generalBusy}>
                {generalBusy ? <Loader2 className="w-4 h-4 animate-spin" /> : <Users className="w-4 h-4" />} Folha Geral
              </Button>
              <Button variant="outline" onClick={shareGeneral} disabled={generalBusy}>
                {generalBusy ? <Loader2 className="w-4 h-4 animate-spin" /> : <Share2 className="w-4 h-4" />} Compartilhar
              </Button>
            </div>
          </div>

          {(entries.advances.length > 0 || entries.purchases.length > 0 || entries.overtimes.length > 0 || entries.bonifications.length > 0 || summary.fixedBonusValue > 0) && (
            <div className="rounded-lg border border-border p-3">
              <p className="text-sm font-semibold mb-2">Lançamentos do mês ({competence})</p>
              <div className="space-y-1 max-h-48 overflow-y-auto text-xs">
                {summary.fixedBonusValue > 0 && (
                  <div className="flex justify-between"><span>Bonificação fixa (cadastro do funcionário){employee?.bonus_inss_incidence ? ' (incide INSS)' : ''}</span><span>{formatBRL(summary.fixedBonusValue)}</span></div>
                )}
                {entries.bonifications.filter((b) => b.status !== 'cancelled' && b.status !== 'included').map((b) => (
                  <div key={b.id} className="flex justify-between"><span>Bonificação — {b.date}{b.inss_incidence ? ' (incide INSS)' : ''}</span><span>{formatBRL(b.amount)}</span></div>
                ))}
                {entries.overtimes.filter((o) => o.status === 'approved' || o.status === 'paid').map((o) => (
                  <div key={o.id} className="flex justify-between">
                    <span>Hora extra — {o.date} ({formatHoursMin(o.hours)} · {o.percent}% · {formatBRL(o.hourly_rate)}/h){o.worked_start && o.worked_end ? ` · ${o.worked_start}–${o.worked_end}` : ''}{o.break_start && o.break_end ? ` · intervalo ${o.break_start}–${o.break_end}` : ''}</span>
                    <span>{formatBRL(o.amount)}</span>
                  </div>
                ))}
                {entries.advances.filter((a) => a.status !== 'cancelled' && a.status !== 'deducted' && a.origin !== 'folha_negativa').map((a) => (
                  <div key={a.id} className="flex justify-between">
                    <span>Adiantamento — {a.date}{a.installment_total > 0 ? ` (PARCELA ${a.installment_number}/${a.installment_total})` : ''}</span>
                    <span>-{formatBRL(a.amount)}</span>
                  </div>
                ))}
                {entries.advances.filter((a) => a.status !== 'cancelled' && a.status !== 'deducted' && a.origin === 'folha_negativa').map((a) => (
                  <div key={a.id} className="flex justify-between text-red-700 font-medium">
                    <span>DESCONTO — Saldo negativo da folha anterior{a.installment_total > 0 ? ` (PARCELA ${a.installment_number}/${a.installment_total})` : ''}</span>
                    <span>-{formatBRL(a.amount)}</span>
                  </div>
                ))}
                {entries.purchases.filter((p) => p.status !== 'cancelled' && p.status !== 'deducted' && p.status !== 'paid').map((p) => (
                  <div key={p.id} className="flex justify-between"><span>Compra — {p.product_name}</span><span>-{formatBRL(p.total)}</span></div>
                ))}
              </div>
            </div>
          )}

          <div>
            <Label>Observações da folha</Label>
            <Textarea rows={2} value={notes} onChange={(e) => setNotes(e.target.value)} disabled={existing?.status === 'closed'} placeholder="Observações do fechamento..." />
          </div>
        </>
      )}

      <PayrollPreviewDialog
        open={previewOpen}
        onClose={() => setPreviewOpen(false)}
        employee={employee}
        summary={summary}
        competence={competence}
        existing={existing}
        settings={settings}
        user={user}
        can={can}
        onClosePayroll={async () => { await closePayroll(); setPreviewOpen(false); }}
        onReopenPayroll={async (reason) => { await reopenPayroll(reason); setPreviewOpen(false); }}
      />

      <PayrollHistoryDialog
        open={historyOpen}
        onClose={() => setHistoryOpen(false)}
        payroll={existing}
      />

      <NegativePayrollDialog
        open={negativeDialogOpen}
        onClose={() => setNegativeDialogOpen(false)}
        employee={employee}
        summary={summary}
        competence={competence}
        onConfirm={handleNegativeConfirm}
        busy={negativeBusy}
      />
    </div>
  );
}