import React, { useState, useEffect, useMemo } from 'react';
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import {
  Select, SelectTrigger, SelectValue, SelectContent, SelectItem,
} from '@/components/ui/select';
import { Switch } from '@/components/ui/switch';
import { Gift, Shield, Plane } from 'lucide-react';
import { useAuth } from '@/lib/AuthContext';
import { useToast } from '@/components/ui/use-toast';
import { base44 } from '@/api/base44Client';
import { logActivity } from '@/lib/activityLog';
import { calcBreakMinutes } from '@/lib/payrollCalc';

const EMPLOYEE_TYPES = [
  { key: 'clt', label: 'CLT' },
  { key: 'pj', label: 'PJ' },
  { key: 'diarista', label: 'Diarista' },
  { key: 'autonomo', label: 'Autônomo' },
  { key: 'estagiario', label: 'Estagiário' },
];

const empty = {
  name: '', cpf: '', phone: '', role: '', employee_type: 'clt',
  admission_date: '', base_salary: 0, status: 'active',
  work_schedule: '', check_in_time: '', check_out_time: '',
  break_start: '', break_end: '', break_minutes: 60, weekly_hours: 44, overtime_percent: 50,
  user_id: '', user_email: '', notes: '', pix_key: '', bank: '', bank_account: '',
  dependents: 0,
  bonus_enabled: false, bonus_value: 0, bonus_type: 'fixa', bonus_periodicity: 'mensal',
  bonus_inss_incidence: false, bonus_notes: '',
  inss_override: 'padrao', inss_percent: 0, inss_fixed_value: 0,
  vacation_start: '', vacation_end: '',
};

const BONUS_PERIODICITIES = [
  { key: 'mensal', label: 'Mensal' },
  { key: 'trimestral', label: 'Trimestral' },
  { key: 'semestral', label: 'Semestral' },
  { key: 'anual', label: 'Anual' },
  { key: 'eventual', label: 'Eventual' },
];

export default function EmployeeFormDialog({ open, employee, onClose, onSaved }) {
  const { user } = useAuth();
  const { toast } = useToast();
  const [form, setForm] = useState(empty);
  const [saving, setSaving] = useState(false);
  const [users, setUsers] = useState([]);

  useEffect(() => {
    if (open) {
      setForm(employee ? { ...empty, ...employee } : empty);
      base44.entities.User.list().then(setUsers).catch(() => {});
    }
  }, [open, employee]);

  const set = (k, v) => setForm((f) => ({ ...f, [k]: v }));

  // Calcula automaticamente a duração do intervalo (break_minutes) quando início/fim são informados.
  useEffect(() => {
    if (form.break_start && form.break_end) {
      const min = calcBreakMinutes(form.break_start, form.break_end);
      if (min > 0) setForm((f) => ({ ...f, break_minutes: min }));
    }
  }, [form.break_start, form.break_end]);

  const linkUser = (userId) => {
    const u = users.find((x) => x.id === userId);
    setForm((f) => ({ ...f, user_id: userId, user_email: u?.email || '' }));
  };

  const submit = async () => {
    if (!form.name?.trim()) {
      toast({ title: 'Nome é obrigatório', variant: 'destructive' });
      return;
    }
    setSaving(true);
    try {
      const payload = {
        ...form,
        base_salary: Number(form.base_salary) || 0,
        weekly_hours: Number(form.weekly_hours) || 0,
        break_minutes: Number(form.break_minutes) || 0,
        overtime_percent: Number(form.overtime_percent) || 0,
        dependents: Number(form.dependents) || 0,
        bonus_enabled: !!form.bonus_enabled,
        bonus_value: Number(form.bonus_value) || 0,
        bonus_type: form.bonus_type || 'fixa',
        bonus_periodicity: form.bonus_periodicity || 'mensal',
        bonus_inss_incidence: !!form.bonus_inss_incidence,
        bonus_notes: form.bonus_notes || '',
        inss_override: form.inss_override || 'padrao',
        inss_percent: Number(form.inss_percent) || 0,
        inss_fixed_value: Number(form.inss_fixed_value) || 0,
      };
      let saved;
      if (employee?.id) {
        saved = await base44.entities.Employee.update(employee.id, payload);
        await logActivity({ action: 'employee_update', description: `Editou funcionário ${payload.name}`, user, entityType: 'Employee', entityId: employee.id });
      } else {
        saved = await base44.entities.Employee.create(payload);
        await logActivity({ action: 'employee_create', description: `Cadastrou funcionário ${payload.name}`, user, entityType: 'Employee', entityId: saved.id });
      }
      toast({ title: employee?.id ? 'Funcionário atualizado' : 'Funcionário cadastrado' });
      onSaved?.(saved);
      onClose();
    } catch (e) {
      toast({ title: 'Erro ao salvar', description: e.message, variant: 'destructive' });
    } finally {
      setSaving(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={(op) => !op && onClose()}>
      <DialogContent className="max-w-2xl max-h-[92vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>{employee?.id ? 'Editar funcionário' : 'Novo funcionário'}</DialogTitle>
          <DialogDescription>Preencha os dados do funcionário e a jornada de trabalho.</DialogDescription>
        </DialogHeader>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
          <div className="md:col-span-2">
            <Label>Nome completo *</Label>
            <Input value={form.name} onChange={(e) => set('name', e.target.value)} />
          </div>
          <div>
            <Label>CPF</Label>
            <Input value={form.cpf} onChange={(e) => set('cpf', e.target.value)} />
          </div>
          <div>
            <Label>Telefone</Label>
            <Input value={form.phone} onChange={(e) => set('phone', e.target.value)} />
          </div>
          <div>
            <Label>Cargo/Função</Label>
            <Input value={form.role} onChange={(e) => set('role', e.target.value)} placeholder="Ex: Vendedor, Motorista" />
          </div>
          <div>
            <Label>Tipo de contratação</Label>
            <Select value={form.employee_type} onValueChange={(v) => set('employee_type', v)}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                {EMPLOYEE_TYPES.map((t) => <SelectItem key={t.key} value={t.key}>{t.label}</SelectItem>)}
              </SelectContent>
            </Select>
          </div>
          <div>
            <Label>Data de admissão</Label>
            <Input type="date" value={form.admission_date || ''} onChange={(e) => set('admission_date', e.target.value)} />
          </div>
          <div>
            <Label>Salário base (R$)</Label>
            <Input type="number" step="0.01" value={form.base_salary} onChange={(e) => set('base_salary', e.target.value)} />
          </div>
          <div>
            <Label>Status</Label>
            <Select value={form.status} onValueChange={(v) => set('status', v)}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="active">Ativo</SelectItem>
                <SelectItem value="inactive">Inativo</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div>
            <Label>Dependentes (IR)</Label>
            <Input type="number" value={form.dependents} onChange={(e) => set('dependents', e.target.value)} />
          </div>
        </div>

        <div className="border-t pt-3 mt-2">
          <p className="text-sm font-semibold mb-2 flex items-center gap-2"><Plane className="w-4 h-4 text-violet-600" /> Férias</p>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            <div>
              <Label>Início das férias</Label>
              <Input type="date" value={form.vacation_start || ''} onChange={(e) => set('vacation_start', e.target.value)} />
            </div>
            <div>
              <Label>Fim das férias (vencimento)</Label>
              <Input type="date" value={form.vacation_end || ''} onChange={(e) => set('vacation_end', e.target.value)} />
            </div>
          </div>
        </div>

        <div className="border-t pt-3 mt-2">
          <p className="text-sm font-semibold mb-2">Jornada de trabalho</p>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
            <div className="col-span-2">
              <Label>Descrição da jornada</Label>
              <Input value={form.work_schedule} onChange={(e) => set('work_schedule', e.target.value)} placeholder="Ex: Seg-Sex 44h" />
            </div>
            <div>
              <Label>Horas/semana</Label>
              <Input type="number" value={form.weekly_hours} onChange={(e) => set('weekly_hours', e.target.value)} />
            </div>
            <div>
              <Label>% Hora extra</Label>
              <Input type="number" value={form.overtime_percent} onChange={(e) => set('overtime_percent', e.target.value)} placeholder="50" />
            </div>
            <div>
              <Label>Entrada prevista</Label>
              <Input type="time" value={form.check_in_time || ''} onChange={(e) => set('check_in_time', e.target.value)} />
            </div>
            <div>
              <Label>Saída prevista</Label>
              <Input type="time" value={form.check_out_time || ''} onChange={(e) => set('check_out_time', e.target.value)} />
            </div>
            <div>
              <Label>Início do intervalo</Label>
              <Input type="time" value={form.break_start || ''} onChange={(e) => set('break_start', e.target.value)} />
            </div>
            <div>
              <Label>Fim do intervalo</Label>
              <Input type="time" value={form.break_end || ''} onChange={(e) => set('break_end', e.target.value)} />
            </div>
            <div>
              <Label>Intervalo (min)</Label>
              <Input type="number" value={form.break_minutes} onChange={(e) => set('break_minutes', e.target.value)} disabled={!!(form.break_start && form.break_end)} />
            </div>
          </div>
        </div>

        <div className="border-t pt-3">
          <p className="text-sm font-semibold mb-2 flex items-center gap-2"><Gift className="w-4 h-4 text-amber-600" /> Bonificação</p>
          <div className="flex items-center gap-3 mb-3">
            <Switch checked={!!form.bonus_enabled} onCheckedChange={(v) => set('bonus_enabled', v)} />
            <Label className="text-sm">Recebe bonificação</Label>
          </div>
          {form.bonus_enabled && (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              <div>
                <Label>Valor da bonificação (R$)</Label>
                <Input type="number" step="0.01" value={form.bonus_value} onChange={(e) => set('bonus_value', e.target.value)} />
              </div>
              <div>
                <Label>Tipo</Label>
                <Select value={form.bonus_type} onValueChange={(v) => set('bonus_type', v)}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="fixa">Fixa (mesmo valor todo mês)</SelectItem>
                    <SelectItem value="variavel">Variável (lançada por competência)</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label>Periodicidade</Label>
                <Select value={form.bonus_periodicity} onValueChange={(v) => set('bonus_periodicity', v)}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    {BONUS_PERIODICITIES.map((p) => <SelectItem key={p.key} value={p.key}>{p.label}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
              <div className="flex items-center gap-3 md:pt-6">
                <Switch checked={!!form.bonus_inss_incidence} onCheckedChange={(v) => set('bonus_inss_incidence', v)} />
                <Label className="text-sm">Incide INSS</Label>
              </div>
              <div className="md:col-span-2">
                <Label>Observação da bonificação</Label>
                <Textarea rows={2} value={form.bonus_notes} onChange={(e) => set('bonus_notes', e.target.value)} placeholder="Motivo/condições da bonificação..." />
              </div>
              <div className="md:col-span-2 text-xs text-amber-700 bg-amber-50 border border-amber-200 rounded px-2 py-1.5">
                Por padrão a bonificação <strong>não incide sobre o INSS</strong>. O valor é somado aos proventos mas fica fora da base de cálculo do INSS.
              </div>
            </div>
          )}
        </div>

        <div className="border-t pt-3">
          <p className="text-sm font-semibold mb-2">Dados de pagamento</p>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
            <div>
              <Label>Chave PIX</Label>
              <Input value={form.pix_key} onChange={(e) => set('pix_key', e.target.value)} />
            </div>
            <div>
              <Label>Banco</Label>
              <Input value={form.bank} onChange={(e) => set('bank', e.target.value)} />
            </div>
            <div>
              <Label>Conta</Label>
              <Input value={form.bank_account} onChange={(e) => set('bank_account', e.target.value)} />
            </div>
          </div>
        </div>

        <div className="border-t pt-3">
          <p className="text-sm font-semibold mb-2 flex items-center gap-2"><Shield className="w-4 h-4 text-blue-600" /> Configuração de INSS</p>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
            <div>
              <Label>Tipo de cálculo</Label>
              <Select value={form.inss_override || 'padrao'} onValueChange={(v) => set('inss_override', v)}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="padrao">Padrão do sistema</SelectItem>
                  <SelectItem value="none">Não descontar INSS (isento)</SelectItem>
                  <SelectItem value="percent">Porcentagem personalizada</SelectItem>
                  <SelectItem value="fixed">Valor fixo personalizado</SelectItem>
                  <SelectItem value="manual">Manual (informado na folha)</SelectItem>
                </SelectContent>
              </Select>
            </div>
            {form.inss_override === 'percent' && (
              <div>
                <Label>Percentual (%)</Label>
                <Input type="number" step="0.01" value={form.inss_percent} onChange={(e) => set('inss_percent', e.target.value)} placeholder="Ex: 8" />
              </div>
            )}
            {form.inss_override === 'fixed' && (
              <div>
                <Label>Valor fixo (R$)</Label>
                <Input type="number" step="0.01" value={form.inss_fixed_value} onChange={(e) => set('inss_fixed_value', e.target.value)} placeholder="Ex: 180.00" />
              </div>
            )}
            {form.inss_override === 'none' && (
              <div className="md:col-span-2 text-xs text-emerald-700 bg-emerald-50 border border-emerald-200 rounded px-2 py-1.5">
                Não haverá desconto de INSS na folha deste funcionário. O valor do INSS será zero em todas as competências.
              </div>
            )}
            {form.inss_override === 'manual' && (
              <div className="md:col-span-2 text-xs text-blue-700 bg-blue-50 border border-blue-200 rounded px-2 py-1.5">
                No modo manual, o valor do INSS é informado individualmente na folha, substituindo o cálculo automático somente naquela competência.
              </div>
            )}
          </div>
        </div>

        <div className="border-t pt-3">
          <p className="text-sm font-semibold mb-2">Vínculo com usuário do sistema</p>
          <Select value={form.user_id || ''} onValueChange={linkUser}>
            <SelectTrigger><SelectValue placeholder="Nenhum vínculo" /></SelectTrigger>
            <SelectContent>
              {users.map((u) => (
                <SelectItem key={u.id} value={u.id}>{u.email} {u.full_name ? `— ${u.full_name}` : ''}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        <div>
          <Label>Observações</Label>
          <Textarea rows={2} value={form.notes} onChange={(e) => set('notes', e.target.value)} />
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={onClose} disabled={saving}>Cancelar</Button>
          <Button onClick={submit} disabled={saving}>{saving ? 'Salvando...' : 'Salvar'}</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}