import React, { useState, useMemo } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent } from '@/components/ui/card';
import {
  Select, SelectTrigger, SelectValue, SelectContent, SelectItem,
} from '@/components/ui/select';
import { Switch } from '@/components/ui/switch';
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter,
} from '@/components/ui/dialog';
import { Gift, Plus, Pencil, Ban, Search, RotateCcw, Trash2 } from 'lucide-react';
import { useAuth } from '@/lib/AuthContext';
import { useToast } from '@/components/ui/use-toast';
import { base44 } from '@/api/base44Client';
import { logActivity } from '@/lib/activityLog';
import { formatBRL, formatDate } from '@/lib/format';
import EmployeePicker from './EmployeePicker';

const STATUS_LABELS = { pending: 'Pendente', included: 'Incluída na folha', cancelled: 'Cancelada' };
const STATUS_COLORS = { pending: 'bg-amber-100 text-amber-800', included: 'bg-emerald-100 text-emerald-800', cancelled: 'bg-red-100 text-red-800' };
const TYPE_LABELS = { fixa: 'Fixa', variavel: 'Variável' };

const empty = { employee_id: '', date: new Date().toISOString().slice(0, 10), competence_month: '', amount: 0, type: 'fixa', periodicity: 'mensal', inss_incidence: false, notes: '' };

export default function BonificationsTab({ employees, bonifications, can, onReload }) {
  const { user } = useAuth();
  const { toast } = useToast();
  const [open, setOpen] = useState(false);
  const [editing, setEditing] = useState(null);
  const [form, setForm] = useState(empty);
  const [saving, setSaving] = useState(false);
  const [q, setQ] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');

  const set = (k, v) => setForm((f) => ({ ...f, [k]: v }));

  const openNew = () => { setEditing(null); setForm({ ...empty, competence_month: new Date().toISOString().slice(0, 7) }); setOpen(true); };
  const openEdit = (b) => { setEditing(b); setForm({ employee_id: b.employee_id, date: b.date, competence_month: b.competence_month || '', amount: b.amount, type: b.type || 'fixa', periodicity: b.periodicity || 'mensal', inss_incidence: !!b.inss_incidence, notes: b.notes || '' }); setOpen(true); };

  const filtered = useMemo(() => {
    let list = [...bonifications].sort((a, b) => (b.date || '').localeCompare(a.date || ''));
    if (statusFilter !== 'all') list = list.filter((b) => b.status === statusFilter);
    const query = q.trim().toLowerCase();
    if (query) list = list.filter((b) => (b.employee_name || '').toLowerCase().includes(query));
    return list;
  }, [bonifications, q, statusFilter]);

  const totals = useMemo(() => ({
    pending: bonifications.filter((b) => b.status === 'pending').reduce((s, b) => s + (Number(b.amount) || 0), 0),
    included: bonifications.filter((b) => b.status === 'included').reduce((s, b) => s + (Number(b.amount) || 0), 0),
    count: bonifications.length,
  }), [bonifications]);

  const submit = async () => {
    if (!form.employee_id) return toast({ title: 'Selecione o funcionário', variant: 'destructive' });
    if (!form.date) return toast({ title: 'Informe a data', variant: 'destructive' });
    if (!form.amount || Number(form.amount) <= 0) return toast({ title: 'Valor inválido', variant: 'destructive' });
    if (!can('Lançar bonificações')) return toast({ title: 'Sem permissão', variant: 'destructive' });
    setSaving(true);
    try {
      const emp = employees.find((e) => e.id === form.employee_id);
      const payload = {
        employee_id: form.employee_id,
        employee_name: emp?.name || '',
        date: form.date,
        competence_month: form.competence_month || form.date.slice(0, 7),
        amount: Number(form.amount) || 0,
        type: form.type,
        periodicity: form.periodicity,
        inss_incidence: !!form.inss_incidence,
        notes: form.notes,
        status: 'pending',
        registered_by: user?.email || '',
      };
      let saved;
      if (editing?.id) {
        if (editing.status === 'included') { toast({ title: 'Bonificação já incluída na folha', description: 'Não pode ser editada após o fechamento.', variant: 'destructive' }); return; }
        saved = await base44.entities.Bonification.update(editing.id, payload);
        await logActivity({ action: 'bonification_update', description: `Editou bonificação de ${emp?.name} (${payload.competence_month})`, user, entityType: 'Bonification', entityId: editing.id });
      } else {
        saved = await base44.entities.Bonification.create(payload);
        await logActivity({ action: 'bonification_create', description: `Lançou bonificação para ${emp?.name} (${payload.competence_month}) — ${formatBRL(payload.amount)}`, user, entityType: 'Bonification', entityId: saved.id });
      }
      toast({ title: editing?.id ? 'Bonificação atualizada' : 'Bonificação lançada' });
      onReload?.();
      setOpen(false);
    } catch (e) {
      toast({ title: 'Erro', description: e.message, variant: 'destructive' });
    } finally {
      setSaving(false);
    }
  };

  const cancel = async (b) => {
    if (b.status === 'included') { toast({ title: 'Bonificação já incluída na folha', description: 'Não pode ser cancelada após o fechamento.', variant: 'destructive' }); return; }
    if (!confirm(`Cancelar a bonificação de ${b.employee_name} (${formatBRL(b.amount)})?`)) return;
    try {
      await base44.entities.Bonification.update(b.id, { status: 'cancelled' });
      await logActivity({ action: 'bonification_cancel', description: `Cancelou bonificação de ${b.employee_name} (${b.competence_month})`, user, entityType: 'Bonification', entityId: b.id });
      toast({ title: 'Bonificação cancelada' });
      onReload?.();
    } catch (e) {
      toast({ title: 'Erro', description: e.message, variant: 'destructive' });
    }
  };

  const reactivate = async (b) => {
    if (!confirm(`Reativar a bonificação de ${b.employee_name} (${formatBRL(b.amount)})?`)) return;
    try {
      await base44.entities.Bonification.update(b.id, { status: 'pending', payroll_id: '' });
      await logActivity({ action: 'bonification_reactivate', description: `Reativou bonificação de ${b.employee_name} (${b.competence_month})`, user, entityType: 'Bonification', entityId: b.id });
      toast({ title: 'Bonificação reativada' });
      onReload?.();
    } catch (e) {
      toast({ title: 'Erro', description: e.message, variant: 'destructive' });
    }
  };

  const exclude = async (b) => {
    const isIncluded = b.status === 'included';
    if (isIncluded && user?.role !== 'admin') {
      toast({ title: 'Apenas administradores podem excluir bonificações já incluídas em folha fechada', variant: 'destructive' });
      return;
    }
    if (!confirm('Tem certeza que deseja excluir esta bonificação? Esta ação não pode ser desfeita.')) return;
    try {
      await base44.entities.Bonification.delete(b.id);
      await logActivity({ action: 'bonification_delete', description: `Excluiu bonificação de ${b.employee_name} (${b.competence_month}) — ${formatBRL(b.amount)}`, user, entityType: 'Bonification', entityId: b.id });
      toast({ title: 'Bonificação excluída' });
      onReload?.();
    } catch (e) {
      toast({ title: 'Erro', description: e.message, variant: 'destructive' });
    }
  };

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
        <Card><CardContent className="p-4"><p className="text-xs text-muted-foreground">Total pendente</p><p className="text-xl font-bold text-amber-600">{formatBRL(totals.pending)}</p></CardContent></Card>
        <Card><CardContent className="p-4"><p className="text-xs text-muted-foreground">Total incluído em folhas</p><p className="text-xl font-bold text-emerald-600">{formatBRL(totals.included)}</p></CardContent></Card>
        <Card><CardContent className="p-4"><p className="text-xs text-muted-foreground">Total de lançamentos</p><p className="text-xl font-bold">{totals.count}</p></CardContent></Card>
      </div>

      <div className="flex flex-col md:flex-row gap-2 md:items-center justify-between">
        <div className="flex gap-2 flex-1">
          <div className="relative flex-1 max-w-xs">
            <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
            <Input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Buscar funcionário..." className="pl-9" />
          </div>
          <Select value={statusFilter} onValueChange={setStatusFilter}>
            <SelectTrigger className="w-44"><SelectValue /></SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Todos os status</SelectItem>
              <SelectItem value="pending">Pendentes</SelectItem>
              <SelectItem value="included">Incluídas</SelectItem>
              <SelectItem value="cancelled">Canceladas</SelectItem>
            </SelectContent>
          </Select>
        </div>
        {can('Lançar bonificações') && <Button onClick={openNew}><Plus className="w-4 h-4" /> Nova bonificação</Button>}
      </div>

      <Card>
        <CardContent className="p-0">
          {filtered.length === 0 ? (
            <p className="text-center py-10 text-muted-foreground">Nenhuma bonificação encontrada.</p>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead className="text-muted-foreground border-b bg-muted/30">
                  <tr>
                    <th className="text-left px-3 py-2 font-medium">Funcionário</th>
                    <th className="text-left px-3 py-2 font-medium hidden md:table-cell">Data</th>
                    <th className="text-left px-3 py-2 font-medium">Competência</th>
                    <th className="text-right px-3 py-2 font-medium">Valor</th>
                    <th className="text-center px-3 py-2 font-medium hidden lg:table-cell">Tipo</th>
                    <th className="text-center px-3 py-2 font-medium hidden lg:table-cell">INSS</th>
                    <th className="text-center px-3 py-2 font-medium">Status</th>
                    <th className="text-left px-3 py-2 font-medium hidden xl:table-cell">Observação</th>
                    <th className="text-right px-3 py-2 font-medium">Ações</th>
                  </tr>
                </thead>
                <tbody>
                  {filtered.map((b) => (
                    <tr key={b.id} className="border-b border-border hover:bg-muted/20">
                      <td className="px-3 py-2 font-medium">{b.employee_name}</td>
                      <td className="px-3 py-2 hidden md:table-cell">{formatDate(b.date)}</td>
                      <td className="px-3 py-2">{b.competence_month || '—'}</td>
                      <td className="px-3 py-2 text-right font-semibold">{formatBRL(b.amount)}</td>
                      <td className="px-3 py-2 text-center hidden lg:table-cell"><Badge variant="secondary">{TYPE_LABELS[b.type] || b.type}</Badge></td>
                      <td className="px-3 py-2 text-center hidden lg:table-cell">{b.inss_incidence ? <Badge className="bg-blue-100 text-blue-800">Sim</Badge> : <Badge variant="outline">Não</Badge>}</td>
                      <td className="px-3 py-2 text-center"><Badge className={STATUS_COLORS[b.status]}>{STATUS_LABELS[b.status] || b.status}</Badge></td>
                      <td className="px-3 py-2 hidden xl:table-cell text-xs text-muted-foreground max-w-[200px] truncate">{b.notes || '—'}</td>
                      <td className="px-3 py-2 text-right">
                        <div className="flex justify-end gap-1">
                          {b.status === 'pending' && can('Lançar bonificações') && (
                            <Button variant="ghost" size="icon" onClick={() => openEdit(b)}><Pencil className="w-4 h-4" /></Button>
                          )}
                          {b.status !== 'cancelled' && b.status !== 'included' && can('Lançar bonificações') && (
                            <Button variant="ghost" size="icon" onClick={() => cancel(b)} title="Cancelar"><Ban className="w-4 h-4 text-red-600" /></Button>
                          )}
                          {b.status === 'cancelled' && can('Lançar bonificações') && (
                            <Button variant="ghost" size="icon" onClick={() => reactivate(b)} title="Reativar"><RotateCcw className="w-4 h-4 text-green-600" /></Button>
                          )}
                          {can('Lançar bonificações') && (
                            <Button variant="ghost" size="icon" onClick={() => exclude(b)} title="Excluir"><Trash2 className="w-4 h-4 text-red-700" /></Button>
                          )}
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </CardContent>
      </Card>

      <Dialog open={open} onOpenChange={(op) => !op && setOpen(false)}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2"><Gift className="w-5 h-5 text-amber-600" /> {editing?.id ? 'Editar bonificação' : 'Nova bonificação'}</DialogTitle>
            <DialogDescription>Lançamento individual de bonificação por competência. O valor é somado aos proventos mas não integra a base de INSS por padrão.</DialogDescription>
          </DialogHeader>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            <div className="md:col-span-2">
              <Label>Funcionário *</Label>
              <EmployeePicker employees={employees} value={form.employee_id} onChange={(v) => set('employee_id', v)} includeInactive />
            </div>
            <div>
              <Label>Data *</Label>
              <Input type="date" value={form.date} onChange={(e) => set('date', e.target.value)} />
            </div>
            <div>
              <Label>Competência (mês)</Label>
              <Input type="month" value={form.competence_month} onChange={(e) => set('competence_month', e.target.value)} />
            </div>
            <div>
              <Label>Valor (R$) *</Label>
              <Input type="number" step="0.01" value={form.amount} onChange={(e) => set('amount', e.target.value)} />
            </div>
            <div>
              <Label>Tipo</Label>
              <Select value={form.type} onValueChange={(v) => set('type', v)}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="fixa">Fixa</SelectItem>
                  <SelectItem value="variavel">Variável</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label>Periodicidade</Label>
              <Select value={form.periodicity} onValueChange={(v) => set('periodicity', v)}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="mensal">Mensal</SelectItem>
                  <SelectItem value="trimestral">Trimestral</SelectItem>
                  <SelectItem value="semestral">Semestral</SelectItem>
                  <SelectItem value="anual">Anual</SelectItem>
                  <SelectItem value="eventual">Eventual</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="flex items-center gap-3 md:pt-6">
              <Switch checked={!!form.inss_incidence} onCheckedChange={(v) => set('inss_incidence', v)} />
              <Label className="text-sm">Incide INSS</Label>
            </div>
            <div className="md:col-span-2">
              <Label>Observação</Label>
              <Textarea rows={2} value={form.notes} onChange={(e) => set('notes', e.target.value)} placeholder="Motivo/condições da bonificação..." />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setOpen(false)} disabled={saving}>Cancelar</Button>
            <Button onClick={submit} disabled={saving}>{saving ? 'Salvando...' : 'Salvar'}</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}