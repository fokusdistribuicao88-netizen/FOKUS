import React, { useMemo } from 'react';
import { useQuery } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Pencil } from 'lucide-react';
import { formatBRL, formatDate } from '@/lib/format';
import EmployeePixQRCard from './EmployeePixQRCard';

const TYPE_LABELS = { clt: 'CLT', pj: 'PJ', diarista: 'Diarista', autonomo: 'Autônomo', estagiario: 'Estagiário' };

function Row({ label, value }) {
  return (
    <div className="flex justify-between gap-3 py-1.5 border-b border-border last:border-0">
      <span className="text-muted-foreground text-sm">{label}</span>
      <span className="text-sm font-medium text-right">{value || '—'}</span>
    </div>
  );
}

export default function EmployeeDetailDialog({ open, employee, advances, purchases, overtimes, onEdit, onClose }) {
  const totals = useMemo(() => {
    const a = (advances || []).filter((x) => x.status !== 'cancelled').reduce((s, x) => s + (Number(x.amount) || 0), 0);
    const p = (purchases || []).filter((x) => x.status !== 'cancelled').reduce((s, x) => s + (Number(x.total) || 0), 0);
    const o = (overtimes || []).filter((x) => x.status === 'approved' || x.status === 'paid').reduce((s, x) => s + (Number(x.amount) || 0), 0);
    return { a, p, o };
  }, [advances, purchases, overtimes]);

  const { data: settings } = useQuery({
    queryKey: ['settings'],
    queryFn: async () => { const list = await base44.entities.Settings.list('-updated_date', 1); return list[0] || null; },
    staleTime: 10 * 60 * 1000,
  });

  if (!employee) return null;
  const net = (Number(employee.base_salary) || 0) + totals.o - totals.a - totals.p;

  return (
    <Dialog open={open} onOpenChange={(op) => !op && onClose()}>
      <DialogContent className="max-w-xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>{employee.name}</DialogTitle>
          <DialogDescription>{employee.role || 'Sem cargo'} • {TYPE_LABELS[employee.employee_type] || employee.employee_type}</DialogDescription>
        </DialogHeader>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-x-6">
          <div>
            <p className="text-xs font-semibold uppercase text-muted-foreground mb-1">Dados pessoais</p>
            <Row label="CPF" value={employee.cpf} />
            <Row label="Telefone" value={employee.phone} />
            <Row label="Admissão" value={formatDate(employee.admission_date)} />
            <Row label="Status" value={employee.status === 'active' ? 'Ativo' : 'Inativo'} />
            <Row label="Dependentes" value={employee.dependents} />
          </div>
          <div>
            <p className="text-xs font-semibold uppercase text-muted-foreground mb-1">Jornada</p>
            <Row label="Jornada" value={employee.work_schedule} />
            <Row label="Horas/sem" value={employee.weekly_hours} />
            <Row label="Entrada" value={employee.check_in_time} />
            <Row label="Saída" value={employee.check_out_time} />
            <Row label="Intervalo" value={employee.break_minutes ? `${employee.break_minutes} min` : '—'} />
            <Row label="% H. extra" value={employee.overtime_percent ? `${employee.overtime_percent}%` : '—'} />
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-x-6">
          <div>
            <p className="text-xs font-semibold uppercase text-muted-foreground mb-1">Pagamento</p>
            <Row label="Salário base" value={formatBRL(employee.base_salary)} />
            <Row label="PIX" value={employee.pix_key} />
            <Row label="Banco" value={employee.bank} />
            <Row label="Conta" value={employee.bank_account} />
          </div>
          <div className="md:col-span-2">
            <EmployeePixQRCard employee={employee} settings={settings} amount={net > 0 ? net : 0} />
          </div>
          <div>
            <p className="text-xs font-semibold uppercase text-muted-foreground mb-1">Bonificação</p>
            {employee.bonus_enabled ? (
              <>
                <Row label="Bonificação" value={formatBRL(employee.bonus_value)} />
                <Row label="Tipo" value={employee.bonus_type === 'fixa' ? 'Fixa' : 'Variável'} />
                <Row label="Periodicidade" value={employee.bonus_periodicity} />
                <Row label="Incide INSS" value={employee.bonus_inss_incidence ? 'Sim' : 'Não'} />
              </>
            ) : (
              <Row label="Bonificação" value="Não configurada" />
            )}
          </div>
          <div>
            <p className="text-xs font-semibold uppercase text-muted-foreground mb-1">Configuração de INSS</p>
            <Row label="Configuração" value={
              employee.inss_override === 'percent' ? 'Porcentagem personalizada' :
              employee.inss_override === 'fixed' ? 'Valor fixo personalizado' :
              employee.inss_override === 'manual' ? 'Cálculo manual' : 'Padrão do sistema'
            } />
            {employee.inss_override === 'percent' && <Row label="Percentual" value={`${employee.inss_percent}%`} />}
            {employee.inss_override === 'fixed' && <Row label="Valor fixo" value={formatBRL(employee.inss_fixed_value)} />}
          </div>
          <div>
            <p className="text-xs font-semibold uppercase text-muted-foreground mb-1">Resumo financeiro</p>
            <Row label="Adiantamentos" value={formatBRL(totals.a)} />
            <Row label="Compras p/ desconto" value={formatBRL(totals.p)} />
            <Row label="Horas extras" value={formatBRL(totals.o)} />
            <Row label="Líquido estimado" value={formatBRL(net)} />
          </div>
        </div>

        <div>
          <p className="text-xs font-semibold uppercase text-muted-foreground mb-2">Compras e Descontos</p>
          {(purchases || []).length === 0 ? (
            <p className="text-sm text-muted-foreground">Nenhuma compra registrada.</p>
          ) : (
            <div className="max-h-56 overflow-y-auto rounded-lg border border-border">
              <table className="w-full text-xs">
                <thead className="bg-muted/40 text-muted-foreground sticky top-0">
                  <tr>
                    <th className="text-left px-2 py-1.5 font-medium">Data</th>
                    <th className="text-left px-2 py-1.5 font-medium">Pedido</th>
                    <th className="text-left px-2 py-1.5 font-medium">Produto</th>
                    <th className="text-right px-2 py-1.5 font-medium">Qtd</th>
                    <th className="text-right px-2 py-1.5 font-medium">Valor</th>
                    <th className="text-left px-2 py-1.5 font-medium">Comp.</th>
                    <th className="text-center px-2 py-1.5 font-medium">Status</th>
                  </tr>
                </thead>
                <tbody>
                  {[...purchases].sort((a, b) => (b.date || '').localeCompare(a.date || '')).map((p) => {
                    const st = { pending: { label: 'Pendente', cls: 'bg-yellow-100 text-yellow-800' }, deducted: { label: 'Descontada', cls: 'bg-blue-100 text-blue-800' }, cancelled: { label: 'Cancelada', cls: 'bg-gray-100 text-gray-600' } }[p.status] || { label: p.status, cls: 'bg-gray-100 text-gray-600' };
                    return (
                      <tr key={p.id} className="border-t border-border">
                        <td className="px-2 py-1.5">{formatDate(p.date)}</td>
                        <td className="px-2 py-1.5 font-mono">{p.sale_code || '—'}</td>
                        <td className="px-2 py-1.5 max-w-[160px] truncate" title={p.product_name}>{p.product_name}</td>
                        <td className="px-2 py-1.5 text-right">{p.quantity}</td>
                        <td className="px-2 py-1.5 text-right font-medium">{formatBRL(p.total)}</td>
                        <td className="px-2 py-1.5 text-muted-foreground">{p.competence_month || '—'}</td>
                        <td className="px-2 py-1.5 text-center"><span className={`px-1.5 py-0.5 rounded-full ${st.cls}`}>{st.label}</span></td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          )}
        </div>

        {employee.notes && (
          <div>
            <p className="text-xs font-semibold uppercase text-muted-foreground mb-1">Observações</p>
            <p className="text-sm">{employee.notes}</p>
          </div>
        )}

        <div className="flex justify-end gap-2 pt-2">
          <Button variant="outline" onClick={onClose}>Fechar</Button>
          <Button onClick={() => onEdit(employee)}><Pencil className="w-4 h-4" /> Editar</Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}