import React, { useMemo } from 'react';
import {
  Select, SelectTrigger, SelectValue, SelectContent, SelectItem,
} from '@/components/ui/select';

export default function EmployeePicker({ employees, value, onChange, placeholder = 'Selecione o funcionário', disabled = false, includeInactive = false }) {
  const list = useMemo(() => {
    return (employees || []).filter((e) => includeInactive || e.status === 'active');
  }, [employees, includeInactive]);

  return (
    <Select value={value || ''} onValueChange={onChange} disabled={disabled || list.length === 0}>
      <SelectTrigger>
        <SelectValue placeholder={list.length === 0 ? 'Nenhum funcionário cadastrado' : placeholder} />
      </SelectTrigger>
      <SelectContent>
        {list.map((e) => (
          <SelectItem key={e.id} value={e.id}>
            {e.name} {e.role ? `— ${e.role}` : ''}
          </SelectItem>
        ))}
      </SelectContent>
    </Select>
  );
}