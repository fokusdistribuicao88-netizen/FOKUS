import React, { useState } from 'react';
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { AlertTriangle, Loader2, ArrowRightLeft } from 'lucide-react';
import { formatBRL } from '@/lib/format';
import { competenceLabel } from '@/lib/payrollPdf';
import { addMonthsToCompetence } from '@/lib/payrollCalc';

export default function NegativePayrollDialog({
  open, onClose, employee, summary, competence, onConfirm, busy,
}) {
  const [installments, setInstallments] = useState(1);
  const [intervalMonths, setIntervalMonths] = useState(1);

  if (!employee || !summary) return null;

  const negativeValue = Math.abs(summary.netSalary);
  const nextCompetence = addMonthsToCompetence(competence, 1);
  const isParcelado = Number(installments) > 1;
  const parcelValue = isParcelado
    ? Math.round((negativeValue / Number(installments)) * 100) / 100
    : negativeValue;
  const lastParcelComp = isParcelado
    ? addMonthsToCompetence(nextCompetence, (Number(installments) - 1) * Number(intervalMonths || 1))
    : nextCompetence;

  const handleConfirm = () => {
    onConfirm({
      installments: Number(installments) || 1,
      intervalMonths: Number(intervalMonths) || 1,
    });
  };

  return (
    <Dialog open={open} onOpenChange={(o) => !o && onClose?.()}>
      <DialogContent className="max-w-lg">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 text-red-700">
            <AlertTriangle className="w-5 h-5" /> Valor Devedor da Folha
          </DialogTitle>
          <DialogDescription>
            A folha de <strong>{employee.name}</strong> ({competenceLabel(competence)}) resultou em saldo negativo.
          </DialogDescription>
        </DialogHeader>

        <div className="rounded-lg border border-red-200 bg-red-50 p-4 space-y-1.5">
          <div className="flex justify-between text-sm">
            <span className="text-muted-foreground">Funcionário</span>
            <span className="font-medium">{employee.name}</span>
          </div>
          <div className="flex justify-between text-sm">
            <span className="text-muted-foreground">Competência atual</span>
            <span className="font-medium">{competenceLabel(competence)}</span>
          </div>
          <div className="flex justify-between text-sm">
            <span className="text-muted-foreground">Salário base</span>
            <span className="font-medium">{formatBRL(summary.baseSalary)}</span>
          </div>
          <div className="flex justify-between text-sm">
            <span className="text-muted-foreground">Total de proventos</span>
            <span className="font-medium">{formatBRL(summary.grossSalary)}</span>
          </div>
          <div className="flex justify-between text-sm">
            <span className="text-muted-foreground">Total de descontos</span>
            <span className="font-medium">{formatBRL(summary.totalDiscounts)}</span>
          </div>
          <div className="flex justify-between text-sm border-t border-red-200 pt-1.5 mt-1.5">
            <span className="text-red-700 font-semibold">Valor negativo (devedor)</span>
            <span className="font-bold text-red-700">{formatBRL(negativeValue)}</span>
          </div>
        </div>

        <div className="rounded-lg border-2 border-blue-200 bg-blue-50 p-4">
          <p className="text-sm font-semibold text-blue-900 mb-2 flex items-center gap-1.5">
            <ArrowRightLeft className="w-4 h-4" /> Valor a descontar na próxima folha
          </p>
          <p className="text-2xl font-bold text-blue-900">{formatBRL(negativeValue)}</p>
          <p className="text-xs text-blue-700 mt-1">
            Será lançado como adiantamento para a competência <strong>{competenceLabel(nextCompetence)}</strong>.
          </p>
        </div>

        <div className="rounded-lg border border-border p-3 space-y-3">
          <div className="flex items-center gap-4">
            <label className="flex items-center gap-2 text-sm cursor-pointer">
              <input type="radio" checked={!isParcelado} onChange={() => setInstallments(1)} />
              À vista (1 parcela)
            </label>
            <label className="flex items-center gap-2 text-sm cursor-pointer">
              <input type="radio" checked={isParcelado} onChange={() => setInstallments(2)} />
              Parcelado
            </label>
          </div>
          {isParcelado && (
            <div className="grid grid-cols-2 gap-3">
              <div>
                <Label className="text-xs">Nº de parcelas</Label>
                <Input type="number" min="2" value={installments} onChange={(e) => setInstallments(e.target.value)} />
              </div>
              <div>
                <Label className="text-xs">Intervalo (meses)</Label>
                <Input type="number" min="1" value={intervalMonths} onChange={(e) => setIntervalMonths(e.target.value)} />
              </div>
              <div className="col-span-2 text-xs text-muted-foreground bg-muted/40 rounded p-2">
                {Number(installments)} parcelas de <strong>{formatBRL(parcelValue)}</strong> — competências de {competenceLabel(nextCompetence)} a {competenceLabel(lastParcelComp)}
              </div>
            </div>
          )}
        </div>

        <DialogFooter className="flex-col sm:flex-row gap-2">
          <Button variant="outline" onClick={onClose} disabled={busy} className="w-full sm:w-auto">
            Cancelar
          </Button>
          <Button onClick={handleConfirm} disabled={busy} className="gap-2 w-full sm:w-auto bg-blue-700 hover:bg-blue-800">
            {busy ? <><Loader2 className="w-4 h-4 animate-spin" /> Lancando adiantamento...</> : <><ArrowRightLeft className="w-4 h-4" /> Lançar e Fechar Folha</>}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}