import React, { useEffect, useState } from 'react';
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Loader2, History } from 'lucide-react';
import { listPayrollSnapshots } from '@/lib/payrollSnapshot';
import { formatBRL } from '@/lib/format';
import { competenceLabel } from '@/lib/payrollPdf';

const ACTION_LABELS = {
  closed: 'Fechamento',
  reopened: 'Reabertura',
  recalculated: 'Recálculo',
  paid: 'Pagamento',
};

const ACTION_VARIANTS = {
  closed: 'bg-green-100 text-green-800',
  reopened: 'bg-orange-100 text-orange-800',
  recalculated: 'bg-blue-100 text-blue-800',
  paid: 'bg-emerald-100 text-emerald-800',
};

export default function PayrollHistoryDialog({ open, onClose, payroll }) {
  const [items, setItems] = useState([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (open && payroll?.id) {
      setLoading(true);
      listPayrollSnapshots(payroll.id)
        .then(setItems)
        .catch(() => setItems([]))
        .finally(() => setLoading(false));
    }
  }, [open, payroll?.id]);

  return (
    <Dialog open={open} onOpenChange={(o) => { if (!o) onClose?.(); }}>
      <DialogContent className="max-w-2xl max-h-[85vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2"><History className="w-5 h-5" /> Histórico da Folha</DialogTitle>
          <DialogDescription>
            {payroll?.employee_name} — Competência {competenceLabel(payroll?.competence_month)}
          </DialogDescription>
        </DialogHeader>

        {loading ? (
          <div className="flex items-center justify-center py-10"><Loader2 className="w-6 h-6 animate-spin text-muted-foreground" /></div>
        ) : items.length === 0 ? (
          <p className="text-center py-10 text-muted-foreground text-sm">Nenhum registro de histórico encontrado.</p>
        ) : (
          <div className="space-y-3">
            {items.map((it) => (
              <div key={it.id} className="rounded-lg border border-border p-3">
                <div className="flex items-center justify-between mb-1">
                  <Badge className={ACTION_VARIANTS[it.action] || 'bg-gray-100 text-gray-800'}>
                    {ACTION_LABELS[it.action] || it.action}
                  </Badge>
                  <span className="text-xs text-muted-foreground">{new Date(it.timestamp).toLocaleString('pt-BR')}</span>
                </div>
                <div className="grid grid-cols-3 gap-2 text-xs mt-2">
                  <div><span className="text-muted-foreground">Bruto:</span><br /><strong>{formatBRL(it.gross_salary)}</strong></div>
                  <div><span className="text-muted-foreground">Descontos:</span><br /><strong>{formatBRL(it.total_discounts)}</strong></div>
                  <div><span className="text-muted-foreground">Líquido:</span><br /><strong>{formatBRL(it.net_salary)}</strong></div>
                </div>
                <div className="text-xs mt-2 text-muted-foreground">
                  Por: {it.user_name || it.user_email || '—'}
                </div>
                {it.reason && <div className="text-xs mt-1"><span className="text-muted-foreground">Motivo:</span> {it.reason}</div>}
              </div>
            ))}
          </div>
        )}

        <div className="flex justify-end pt-2">
          <Button variant="outline" size="sm" onClick={onClose}>Fechar</Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}