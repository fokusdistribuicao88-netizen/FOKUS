import React, { useState, useMemo, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter,
} from '@/components/ui/dialog';
import {
  Select, SelectTrigger, SelectValue, SelectContent, SelectItem,
} from '@/components/ui/select';
import { Plus, Pencil, HandCoins, Wallet, RotateCcw, Trash2, Ban, CalendarClock, Eye, Printer, Share2 } from 'lucide-react';
import { useQuery } from '@tanstack/react-query';
import { useAuth } from '@/lib/AuthContext';
import { useToast } from '@/components/ui/use-toast';
import { base44 } from '@/api/base44Client';
import { logActivity } from '@/lib/activityLog';
import { currentCompetence } from '@/lib/payrollCalc';
import { formatBRL, formatDate } from '@/lib/format';
import { computeEmployeeDebt } from '@/lib/employeePurchaseSync';
import { syncPurchaseFinance } from '@/lib/expenseFinance';
import { previewPurchasePdf, printPurchasePdf, sharePurchasePdf } from '@/lib/employeeReceiptPdf';
import EmployeePicker from './EmployeePicker';
import OrderProductPicker from '@/components/orders/OrderProductPicker';
import { SYSTEM_TABLES } from '@/lib/posPriceTables';

const isSystemCode = (id) => SYSTEM_TABLES.some((s) => s.code === id);

const STATUS = {
  pending: { label: 'Em aberto', cls: 'bg-yellow-100 text-yellow-800' },
  deducted: { label: 'Descontada', cls: 'bg-blue-100 text-blue-800' },
  paid: { label: 'Quitada', cls: 'bg-green-100 text-green-800' },
  cancelled: { label: 'Cancelada', cls: 'bg-gray-100 text-gray-600' },
};
const METHODS = ['Dinheiro', 'PIX', 'Transferência', 'Cartão', 'Convênio', 'Desconto em folha'];
const PAY_METHODS = ['Dinheiro', 'PIX', 'Transferência', 'Cartão', 'Outro'];

function addMonthsToCompetence(competence, monthsToAdd) {
  if (!competence) return competence;
  const [y, m] = competence.split('-').map(Number);
  const d = new Date(y, m - 1 + monthsToAdd, 1);
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`;
}
const TYPE_FILTERS = [
  { value: 'all', label: 'Todos' },
  { value: 'Crediário', label: 'Crediário' },
  { value: 'Desconto em folha', label: 'Desconto em folha' },
  { value: 'other', label: 'Outros' },
];

const empty = {
  employee_id: '', date: new Date().toISOString().slice(0, 10),
  items: [{ product_id: '', product_name: '', quantity: 1, unit_price: '', total: 0 }],
  payment_method: 'Desconto em folha', competence_month: currentCompetence(),
  status: 'pending', notes: '',
  price_table_id: 'PADRAO', price_table_name: 'Padrão',
};
const STATUS_FILTERS = [
  { value: 'active', label: 'Ativos' },
  { value: 'all', label: 'Todos' },
  { value: 'pending', label: 'Em aberto' },
  { value: 'paid_deducted', label: 'Pagas e descontadas' },
  { value: 'cancelled', label: 'Canceladas' },
];

export default function PurchasesTab({ employees, purchases, can, onReload }) {
  const { user } = useAuth();
  const { toast } = useToast();
  const { data: products = [] } = useQuery({
    queryKey: ['products'],
    queryFn: () => base44.entities.Product.list(),
  });
  const { data: settings } = useQuery({
    queryKey: ['settings'],
    queryFn: () => base44.entities.Settings.list('-updated_date', 1).then((r) => r[0]),
  });
  const { data: priceTables = [] } = useQuery({
    queryKey: ['price-tables'],
    queryFn: () => base44.entities.PriceTable.list('-updated_date'),
  });
  const activeTables = useMemo(() => (priceTables || []).filter((t) => t.status !== 'inactive'), [priceTables]);
  const customTables = useMemo(() => activeTables.filter((t) => !isSystemCode(t.code)), [activeTables]);

  const [open, setOpen] = useState(false);
  const [editing, setEditing] = useState(null);
  const [form, setForm] = useState(empty);
  const [saving, setSaving] = useState(false);
  const [filterEmp, setFilterEmp] = useState('all');
  const [filterType, setFilterType] = useState('all');
  const [filterStatus, setFilterStatus] = useState('active');

  const selectedTableId = form.price_table_id || 'PADRAO';
  const sysTable = isSystemCode(selectedTableId) ? SYSTEM_TABLES.find((s) => s.code === selectedTableId) : null;
  const entTable = !sysTable ? activeTables.find((t) => t.id === selectedTableId) : null;
  const itemsEntityId = (sysTable ? priceTables.find((t) => t.code === sysTable.code) : entTable)?.id || null;

  const { data: tableItems = [] } = useQuery({
    queryKey: ['price-table-items', itemsEntityId],
    queryFn: () => base44.entities.PriceTableItem.filter({ price_table_id: itemsEntityId }),
    enabled: !!itemsEntityId,
    staleTime: 30 * 1000,
  });
  const itemsByProduct = useMemo(() => {
    const m = {};
    (tableItems || []).forEach((it) => { m[it.product_id] = it; });
    return m;
  }, [tableItems]);

  const priceOf = (product) => {
    if (!product) return 0;
    if (product.price_promo) return product.price_promo;
    const it = itemsByProduct[product.id];
    if (it && Number(it.custom_price) >= 0) return Number(it.custom_price);
    if (sysTable) return Number(product[sysTable.field]) || Number(product.price) || 0;
    return Number(product.price) || 0;
  };

  const changePriceTable = (tableId) => {
    const sys = isSystemCode(tableId) ? SYSTEM_TABLES.find((s) => s.code === tableId) : null;
    const ent = !sys ? activeTables.find((t) => t.id === tableId) : null;
    if (!sys && !ent) return;
    const name = sys ? sys.name : ent.name;
    const hasItems = (form.items || []).some((it) => it.product_id);
    const apply = () => setForm((f) => ({ ...f, price_table_id: tableId, price_table_name: name }));
    if (hasItems) {
      if (window.confirm(`Trocar para "${name}"? Os preços dos produtos já adicionados serão recalculados.`)) apply();
    } else {
      apply();
    }
  };

  // Recalcula preços dos itens quando a tabela muda e os itens da tabela carregam
  useEffect(() => {
    setForm((f) => {
      if (!f.items || f.items.length === 0) return f;
      const updated = f.items.map((it) => {
        if (!it.product_id) return it;
        const product = products.find((p) => p.id === it.product_id);
        if (!product) return it;
        const newPrice = priceOf(product);
        const qty = Number(it.quantity) || 0;
        return { ...it, unit_price: newPrice, total: Math.round(newPrice * qty * 100) / 100 };
      });
      return { ...f, items: updated };
    });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [itemsByProduct, selectedTableId]);

  // Pagamento (crediário)
  const [payOpen, setPayOpen] = useState(false);
  const [payTarget, setPayTarget] = useState(null);
  const [payForm, setPayForm] = useState({ amount: '', date: new Date().toISOString().slice(0, 10), method: 'Dinheiro', notes: '' });

  const matchType = (p) => {
    if (filterType === 'all') return true;
    if (filterType === 'other') return p.payment_method !== 'Crediário' && p.payment_method !== 'Desconto em folha';
    return p.payment_method === filterType;
  };

  const filtered = useMemo(() => {
    let list = [...(purchases || [])];
    if (filterEmp !== 'all') list = list.filter((p) => p.employee_id === filterEmp);
    list = list.filter(matchType);
    if (filterStatus === 'active') list = list.filter((p) => p.status !== 'deducted' && p.status !== 'paid');
    else if (filterStatus === 'paid_deducted') list = list.filter((p) => p.status === 'paid' || p.status === 'deducted');
    else if (filterStatus !== 'all') list = list.filter((p) => p.status === filterStatus);
    return list.sort((a, b) => new Date(b.date || 0) - new Date(a.date || 0));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [purchases, filterEmp, filterType, filterStatus]);

  const total = useMemo(
    () => filtered.filter((p) => p.status !== 'cancelled').reduce((s, p) => s + (Number(p.total) || 0), 0),
    [filtered]
  );

  // Resumo crediário (aplica filtro de funcionário)
  const crediarioSummary = useMemo(() => {
    const list = (purchases || []).filter((p) => p.payment_method === 'Crediário' && matchType(p));
    const scoped = filterEmp === 'all' ? list : list.filter((p) => p.employee_id === filterEmp);
    return computeEmployeeDebt(scoped);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [purchases, filterEmp, filterType]);

  // Resumo individual por funcionário (crediário)
  const perEmployee = useMemo(() => {
    if (filterEmp !== 'all' || filterType !== 'all') return [];
    const crediario = (purchases || []).filter((p) => p.payment_method === 'Crediário');
    const map = {};
    crediario.forEach((p) => {
      if (p.status === 'cancelled') return;
      if (!map[p.employee_id]) map[p.employee_id] = { name: p.employee_name, ...computeEmployeeDebt([]) };
    });
    crediario.forEach((p) => {
      if (p.status === 'cancelled') return;
      const s = map[p.employee_id];
      if (!s) return;
      s.totalDebt += Number(p.total) || 0;
      // quitadas/descontadas = liquidadas integralmente
      if (p.status === 'paid' || p.status === 'deducted') s.totalPaid += Number(p.total) || 0;
      else s.totalPaid += Number(p.paid_amount) || 0;
      if (p.status === 'pending') s.pendingCount += 1;
      if (p.status === 'paid' || p.status === 'deducted') s.paidCount += 1;
    });
    Object.values(map).forEach((s) => { s.balance = Math.max(0, s.totalDebt - s.totalPaid); });
    return Object.values(map).filter((s) => s.totalDebt > 0).sort((a, b) => b.balance - a.balance);
  }, [purchases, filterEmp, filterType]);

  const set = (k, v) => setForm((f) => ({ ...f, [k]: v }));
  const setItem = (idx, field, value) => setForm((f) => {
    const items = [...(f.items || [])];
    const item = { ...items[idx], [field]: value };
    if (field === 'quantity' || field === 'unit_price') {
      item.total = Math.round(((Number(item.quantity) || 0) * (Number(item.unit_price) || 0)) * 100) / 100;
    }
    items[idx] = item;
    return { ...f, items };
  });
  const addItem = () => setForm((f) => ({ ...f, items: [...(f.items || []), { product_id: '', product_name: '', quantity: 1, unit_price: '', total: 0 }] }));
  const removeItem = (idx) => setForm((f) => ({ ...f, items: (f.items || []).filter((_, i) => i !== idx) }));
  const grandTotal = useMemo(() => (form.items || []).reduce((s, it) => s + (Number(it.total) || 0), 0), [form.items]);

  const openNew = () => { setEditing(null); setForm({ ...empty, items: [{ product_id: '', product_name: '', quantity: 1, unit_price: '', total: 0 }] }); setOpen(true); };
  const openEdit = (p) => {
    setEditing(p);
    setForm({
      ...empty,
      employee_id: p.employee_id,
      date: p.date,
      competence_month: p.competence_month,
      payment_method: p.payment_method,
      status: p.status,
      notes: p.notes || '',
      items: [{ product_id: p.product_id || '', product_name: p.product_name || '', quantity: p.quantity || 1, unit_price: p.unit_price || '', total: p.total || 0 }],
    });
    setOpen(true);
  };

  const submit = async (action = 'save') => {
    if (!form.employee_id) return toast({ title: 'Selecione o funcionário', variant: 'destructive' });
    const validItems = (form.items || []).filter((it) => it.product_name?.trim());
    if (validItems.length === 0) return toast({ title: 'Adicione ao menos um produto', variant: 'destructive' });
    setSaving(true);
    try {
      const emp = employees.find((e) => e.id === form.employee_id);
      const basePayload = {
        employee_id: form.employee_id,
        employee_name: emp?.name || '',
        date: form.date,
        payment_method: form.payment_method,
        competence_month: form.competence_month || currentCompetence(form.date),
        notes: form.notes,
        registered_by: user?.email || '',
      };
      if (editing?.id) {
        const it = validItems[0];
        const totalVal = Math.round((Number(it.quantity) * Number(it.unit_price)) * 100) / 100;
        const payload = {
          ...basePayload,
          product_name: it.product_name,
          quantity: Number(it.quantity) || 0,
          unit_price: Number(it.unit_price) || 0,
          total: totalVal,
          status: form.status,
        };
        const saved = await base44.entities.EmployeePurchase.update(editing.id, payload);
        try {
          const feId = await syncPurchaseFinance({ ...saved, employee_name: emp?.name }, user);
          if (feId && feId !== saved.financial_entry_id) await base44.entities.EmployeePurchase.update(saved.id, { financial_entry_id: feId });
        } catch { /* ignore finance error */ }
        await logActivity({ action: 'purchase_update', description: `Editou compra de ${emp?.name}`, user, entityType: 'EmployeePurchase', entityId: editing.id });
        toast({ title: 'Compra salva' });
        if (action !== 'save') {
          try {
            const fn = action === 'preview' ? previewPurchasePdf : printPurchasePdf;
            await fn({ purchase: saved, employee: emp, settings, user });
          } catch { /* ignore PDF error */ }
        }
        setOpen(false);
        onReload?.();
        return;
      }
      const records = validItems.map((it) => {
        const totalVal = Math.round((Number(it.quantity) * Number(it.unit_price)) * 100) / 100;
        return {
          ...basePayload,
          product_name: it.product_name,
          quantity: Number(it.quantity) || 0,
          unit_price: Number(it.unit_price) || 0,
          total: totalVal,
          status: 'pending',
        };
      });
      const created = await base44.entities.EmployeePurchase.bulkCreate(records);
      const createdArr = Array.isArray(created) ? created : [created];
      for (let i = 0; i < createdArr.length; i++) {
        const c = createdArr[i];
        try {
          const feId = await syncPurchaseFinance({ ...c, employee_name: emp?.name }, user);
          if (feId) await base44.entities.EmployeePurchase.update(c.id, { financial_entry_id: feId });
        } catch { /* ignore finance error */ }
      }
      const grandTotalVal = records.reduce((s, r) => s + r.total, 0);
      await logActivity({ action: 'purchase_create', description: `Compra de ${formatBRL(grandTotalVal)} de ${emp?.name} (${records.length} item(ns))`, user, entityType: 'EmployeePurchase', entityId: createdArr[0]?.id });
      toast({ title: 'Compra salva', description: `${records.length} item(ns) registrado(s)` });
      if (action !== 'save' && createdArr[0]) {
        try {
          const fn = action === 'preview' ? previewPurchasePdf : printPurchasePdf;
          await fn({ purchase: createdArr[0], employee: emp, settings, user });
        } catch { /* ignore PDF error */ }
      }
      setOpen(false);
      onReload?.();
    } catch (e) {
      toast({ title: 'Erro', description: e.message, variant: 'destructive' });
    } finally {
      setSaving(false);
    }
  };

  const setStatus = async (p, status) => {
    const updated = await base44.entities.EmployeePurchase.update(p.id, { status });
    try {
      const feId = await syncPurchaseFinance({ ...updated, employee_name: p.employee_name }, user);
      if (feId && feId !== p.financial_entry_id) await base44.entities.EmployeePurchase.update(p.id, { financial_entry_id: feId });
    } catch { /* ignore finance error */ }
    toast({ title: `Compra marcada como ${STATUS[status]?.label || status}` });
    onReload?.();
  };

  const cancelPurchase = async (p) => {
    if (!window.confirm('Cancelar esta compra?')) return;
    try {
      await base44.entities.EmployeePurchase.update(p.id, { status: 'cancelled' });
      if (p.financial_entry_id) {
        try { await base44.entities.FinancialEntry.update(p.financial_entry_id, { status: 'cancelled' }); } catch { /* ignore */ }
      }
      await logActivity({ action: 'purchase_cancel', description: `Cancelou compra de ${p.employee_name} (${formatBRL(p.total)})`, user, entityType: 'EmployeePurchase', entityId: p.id });
      toast({ title: 'Compra cancelada' });
      onReload?.();
    } catch (e) {
      toast({ title: 'Erro', description: e.message, variant: 'destructive' });
    }
  };

  const reactivatePurchase = async (p) => {
    if (!window.confirm('Reativar esta compra? Ela voltará a ser considerada na folha/crediário.')) return;
    try {
      const restoreStatus = p.paid_amount > 0 && Number(p.total) - Number(p.paid_amount) <= 0.01 ? 'paid' : 'pending';
      const updated = await base44.entities.EmployeePurchase.update(p.id, { status: restoreStatus, payroll_id: '' });
      try {
        const feId = await syncPurchaseFinance({ ...updated, employee_name: p.employee_name }, user);
        if (feId && feId !== p.financial_entry_id) await base44.entities.EmployeePurchase.update(p.id, { financial_entry_id: feId });
      } catch { /* ignore finance error */ }
      await logActivity({ action: 'purchase_reactivate', description: `Reativou compra de ${p.employee_name} (${formatBRL(p.total)})`, user, entityType: 'EmployeePurchase', entityId: p.id });
      toast({ title: 'Compra reativada' });
      onReload?.();
    } catch (e) {
      toast({ title: 'Erro', description: e.message, variant: 'destructive' });
    }
  };

  const pushNextMonth = async (p) => {
    const next = addMonthsToCompetence(p.competence_month || currentCompetence(p.date), 1);
    if (!window.confirm(`Jogar esta compra para a competência ${next}?`)) return;
    try {
      await base44.entities.EmployeePurchase.update(p.id, { competence_month: next });
      await logActivity({ action: 'purchase_push_month', description: `Compra de ${p.employee_name} jogada para ${next}`, user, entityType: 'EmployeePurchase', entityId: p.id });
      toast({ title: 'Compra movida', description: `Nova competência: ${next}` });
      onReload?.();
    } catch (e) {
      toast({ title: 'Erro', description: e.message, variant: 'destructive' });
    }
  };

  const excludePurchase = async (p) => {
    const isDeducted = p.status === 'deducted';
    if (isDeducted && user?.role !== 'admin') {
      toast({ title: 'Apenas administradores podem excluir compras já descontadas em folha fechada', variant: 'destructive' });
      return;
    }
    if (!window.confirm('Tem certeza que deseja excluir esta compra? Esta ação não pode ser desfeita.')) return;
    try {
      if (p.financial_entry_id) {
        try { await base44.entities.FinancialEntry.update(p.financial_entry_id, { status: 'cancelled' }); } catch { /* ignore */ }
      }
      await base44.entities.EmployeePurchase.delete(p.id);
      await logActivity({ action: 'purchase_delete', description: `Excluiu compra de ${p.employee_name} (${formatBRL(p.total)})`, user, entityType: 'EmployeePurchase', entityId: p.id });
      toast({ title: 'Compra excluída' });
      onReload?.();
    } catch (e) {
      toast({ title: 'Erro', description: e.message, variant: 'destructive' });
    }
  };

  const openPay = (p) => {
    const balance = (Number(p.total) || 0) - (Number(p.paid_amount) || 0);
    setPayTarget(p);
    setPayForm({ amount: String(balance.toFixed(2)), date: new Date().toISOString().slice(0, 10), method: 'Dinheiro', notes: '' });
    setPayOpen(true);
  };

  const submitPay = async () => {
    if (!payTarget) return;
    const amount = Math.round((Number(payForm.amount) || 0) * 100) / 100;
    if (amount <= 0) return toast({ title: 'Informe o valor do pagamento', variant: 'destructive' });
    setSaving(true);
    try {
      const currentPaid = Number(payTarget.paid_amount) || 0;
      const newPaid = Math.round((currentPaid + amount) * 100) / 100;
      const balanceAfter = Math.max(0, (Number(payTarget.total) || 0) - newPaid);
      const newStatus = balanceAfter <= 0.01 ? 'paid' : payTarget.status;
      const historyEntry = {
        date: payForm.date,
        amount,
        method: payForm.method,
        responsible: user?.email || '',
        notes: payForm.notes || '',
        balance_after: balanceAfter,
      };
      const updated = await base44.entities.EmployeePurchase.update(payTarget.id, {
        paid_amount: newPaid,
        status: newStatus,
        payment_history: [...(payTarget.payment_history || []), historyEntry],
      });
      try {
        const feId = await syncPurchaseFinance({ ...updated, employee_name: payTarget.employee_name }, user);
        if (feId && feId !== payTarget.financial_entry_id) await base44.entities.EmployeePurchase.update(payTarget.id, { financial_entry_id: feId });
      } catch { /* ignore finance error */ }
      await logActivity({
        action: 'crediario_payment',
        description: `Pagamento de ${formatBRL(amount)} — ${payTarget.employee_name} (saldo: ${formatBRL(balanceAfter)})`,
        user, entityType: 'EmployeePurchase', entityId: payTarget.id,
      });
      toast({ title: 'Pagamento registrado', description: `Saldo restante: ${formatBRL(balanceAfter)}` });
      setPayOpen(false);
      onReload?.();
    } catch (e) {
      toast({ title: 'Erro', description: e.message, variant: 'destructive' });
    } finally {
      setSaving(false);
    }
  };

  const showCrediarioSummary = filterType === 'all' || filterType === 'Crediário';

  return (
    <div className="space-y-4">
      {/* Filtros + resumo */}
      <div className="flex flex-col md:flex-row gap-3 md:items-center justify-between">
        <div className="flex flex-wrap gap-2">
          <Select value={filterEmp} onValueChange={setFilterEmp}>
            <SelectTrigger className="md:w-56 w-full"><SelectValue placeholder="Filtrar por funcionário" /></SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Todos funcionários</SelectItem>
              {employees.map((e) => <SelectItem key={e.id} value={e.id}>{e.name}</SelectItem>)}
            </SelectContent>
          </Select>
          <Select value={filterType} onValueChange={setFilterType}>
            <SelectTrigger className="md:w-48 w-full"><SelectValue placeholder="Tipo" /></SelectTrigger>
            <SelectContent>
              {TYPE_FILTERS.map((t) => <SelectItem key={t.value} value={t.value}>{t.label}</SelectItem>)}
            </SelectContent>
          </Select>
          <Select value={filterStatus} onValueChange={setFilterStatus}>
            <SelectTrigger className="md:w-40 w-full"><SelectValue placeholder="Status" /></SelectTrigger>
            <SelectContent>
              {STATUS_FILTERS.map((s) => <SelectItem key={s.value} value={s.value}>{s.label}</SelectItem>)}
            </SelectContent>
          </Select>
        </div>
        <div className="flex flex-wrap items-center gap-3 text-sm">
          {showCrediarioSummary ? (
            <>
              <div className="rounded-lg bg-muted/50 px-3 py-1.5">
                <span className="text-muted-foreground">Dívidas: </span>
                <strong>{formatBRL(crediarioSummary.totalDebt)}</strong>
              </div>
              <div className="rounded-lg bg-green-50 px-3 py-1.5">
                <span className="text-green-700">Pago: </span>
                <strong className="text-green-700">{formatBRL(crediarioSummary.totalPaid)}</strong>
              </div>
              <div className="rounded-lg bg-amber-50 px-3 py-1.5">
                <span className="text-amber-700">Em aberto: </span>
                <strong className="text-amber-700">{formatBRL(crediarioSummary.balance)}</strong>
              </div>
            </>
          ) : (
            <div className="rounded-lg bg-muted/50 px-3 py-1.5">
              <span className="text-muted-foreground">Total: </span>
              <strong>{formatBRL(total)}</strong>
            </div>
          )}
          {can('Registrar compras') && <Button onClick={openNew}><Plus className="w-4 h-4" /> Nova compra</Button>}
        </div>
      </div>

      {/* Resumo por funcionário (visão geral de crediário) */}
      {filterEmp === 'all' && filterType === 'all' && perEmployee.length > 0 && (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
          {perEmployee.map((s) => (
            <div key={s.name} className="rounded-lg border border-border p-3">
              <div className="flex items-center gap-2 mb-2">
                <Wallet className="w-4 h-4 text-amber-600" />
                <p className="font-medium text-sm truncate">{s.name}</p>
              </div>
              <div className="grid grid-cols-2 gap-1 text-xs">
                <span className="text-muted-foreground">Dívida:</span><span className="text-right font-medium">{formatBRL(s.totalDebt)}</span>
                <span className="text-muted-foreground">Pago:</span><span className="text-right text-green-600 font-medium">{formatBRL(s.totalPaid)}</span>
                <span className="text-muted-foreground">Saldo:</span><span className="text-right text-amber-600 font-bold">{formatBRL(s.balance)}</span>
                <span className="text-muted-foreground">Pend/Quit:</span><span className="text-right">{s.pendingCount}/{s.paidCount}</span>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Tabela de compras */}
      <div className="overflow-x-auto rounded-lg border border-border">
        <table className="w-full text-sm">
          <thead className="bg-muted/50 text-muted-foreground">
            <tr>
              <th className="text-left px-3 py-2 font-medium">Funcionário</th>
              <th className="text-left px-3 py-2 font-medium hidden md:table-cell">Produto</th>
              <th className="text-left px-3 py-2 font-medium hidden lg:table-cell">Pedido</th>
              <th className="text-left px-3 py-2 font-medium hidden md:table-cell">Método</th>
              <th className="text-right px-3 py-2 font-medium hidden md:table-cell">Qtd</th>
              <th className="text-right px-3 py-2 font-medium">Total</th>
              <th className="text-right px-3 py-2 font-medium hidden md:table-cell">Pago</th>
              <th className="text-right px-3 py-2 font-medium">Saldo</th>
              <th className="text-left px-3 py-2 font-medium hidden lg:table-cell">Competência</th>
              <th className="text-left px-3 py-2 font-medium hidden lg:table-cell">Vencimento</th>
              <th className="text-center px-3 py-2 font-medium">Status</th>
              <th className="text-center px-3 py-2 font-medium">Ações</th>
            </tr>
          </thead>
          <tbody>
            {filtered.length === 0 && <tr><td colSpan={12} className="text-center py-8 text-muted-foreground">Nenhuma compra registrada.</td></tr>}
            {filtered.map((p) => {
              const st = STATUS[p.status] || STATUS.pending;
              const balance = (p.status === 'paid' || p.status === 'deducted' || p.status === 'cancelled')
                ? 0
                : (Number(p.total) || 0) - (Number(p.paid_amount) || 0);
              const isCrediario = p.payment_method === 'Crediário';
              return (
                <tr key={p.id} className="border-t border-border hover:bg-muted/30">
                  <td className="px-3 py-2 font-medium">{p.employee_name}</td>
                  <td className="px-3 py-2 hidden md:table-cell max-w-[160px] truncate">{p.product_name}</td>
                  <td className="px-3 py-2 hidden lg:table-cell font-mono text-xs">#{p.sale_code || '—'}</td>
                  <td className="px-3 py-2 hidden md:table-cell">
                    <span className={`text-xs px-2 py-0.5 rounded-full ${isCrediario ? 'bg-amber-100 text-amber-800' : 'bg-slate-100 text-slate-700'}`}>
                      {p.payment_method || '—'}
                    </span>
                  </td>
                  <td className="px-3 py-2 text-right hidden md:table-cell">{p.quantity}</td>
                  <td className="px-3 py-2 text-right font-medium">{formatBRL(p.total)}</td>
                  <td className="px-3 py-2 text-right hidden md:table-cell text-green-600">{formatBRL(p.paid_amount || 0)}</td>
                  <td className="px-3 py-2 text-right font-bold text-amber-600">{formatBRL(balance)}</td>
                  <td className="px-3 py-2 hidden lg:table-cell text-muted-foreground">{p.competence_month || '—'}</td>
                  <td className="px-3 py-2 hidden lg:table-cell text-muted-foreground">{p.due_date ? formatDate(p.due_date) : '—'}</td>
                  <td className="px-3 py-2 text-center">
                    <span className={`text-xs px-2 py-0.5 rounded-full ${st.cls}`}>{st.label}</span>
                  </td>
                  <td className="px-3 py-2">
                    <div className="flex items-center justify-center gap-1">
                      <Button variant="ghost" size="icon" onClick={() => previewPurchasePdf({ purchase: p, employee: employees.find((e) => e.id === p.employee_id), settings, user })} title="Visualizar PDF"><Eye className="w-4 h-4" /></Button>
                      <Button variant="ghost" size="icon" onClick={() => printPurchasePdf({ purchase: p, employee: employees.find((e) => e.id === p.employee_id), settings, user })} title="Imprimir PDF"><Printer className="w-4 h-4" /></Button>
                      <Button variant="ghost" size="icon" onClick={() => sharePurchasePdf({ purchase: p, employee: employees.find((e) => e.id === p.employee_id), settings, user })} title="Compartilhar PDF"><Share2 className="w-4 h-4" /></Button>
                      {can('Registrar compras') && (
                        <Button variant="ghost" size="icon" onClick={() => openEdit(p)} title="Editar"><Pencil className="w-4 h-4" /></Button>
                      )}
                      {can('Registrar compras') && isCrediario && p.status === 'pending' && (
                        <Button variant="ghost" size="sm" onClick={() => openPay(p)} title="Registrar pagamento" className="gap-1">
                          <HandCoins className="w-4 h-4" /> Pagar
                        </Button>
                      )}
                      {can('Registrar compras') && p.status === 'pending' && (
                        <Button variant="ghost" size="icon" onClick={() => pushNextMonth(p)} title="Jogar para próximo mês"><CalendarClock className="w-4 h-4 text-blue-600" /></Button>
                      )}
                      {can('Registrar compras') && p.status !== 'deducted' && p.status !== 'cancelled' && !isCrediario && (
                        <Button variant="ghost" size="sm" onClick={() => setStatus(p, 'deducted')} title="Marcar descontada">✓</Button>
                      )}
                      {can('Registrar compras') && p.status !== 'cancelled' && (
                        <Button variant="ghost" size="icon" onClick={() => cancelPurchase(p)} title="Cancelar"><Ban className="w-4 h-4 text-red-600" /></Button>
                      )}
                      {can('Registrar compras') && p.status === 'cancelled' && (
                        <Button variant="ghost" size="icon" onClick={() => reactivatePurchase(p)} title="Reativar"><RotateCcw className="w-4 h-4 text-green-600" /></Button>
                      )}
                      {can('Registrar compras') && (
                        <Button variant="ghost" size="icon" onClick={() => excludePurchase(p)} title="Excluir"><Trash2 className="w-4 h-4 text-red-700" /></Button>
                      )}
                    </div>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>

      {/* Dialog de nova/editar compra */}
      <Dialog open={open} onOpenChange={(op) => !op && setOpen(false)}>
        <DialogContent className="max-w-lg">
          <DialogHeader><DialogTitle>{editing?.id ? 'Editar compra' : 'Nova compra'}</DialogTitle></DialogHeader>
          <div className="space-y-3">
            <div>
              <Label>Funcionário *</Label>
              <EmployeePicker employees={employees} value={form.employee_id} onChange={(v) => set('employee_id', v)} />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div><Label>Data *</Label><Input type="date" value={form.date} onChange={(e) => set('date', e.target.value)} /></div>
              <div><Label>Competência (desconto)</Label><Input type="month" value={form.competence_month} onChange={(e) => set('competence_month', e.target.value)} /></div>
            </div>
            <div>
              <Label>Tabela de Preços</Label>
              <Select value={selectedTableId} onValueChange={changePriceTable}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent className="max-h-60">
                  {SYSTEM_TABLES.map((s) => (
                    <SelectItem key={s.code} value={s.code}>
                      <div className="flex flex-col">
                        <span className="font-medium">{s.name}</span>
                        <span className="text-[10px] text-muted-foreground">Sistema · preço do cadastro</span>
                      </div>
                    </SelectItem>
                  ))}
                  {customTables.map((t) => (
                    <SelectItem key={t.id} value={t.id}>
                      <div className="flex flex-col">
                        <span className="font-medium">{t.name}{t.is_default ? ' (padrão)' : ''}</span>
                        {t.description && <span className="text-[10px] text-muted-foreground">{t.description}</span>}
                      </div>
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div>
              <div className="flex items-center justify-between mb-1">
                <Label>Produtos *</Label>
                {!editing?.id && <Button type="button" variant="outline" size="sm" onClick={addItem}><Plus className="w-4 h-4" /> Adicionar produto</Button>}
              </div>
              <div className="space-y-2 max-h-[280px] overflow-y-auto pr-1">
                {(form.items || []).map((it, idx) => (
                  <div key={idx} className="rounded-lg border border-border p-2 space-y-2 bg-muted/20">
                    <div className="flex gap-2">
                      <Input value={it.product_name} onChange={(e) => setItem(idx, 'product_name', e.target.value)} placeholder="Selecione ou digite o produto" />
                      <OrderProductPicker
                        products={products}
                        onAdd={(p) => {
                          setItem(idx, 'product_id', p.id);
                          setItem(idx, 'product_name', p.name);
                          setItem(idx, 'unit_price', priceOf(p));
                        }}
                        addedIds={it.product_id ? [it.product_id] : []}
                        priceOf={priceOf}
                        priceTableLabel={form.price_table_name || 'Padrão'}
                      />
                      {(form.items || []).length > 1 && !editing?.id && (
                        <Button type="button" variant="ghost" size="icon" onClick={() => removeItem(idx)} title="Remover"><Trash2 className="w-4 h-4 text-red-600" /></Button>
                      )}
                    </div>
                    <div className="grid grid-cols-3 gap-2">
                      <div>
                        <Label className="text-xs">Qtd</Label>
                        <Input type="number" step="0.01" value={it.quantity} onChange={(e) => setItem(idx, 'quantity', e.target.value)} />
                      </div>
                      <div>
                        <Label className="text-xs">Valor unit.</Label>
                        <Input type="number" step="0.01" value={it.unit_price} onChange={(e) => setItem(idx, 'unit_price', e.target.value)} />
                      </div>
                      <div>
                        <Label className="text-xs">Total</Label>
                        <Input value={formatBRL(it.total)} disabled className="bg-muted/40 font-semibold" />
                      </div>
                    </div>
                  </div>
                ))}
              </div>
              <div className="flex justify-end pt-1 text-sm">
                <span className="text-muted-foreground">Total geral: <strong className="text-foreground text-base">{formatBRL(grandTotal)}</strong></span>
              </div>
            </div>
            <div>
              <Label>Forma de pagamento</Label>
              <Select value={form.payment_method} onValueChange={(v) => set('payment_method', v)}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>{METHODS.map((m) => <SelectItem key={m} value={m}>{m}</SelectItem>)}</SelectContent>
              </Select>
            </div>
            <div><Label>Observações</Label><Textarea rows={2} value={form.notes} onChange={(e) => set('notes', e.target.value)} /></div>
          </div>
          <DialogFooter className="flex-col sm:flex-row gap-2">
            <Button variant="outline" onClick={() => setOpen(false)} disabled={saving}>Cancelar</Button>
            <div className="flex gap-2 sm:ml-auto">
              <Button variant="secondary" onClick={() => submit('preview')} disabled={saving}>{saving ? 'Salvando...' : 'Salvar e Visualizar'}</Button>
              <Button variant="secondary" onClick={() => submit('print')} disabled={saving}>{saving ? 'Salvando...' : 'Salvar e Imprimir'}</Button>
              <Button onClick={() => submit('save')} disabled={saving}>{saving ? 'Salvando...' : 'Salvar'}</Button>
            </div>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Dialog de pagamento (crediário) */}
      <Dialog open={payOpen} onOpenChange={(op) => !op && setPayOpen(false)}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <HandCoins className="w-5 h-5 text-green-600" /> Pagamento de Crediário
            </DialogTitle>
          </DialogHeader>
          {payTarget && (
            <div className="space-y-3">
              <div className="rounded-lg bg-muted/50 p-3 text-sm space-y-1">
                <p><strong>{payTarget.employee_name}</strong></p>
                <p className="text-muted-foreground">{payTarget.product_name} — Pedido #{payTarget.sale_code}</p>
                <div className="flex justify-between"><span>Total da dívida:</span><span>{formatBRL(payTarget.total)}</span></div>
                <div className="flex justify-between text-green-600"><span>Já pago:</span><span>{formatBRL(payTarget.paid_amount || 0)}</span></div>
                <div className="flex justify-between font-bold text-amber-600"><span>Saldo devedor:</span><span>{formatBRL((Number(payTarget.total) || 0) - (Number(payTarget.paid_amount) || 0))}</span></div>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <Label>Valor do pagamento *</Label>
                  <Input type="number" step="0.01" value={payForm.amount} onChange={(e) => setPayForm((f) => ({ ...f, amount: e.target.value }))} />
                </div>
                <div>
                  <Label>Data *</Label>
                  <Input type="date" value={payForm.date} onChange={(e) => setPayForm((f) => ({ ...f, date: e.target.value }))} />
                </div>
              </div>
              <div>
                <Label>Forma de pagamento</Label>
                <Select value={payForm.method} onValueChange={(v) => setPayForm((f) => ({ ...f, method: v }))}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>{PAY_METHODS.map((m) => <SelectItem key={m} value={m}>{m}</SelectItem>)}</SelectContent>
                </Select>
              </div>
              <div>
                <Label>Observações</Label>
                <Textarea rows={2} value={payForm.notes} onChange={(e) => setPayForm((f) => ({ ...f, notes: e.target.value }))} />
              </div>
            </div>
          )}
          <DialogFooter>
            <Button variant="outline" onClick={() => setPayOpen(false)} disabled={saving}>Cancelar</Button>
            <Button onClick={submitPay} disabled={saving} className="bg-green-600 hover:bg-green-700">
              {saving ? 'Salvando...' : 'Confirmar pagamento'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}