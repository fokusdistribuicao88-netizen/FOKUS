import React, { useState, useMemo } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter,
} from '@/components/ui/dialog';
import {
  Select, SelectTrigger, SelectValue, SelectContent, SelectItem,
} from '@/components/ui/select';
import { Plus, Pencil, Check, X, AlertTriangle } from 'lucide-react';
import { useAuth } from '@/lib/AuthContext';
import { useToast } from '@/components/ui/use-toast';
import { base44 } from '@/api/base44Client';
import { logActivity } from '@/lib/activityLog';
import {
  hourlyRate, hourlyRateRaw, overtimeHourlyRate, calcOvertimeAmountFromMinutes,
  calcOvertimeMinutes, calcWorkedMinutes, calcRegularMinutes, calcBreakMinutes,
  formatHoursMin, timeToMinutes, currentCompetence,
} from '@/lib/payrollCalc';
import { formatBRL, formatDate } from '@/lib/format';
import EmployeePicker from './EmployeePicker';

const TYPES = [
  { key: 'weekday', label: 'Dia útil' },
  { key: 'weekend', label: 'Final de semana' },
  { key: 'holiday', label: 'Feriado' },
  { key: 'night', label: 'Noturna' },
];
const STATUS = {
  pending: { label: 'Pendente', cls: 'bg-yellow-100 text-yellow-800' },
  approved: { label: 'Aprovada', cls: 'bg-green-100 text-green-800' },
  rejected: { label: 'Rejeitada', cls: 'bg-red-100 text-red-800' },
  paid: { label: 'Paga', cls: 'bg-blue-100 text-blue-800' },
};

const empty = {
  employee_id: '', date: new Date().toISOString().slice(0, 10),
  regular_start: '', regular_end: '', worked_start: '', worked_end: '',
  break_start: '', break_end: '', break_minutes: 0,
  hours: 0, overtime_type: 'weekday', percent: 50, amount: 0,
  competence_month: currentCompetence(), notes: '',
};

// Valida os horários do formulário e retorna lista de erros.
function validateTimes(form) {
  const errors = [];
  const ws = timeToMinutes(form.worked_start);
  const we = timeToMinutes(form.worked_end);
  const rs = timeToMinutes(form.regular_start);
  const re = timeToMinutes(form.regular_end);
  const bs = timeToMinutes(form.break_start);
  const be = timeToMinutes(form.break_end);

  if (!form.worked_start) errors.push('Informe o horário de entrada trabalhado.');
  if (!form.worked_end) errors.push('Informe o horário de saída trabalhado.');
  if (form.worked_start && ws === null) errors.push('Horário de entrada inválido.');
  if (form.worked_end && we === null) errors.push('Horário de saída inválido.');
  if (form.regular_start && rs === null) errors.push('Horário normal de entrada inválido.');
  if (form.regular_end && re === null) errors.push('Horário normal de saída inválido.');
  if (form.break_start && bs === null) errors.push('Horário de início do intervalo inválido.');
  if (form.break_end && be === null) errors.push('Horário de término do intervalo inválido.');

  if (ws !== null && we !== null && ws === we) errors.push('Entrada e saída iguais — verifique os horários.');

  if (ws !== null && we !== null) {
    let workedMin = we - ws;
    if (workedMin < 0) workedMin += 24 * 60;
    const breakMin = Number(form.break_minutes) || 0;
    if (breakMin > workedMin) errors.push('Intervalo maior que o tempo trabalhado.');
  }
  return errors;
}

export default function OvertimeTab({ employees, overtimes, can, onReload }) {
  const { user } = useAuth();
  const { toast } = useToast();
  const [open, setOpen] = useState(false);
  const [editing, setEditing] = useState(null);
  const [form, setForm] = useState(empty);
  const [saving, setSaving] = useState(false);
  const [filterEmp, setFilterEmp] = useState('all');

  const filtered = useMemo(() => {
    let list = [...(overtimes || [])];
    if (filterEmp !== 'all') list = list.filter((o) => o.employee_id === filterEmp);
    return list.sort((a, b) => new Date(b.date || 0) - new Date(a.date || 0));
  }, [overtimes, filterEmp]);

  const total = useMemo(() => filtered.filter((o) => o.status === 'approved' || o.status === 'paid').reduce((s, o) => s + (Number(o.amount) || 0), 0), [filtered]);

  // Cálculo automático derivado dos horários + jornada + intervalo.
  // Trabalha internamente com MINUTOS para precisão financeira exata.
  const calc = useMemo(() => {
    const emp = employees.find((e) => e.id === form.employee_id);
    const hrRaw = hourlyRateRaw(emp?.base_salary, emp?.weekly_hours);
    const hr = Math.round(hrRaw * 100) / 100;
    const breakMin = form.break_start && form.break_end
      ? calcBreakMinutes(form.break_start, form.break_end)
      : (Number(form.break_minutes) || 0);
    const workedMin = calcWorkedMinutes(form.worked_start, form.worked_end, breakMin);
    const regularMin = calcRegularMinutes(form.regular_start, form.regular_end, breakMin);
    const otMin = calcOvertimeMinutes(form.worked_start, form.worked_end, breakMin, form.regular_start, form.regular_end);
    const percent = Number(form.percent) || 50;
    const otRate = overtimeHourlyRate(hrRaw, percent);
    const amount = otMin !== null && otMin > 0 ? calcOvertimeAmountFromMinutes(hrRaw, otMin, percent) : 0;
    const errors = validateTimes({ ...form, break_minutes: breakMin });
    return {
      emp, hr, hrRaw, breakMin,
      workedMin, regularMin, otMin,
      worked: workedMin !== null ? workedMin / 60 : null,
      regular: regularMin !== null ? regularMin / 60 : null,
      otHours: otMin !== null ? otMin / 60 : null,
      otRate, percent, amount, errors,
    };
  }, [form, employees]);

  const set = (k, v) => setForm((f) => ({ ...f, [k]: v }));

  // Ao selecionar funcionário, busca o cadastro e preenche jornada + intervalo automaticamente.
  // O usuário não precisa digitar esses dados — eles vêm do cadastro do funcionário.
  const pickEmployee = (id) => {
    const emp = employees.find((e) => e.id === id);
    setForm((f) => ({
      ...f,
      employee_id: id,
      regular_start: emp?.check_in_time || '',
      regular_end: emp?.check_out_time || '',
      break_start: emp?.break_start || '',
      break_end: emp?.break_end || '',
      break_minutes: emp?.break_minutes != null ? Number(emp.break_minutes) : 0,
      percent: emp?.overtime_percent || 50,
    }));
  };

  const openNew = () => { setEditing(null); setForm(empty); setOpen(true); };
  const openEdit = (o) => { setEditing(o); setForm({ ...empty, ...o }); setOpen(true); };

  const submit = async () => {
    if (!form.employee_id) return toast({ title: 'Selecione o funcionário', variant: 'destructive' });
    if (calc.errors.length) return toast({ title: 'Corrija os horários', description: calc.errors[0], variant: 'destructive' });
    if (calc.otHours === null || calc.otHours <= 0) return toast({ title: 'Sem horas extras', description: 'O tempo trabalhado não ultrapassou a jornada normal.', variant: 'destructive' });
    setSaving(true);
    try {
      const payload = {
        employee_id: form.employee_id,
        employee_name: calc.emp?.name || '',
        date: form.date,
        regular_start: form.regular_start, regular_end: form.regular_end,
        worked_start: form.worked_start, worked_end: form.worked_end,
        break_start: form.break_start || '',
        break_end: form.break_end || '',
        break_minutes: calc.breakMin,
        hours: calc.otMin !== null ? calc.otMin / 60 : 0,
        overtime_type: form.overtime_type,
        percent: Number(form.percent) || 50,
        hourly_rate: calc.hr,
        amount: calc.amount,
        competence_month: form.competence_month || currentCompetence(form.date),
        status: form.status || 'pending',
        notes: form.notes,
        registered_by: user?.email || '',
      };
      let saved;
      if (editing?.id) {
        saved = await base44.entities.Overtime.update(editing.id, payload);
        await logActivity({ action: 'overtime_update', description: `Editou hora extra de ${calc.emp?.name}`, user, entityType: 'Overtime', entityId: editing.id });
      } else {
        saved = await base44.entities.Overtime.create(payload);
        await logActivity({ action: 'overtime_create', description: `Hora extra de ${calc.emp?.name}: ${formatHoursMin(calc.otHours)}`, user, entityType: 'Overtime', entityId: saved.id });
      }
      toast({ title: 'Hora extra salva', description: `${formatHoursMin(calc.otHours)} — ${formatBRL(calc.amount)}` });
      setOpen(false);
      onReload?.();
    } catch (e) {
      toast({ title: 'Erro', description: e.message, variant: 'destructive' });
    } finally {
      setSaving(false);
    }
  };

  const approve = async (o) => {
    await base44.entities.Overtime.update(o.id, { status: 'approved' });
    toast({ title: 'Hora extra aprovada' });
    onReload?.();
  };
  const reject = async (o) => {
    await base44.entities.Overtime.update(o.id, { status: 'rejected' });
    toast({ title: 'Hora extra rejeitada' });
    onReload?.();
  };

  return (
    <div className="space-y-3">
      <div className="flex flex-col md:flex-row gap-2 md:items-center justify-between">
        <Select value={filterEmp} onValueChange={setFilterEmp}>
          <SelectTrigger className="md:w-64"><SelectValue placeholder="Filtrar por funcionário" /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">Todos funcionários</SelectItem>
            {employees.map((e) => <SelectItem key={e.id} value={e.id}>{e.name}</SelectItem>)}
          </SelectContent>
        </Select>
        <div className="flex items-center gap-3">
          <span className="text-sm text-muted-foreground">Aprovadas: <strong className="text-foreground">{formatBRL(total)}</strong></span>
          {can('Registrar horas extras') && <Button onClick={openNew}><Plus className="w-4 h-4" /> Nova hora extra</Button>}
        </div>
      </div>

      <div className="overflow-x-auto rounded-lg border border-border">
        <table className="w-full text-sm">
          <thead className="bg-muted/50 text-muted-foreground">
            <tr>
              <th className="text-left px-3 py-2 font-medium">Funcionário</th>
              <th className="text-left px-3 py-2 font-medium">Data</th>
              <th className="text-left px-3 py-2 font-medium hidden md:table-cell">Horário</th>
              <th className="text-right px-3 py-2 font-medium">Horas extras</th>
              <th className="text-left px-3 py-2 font-medium hidden md:table-cell">Tipo</th>
              <th className="text-right px-3 py-2 font-medium hidden md:table-cell">%</th>
              <th className="text-right px-3 py-2 font-medium">Valor</th>
              <th className="text-center px-3 py-2 font-medium">Status</th>
              <th className="text-center px-3 py-2 font-medium">Ações</th>
            </tr>
          </thead>
          <tbody>
            {filtered.length === 0 && <tr><td colSpan={9} className="text-center py-8 text-muted-foreground">Nenhuma hora extra registrada.</td></tr>}
            {filtered.map((o) => {
              const st = STATUS[o.status] || STATUS.pending;
              return (
                <tr key={o.id} className="border-t border-border hover:bg-muted/30">
                  <td className="px-3 py-2 font-medium">{o.employee_name}</td>
                  <td className="px-3 py-2">{formatDate(o.date)}</td>
                  <td className="px-3 py-2 hidden md:table-cell text-muted-foreground text-xs">
                    {o.worked_start && o.worked_end ? `${o.worked_start}–${o.worked_end}` : '—'}
                  </td>
                  <td className="px-3 py-2 text-right">{formatHoursMin(o.hours)}</td>
                  <td className="px-3 py-2 hidden md:table-cell text-muted-foreground">{TYPES.find((t) => t.key === o.overtime_type)?.label || o.overtime_type}</td>
                  <td className="px-3 py-2 text-right hidden md:table-cell">{o.percent}%</td>
                  <td className="px-3 py-2 text-right font-medium">{formatBRL(o.amount)}</td>
                  <td className="px-3 py-2 text-center"><span className={`text-xs px-2 py-0.5 rounded-full ${st.cls}`}>{st.label}</span></td>
                  <td className="px-3 py-2">
                    <div className="flex items-center justify-center gap-1">
                      {can('Registrar horas extras') && o.status === 'pending' && (
                        <>
                          <Button variant="ghost" size="icon" onClick={() => approve(o)} title="Aprovar"><Check className="w-4 h-4 text-green-600" /></Button>
                          <Button variant="ghost" size="icon" onClick={() => reject(o)} title="Rejeitar"><X className="w-4 h-4 text-red-600" /></Button>
                        </>
                      )}
                      {can('Registrar horas extras') && (
                        <Button variant="ghost" size="icon" onClick={() => openEdit(o)} title="Editar"><Pencil className="w-4 h-4" /></Button>
                      )}
                    </div>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>

      <Dialog open={open} onOpenChange={(op) => !op && setOpen(false)}>
        <DialogContent className="max-w-lg max-h-[90vh] overflow-y-auto">
          <DialogHeader><DialogTitle>{editing?.id ? 'Editar hora extra' : 'Nova hora extra'}</DialogTitle></DialogHeader>
          <div className="space-y-3">
            <div>
              <Label>Funcionário *</Label>
              <EmployeePicker employees={employees} value={form.employee_id} onChange={pickEmployee} />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div><Label>Data *</Label><Input type="date" value={form.date} onChange={(e) => set('date', e.target.value)} /></div>
              <div><Label>Competência</Label><Input type="month" value={form.competence_month} onChange={(e) => set('competence_month', e.target.value)} /></div>
            </div>

            <div className="rounded-lg border border-blue-200 bg-blue-50/40 p-3 space-y-2">
              <div className="flex items-center justify-between">
                <p className="text-xs font-semibold text-blue-700">DADOS DA JORNADA DO CADASTRO</p>
                <span className="text-[10px] text-blue-600/70">Somente consulta — altere no cadastro do funcionário</span>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div><Label className="text-xs">Entrada prevista</Label><Input type="time" value={form.regular_start || ''} disabled className="bg-white" /></div>
                <div><Label className="text-xs">Saída prevista</Label><Input type="time" value={form.regular_end || ''} disabled className="bg-white" /></div>
              </div>
            </div>

            <div className="rounded-lg border border-amber-200 bg-amber-50/40 p-3 space-y-2">
              <p className="text-xs font-semibold text-amber-700">Intervalo cadastrado (não conta como trabalhado)</p>
              <div className="grid grid-cols-2 gap-3">
                <div><Label className="text-xs">Início</Label><Input type="time" value={form.break_start || ''} disabled className="bg-white" /></div>
                <div><Label className="text-xs">Término</Label><Input type="time" value={form.break_end || ''} disabled className="bg-white" /></div>
              </div>
              {calc.breakMin > 0 && (
                <p className="text-xs text-amber-800">Duração do intervalo: <strong>{formatHoursMin(calc.breakMin / 60)}</strong></p>
              )}
            </div>

            <div className="rounded-lg border border-green-200 bg-green-50/40 p-3 space-y-2">
              <p className="text-xs font-semibold text-green-700">Horário realizado (informe somente o que foi trabalhado)</p>
              <div className="grid grid-cols-2 gap-3">
                <div><Label className="text-xs">Entrada real *</Label><Input type="time" value={form.worked_start || ''} onChange={(e) => set('worked_start', e.target.value)} /></div>
                <div><Label className="text-xs">Saída real *</Label><Input type="time" value={form.worked_end || ''} onChange={(e) => set('worked_end', e.target.value)} /></div>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <Label>Tipo</Label>
                <Select value={form.overtime_type} onValueChange={(v) => set('overtime_type', v)}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>{TYPES.map((t) => <SelectItem key={t.key} value={t.key}>{t.label}</SelectItem>)}</SelectContent>
                </Select>
              </div>
              <div><Label>Percentual (%)</Label><Input type="number" value={form.percent} onChange={(e) => set('percent', e.target.value)} /></div>
            </div>

            {/* Resultado automático */}
            <div className="rounded-lg border-2 border-slate-200 bg-slate-50 p-3 space-y-2">
              <p className="text-xs font-semibold text-slate-600">Cálculo automático (precisão de minutos)</p>
              <div className="grid grid-cols-2 gap-3 text-sm">
                <div className="flex justify-between"><span className="text-muted-foreground">Jornada prevista:</span><span className="font-medium">{calc.regular !== null ? formatHoursMin(calc.regular) : '—'}</span></div>
                <div className="flex justify-between"><span className="text-muted-foreground">Tempo total:</span><span className="font-medium">{calc.worked !== null ? formatHoursMin((calc.workedMin + calc.breakMin) / 60) : '—'}</span></div>
                <div className="flex justify-between"><span className="text-muted-foreground">Intervalo:</span><span className="font-medium">{calc.breakMin > 0 ? formatHoursMin(calc.breakMin / 60) : '0h00min'}</span></div>
                <div className="flex justify-between"><span className="text-muted-foreground">Tempo trabalhado:</span><span className="font-medium">{calc.worked !== null ? formatHoursMin(calc.worked) : '—'}</span></div>
                <div className="flex justify-between"><span className="text-muted-foreground">Horas extras:</span><span className="font-medium text-blue-700">{calc.otHours !== null && calc.otHours > 0 ? formatHoursMin(calc.otHours) : '—'}</span></div>
                <div className="flex justify-between"><span className="text-muted-foreground">Valor da hora normal:</span><span className="font-medium">{formatBRL(calc.hr)}</span></div>
                <div className="flex justify-between"><span className="text-muted-foreground">Adicional:</span><span className="font-medium">{calc.percent}%</span></div>
                <div className="flex justify-between"><span className="text-muted-foreground">Valor da hora extra:</span><span className="font-medium">{formatBRL(calc.otRate)}</span></div>
              </div>
              <div className="grid grid-cols-2 gap-3 pt-2 border-t border-slate-200">
                <div>
                  <Label className="text-xs">Horas extras</Label>
                  <Input value={calc.otHours !== null && calc.otHours > 0 ? formatHoursMin(calc.otHours) : '—'} disabled className="bg-white font-bold text-blue-700" />
                </div>
                <div>
                  <Label className="text-xs">Valor total das horas extras</Label>
                  <Input value={formatBRL(calc.amount)} disabled className="bg-white font-bold text-green-700" />
                </div>
              </div>
            </div>

            {calc.errors.length > 0 && (
              <div className="rounded-lg border border-amber-300 bg-amber-50 p-3 flex items-start gap-2">
                <AlertTriangle className="w-4 h-4 text-amber-600 mt-0.5 shrink-0" />
                <div className="text-xs text-amber-800 space-y-0.5">
                  {calc.errors.map((e, i) => <p key={i}>{e}</p>)}
                </div>
              </div>
            )}

            <div><Label>Observação</Label><Textarea rows={2} value={form.notes} onChange={(e) => set('notes', e.target.value)} /></div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setOpen(false)} disabled={saving}>Cancelar</Button>
            <Button onClick={submit} disabled={saving || calc.errors.length > 0 || calc.otHours === null || calc.otHours <= 0}>{saving ? 'Salvando...' : 'Salvar'}</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}