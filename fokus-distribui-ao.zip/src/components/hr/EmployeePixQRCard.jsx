import React, { useState, useEffect } from 'react';
import QRCode from 'qrcode';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { QrCode, Copy, Check, KeyRound, Loader2, Download } from 'lucide-react';
import { generatePixBrCode, identifyPixKeyType } from '@/lib/pixBrCode';
import { formatBRL } from '@/lib/format';

const TYPE_BADGE = {
  phone: { label: 'Telefone', cls: 'bg-blue-100 text-blue-800' },
  cpf: { label: 'CPF', cls: 'bg-green-100 text-green-800' },
  cnpj: { label: 'CNPJ', cls: 'bg-green-100 text-green-800' },
  email: { label: 'E-mail', cls: 'bg-purple-100 text-purple-800' },
  random: { label: 'Chave aleatória', cls: 'bg-amber-100 text-amber-800' },
  unknown: { label: 'Não informada', cls: 'bg-gray-100 text-gray-600' },
};

/**
 * Card que gera o QR Code (BR Code) PIX a partir da chave do funcionário.
 * Identifica automaticamente o tipo da chave (telefone, CPF, CNPJ, e-mail ou aleatória).
 */
export default function EmployeePixQRCard({ employee, settings, amount }) {
  const [key, setKey] = useState(employee?.pix_key || '');
  const [qrDataUrl, setQrDataUrl] = useState('');
  const [brCode, setBrCode] = useState('');
  const [copied, setCopied] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  useEffect(() => { setKey(employee?.pix_key || ''); }, [employee?.pix_key]);

  const keyInfo = identifyPixKeyType(key);
  const badge = TYPE_BADGE[keyInfo.type] || TYPE_BADGE.unknown;
  const value = amount && Number(amount) > 0 ? Number(amount) : 0;

  const generate = async (keyToUse) => {
    const k = String(keyToUse || '').trim();
    if (!k) { setError('Informe a chave PIX.'); setQrDataUrl(''); setBrCode(''); return; }
    setLoading(true); setError('');
    try {
      const code = generatePixBrCode({
        key: k,
        amount: value || undefined,
        beneficiary: settings?.pix_beneficiary_name || settings?.company_name || employee?.name || '',
        city: settings?.pix_city || '',
      });
      setBrCode(code);
      const url = await QRCode.toDataURL(code, { width: 240, margin: 1, color: { dark: '#000000', light: '#ffffff' } });
      setQrDataUrl(url);
    } catch (e) {
      setError(e.message || 'Erro ao gerar QR Code.');
      setQrDataUrl(''); setBrCode('');
    } finally { setLoading(false); }
  };

  useEffect(() => {
    if (key.trim()) generate(key);
    else { setQrDataUrl(''); setBrCode(''); }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [key, value]);

  const handleCopy = async () => {
    if (!brCode) return;
    try { await navigator.clipboard.writeText(brCode); setCopied(true); setTimeout(() => setCopied(false), 2000); } catch { /* ignore */ }
  };

  const handleDownload = () => {
    if (!qrDataUrl) return;
    const a = document.createElement('a');
    a.href = qrDataUrl;
    a.download = `pix-${employee?.name || 'funcionario'}.png`;
    a.click();
  };

  if (!employee?.pix_key) {
    return (
      <div className="rounded-lg border border-dashed border-border p-4 text-center">
        <KeyRound className="w-6 h-6 mx-auto text-muted-foreground mb-2" />
        <p className="text-sm text-muted-foreground">Nenhuma chave PIX cadastrada para este funcionário.</p>
      </div>
    );
  }

  return (
    <div className="rounded-lg border border-border p-4 space-y-3">
      <div className="flex items-center gap-2">
        <QrCode className="w-4 h-4 text-blue-600" />
        <p className="text-sm font-semibold">QR Code PIX</p>
        <span className={`ml-auto text-[11px] px-2 py-0.5 rounded-full ${badge.cls}`}>{badge.label}</span>
      </div>

      <div className="space-y-1.5">
        <Label className="text-xs flex items-center gap-1.5"><KeyRound className="w-3.5 h-3.5" /> Chave PIX</Label>
        <Input value={key} onChange={(e) => setKey(e.target.value)} placeholder="Chave PIX do funcionário" />
      </div>

      {value > 0 && (
        <div className="flex justify-between text-sm rounded-md bg-muted/40 px-2 py-1.5">
          <span className="text-muted-foreground">Valor</span>
          <span className="font-bold text-blue-700">{formatBRL(value)}</span>
        </div>
      )}

      <div className="flex flex-col items-center gap-2">
        {loading ? (
          <div className="w-40 h-40 flex items-center justify-center"><Loader2 className="w-6 h-6 animate-spin text-muted-foreground" /></div>
        ) : qrDataUrl ? (
          <img src={qrDataUrl} alt="QR Code PIX" className="w-40 h-40 rounded-lg border border-border" />
        ) : (
          <div className="w-40 h-40 flex items-center justify-center text-center text-xs text-muted-foreground border-2 border-dashed border-border rounded-lg">
            {error || 'Informe a chave para gerar o QR Code.'}
          </div>
        )}
        {qrDataUrl && (
          <Button variant="outline" size="sm" onClick={handleDownload} className="gap-2">
            <Download className="w-4 h-4" /> Baixar imagem
          </Button>
        )}
      </div>

      {brCode && (
        <div className="space-y-1.5">
          <Label className="text-xs">PIX Copia e Cola</Label>
          <div className="flex gap-2">
            <Input readOnly value={brCode} className="font-mono text-xs" />
            <Button variant="outline" size="icon" onClick={handleCopy} title="Copiar">
              {copied ? <Check className="w-4 h-4 text-green-600" /> : <Copy className="w-4 h-4" />}
            </Button>
          </div>
        </div>
      )}

      {error && <p className="text-xs text-red-600 text-center">{error}</p>}
    </div>
  );
}