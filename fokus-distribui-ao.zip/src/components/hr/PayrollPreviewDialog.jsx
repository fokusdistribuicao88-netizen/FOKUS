import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import {
  Eye, Printer, FileDown, Lock, Unlock, Loader2, AlertTriangle, Share2,
} from 'lucide-react';
import { formatBRL } from '@/lib/format';
import { formatHoursMin, overtimeHourlyRate } from '@/lib/payrollCalc';
import {
  previewPayrollPdf, printPayrollPdf, generatePayrollPdf, sharePayrollPdf, competenceLabel,
} from '@/lib/payrollPdf';
import { useToast } from '@/components/ui/use-toast';

function Field({ label, value, strong = false, muted = false }) {
  return (
    <div className="flex justify-between py-1.5 border-b border-border last:border-0">
      <span className={`text-sm ${muted ? 'text-muted-foreground' : ''}`}>{label}</span>
      <span className={`text-sm tabular-nums ${strong ? 'font-bold' : 'font-medium'}`}>{value}</span>
    </div>
  );
}

export default function PayrollPreviewDialog({
  open, onClose, employee, summary, competence, existing, settings, user, can,
  onClosePayroll, onReopenPayroll,
}) {
  const { toast } = useToast();
  const [busy, setBusy] = useState(null);
  const [confirmClose, setConfirmClose] = useState(false);
  const [reopenMode, setReopenMode] = useState(false);
  const [reason, setReason] = useState('');

  if (!employee || !summary) return null;

  const isClosed = existing?.status === 'closed' || existing?.status === 'paid';
  const isPreview = !isClosed;

  const payrollForPdf = existing || {
    id: '',
    employee_id: employee.id,
    employee_name: employee.name,
    competence_month: competence,
    base_salary: summary.baseSalary,
    overtime_total: summary.overtimeTotal,
    overtime_hours: summary.overtimeHours,
    overtime_percent: summary.overtimePercent,
    hourly_rate: summary.hourlyRate,
    weekly_hours: summary.weeklyHours,
    bonus: summary.bonus,
    additions: summary.additions,
    gross_salary: summary.grossSalary,
    inss: summary.inss,
    advances_total: summary.advancesTotal,
    purchases_total: summary.purchasesTotal,
    other_discounts: summary.otherDiscounts,
    total_discounts: summary.totalDiscounts,
    net_salary: summary.netSalary,
    closed_at: '',
    closed_by: '',
  };

  const run = async (key, fn) => {
    setBusy(key);
    try { await fn(); }
    catch (e) { toast({ title: 'Erro', description: e.message, variant: 'destructive' }); }
    finally { setBusy(null); }
  };

  const handlePreview = () => run('preview', () => previewPayrollPdf({ payroll: payrollForPdf, employee, settings, isPreview, user }));
  const handlePrint = () => run('print', () => printPayrollPdf({ payroll: payrollForPdf, employee, settings, isPreview, user }));
  const handlePdf = () => run('pdf', () => generatePayrollPdf({ payroll: payrollForPdf, employee, settings, isPreview, user }));
  const handleShare = () => run('share', async () => {
    const { shared } = await sharePayrollPdf({ payroll: payrollForPdf, employee, settings, isPreview, user });
    toast({ title: shared ? 'Compartilhando PDF' : 'PDF baixado', description: shared ? 'Escolha o aplicativo para enviar.' : 'Compartilhamento não suportado — PDF baixado.' });
  });

  const handleConfirmClose = async () => {
    setBusy('close');
    try {
      await onClosePayroll?.();
      setConfirmClose(false);
    } catch (e) {
      toast({ title: 'Erro', description: e.message, variant: 'destructive' });
    } finally { setBusy(null); }
  };

  const handleReopen = async () => {
    if (!reason.trim()) { toast({ title: 'Informe o motivo da reabertura', variant: 'destructive' }); return; }
    setBusy('reopen');
    try {
      await onReopenPayroll?.(reason);
      setReopenMode(false);
      setReason('');
    } catch (e) {
      toast({ title: 'Erro', description: e.message, variant: 'destructive' });
    } finally { setBusy(null); }
  };

  return (
    <Dialog open={open} onOpenChange={(o) => { if (!o) { setConfirmClose(false); setReopenMode(false); setReason(''); } onClose?.(); }}>
      <DialogContent className="max-w-3xl max-h-[92vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 flex-wrap">
            <span>Folha de Pagamento</span>
            <Badge variant={isPreview ? 'secondary' : 'default'} className={isPreview ? 'bg-amber-100 text-amber-800' : 'bg-green-100 text-green-800'}>
              {isPreview ? 'PRÉVIA — FOLHA AINDA NÃO FECHADA' : existing?.status === 'paid' ? 'FOLHA PAGA' : 'FOLHA DE PAGAMENTO — FECHADA'}
            </Badge>
          </DialogTitle>
          <DialogDescription>
            {employee.name} — Competência {competenceLabel(competence)}
          </DialogDescription>
        </DialogHeader>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="rounded-lg border border-green-200 bg-green-50/40 p-4">
            <p className="text-sm font-semibold mb-2 text-green-700">Proventos</p>
            <Field label="Salário base" value={formatBRL(summary.baseSalary)} />
            {summary.overtimeTotal > 0 && (
              <div className="py-1.5 border-b border-border last:border-0">
                <div className="flex justify-between">
                  <span className="text-sm text-muted-foreground">Horas extras</span>
                  <span className="text-sm tabular-nums font-medium">{formatBRL(summary.overtimeTotal)}</span>
                </div>
                <div className="flex flex-wrap gap-x-4 gap-y-0.5 mt-1 text-xs text-muted-foreground">
                  <span>Qtde: <strong className="text-foreground">{formatHoursMin(summary.overtimeHours || 0)}</strong></span>
                  <span>Adicional: <strong className="text-foreground">{summary.overtimePercent || 50}%</strong></span>
                  <span>Hora normal: <strong className="text-foreground">{formatBRL(summary.hourlyRate)}</strong></span>
                  <span>Hora extra: <strong className="text-foreground">{formatBRL(overtimeHourlyRate(summary.hourlyRate, summary.overtimePercent || 50))}</strong></span>
                </div>
              </div>
            )}
            {summary.overtimeTotal === 0 && <Field label="Horas extras" value={formatBRL(0)} muted />}
            {summary.fixedBonusValue > 0 && <Field label="Bonificação fixa" value={formatBRL(summary.fixedBonusValue)} muted />}
            {summary.variableBonusTotal > 0 && <Field label="Bonificação variável" value={formatBRL(summary.variableBonusTotal)} muted />}
            {summary.fixedBonusValue === 0 && summary.variableBonusTotal === 0 && <Field label="Bonificações" value={formatBRL(0)} muted />}
            <Field label="Outros proventos" value={formatBRL(summary.additions)} muted />
            <Field label="Salário bruto" value={formatBRL(summary.grossSalary)} strong />
          </div>

          <div className="rounded-lg border border-red-200 bg-red-50/40 p-4">
            <p className="text-sm font-semibold mb-2 text-red-700">Descontos</p>
            <Field label="INSS" value={formatBRL(summary.inss)} muted />
            {summary.negativeBalanceTotal > 0 && (
              <Field label="Saldo negativo folha anterior" value={formatBRL(summary.negativeBalanceTotal)} muted />
            )}
            <Field label="Adiantamentos" value={formatBRL(summary.regularAdvancesTotal)} muted />
            <Field label="Compras descontadas" value={formatBRL(summary.purchasesTotal)} muted />
            <Field label="Outros descontos" value={formatBRL(summary.otherDiscounts)} muted />
            <Field label="Total de descontos" value={formatBRL(summary.totalDiscounts)} strong />
          </div>
        </div>

        <div className="rounded-lg border-2 border-blue-200 bg-blue-50 p-4 flex items-center justify-between">
          <div>
            <p className="text-sm text-muted-foreground">Salário líquido</p>
            <p className="text-2xl font-bold text-blue-900">{formatBRL(summary.netSalary)}</p>
          </div>
          {isClosed && existing?.closed_at && (
            <div className="text-xs text-muted-foreground text-right">
              <p>Fechada em {new Date(existing.closed_at).toLocaleString('pt-BR')}</p>
              <p>Por: {existing.closed_by || '—'}</p>
            </div>
          )}
        </div>

        {isClosed && existing?.negative_balance_transferred && Number(existing.negative_balance) > 0 && (
          <div className="rounded-lg border-2 border-amber-300 bg-amber-50 p-4 space-y-1.5">
            <p className="text-sm font-semibold text-amber-900 flex items-center gap-1.5">
              <AlertTriangle className="w-4 h-4" /> Valor Devedor Transferido
            </p>
            <div className="flex justify-between text-sm">
              <span className="text-amber-800">Resultado da folha</span>
              <span className="font-bold text-red-700">-{formatBRL(Number(existing.negative_balance))}</span>
            </div>
            <div className="flex justify-between text-sm">
              <span className="text-amber-800">Valor transferido para a próxima folha</span>
              <span className="font-bold text-amber-900">{formatBRL(Number(existing.negative_balance))}</span>
            </div>
            <p className="text-xs text-amber-700 mt-1">
              O saldo devedor foi lançado como adiantamento e será descontado automaticamente na próxima competência.
            </p>
          </div>
        )}

        {isClosed && (
          <div className="rounded-lg border border-border p-3 text-xs text-muted-foreground space-y-1">
            <p><strong>Competência:</strong> {competenceLabel(competence)}</p>
            <p><strong>Data de fechamento:</strong> {existing?.closed_at ? new Date(existing.closed_at).toLocaleString('pt-BR') : '—'}</p>
            <p><strong>Usuário:</strong> {existing?.closed_by || '—'}</p>
          </div>
        )}

        {/* Confirmação de fechamento */}
        {confirmClose && (
          <div className="rounded-lg border-2 border-amber-300 bg-amber-50 p-4 space-y-3">
            <p className="text-sm font-semibold text-amber-900">Confirmar fechamento da folha</p>
            <p className="text-sm text-amber-800">
              Você está prestes a fechar a folha de <strong>{competenceLabel(competence)}</strong>.
              Após o fechamento, os valores serão registrados e utilizados nas despesas e relatórios da empresa.
            </p>
            <div className="flex gap-2 justify-end">
              <Button variant="outline" size="sm" onClick={() => setConfirmClose(false)} disabled={busy === 'close'}>Cancelar</Button>
              <Button size="sm" className="bg-amber-600 hover:bg-amber-700" onClick={handleConfirmClose} disabled={busy === 'close'}>
                {busy === 'close' ? <><Loader2 className="w-4 h-4 animate-spin" /> Fechando...</> : <><Lock className="w-4 h-4" /> Confirmar fechamento</>}
              </Button>
            </div>
          </div>
        )}

        {/* Reabertura */}
        {reopenMode && (
          <div className="rounded-lg border-2 border-orange-300 bg-orange-50 p-4 space-y-3">
            <p className="text-sm font-semibold text-orange-900">Reabrir folha (administrador)</p>
            <p className="text-sm text-orange-800">Ao reabrir, a folha voltará ao estado aberta para correção. Uma cópia da versão atual será preservada no histórico.</p>
            <div>
              <Label>Motivo da reabertura *</Label>
              <Textarea rows={2} value={reason} onChange={(e) => setReason(e.target.value)} placeholder="Informe o motivo..." />
            </div>
            <div className="flex gap-2 justify-end">
              <Button variant="outline" size="sm" onClick={() => { setReopenMode(false); setReason(''); }} disabled={busy === 'reopen'}>Cancelar</Button>
              <Button size="sm" variant="destructive" onClick={handleReopen} disabled={busy === 'reopen'}>
                {busy === 'reopen' ? <><Loader2 className="w-4 h-4 animate-spin" /> Reabrindo...</> : <><Unlock className="w-4 h-4" /> Reabrer folha</>}
              </Button>
            </div>
          </div>
        )}

        {!employee?.pix_key && (
          <div className="rounded-lg border border-amber-300 bg-amber-50 p-3 flex items-center justify-between gap-3">
            <div className="text-sm text-amber-800">
              <p className="font-semibold">Funcionário não possui chave PIX cadastrada.</p>
              <p className="text-xs">O QR Code PIX não será gerado no PDF da folha. Cadastre a chave PIX do funcionário para habilitar o pagamento via PIX.</p>
            </div>
            <Link to="/employees" className="text-xs text-amber-900 font-semibold underline shrink-0 hover:text-amber-700">Cadastrar PIX</Link>
          </div>
        )}

        <DialogFooter className="flex-wrap gap-2 sm:flex-nowrap">
          <Button variant="outline" size="sm" onClick={handlePreview} disabled={!!busy}>
            {busy === 'preview' ? <Loader2 className="w-4 h-4 animate-spin" /> : <Eye className="w-4 h-4" />}
            {isPreview ? 'Visualizar Folha' : 'Visualizar Folha Fechada'}
          </Button>
          <Button variant="outline" size="sm" onClick={handlePrint} disabled={!!busy}>
            {busy === 'print' ? <Loader2 className="w-4 h-4 animate-spin" /> : <Printer className="w-4 h-4" />} Imprimir
          </Button>
          <Button variant="outline" size="sm" onClick={handlePdf} disabled={!!busy}>
            {busy === 'pdf' ? <Loader2 className="w-4 h-4 animate-spin" /> : <FileDown className="w-4 h-4" />} Gerar PDF
          </Button>
          <Button variant="outline" size="sm" onClick={handleShare} disabled={!!busy}>
            {busy === 'share' ? <Loader2 className="w-4 h-4 animate-spin" /> : <Share2 className="w-4 h-4" />} Compartilhar
          </Button>
          {isPreview && can('Fechar folha') && !confirmClose && (
            <Button size="sm" className="bg-green-600 hover:bg-green-700" onClick={() => setConfirmClose(true)} disabled={!!busy}>
              <Lock className="w-4 h-4" /> Fechar Folha
            </Button>
          )}
          {isClosed && user?.role === 'admin' && !reopenMode && (
            <Button size="sm" variant="destructive" onClick={() => setReopenMode(true)} disabled={!!busy}>
              <Unlock className="w-4 h-4" /> Reabrir Folha
            </Button>
          )}
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}