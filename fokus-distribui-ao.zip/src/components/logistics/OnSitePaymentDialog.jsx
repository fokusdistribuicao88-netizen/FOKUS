import React, { useState, useMemo } from 'react';
import { useQuery } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { useAuth } from '@/lib/AuthContext';
import { useToast } from '@/components/ui/use-toast';
import PaymentDialog from '@/components/pos/PaymentDialog';
import OrderPrintDialog from '@/components/orders/OrderPrintDialog';
import DeliveryConfirmDialog from '@/components/logistics/DeliveryConfirmDialog';
import { registerOnSitePayment, confirmDelivery } from '@/lib/onSiteReceiptService';
import { findEmployeeForCustomer } from '@/lib/employeePurchaseSync';
import { logActivity } from '@/lib/activityLog';
import { fmt } from '@/components/pos/payment/paymentMethods';
import { formatCurrency } from '@/components/orders/orderStatus';
import { canOverrideCreditLimit } from '@/lib/userRoles';
import { checkCreditForSale } from '@/lib/customerAccountService';
import { findCustomerByEmailOrPhone } from '@/lib/customerLookup';
import CreditLimitDialog from '@/components/customeraccounts/CreditLimitDialog';

const TERM_METHODS = ['contas_receber', 'convenio', 'crediario', 'credit', 'boleto', 'transfer', 'cheque'];
const termAmountOf = (payments) => (payments || []).filter((p) => TERM_METHODS.includes(p.method)).reduce((s, p) => s + (Number(p.amount) || 0), 0);

/**
 * Wrapper da Logística que reaproveita o PaymentDialog centralizado (PDV/Pedidos)
 * para registrar o recebimento no local da entrega. Mesmas regras, cálculos e
 * componentes — nenhum terceiro sistema de pagamentos.
 */
export default function OnSitePaymentDialog({ open, order, onClose, onRegistered }) {
  const { user } = useAuth();
  const { toast } = useToast();
  const [busy, setBusy] = useState(false);
  const [creditIssue, setCreditIssue] = useState(null);
  const [creditBypass, setCreditBypass] = useState(false);
  const [printOpen, setPrintOpen] = useState(false);
  const [lastResult, setLastResult] = useState(null);
  const [deliveryOrder, setDeliveryOrder] = useState(null);
  const [deliveryOpen, setDeliveryOpen] = useState(false);
  const canOverride = canOverrideCreditLimit(user?.role);

  const { data: settings } = useQuery({
    queryKey: ['settings'],
    queryFn: async () => {
      const list = await base44.entities.Settings.list('-updated_date', 1);
      return list[0] || null;
    },
  });

  const { data: employees = [] } = useQuery({
    queryKey: ['employees'],
    queryFn: () => base44.entities.Employee.list(),
    staleTime: 60 * 1000,
  });

  const { data: products = [] } = useQuery({
    queryKey: ['products'],
    queryFn: () => base44.entities.Product.list(),
    staleTime: 60 * 1000,
  });

  const cart = useMemo(() => (order?.items || []).map((i) => ({
    product_id: i.product_id, product_name: i.product_name,
    quantity: i.quantity, unit_price: i.unit_price, subtotal: i.subtotal,
  })), [order]);

  const customer = useMemo(() => {
    if (!order) return null;
    const base = {
      name: order.customer_name || 'Consumidor Final',
      phone: order.customer_phone || '',
      email: order.customer_email || '',
      cpf_cnpj: order.cpf_cnpj || '',
      address: order.customer_address || '',
      city: order.city || '',
      state: order.state || '',
    };
    const matched = findEmployeeForCustomer(base, employees);
    if (matched) return { ...base, ...matched, _isEmployee: true };
    return base;
  }, [order, employees]);

  const orderTotal = Number(order?.total) || 0;
  const alreadyPaid = useMemo(() => {
    const history = order?.receipt_history || [];
    const lastBalance = history.length ? Number(history[history.length - 1].balance_after) : null;
    if (lastBalance != null && !isNaN(lastBalance)) return Math.max(0, orderTotal - lastBalance);
    const fromHistory = history.reduce((s, r) => s + (Number(r.amount_received) || 0), 0);
    return fromHistory || Number(order?.on_site_payment?.amount_received) || 0;
  }, [order]);
  const remaining = Math.max(0, orderTotal - alreadyPaid);

  const productMap = useMemo(() => {
    const m = {};
    (products || []).forEach((p) => { m[p.id] = p; });
    return m;
  }, [products]);

  const headerInfo = order ? (
    <div className="rounded-xl border-2 border-amber-300 bg-amber-50 p-3">
      <p className="text-xs font-semibold text-amber-900 uppercase mb-2">Recebimento no Local da Entrega</p>
      <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 text-sm">
        <div>
          <p className="text-[10px] uppercase text-amber-700/80">Cliente</p>
          <p className="font-semibold text-amber-900 break-words">{order.customer_name}</p>
        </div>
        <div>
          <p className="text-[10px] uppercase text-amber-700/80">Pedido</p>
          <p className="font-semibold text-amber-900">#{(order.id || '').substring(0, 8).toUpperCase()}</p>
        </div>
        <div>
          <p className="text-[10px] uppercase text-amber-700/80">Valor do pedido</p>
          <p className="font-semibold text-amber-900">{formatCurrency(orderTotal)}</p>
        </div>
        <div>
          <p className="text-[10px] uppercase text-amber-700/80">Já pago</p>
          <p className="font-semibold text-amber-900">{formatCurrency(alreadyPaid)}</p>
        </div>
        <div className="col-span-2 sm:col-span-1">
          <p className="text-[10px] uppercase text-amber-700/80">A receber</p>
          <p className="font-bold text-amber-900 text-lg">{formatCurrency(remaining)}</p>
        </div>
      </div>
    </div>
  ) : null;

  const handleConfirm = async (payments, delivery, finalTotal, payrollDiscount) => {
    if (!order) return;
    const isEmployeeCrediario = !!payrollDiscount?.enabled && payrollDiscount?.type === 'crediario' && payrollDiscount?.employee;
    const termAmount = termAmountOf(payments);
    if (termAmount > 0 && !isEmployeeCrediario && !creditBypass) {
      try {
        const cust = await findCustomerByEmailOrPhone(order.customer_email, order.customer_phone);
        if (cust?.credit_limit > 0) {
          const check = await checkCreditForSale({ customer: cust, termAmount });
          if (!check.ok) {
            setCreditIssue(check);
            return;
          }
        }
      } catch { /* best-effort */ }
    }
    setBusy(true);
    try {
      const result = await registerOnSitePayment({ order, payments, user, payrollDiscount });
      setLastResult(result);
      const label = result.onSiteStatus === 'received' ? 'Recebimento quitado no local' : 'Recebimento parcial no local';
      const desc = result.balance > 0
        ? `Pedido #${result.saleCode} — Recebido ${fmt(result.receivedNow)} — Saldo ${fmt(result.balance)}`
        : `Pedido #${result.saleCode} — Recebido ${fmt(result.receivedNow)} — Recebimento completo`;
      toast({ title: label, description: desc });
      logActivity({
        action: 'logistics_on_site_receipt',
        description: `Recebimento no local — Pedido #${result.saleCode} — ${fmt(result.receivedNow)}${result.crediarioAmount > 0 ? ` + Crediário ${fmt(result.crediarioAmount)}` : ''}`,
        user_email: user?.email, user_name: user?.full_name || user?.email,
        entity_id: order.id, metadata: { received: result.receivedNow, crediario: result.crediarioAmount, balance: result.balance },
      });
      setLastResult(result);
      onRegistered?.(result.order);
      // Após o pagamento, NÃO conclui a entrega — abre etapa obrigatória de confirmação.
      setDeliveryOrder(result.order);
      setDeliveryOpen(true);
    } catch (e) {
      toast({ title: 'Erro ao registrar recebimento', description: String(e.message || e), variant: 'destructive' });
    } finally {
      setBusy(false);
      setCreditBypass(false);
    }
  };

  const handleDeliveryConfirmed = async (receiver) => {
    const target = deliveryOrder || order;
    if (!target) return;
    try {
      const res = await confirmDelivery({ order: target, receiver, user });
      toast({ title: 'Entrega confirmada', description: `Pedido #${res.saleCode} — Recebedor: ${res.receiverName}` });
      logActivity({
        action: 'logistics_delivery_confirmed',
        description: `Entrega confirmada — Pedido #${res.saleCode} — Recebedor: ${res.receiverName} (CPF ${receiver.receiver_document})`,
        user_email: user?.email, user_name: user?.full_name || user?.email,
        entity_id: target.id, metadata: { receiver_name: res.receiverName, receiver_document: receiver.receiver_document },
      });
      onRegistered?.(res.order);
      setDeliveryOpen(false);
      setDeliveryOrder(res.order);
      setLastResult({ ...lastResult, order: res.order });
      setPrintOpen(true); // comprovante de entrega disponível após confirmar
    } catch (e) {
      throw e;
    }
  };

  // Após fechar o pagamento, mantém o comprovante disponível (lastResult).
  if (!order && !lastResult && !deliveryOrder) return null;

  // Pedido já quitado no local: se ainda não foi entregue, vai direto à confirmação de entrega.
  if (order && open && remaining <= 0.01 && order.status !== 'delivered') {
    return (
      <>
        <DeliveryConfirmDialog
          open
          order={order}
          user={user}
          onClose={() => { onClose(); setLastResult(null); }}
          onConfirmed={handleDeliveryConfirmed}
        />
        <OrderPrintDialog
          open={printOpen}
          onClose={() => { setPrintOpen(false); onClose(); setLastResult(null); setDeliveryOrder(null); }}
          order={lastResult?.order || deliveryOrder || order}
          settings={settings}
          productMap={productMap}
        />
      </>
    );
  }

  // Pedido já quitado E já entregue — abre direto o comprovante.
  if (order && open && remaining <= 0.01 && order.status === 'delivered') {
    return (
      <OrderPrintDialog
        open={printOpen}
        onClose={() => { setPrintOpen(false); onClose(); setLastResult(null); }}
        order={order}
        settings={settings}
        productMap={productMap}
      />
    );
  }

  return (
    <>
      {order && (
        <PaymentDialog
          open={open}
          onClose={onClose}
          cart={cart}
          customer={customer}
          gross={remaining}
          discount={0}
          notes={order.notes || ''}
          total={remaining}
          canCredit={['admin', 'gerente', 'operador', 'motorista', 'auxiliar'].includes(user?.role)}
          canPartial={['admin', 'gerente', 'motorista', 'auxiliar'].includes(user?.role)}
          onConfirm={handleConfirm}
          onPrePrint={() => setPrintOpen(true)}
          operatorName={user?.full_name || user?.email}
          busy={busy}
          headerInfo={headerInfo}
          hideDelivery
          hidePayrollDiscount
          receiptMode
        />
      )}

      <OrderPrintDialog
        open={printOpen}
        onClose={() => { setPrintOpen(false); setLastResult(null); setDeliveryOrder(null); onClose(); }}
        order={lastResult?.order || deliveryOrder || order}
        settings={settings}
        productMap={productMap}
      />

      <DeliveryConfirmDialog
        open={deliveryOpen}
        order={deliveryOrder || order}
        user={user}
        onClose={() => { setDeliveryOpen(false); setDeliveryOrder(null); onClose(); }}
        onConfirmed={handleDeliveryConfirmed}
      />

      <CreditLimitDialog
        open={!!creditIssue}
        info={creditIssue}
        canOverride={canOverride}
        onClose={() => setCreditIssue(null)}
        onOverride={() => { setCreditBypass(true); setCreditIssue(null); }}
      />
    </>
  );
}