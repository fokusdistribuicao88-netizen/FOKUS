import React, { useState, useMemo } from 'react';
import {
  Search, Truck, UserCheck, CheckCircle2, XCircle, MoreHorizontal, Eye,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import {
  Select, SelectTrigger, SelectValue, SelectContent, SelectItem,
} from '@/components/ui/select';
import {
  DropdownMenu, DropdownMenuTrigger, DropdownMenuContent, DropdownMenuItem, DropdownMenuSeparator,
} from '@/components/ui/dropdown-menu';
import {
  LOGISTICS_STATUS, LOGISTICS_STATUS_LIST, formatCurrency, ORDER_STATUS,
  ON_SITE_PAYMENT_STATUS,
} from '@/components/orders/orderStatus';
import { canAssumeDelivery, canReassign, isDriver, canSetStatus, userDisplayName } from '@/lib/logistics';
import { Wallet } from 'lucide-react';

function Badge({ className, children }) {
  return <span className={`inline-flex items-center gap-1 px-1.5 py-0.5 rounded-full text-[10px] font-medium whitespace-nowrap ${className}`}>{children}</span>;
}

export default function LogisticsDeliveryTable({
  orders, users, user, onAction, onAssume, onReassign, onView, onRegisterReceipt, onConfirmDelivery,
}) {
  const [search, setSearch] = useState('');
  const [filterStatus, setFilterStatus] = useState('');
  const [filterDriver, setFilterDriver] = useState('');
  const [filterHelper, setFilterHelper] = useState('');
  const [filterDate, setFilterDate] = useState('');

  const drivers = useMemo(() => users.filter((u) => u.role === 'motorista'), [users]);
  const helpers = useMemo(() => users.filter((u) => u.role === 'auxiliar'), [users]);

  const filtered = useMemo(() => {
    const q = search.toLowerCase().trim();
    return orders.filter((o) => {
      if (q) {
        const hay = [o.id, o.customer_name, o.city, o.neighborhood, o.customer_address].filter(Boolean).join(' ').toLowerCase();
        if (!hay.includes(q)) return false;
      }
      if (filterStatus && o.status !== filterStatus) return false;
      if (filterDriver && o.driver_name !== filterDriver) return false;
      if (filterHelper && o.helper_name !== filterHelper) return false;
      if (filterDate) {
        const d = new Date(o.delivery_expected_date || o.created_date);
        const f = new Date(filterDate);
        if (d.toDateString() !== f.toDateString()) return false;
      }
      return true;
    });
  }, [orders, search, filterStatus, filterDriver, filterHelper, filterDate]);

  const fmtDate = (d) => d ? new Date(d).toLocaleDateString('pt-BR', { day: '2-digit', month: '2-digit' }) : '—';
  const shortCode = (id) => (id ? '#' + id.substring(0, 8).toUpperCase() : '—');

  return (
    <div className="bg-card border border-border rounded-2xl shadow-sm overflow-hidden">
      {/* Filters */}
      <div className="flex flex-wrap items-center gap-2 p-3 border-b border-border bg-muted/30">
        <div className="relative flex-1 min-w-[200px]">
          <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Buscar por pedido, cliente, cidade ou bairro..."
            className="pl-8 h-8"
          />
        </div>
        <Select value={filterStatus} onValueChange={(v) => setFilterStatus(v === 'all' ? '' : v)}>
          <SelectTrigger className="w-40 h-8"><SelectValue placeholder="Status" /></SelectTrigger>
          <SelectContent className="max-h-72">
            <SelectItem value="all">Todos os status</SelectItem>
            {LOGISTICS_STATUS_LIST.map((s) => <SelectItem key={s} value={s}>{LOGISTICS_STATUS[s].label}</SelectItem>)}
          </SelectContent>
        </Select>
        <Select value={filterDriver} onValueChange={(v) => setFilterDriver(v === 'all' ? '' : v)}>
          <SelectTrigger className="w-36 h-8"><SelectValue placeholder="Motorista" /></SelectTrigger>
          <SelectContent className="max-h-72">
            <SelectItem value="all">Todos motoristas</SelectItem>
            {drivers.map((d) => <SelectItem key={d.id} value={d.full_name || d.email}>{d.full_name || d.email}</SelectItem>)}
          </SelectContent>
        </Select>
        <Select value={filterHelper} onValueChange={(v) => setFilterHelper(v === 'all' ? '' : v)}>
          <SelectTrigger className="w-36 h-8"><SelectValue placeholder="Auxiliar" /></SelectTrigger>
          <SelectContent className="max-h-72">
            <SelectItem value="all">Todos auxiliares</SelectItem>
            {helpers.map((h) => <SelectItem key={h.id} value={h.full_name || h.email}>{h.full_name || h.email}</SelectItem>)}
          </SelectContent>
        </Select>
        <Input type="date" value={filterDate} onChange={(e) => setFilterDate(e.target.value)} className="w-full sm:w-44 h-8" />
      </div>

      <div className="overflow-x-auto">
        <table className="w-full text-xs table-fixed min-w-[680px]">
          <thead className="bg-muted/50 text-muted-foreground">
            <tr>
              <th className="text-left font-medium px-2 py-2 pr-6 w-28">Pedido</th>
              <th className="text-left font-medium px-2 py-2 pr-8 w-44">Cliente</th>
              <th className="text-right font-medium px-2 py-2 w-24">Valor</th>
              <th className="text-left font-medium px-2 py-2 w-20">Venda</th>
              <th className="text-left font-medium px-2 py-2 w-28">Status</th>
              <th className="text-right font-medium px-2 py-2 w-20">Ações</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-border">
            {filtered.length === 0 && (
              <tr><td colSpan={6} className="text-center py-10 text-muted-foreground">Nenhum pedido encontrado</td></tr>
            )}
            {filtered.map((order) => {
              const info = LOGISTICS_STATUS[order.status] || ORDER_STATUS[order.status] || { label: order.status, badge: 'bg-slate-100 text-slate-700' };
              const canAssume = canAssumeDelivery(user) && !order.driver_name && isDriver(user);
              const isOnSite = order.delivery_receipt_mode === 'on_site';
              const onSiteStatus = isOnSite ? (ON_SITE_PAYMENT_STATUS[order.on_site_payment_status] || ON_SITE_PAYMENT_STATUS.pending) : null;
              const onSiteReceived = isOnSite && order.on_site_payment_status === 'received';
              const onSitePaid = isOnSite && (order.on_site_payment_status === 'received' || order.on_site_payment_status === 'partial');
              const onSiteBalance = isOnSite ? Math.max(0, (Number(order.total) || 0) - (Number(order.on_site_payment?.amount_received) || 0)) : 0;
              const canConfirmDelivery = isOnSite && onSitePaid && order.status !== 'delivered' && onConfirmDelivery;
              return (
                <tr key={order.id} className={`hover:bg-muted/40 ${isOnSite && !onSiteReceived ? 'bg-amber-50/60' : ''}`}>
                  <td className="px-2 py-2 pr-6 font-medium">{shortCode(order.id)}</td>
                  <td className="px-2 py-2 pr-8 truncate">{order.customer_name}</td>
                  <td className="px-2 py-2 text-right font-medium whitespace-nowrap">{formatCurrency(order.total)}</td>
                  <td className="px-2 py-2 text-muted-foreground whitespace-nowrap">{fmtDate(order.created_date)}</td>
                  <td className="px-2 py-2">
                    <div className="flex flex-col gap-1">
                      <Badge className={info.badge}><span className={`w-1.5 h-1.5 rounded-full ${info.dot}`} />{info.label}</Badge>
                      {isOnSite && (
                        <Badge className={onSiteReceived ? 'bg-green-100 text-green-700' : 'bg-amber-100 text-amber-700'}>
                          <Wallet className="w-3 h-3" />
                          {onSiteReceived ? `✓ Recebido ${formatCurrency(order.on_site_payment?.amount_received || 0)}` : `💰 Receber ${formatCurrency(onSiteBalance)}`}
                        </Badge>
                      )}
                    </div>
                  </td>
                  <td className="px-2 py-2 text-right">
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button variant="ghost" size="icon" className="h-8 w-8"><MoreHorizontal className="w-4 h-4" /></Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end" className="w-52">
                        <DropdownMenuItem onClick={() => onView(order)}><Eye className="w-4 h-4 mr-2" /> Visualizar</DropdownMenuItem>
                        {canAssume && (
                          <DropdownMenuItem onClick={() => onAssume(order)}><Truck className="w-4 h-4 mr-2" /> Assumir entrega</DropdownMenuItem>
                        )}
                        {canSetStatus(user, 'occurrence') && (
                          <DropdownMenuItem onClick={() => onAction(order)}><CheckCircle2 className="w-4 h-4 mr-2" /> Atualizar status</DropdownMenuItem>
                        )}
                        {canReassign(user) && (
                          <DropdownMenuItem onClick={() => onReassign(order)}><UserCheck className="w-4 h-4 mr-2" /> Reatribuir equipe</DropdownMenuItem>
                        )}
                        {isOnSite && !onSiteReceived && onRegisterReceipt && (
                          <DropdownMenuItem onClick={() => onRegisterReceipt(order)} className="text-amber-700 focus:text-amber-800"><Wallet className="w-4 h-4 mr-2" /> Registrar recebimento</DropdownMenuItem>
                        )}
                        {canConfirmDelivery && (
                          <DropdownMenuItem onClick={() => onConfirmDelivery(order)} className="text-green-700 focus:text-green-800"><CheckCircle2 className="w-4 h-4 mr-2" /> Confirmar entrega</DropdownMenuItem>
                        )}
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>

      <div className="px-4 py-2 border-t border-border text-xs text-muted-foreground">
        {filtered.length} pedido(s) para entrega
      </div>
    </div>
  );
}