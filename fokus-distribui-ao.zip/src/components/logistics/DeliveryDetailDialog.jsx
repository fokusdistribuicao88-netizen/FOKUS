import React from 'react';
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Truck, UserCheck, CheckCircle2, MapPin, Calendar, User, Wallet, Phone } from 'lucide-react';
import {
  LOGISTICS_STATUS, formatCurrency, ORDER_STATUS, ON_SITE_PAYMENT_STATUS,
} from '@/components/orders/orderStatus';
import { canAssumeDelivery, canReassign, canSetStatus, isDriver } from '@/lib/logistics';

function Row({ icon: Icon, label, value }) {
  return (
    <div className="flex items-start gap-2 py-1.5">
      <Icon className="w-4 h-4 text-muted-foreground flex-shrink-0 mt-0.5" />
      <span className="text-xs text-muted-foreground flex-shrink-0 w-16">{label}</span>
      <span className="text-sm font-medium min-w-0 break-words">{value || '—'}</span>
    </div>
  );
}

export default function DeliveryDetailDialog({
  open, order, user, onClose, onAction, onAssume, onReassign, onRegisterReceipt, onConfirmDelivery,
}) {
  if (!order) return null;

  const info = LOGISTICS_STATUS[order.status] || ORDER_STATUS[order.status] || { label: order.status, badge: 'bg-slate-100 text-slate-700' };
  const shortCode = (id) => (id ? '#' + id.substring(0, 8).toUpperCase() : '—');
  const fmtDate = (d) => d ? new Date(d).toLocaleDateString('pt-BR') : '—';

  const canAssume = canAssumeDelivery(user) && !order.driver_name && isDriver(user);
  const isOnSite = order.delivery_receipt_mode === 'on_site';
  const onSiteStatus = isOnSite ? (ON_SITE_PAYMENT_STATUS[order.on_site_payment_status] || ON_SITE_PAYMENT_STATUS.pending) : null;
  const onSiteReceived = isOnSite && order.on_site_payment_status === 'received';
  const onSitePaid = isOnSite && (order.on_site_payment_status === 'received' || order.on_site_payment_status === 'partial');
  const onSiteBalance = isOnSite ? Math.max(0, (Number(order.total) || 0) - (Number(order.on_site_payment?.amount_received) || 0)) : 0;
  const canConfirmDelivery = isOnSite && onSitePaid && order.status !== 'delivered' && onConfirmDelivery;
  const isDelivered = order.status === 'delivered';
  const fmtDateTime = (d) => d ? new Date(d).toLocaleString('pt-BR', { day: '2-digit', month: '2-digit', year: 'numeric', hour: '2-digit', minute: '2-digit' }) : '—';

  return (
    <Dialog open={open} onOpenChange={(op) => !op && onClose()}>
      <DialogContent className="max-w-md max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 flex-wrap">
            Detalhes da entrega
            <span className="text-sm font-normal text-muted-foreground">{shortCode(order.id)}</span>
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-3">
          {/* Resumo */}
          <div className="bg-muted/40 rounded-xl p-3 space-y-1">
            <div className="flex justify-between gap-2">
              <span className="text-xs text-muted-foreground flex-shrink-0">Cliente</span>
              <span className="text-sm font-medium text-right break-words min-w-0">{order.customer_name}</span>
            </div>
            <div className="flex justify-between gap-2">
              <span className="text-xs text-muted-foreground flex-shrink-0">Valor</span>
              <span className="text-sm font-medium text-right">{formatCurrency(order.total)}</span>
            </div>
            <div className="flex justify-between gap-2 items-center">
              <span className="text-xs text-muted-foreground flex-shrink-0">Status</span>
              <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-medium whitespace-nowrap ${info.badge}`}>
                <span className={`w-1.5 h-1.5 rounded-full ${info.dot}`} />
                {info.label}
              </span>
            </div>
          </div>

          {/* Detalhes da entrega */}
          <div className="border border-border rounded-xl p-3">
            <h3 className="text-xs font-semibold uppercase tracking-wider text-muted-foreground mb-2">Entrega</h3>
            <Row icon={MapPin} label="Endereço" value={order.customer_address} />
            <Row icon={MapPin} label="Cidade" value={order.city} />
            <Row icon={MapPin} label="Bairro" value={order.neighborhood} />
            <Row icon={Phone} label="Telefone" value={order.customer_phone} />
            <Row icon={Calendar} label="Prevista" value={fmtDate(order.delivery_expected_date)} />
            <Row icon={Truck} label="Motorista" value={order.driver_name} />
            <Row icon={User} label="Auxiliar" value={order.helper_name} />
          </div>

          {/* Recebimento no local */}
          {isOnSite && (
            <div className={`rounded-xl p-3 border-2 ${onSiteReceived ? 'border-green-300 bg-green-50' : 'border-amber-300 bg-amber-50'}`}>
              <div className="flex items-center gap-2 mb-2">
                <Wallet className={`w-4 h-4 ${onSiteReceived ? 'text-green-700' : 'text-amber-700'}`} />
                <h3 className={`text-xs font-semibold uppercase tracking-wider ${onSiteReceived ? 'text-green-700' : 'text-amber-700'}`}>
                  {onSiteReceived ? '✓ Recebido no local' : '💰 Receber no local'}
                </h3>
              </div>
              <div className="space-y-1 text-sm">
                <div className="flex justify-between gap-2">
                  <span className="text-xs text-muted-foreground">Valor total</span>
                  <span className="font-medium">{formatCurrency(order.total)}</span>
                </div>
                <div className="flex justify-between gap-2">
                  <span className="text-xs text-muted-foreground">Já recebido</span>
                  <span className="font-medium">{formatCurrency(order.on_site_payment?.amount_received || 0)}</span>
                </div>
                <div className="flex justify-between gap-2">
                  <span className="text-xs text-muted-foreground">A receber</span>
                  <span className={`font-bold ${onSiteReceived ? 'text-green-700' : 'text-amber-700'}`}>{formatCurrency(onSiteBalance)}</span>
                </div>
                {order.on_site_payment?.payment_method && (
                  <div className="flex justify-between gap-2">
                    <span className="text-xs text-muted-foreground">Forma recebida</span>
                    <span className="font-medium">{order.on_site_payment.payment_method}</span>
                  </div>
                )}
                {order.on_site_payment?.responsible && (
                  <div className="flex justify-between gap-2">
                    <span className="text-xs text-muted-foreground">Responsável</span>
                    <span className="font-medium">{order.on_site_payment.responsible}</span>
                  </div>
                )}
                {onSiteStatus && (
                  <div className="flex justify-between gap-2 pt-1 border-t border-amber-200/60">
                    <span className="text-xs text-muted-foreground">Status</span>
                    <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-medium ${onSiteStatus.badge}`}>
                      <span className={`w-1.5 h-1.5 rounded-full ${onSiteStatus.dot}`} />
                      {onSiteStatus.label}
                    </span>
                  </div>
                )}
              </div>
            </div>
          )}

          {/* Recebedor (após entrega confirmada) */}
          {isDelivered && order.receiver_name && (
            <div className="border border-green-300 bg-green-50 rounded-xl p-3">
              <h3 className="text-xs font-semibold uppercase tracking-wider text-green-700 mb-2">Recebedor</h3>
              <Row icon={User} label="Nome" value={order.receiver_name} />
              <Row icon={User} label="CPF" value={order.receiver_document} />
              <Row icon={Calendar} label="Entrega em" value={fmtDateTime(order.delivery_confirmed_at)} />
              <Row icon={User} label="Responsável" value={order.driver_name || order.on_site_payment?.responsible} />
            </div>
          )}

          {/* Histórico da entrega */}
          {(order.delivery_history || []).length > 0 && (
            <div className="border border-border rounded-xl p-3">
              <h3 className="text-xs font-semibold uppercase tracking-wider text-muted-foreground mb-2">Histórico da Entrega</h3>
              <div className="space-y-2 max-h-52 overflow-y-auto">
                {(order.delivery_history || []).slice().reverse().map((h, idx) => {
                  const st = LOGISTICS_STATUS[h.status] || ORDER_STATUS[h.status] || { label: h.status || '—' };
                  return (
                    <div key={idx} className="border-l-2 border-border pl-2 py-1">
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className="text-[10px] font-semibold uppercase text-muted-foreground">Entrega:</span>
                        <span className="inline-flex items-center gap-1 px-1.5 py-0.5 rounded-full text-[10px] font-medium bg-muted text-foreground">{st.label}</span>
                        <span className="text-[10px] text-muted-foreground">{fmtDateTime(h.date)}</span>
                      </div>
                      {h.user && <p className="text-[11px] text-muted-foreground mt-0.5">Responsável: {h.user}</p>}
                      {h.receiver_name && (
                        <p className="text-[11px] mt-0.5"><b>Recebido por:</b> {h.receiver_name}{h.receiver_document ? ` — CPF ${h.receiver_document}` : ''}</p>
                      )}
                      {h.notes && <p className="text-[11px] text-muted-foreground mt-0.5">{h.notes}</p>}
                      {(h.payment_status || h.payment_method || h.amount_received) && (
                        <p className="text-[11px] mt-0.5">
                          <b>Pagamento:</b> {h.payment_status || '—'}{h.payment_method ? ` — Forma: ${h.payment_method}` : ''}{h.amount_received ? ` — Valor: ${formatCurrency(h.amount_received)}` : ''}
                        </p>
                      )}
                    </div>
                  );
                })}
              </div>
            </div>
          )}
        </div>

        <DialogFooter className="flex-wrap gap-2">
          {isOnSite && !onSiteReceived && onRegisterReceipt && (
            <Button size="sm" onClick={() => { onRegisterReceipt(order); }} className="gap-2 bg-amber-600 hover:bg-amber-700">
              <Wallet className="w-4 h-4" /> Registrar recebimento
            </Button>
          )}
          {canConfirmDelivery && (
            <Button size="sm" onClick={() => { onConfirmDelivery(order); }} className="gap-2 bg-green-600 hover:bg-green-700">
              <CheckCircle2 className="w-4 h-4" /> Confirmar entrega
            </Button>
          )}
          {canAssume && (
            <Button variant="outline" size="sm" onClick={() => { onAssume(order); onClose(); }} className="gap-2">
              <Truck className="w-4 h-4" /> Assumir
            </Button>
          )}
          {canSetStatus(user, 'occurrence') && (
            <Button variant="outline" size="sm" onClick={() => { onAction(order); }} className="gap-2">
              <CheckCircle2 className="w-4 h-4" /> Atualizar status
            </Button>
          )}
          {canReassign(user) && (
            <Button variant="outline" size="sm" onClick={() => { onReassign(order); }} className="gap-2">
              <UserCheck className="w-4 h-4" /> Reatribuir
            </Button>
          )}
          <Button size="sm" onClick={onClose}>Fechar</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}