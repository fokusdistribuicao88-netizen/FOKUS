import React, { useMemo } from 'react';
import { useQuery } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import {
  PackageCheck, Truck, ClipboardList, MapPin, CheckCircle2, AlertTriangle, Boxes,
  CalendarDays, UserCheck, Users,
} from 'lucide-react';
import { LOGISTICS_STATUS, formatCurrency } from '@/components/orders/orderStatus';

function MiniStat({ icon: Icon, label, value, accent }) {
  const accents = {
    slate: 'bg-slate-50 dark:bg-slate-900/40 text-slate-600 dark:text-slate-300',
    amber: 'bg-amber-50 dark:bg-amber-950/40 text-amber-600 dark:text-amber-400',
    blue: 'bg-blue-50 dark:bg-blue-950/40 text-blue-600 dark:text-blue-400',
    orange: 'bg-orange-50 dark:bg-orange-950/40 text-orange-600 dark:text-orange-400',
    green: 'bg-green-50 dark:bg-green-950/40 text-green-600 dark:text-green-400',
    red: 'bg-red-50 dark:bg-red-950/40 text-red-600 dark:text-red-400',
    violet: 'bg-violet-50 dark:bg-violet-950/40 text-violet-600 dark:text-violet-400',
  };
  return (
    <div className="bg-card border border-border rounded-xl p-3 flex items-center gap-2 sm:gap-3">
      <div className={`w-9 h-9 rounded-lg flex items-center justify-center flex-shrink-0 ${accents[accent] || accents.slate}`}>
        <Icon className="w-4 h-4 sm:w-5 sm:h-5" />
      </div>
      <div className="min-w-0">
        <p className="text-[10px] uppercase tracking-wider text-muted-foreground leading-tight">{label}</p>
        <p className="text-base sm:text-lg font-bold leading-tight">{value}</p>
      </div>
    </div>
  );
}

export default function LogisticsOverview({ orders, users }) {
  const stats = useMemo(() => {
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const s = (status) => orders.filter((o) => o.status === status).length;

    const drivers = users.filter((u) => u.role === 'motorista');
    const helpers = users.filter((u) => u.role === 'auxiliar');
    const driversOnDuty = new Set(
      orders.filter((o) => ['in_route', 'out_for_delivery'].includes(o.status) && o.driver_name).map((o) => o.driver_name)
    );
    const helpersOnDuty = new Set(
      orders.filter((o) => ['in_route', 'out_for_delivery'].includes(o.status) && o.helper_name).map((o) => o.helper_name)
    );

    const deliveredToday = orders.filter((o) => {
      if (o.status !== 'delivered') return false;
      const d = new Date(o.delivery_confirmed_at || o.updated_date);
      return d >= today;
    }).length;

    const avgDeliveryMs = (() => {
      const done = orders.filter((o) => o.status === 'delivered' && o.delivery_confirmed_at && o.created_date);
      if (!done.length) return 0;
      const totalH = done.reduce((acc, o) => {
        const diff = new Date(o.delivery_confirmed_at) - new Date(o.created_date);
        return acc + diff / (1000 * 60 * 60);
      }, 0);
      return totalH / done.length;
    })();

    return {
      awaitingCheck: s('pending') + s('payment_approved') + s('confirmed'),
      separating: s('separating'),
      awaitingShipment: s('awaiting_shipment'),
      readyForDelivery: s('ready_for_delivery'),
      inRoute: s('in_route') + s('out_for_delivery'),
      delivered: s('delivered'),
      occurrence: s('occurrence') + s('customer_absent') + s('refused') + s('rescheduled'),
      deliveredToday,
      driversOnDuty: driversOnDuty.size,
      helpersOnDuty: helpersOnDuty.size,
      totalDrivers: drivers.length,
      totalHelpers: helpers.length,
      avgDeliveryH: avgDeliveryMs,
    };
  }, [orders, users]);

  const byDriver = useMemo(() => {
    const map = {};
    orders.filter((o) => o.driver_name).forEach((o) => {
      map[o.driver_name] = (map[o.driver_name] || 0) + 1;
    });
    return Object.entries(map).sort((a, b) => b[1] - a[1]).slice(0, 6);
  }, [orders]);

  const byStatus = useMemo(() => {
    const map = {};
    orders.forEach((o) => {
      const info = LOGISTICS_STATUS[o.status];
      if (!info) return;
      map[o.status] = (map[o.status] || 0) + 1;
    });
    return Object.entries(map).sort((a, b) => b[1] - a[1]).slice(0, 6);
  }, [orders]);

  const byPeriod = useMemo(() => {
    const days = {};
    orders.filter((o) => o.status === 'delivered').forEach((o) => {
      const d = new Date(o.delivery_confirmed_at || o.updated_date);
      const key = d.toLocaleDateString('pt-BR', { day: '2-digit', month: '2-digit' });
      days[key] = (days[key] || 0) + 1;
    });
    return Object.entries(days).slice(-7);
  }, [orders]);

  const maxByPeriod = Math.max(1, ...byPeriod.map(([, v]) => v));
  const maxByDriver = Math.max(1, ...byDriver.map(([, v]) => v));
  const maxByStatus = Math.max(1, ...byStatus.map(([, v]) => v));

  return (
    <div className="space-y-5">
      <div className="grid grid-cols-2 md:grid-cols-3 xl:grid-cols-5 gap-3">
        <MiniStat icon={ClipboardList} label="Aguardando conferência" value={stats.awaitingCheck} accent="slate" />
        <MiniStat icon={Boxes} label="Em separação" value={stats.separating} accent="blue" />
        <MiniStat icon={PackageCheck} label="Aguardando expedição" value={stats.awaitingShipment} accent="amber" />
        <MiniStat icon={Truck} label="Prontos para entrega" value={stats.readyForDelivery} accent="blue" />
        <MiniStat icon={MapPin} label="Em rota" value={stats.inRoute} accent="orange" />
        <MiniStat icon={CheckCircle2} label="Entregues" value={stats.delivered} accent="green" />
        <MiniStat icon={AlertTriangle} label="Ocorrências" value={stats.occurrence} accent="red" />
        <MiniStat icon={CalendarDays} label="Entregas do dia" value={stats.deliveredToday} accent="green" />
        <MiniStat icon={UserCheck} label="Motoristas em serviço" value={`${stats.driversOnDuty}/${stats.totalDrivers}`} accent="violet" />
        <MiniStat icon={Users} label="Auxiliares em serviço" value={`${stats.helpersOnDuty}/${stats.totalHelpers}`} accent="blue" />
        <MiniStat icon={CalendarDays} label="Tempo médio (h)" value={stats.avgDeliveryH ? stats.avgDeliveryH.toFixed(1) : '—'} accent="slate" />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* Entregas por período */}
        <div className="bg-card border border-border rounded-2xl p-4">
          <h4 className="text-sm font-semibold mb-3">Entregas por período</h4>
          {byPeriod.length === 0 ? (
            <p className="text-xs text-muted-foreground text-center py-6">Sem dados de entregas concluídas</p>
          ) : (
            <div className="space-y-2">
              {byPeriod.map(([label, val]) => (
                <div key={label} className="flex items-center gap-2">
                  <span className="text-xs w-12 text-muted-foreground">{label}</span>
                  <div className="flex-1 bg-muted rounded-full h-5 overflow-hidden">
                    <div className="bg-blue-500 h-full rounded-full flex items-center justify-end pr-2" style={{ width: `${(val / maxByPeriod) * 100}%` }}>
                      <span className="text-[10px] text-white font-medium">{val}</span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Entregas por motorista */}
        <div className="bg-card border border-border rounded-2xl p-4">
          <h4 className="text-sm font-semibold mb-3">Entregas por motorista</h4>
          {byDriver.length === 0 ? (
            <p className="text-xs text-muted-foreground text-center py-6">Nenhum motorista atribuído</p>
          ) : (
            <div className="space-y-2">
              {byDriver.map(([name, val]) => (
                <div key={name} className="flex items-center gap-2">
                  <span className="text-xs w-24 truncate text-muted-foreground">{name}</span>
                  <div className="flex-1 bg-muted rounded-full h-5 overflow-hidden">
                    <div className="bg-violet-500 h-full rounded-full flex items-center justify-end pr-2" style={{ width: `${(val / maxByDriver) * 100}%` }}>
                      <span className="text-[10px] text-white font-medium">{val}</span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Pedidos por status */}
        <div className="bg-card border border-border rounded-2xl p-4">
          <h4 className="text-sm font-semibold mb-3">Pedidos por status</h4>
          {byStatus.length === 0 ? (
            <p className="text-xs text-muted-foreground text-center py-6">Sem pedidos</p>
          ) : (
            <div className="space-y-2">
              {byStatus.map(([key, val]) => {
                const info = LOGISTICS_STATUS[key] || {};
                return (
                  <div key={key} className="flex items-center gap-2">
                    <span className={`w-2 h-2 rounded-full ${info.dot || 'bg-slate-400'}`} />
                    <span className="text-xs flex-1 truncate text-muted-foreground">{info.label || key}</span>
                    <span className="text-xs font-semibold w-6 text-right">{val}</span>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}