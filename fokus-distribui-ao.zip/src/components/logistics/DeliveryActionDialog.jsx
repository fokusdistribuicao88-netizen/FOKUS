import React, { useState, useEffect } from 'react';
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import {
  Select, SelectTrigger, SelectValue, SelectContent, SelectItem,
} from '@/components/ui/select';
import {
  LOGISTICS_STATUS, LOGISTICS_STATUS_LIST, formatCurrency,
} from '@/components/orders/orderStatus';
import { canSetStatus, isDriver, userDisplayName } from '@/lib/logistics';

export default function DeliveryActionDialog({ open, order, user, onClose, onSave }) {
  const [status, setStatus] = useState('');
  const [notes, setNotes] = useState('');
  const [receiverName, setReceiverName] = useState('');
  const [receiverDocument, setReceiverDocument] = useState('');
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (order) {
      setStatus(order.status || '');
      setNotes('');
      setReceiverName(order.receiver_name || '');
      setReceiverDocument(order.receiver_document || '');
    }
  }, [order, open]);

  if (!order) return null;

  const availableStatuses = LOGISTICS_STATUS_LIST.filter((s) => {
    if (user?.role === 'admin' || user?.role === 'gerente') return true;
    return canSetStatus(user, s);
  });

  const isDelivered = status === 'delivered';
  const shortCode = (id) => (id ? '#' + id.substring(0, 8).toUpperCase() : '—');

  const submit = async () => {
    setSaving(true);
    await onSave(order, {
      status,
      notes,
      receiver_name: isDelivered ? receiverName : undefined,
      receiver_document: isDelivered ? receiverDocument : undefined,
      delivery_confirmed_at: isDelivered ? new Date().toISOString() : undefined,
    });
    setSaving(false);
    onClose();
  };

  return (
    <Dialog open={open} onOpenChange={(op) => !op && onClose()}>
      <DialogContent className="max-w-lg max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Atualizar entrega — {shortCode(order.id)}</DialogTitle>
        </DialogHeader>

        <div className="space-y-3">
          <div className="bg-muted/40 rounded-xl p-3 text-sm space-y-1">
            <div className="flex justify-between gap-2"><span className="text-muted-foreground flex-shrink-0">Cliente</span><span className="font-medium text-right break-words min-w-0">{order.customer_name}</span></div>
            <div className="flex justify-between gap-2"><span className="text-muted-foreground flex-shrink-0">Endereço</span><span className="font-medium text-right break-words min-w-0">{order.customer_address || '—'}</span></div>
            <div className="flex justify-between gap-2"><span className="text-muted-foreground flex-shrink-0">Valor</span><span className="font-medium text-right break-words min-w-0">{formatCurrency(order.total)}</span></div>
          </div>

          <div>
            <Label className="text-xs">Status da entrega</Label>
            <Select value={status} onValueChange={setStatus}>
              <SelectTrigger><SelectValue placeholder="Selecione o status" /></SelectTrigger>
              <SelectContent className="max-h-72">
                {availableStatuses.map((s) => (
                  <SelectItem key={s} value={s}>{LOGISTICS_STATUS[s].label}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {isDelivered && (
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 p-3 bg-green-50 dark:bg-green-950/30 rounded-xl border border-green-200 dark:border-green-900">
              <div className="sm:col-span-2 text-xs font-semibold text-green-700 dark:text-green-400">Comprovante de entrega</div>
              <div>
                <Label className="text-xs">Nome do recebedor</Label>
                <Input value={receiverName} onChange={(e) => setReceiverName(e.target.value)} placeholder="Quem recebeu" />
              </div>
              <div>
                <Label className="text-xs">Documento (opcional)</Label>
                <Input value={receiverDocument} onChange={(e) => setReceiverDocument(e.target.value)} placeholder="RG / CPF" />
              </div>
            </div>
          )}

          <div>
            <Label className="text-xs">Observações</Label>
            <Textarea value={notes} onChange={(e) => setNotes(e.target.value)} rows={3} placeholder="Observações sobre a entrega / ocorrência" />
          </div>
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={onClose}>Cancelar</Button>
          <Button onClick={submit} disabled={saving || !status} className="bg-blue-700 hover:bg-blue-800">
            {saving ? 'Salvando...' : 'Confirmar'}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}