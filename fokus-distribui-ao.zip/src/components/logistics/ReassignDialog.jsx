import React, { useState, useEffect, useMemo } from 'react';
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import {
  Select, SelectTrigger, SelectValue, SelectContent, SelectItem,
} from '@/components/ui/select';

export default function ReassignDialog({ open, order, users, onClose, onSave }) {
  const [driverName, setDriverName] = useState('');
  const [helperName, setHelperName] = useState('');
  const [saving, setSaving] = useState(false);

  const drivers = useMemo(() => users.filter((u) => u.role === 'motorista'), [users]);
  const helpers = useMemo(() => users.filter((u) => u.role === 'auxiliar'), [users]);

  useEffect(() => {
    if (order) {
      setDriverName(order.driver_name || '');
      setHelperName(order.helper_name || '');
    }
  }, [order, open]);

  if (!order) return null;

  const submit = async () => {
    setSaving(true);
    await onSave(order, { driver_name: driverName, helper_name: helperName });
    setSaving(false);
    onClose();
  };

  return (
    <Dialog open={open} onOpenChange={(op) => !op && onClose()}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle>Reatribuir equipe de entrega</DialogTitle>
        </DialogHeader>
        <div className="space-y-3">
          <div>
            <Label className="text-xs">Motorista responsável</Label>
            <Select value={driverName} onValueChange={setDriverName}>
              <SelectTrigger><SelectValue placeholder="Selecionar motorista" /></SelectTrigger>
              <SelectContent className="max-h-60">
                <SelectItem value={null}>Sem motorista</SelectItem>
                {drivers.map((d) => <SelectItem key={d.id} value={d.full_name || d.email}>{d.full_name || d.email}</SelectItem>)}
              </SelectContent>
            </Select>
          </div>
          <div>
            <Label className="text-xs">Auxiliar de entrega</Label>
            <Select value={helperName} onValueChange={setHelperName}>
              <SelectTrigger><SelectValue placeholder="Selecionar auxiliar" /></SelectTrigger>
              <SelectContent className="max-h-60">
                <SelectItem value={null}>Sem auxiliar</SelectItem>
                {helpers.map((h) => <SelectItem key={h.id} value={h.full_name || h.email}>{h.full_name || h.email}</SelectItem>)}
              </SelectContent>
            </Select>
          </div>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={onClose}>Cancelar</Button>
          <Button onClick={submit} disabled={saving} className="bg-blue-700 hover:bg-blue-800">
            {saving ? 'Salvando...' : 'Salvar atribuição'}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}