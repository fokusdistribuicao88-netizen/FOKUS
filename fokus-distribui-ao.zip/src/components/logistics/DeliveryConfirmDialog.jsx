import React, { useState, useMemo } from 'react';
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { UserCheck, ArrowLeft, ArrowRight, CheckCircle2, Truck, Wallet } from 'lucide-react';
import { formatCurrency, ON_SITE_PAYMENT_STATUS, PAYMENT_METHODS } from '@/components/orders/orderStatus';

function maskCPF(v) {
  const d = (v || '').replace(/\D/g, '').slice(0, 11);
  if (!d) return '';
  return d
    .replace(/(\d{3})(\d)/, '$1.$2')
    .replace(/(\d{3})(\d)/, '$1.$2')
    .replace(/(\d{3})(\d{1,2})$/, '$1-$2');
}
/**
 * Etapa obrigatória após o recebimento no local: confirmar a entrega informando
 * os dados de quem recebeu fisicamente a mercadoria. O pagamento NÃO marca a
 * entrega como entregue — somente este diálogo, após "CONFIRMAR ENTREGA".
 *
 * Duas etapas: formulário do recebedor → revisão/confirmação.
 */
export default function DeliveryConfirmDialog({ open, order, user, onClose, onConfirmed }) {
  const [step, setStep] = useState('form'); // 'form' | 'review'
  const [form, setForm] = useState({
    receiver_name: '', receiver_document: '',
  });
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');

  React.useEffect(() => {
    if (open) {
      setStep('form');
      setError('');
      setForm({
        receiver_name: order?.receiver_name || '',
        receiver_document: order?.receiver_document || '',
      });
    }
  }, [open, order]);

  const shortCode = (id) => (id ? '#' + id.substring(0, 8).toUpperCase() : '—');
  const now = useMemo(() => new Date(), [open]);
  const dateStr = now.toLocaleDateString('pt-BR');
  const timeStr = now.toTimeString().slice(0, 5);
  const responsible = user?.full_name || user?.email || '—';

  const onSiteStatus = order?.on_site_payment_status;
  const onSiteLabel = onSiteStatus ? (ON_SITE_PAYMENT_STATUS[onSiteStatus]?.label || onSiteStatus) : '—';
  const paymentMethod = order?.on_site_payment?.payment_method;
  const paymentMethodLabel = paymentMethod ? (PAYMENT_METHODS[paymentMethod] || paymentMethod) : '—';
  const amountReceived = Number(order?.on_site_payment?.amount_received) || 0;

  const validate = () => {
    if (!form.receiver_name.trim()) return 'Informe o nome completo do recebedor.';
    const cpfDigits = form.receiver_document.replace(/\D/g, '');
    if (cpfDigits.length !== 11) return 'Informe um CPF válido (11 dígitos).';
    return '';
  };

  const goReview = () => {
    const err = validate();
    if (err) { setError(err); return; }
    setError('');
    setStep('review');
  };

  const handleConfirm = () => {
    setBusy(true);
    Promise.resolve(onConfirmed?.({
      receiver_name: form.receiver_name.trim(),
      receiver_document: form.receiver_document.trim(),
    }))
      .catch((e) => setError(String(e?.message || e)))
      .finally(() => setBusy(false));
  };

  if (!order) return null;

  return (
    <Dialog open={open} onOpenChange={(op) => !op && !busy && onClose()}>
      <DialogContent className="max-w-lg max-h-[92vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 flex-wrap">
            <Truck className="w-5 h-5 text-orange-600" />
            Atualizar como Entregue
            <span className="text-sm font-normal text-muted-foreground">{shortCode(order.id)}</span>
          </DialogTitle>
          <DialogDescription>
            {step === 'form'
              ? 'Informe os dados de quem recebeu fisicamente a mercadoria. O pagamento não conclui a entrega — ela só será concluída após a confirmação abaixo.'
              : 'Confira os dados antes de concluir a entrega.'}
          </DialogDescription>
        </DialogHeader>

        {step === 'form' && (
          <div className="space-y-3">
            <div className="rounded-xl border-2 border-amber-300 bg-amber-50 p-3">
              <p className="text-xs font-semibold text-amber-900 uppercase mb-1">Informações do Recebedor</p>
              <p className="text-[11px] text-amber-700/80">Identifique claramente quem recebeu a mercadoria.</p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div className="sm:col-span-2 space-y-1">
                <Label className="text-xs">Nome completo do recebedor *</Label>
                <Input value={form.receiver_name} onChange={(e) => setForm({ ...form, receiver_name: e.target.value })} placeholder="Nome completo" />
              </div>
              <div className="sm:col-span-2 space-y-1">
                <Label className="text-xs">CPF do recebedor *</Label>
                <Input value={form.receiver_document} onChange={(e) => setForm({ ...form, receiver_document: maskCPF(e.target.value) })} placeholder="000.000.000-00" inputMode="numeric" />
              </div>
            </div>

            {error && <p className="text-xs text-red-600">{error}</p>}
          </div>
        )}

        {step === 'review' && (
          <div className="space-y-3">
            <div className="rounded-xl border-2 border-green-300 bg-green-50 p-3 space-y-1.5">
              <p className="text-xs font-semibold text-green-900 uppercase">Confirmação da Entrega</p>
              <div className="grid grid-cols-2 gap-x-3 gap-y-1 text-sm">
                <ReviewRow label="Pedido" value={shortCode(order.id)} />
                <ReviewRow label="Cliente" value={order.customer_name} />
                <ReviewRow label="Recebedor" value={form.receiver_name} />
                <ReviewRow label="CPF" value={form.receiver_document} />
                <ReviewRow label="Data" value={dateStr} />
                <ReviewRow label="Horário" value={timeStr} />
                <ReviewRow label="Responsável" value={responsible} />
              </div>
            </div>

            <div className="rounded-xl border border-border bg-muted/40 p-3">
              <p className="text-[10px] uppercase font-semibold text-muted-foreground mb-1">Pagamento (independente)</p>
              <div className="flex flex-wrap items-center gap-x-4 gap-y-1 text-xs">
                <span><b>Status:</b> {onSiteLabel}</span>
                <span><b>Forma:</b> {paymentMethodLabel}</span>
                <span><b>Valor recebido:</b> {formatCurrency(amountReceived)}</span>
              </div>
            </div>

            {error && <p className="text-xs text-red-600">{error}</p>}
          </div>
        )}

        <DialogFooter className="flex-wrap gap-2">
          {step === 'form' ? (
            <>
              <Button variant="outline" onClick={onClose} disabled={busy}>Cancelar</Button>
              <Button onClick={goReview} className="gap-2 bg-orange-600 hover:bg-orange-700">
                Continuar <ArrowRight className="w-4 h-4" />
              </Button>
            </>
          ) : (
            <>
              <Button variant="outline" onClick={() => setStep('form')} disabled={busy} className="gap-2">
                <ArrowLeft className="w-4 h-4" /> Voltar
              </Button>
              <Button onClick={handleConfirm} disabled={busy} className="gap-2 bg-green-600 hover:bg-green-700">
                <CheckCircle2 className="w-4 h-4" /> Confirmar Entrega
              </Button>
            </>
          )}
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

function ReviewRow({ label, value }) {
  return (
    <div className="flex justify-between gap-2 min-w-0">
      <span className="text-xs text-muted-foreground flex-shrink-0">{label}</span>
      <span className="text-sm font-medium text-right break-words min-w-0">{value || '—'}</span>
    </div>
  );
}