import React, { useState, useEffect, useRef, useMemo } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { AnimatePresence, motion } from 'framer-motion';
import { Compass, X } from 'lucide-react';
import { useAuth } from '@/lib/AuthContext';
import { isStaffRole } from '@/lib/userRoles';
import { getNavSections } from '@/lib/adminNav';

export default function FloatingNav() {
  const { user } = useAuth();
  const [open, setOpen] = useState(false);
  const location = useLocation();
  const navigate = useNavigate();
  const containerRef = useRef(null);

  const sections = useMemo(() => getNavSections(user?.role), [user?.role]);

  // Fecha ao clicar fora
  useEffect(() => {
    if (!open) return;
    const handler = (e) => {
      if (containerRef.current && !containerRef.current.contains(e.target)) setOpen(false);
    };
    document.addEventListener('mousedown', handler);
    return () => document.removeEventListener('mousedown', handler);
  }, [open]);

  // Fecha com a tecla Esc
  useEffect(() => {
    if (!open) return;
    const handler = (e) => { if (e.key === 'Escape') setOpen(false); };
    document.addEventListener('keydown', handler);
    return () => document.removeEventListener('keydown', handler);
  }, [open]);

  // Fecha ao trocar de rota
  useEffect(() => { setOpen(false); }, [location.pathname]);

  if (!user || !isStaffRole(user.role)) return null;
  // Não exibir no Catálogo (área do cliente)
  if (location.pathname === '/') return null;

  const handleItemClick = (item) => {
    setOpen(false);
    if (item.scroll) {
      const onProfile = location.pathname === item.to;
      if (onProfile) {
        setTimeout(() => document.getElementById(item.scroll)?.scrollIntoView({ behavior: 'smooth' }), 100);
      } else {
        navigate(item.to);
        setTimeout(() => document.getElementById(item.scroll)?.scrollIntoView({ behavior: 'smooth' }), 400);
      }
    } else if (item.to != null) {
      navigate(item.to);
    }
  };

  const isActive = (to) => {
    if (to === '/') return location.pathname === '/';
    return location.pathname === to || location.pathname.startsWith(to);
  };

  return (
    <div ref={containerRef} className="block">
      <button
        onClick={() => setOpen((v) => !v)}
        className={`fixed bottom-4 right-4 lg:top-4 z-[60] flex items-center justify-center w-12 h-12 lg:w-11 lg:h-11 rounded-full shadow-lg transition-all duration-200 ${
          open
            ? 'bg-blue-800 text-white rotate-90'
            : 'bg-white text-blue-700 hover:bg-blue-50 border border-blue-100 hover:scale-105'
        }`}
        style={{ marginBottom: 'env(safe-area-inset-bottom)' }}
        aria-label="Navegação rápida"
        title="Navegação rápida"
      >
        {open ? <X className="w-5 h-5" /> : <Compass className="w-5 h-5" />}
      </button>

      <AnimatePresence>
        {open && (
          <motion.div
            initial={{ opacity: 0, scale: 0.95, y: 8 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.95, y: 8 }}
            transition={{ duration: 0.18, ease: 'easeOut' }}
            className="fixed bottom-20 right-4 lg:top-16 lg:right-4 z-[60] w-80 max-w-[calc(100vw-2rem)] bg-card rounded-2xl shadow-2xl border border-border overflow-hidden"
          >
            <div className="px-4 py-3 border-b border-border bg-gradient-to-r from-blue-600 to-blue-800">
              <p className="text-sm font-bold text-white">Navegação Rápida</p>
              <p className="text-[10px] text-blue-100">Acesse qualquer módulo do sistema</p>
            </div>
            <div className="max-h-[70vh] overflow-y-auto p-2">
              {sections.map((section) => {
                const items = section.items.filter((i) => !i.soon);
                if (!items.length) return null;
                return (
                  <div key={section.title} className="mb-2">
                    <p className="px-2 mb-1 text-[10px] font-semibold uppercase tracking-wider text-muted-foreground">
                      {section.title}
                    </p>
                    {items.map((item) => {
                      const Icon = item.icon;
                      const active = item.to ? isActive(item.to) : false;
                      return (
                        <button
                          key={item.label}
                          onClick={() => handleItemClick(item)}
                          className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-colors ${
                            active
                              ? 'bg-blue-700 text-white shadow-sm'
                              : 'text-foreground hover:bg-accent'
                          }`}
                        >
                          <Icon className="w-4 h-4 flex-shrink-0" />
                          <span className="truncate">{item.label}</span>
                        </button>
                      );
                    })}
                  </div>
                );
              })}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}