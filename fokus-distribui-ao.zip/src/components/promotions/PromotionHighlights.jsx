import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Eye, Clock } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { fmtMoney } from '@/lib/promotions';

function useCountdown(endDate) {
  const [remaining, setRemaining] = useState('');
  useEffect(() => {
    if (!endDate) return;
    const tick = () => {
      const diff = new Date(endDate).getTime() - Date.now();
      if (diff <= 0) { setRemaining('Encerrada'); return; }
      const d = Math.floor(diff / 86400000);
      const h = Math.floor((diff % 86400000) / 3600000);
      const m = Math.floor((diff % 3600000) / 60000);
      const s = Math.floor((diff % 60000) / 1000);
      setRemaining(`${d}d ${String(h).padStart(2, '0')}h ${String(m).padStart(2, '0')}m ${String(s).padStart(2, '0')}s`);
    };
    tick();
    const id = setInterval(tick, 1000);
    return () => clearInterval(id);
  }, [endDate]);
  return remaining;
}

function HighlightCard({ promo, onView }) {
  const countdown = useCountdown(promo.end_date);
  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.96 }}
      animate={{ opacity: 1, scale: 1 }}
      className="relative rounded-2xl overflow-hidden border border-border bg-card shadow-sm min-w-[260px] max-w-[300px]"
    >
      <div className="aspect-[4/3] bg-muted overflow-hidden">
        {promo.image_url ? (
          <img src={promo.image_url} alt={promo.name} className="w-full h-full object-cover" />
        ) : (
          <div className="w-full h-full flex items-center justify-center text-muted-foreground text-sm">Sem imagem</div>
        )}
      </div>
      <div className="p-3 space-y-2">
        <div className="flex items-center justify-between gap-2">
          <h4 className="text-sm font-semibold text-foreground line-clamp-1">{promo.name}</h4>
          <span className="px-2 py-0.5 rounded-full bg-red-100 text-red-700 dark:bg-red-900/40 dark:text-red-300 text-[10px] font-bold">-{promo.discount_percent || 0}%</span>
        </div>
        <div className="flex items-end gap-2">
          <span className="text-xs line-through text-muted-foreground">{fmtMoney(promo.original_price)}</span>
          <span className="text-lg font-extrabold text-blue-900 dark:text-yellow-400">{fmtMoney(promo.promo_price)}</span>
        </div>
        <div className="flex items-center gap-1 text-[11px] text-muted-foreground">
          <Clock className="w-3 h-3" /> {countdown}
        </div>
        <Button size="sm" variant="outline" className="w-full" onClick={() => onView(promo)}>
          <Eye className="w-4 h-4 mr-1" /> Visualizar
        </Button>
      </div>
    </motion.div>
  );
}

export default function PromotionHighlights({ promotions, onView }) {
  const active = promotions.filter((p) => p._effective === 'active' || (p.status === 'active' && p._effective !== 'ended'));
  if (active.length === 0) {
    return (
      <div className="rounded-2xl border border-dashed border-border p-6 text-center text-sm text-muted-foreground">
        Nenhuma promoção em destaque no momento.
      </div>
    );
  }
  return (
    <div>
      <h3 className="text-sm font-semibold text-foreground mb-3">Destaques</h3>
      <div className="flex gap-3 overflow-x-auto pb-2">
        {active.map((p) => <HighlightCard key={p.id} promo={p} onView={onView} />)}
      </div>
    </div>
  );
}