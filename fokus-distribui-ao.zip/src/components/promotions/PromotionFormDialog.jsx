import React, { useState, useEffect, useMemo } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Plus, Trash2, Loader2, AlertTriangle, Upload } from 'lucide-react';
import { fmtMoney, computeComboOriginal, discountPercent, isDuplicate } from '@/lib/promotions';
import { base44 } from '@/api/base44Client';
import ProductPicker from '@/components/products/ProductPicker';

const toLocalInput = (iso) => {
  if (!iso) return '';
  try {
    const d = new Date(iso);
    const off = d.getTimezoneOffset();
    return new Date(d.getTime() - off * 60000).toISOString().slice(0, 16);
  } catch { return ''; }
};

export default function PromotionFormDialog({ open, onClose, onSave, saving, products = [], allPromotions = [], existing = null }) {
  const [form, setForm] = useState({ name: '', type: 'product', description: '', image_url: '', product_id: '', product_name: '', original_price: 0, promo_price: 0, discount_percent: 0, quantity_available: '', start_date: '', end_date: '', status: 'scheduled', combo_items: [] });

  useEffect(() => {
    if (!open) return;
    if (existing) {
      setForm({
        name: existing.name || '', type: existing.type || 'product', description: existing.description || '', image_url: existing.image_url || '',
        product_id: existing.product_id || '', product_name: existing.product_name || '', original_price: existing.original_price || 0,
        promo_price: existing.promo_price || 0, discount_percent: existing.discount_percent || 0, quantity_available: existing.quantity_available ?? '',
        start_date: toLocalInput(existing.start_date), end_date: toLocalInput(existing.end_date),
        status: existing.status || 'scheduled', combo_items: existing.combo_items || [],
      });
    } else {
      setForm({ name: '', type: 'product', description: '', image_url: '', product_id: '', product_name: '', original_price: 0, promo_price: 0, discount_percent: 0, quantity_available: '', start_date: '', end_date: '', status: 'scheduled', combo_items: [] });
    }
  }, [open, existing]);

  const set = (k, v) => setForm((f) => ({ ...f, [k]: v }));
  const [uploading, setUploading] = useState(false);

  const onUploadImage = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    try {
      setUploading(true);
      const res = await base44.integrations.Core.UploadFile({ file });
      if (res?.file_url) set('image_url', res.file_url);
    } catch {
      // ignore — field stays as-is
    } finally {
      setUploading(false);
      e.target.value = '';
    }
  };

  const onSelectProduct = (p) => {
    if (!p) return;
    setForm((f) => ({ ...f, product_id: p.id, product_name: p.name || '', original_price: p.price || 0, discount_percent: discountPercent(p.price || 0, f.promo_price) }));
  };

  const [comboPicker, setComboPicker] = useState({ open: false, index: null });
  const openComboPicker = (i) => setComboPicker({ open: true, index: i });
  const onComboPick = (p) => {
    if (comboPicker.index == null || !p) return;
    updateComboItem(comboPicker.index, { product_id: p.id, product_name: p.name || '', unit_price: p.price || 0 });
  };
  const onPromoPrice = (v) => {
    const promo = Number(v) || 0;
    setForm((f) => ({ ...f, promo_price: promo, discount_percent: discountPercent(f.original_price, promo) }));
  };

  const addComboItem = () => setForm((f) => ({ ...f, combo_items: [...f.combo_items, { product_id: '', product_name: '', quantity: 1, unit_price: 0 }] }));
  const updateComboItem = (i, patch) => setForm((f) => {
    const items = [...f.combo_items];
    items[i] = { ...items[i], ...patch };
    return { ...f, combo_items: items };
  });
  const removeComboItem = (i) => setForm((f) => ({ ...f, combo_items: f.combo_items.filter((_, idx) => idx !== i) }));

  const comboOriginal = useMemo(() => computeComboOriginal(form.combo_items), [form.combo_items]);
  const comboSavings = form.type === 'combo' ? Math.max(0, comboOriginal - (Number(form.promo_price) || 0)) : 0;
  const dup = isDuplicate({ ...form, id: existing?.id, start_date: form.start_date ? new Date(form.start_date).toISOString() : null, end_date: form.end_date ? new Date(form.end_date).toISOString() : null }, allPromotions, existing?.id);

  const canSave = form.name.trim() && form.start_date && form.end_date && (form.type === 'product' ? form.product_id : form.combo_items.length > 0);

  const handleSubmit = () => {
    if (!canSave) return;
    if (dup) return;
    const payload = {
      ...form,
      original_price: form.type === 'combo' ? comboOriginal : Number(form.original_price) || 0,
      discount_percent: form.type === 'combo' ? discountPercent(comboOriginal, form.promo_price) : form.discount_percent,
      quantity_available: form.quantity_available === '' ? null : Number(form.quantity_available),
      start_date: new Date(form.start_date).toISOString(),
      end_date: new Date(form.end_date).toISOString(),
    };
    onSave(payload);
  };

  return (
    <Dialog open={open} onOpenChange={(o) => !o && onClose()}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>{existing ? 'Editar promoção' : 'Nova promoção'}</DialogTitle>
        </DialogHeader>

        <div className="grid gap-4 py-2">
          <div className="flex gap-2">
            <Button type="button" size="sm" variant={form.type === 'product' ? 'default' : 'outline'} onClick={() => set('type', 'product')} className="flex-1">Promoção de Produto</Button>
            <Button type="button" size="sm" variant={form.type === 'combo' ? 'default' : 'outline'} onClick={() => set('type', 'combo')} className="flex-1">Promoção de Combo</Button>
          </div>

          <div className="grid gap-2">
            <Label htmlFor="p-name">Nome *</Label>
            <Input id="p-name" value={form.name} onChange={(e) => set('name', e.target.value)} placeholder="Ex: Black Friday Cerveja" />
          </div>

          <div className="grid gap-2">
            <Label htmlFor="p-desc">Descrição</Label>
            <Textarea id="p-desc" value={form.description} onChange={(e) => set('description', e.target.value)} rows={2} />
          </div>

          <div className="grid gap-2">
            <Label>Imagem</Label>
            {form.image_url && <img src={form.image_url} alt="preview" className="h-28 w-full object-cover rounded-lg border" />}
            <div className="flex gap-2">
              <Input value={form.image_url} onChange={(e) => set('image_url', e.target.value)} placeholder="Cole uma URL..." className="flex-1" />
              <label className="inline-flex items-center gap-2 whitespace-nowrap rounded-md border border-input bg-background px-3 h-9 text-sm cursor-pointer hover:bg-accent">
                {uploading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Upload className="w-4 h-4" />}
                {uploading ? 'Enviando...' : 'Enviar'}
                <input type="file" accept="image/*" className="hidden" onChange={onUploadImage} disabled={uploading} />
              </label>
            </div>
          </div>

          {form.type === 'product' ? (
            <div className="grid sm:grid-cols-2 gap-3">
              <div className="grid gap-2">
                <Label>Produto *</Label>
                <ProductPicker
                  products={products}
                  mode="select"
                  selectedId={form.product_id}
                  onSelect={onSelectProduct}
                  triggerVariant="select"
                  triggerLabel="Selecione um produto..."
                  stockFilter={null}
                />
              </div>
              <div className="grid gap-2">
                <Label>Valor original</Label>
                <Input value={fmtMoney(form.original_price)} disabled />
              </div>
              <div className="grid gap-2">
                <Label>Valor promocional *</Label>
                <Input type="number" step="0.01" value={form.promo_price || ''} onChange={(e) => onPromoPrice(e.target.value)} />
              </div>
              <div className="grid gap-2">
                <Label>Desconto (%)</Label>
                <Input value={`${form.discount_percent}%`} disabled />
              </div>
              <div className="grid gap-2">
                <Label>Quantidade disponível</Label>
                <Input type="number" value={form.quantity_available} onChange={(e) => set('quantity_available', e.target.value)} placeholder="Ilimitado" />
              </div>
            </div>
          ) : (
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <Label>Itens do combo</Label>
                <Button type="button" size="sm" variant="outline" onClick={addComboItem}><Plus className="w-4 h-4 mr-1" /> Adicionar item</Button>
              </div>
              {form.combo_items.map((it, i) => (
                <div key={i} className="grid grid-cols-12 gap-2 items-end">
                  <div className="col-span-6 grid gap-1">
                    <Label className="text-xs">Produto</Label>
                    <button
                      type="button"
                      onClick={() => openComboPicker(i)}
                      className="flex h-9 w-full items-center justify-between rounded-md border border-input bg-transparent px-3 text-sm shadow-sm hover:bg-accent"
                    >
                      <span className={it.product_name ? 'text-foreground truncate' : 'text-muted-foreground'}>
                        {it.product_name || 'Selecione...'}
                      </span>
                      <Plus className="h-4 w-4 opacity-50 shrink-0" />
                    </button>
                  </div>
                  <div className="col-span-3 grid gap-1">
                    <Label className="text-xs">Qtd</Label>
                    <Input type="number" min="1" className="h-9" value={it.quantity} onChange={(e) => updateComboItem(i, { quantity: Number(e.target.value) || 1 })} />
                  </div>
                  <div className="col-span-2 grid gap-1">
                    <Label className="text-xs">Preço</Label>
                    <Input type="number" step="0.01" className="h-9" value={it.unit_price} onChange={(e) => updateComboItem(i, { unit_price: Number(e.target.value) || 0 })} />
                  </div>
                  <Button type="button" size="icon" variant="ghost" className="col-span-1 h-9" onClick={() => removeComboItem(i)}><Trash2 className="w-4 h-4 text-red-500" /></Button>
                </div>
              ))}
              <div className="grid sm:grid-cols-3 gap-2 text-sm">
                <div className="rounded-lg bg-muted px-3 py-2"><span className="text-muted-foreground">Original: </span><b>{fmtMoney(comboOriginal)}</b></div>
                <div className="rounded-lg bg-muted px-3 py-2"><span className="text-muted-foreground">Economia: </span><b>{fmtMoney(comboSavings)}</b></div>
                <div className="rounded-lg bg-muted px-3 py-2"><span className="text-muted-foreground">Desconto: </span><b>{discountPercent(comboOriginal, form.promo_price)}%</b></div>
              </div>
              <div className="grid gap-2">
                <Label>Valor promocional do combo *</Label>
                <Input type="number" step="0.01" value={form.promo_price || ''} onChange={(e) => onPromoPrice(e.target.value)} />
              </div>

              <ProductPicker
                products={products}
                mode="select"
                open={comboPicker.open}
                onOpenChange={(v) => setComboPicker((s) => ({ ...s, open: v }))}
                onSelect={onComboPick}
                selectedId={comboPicker.index != null ? (form.combo_items[comboPicker.index]?.product_id || null) : null}
                stockFilter={null}
              />
            </div>
          )}

          <div className="grid sm:grid-cols-2 gap-3">
            <div className="grid gap-2">
              <Label>Data inicial *</Label>
              <Input type="datetime-local" value={form.start_date} onChange={(e) => set('start_date', e.target.value)} />
            </div>
            <div className="grid gap-2">
              <Label>Data final *</Label>
              <Input type="datetime-local" value={form.end_date} onChange={(e) => set('end_date', e.target.value)} />
            </div>
          </div>

          <div className="grid gap-2">
            <Label>Status</Label>
            <Select value={form.status} onValueChange={(v) => set('status', v)}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="scheduled">Agendada</SelectItem>
                <SelectItem value="active">Ativa</SelectItem>
                <SelectItem value="inactive">Inativa</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {dup && (
            <div className="flex items-center gap-2 text-sm text-amber-700 dark:text-amber-400 bg-amber-50 dark:bg-amber-950/30 rounded-lg px-3 py-2">
              <AlertTriangle className="w-4 h-4" /> Já existe uma promoção ativa para este produto neste período.
            </div>
          )}
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={onClose}>Cancelar</Button>
          <Button onClick={handleSubmit} disabled={!canSave || dup || saving}>
            {saving ? <Loader2 className="w-4 h-4 animate-spin mr-1" /> : null}
            {existing ? 'Salvar' : 'Criar promoção'}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}