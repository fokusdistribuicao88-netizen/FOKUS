import React from 'react';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Search } from 'lucide-react';

const FILTERS = [
  { key: 'all', label: 'Todas' },
  { key: 'active', label: 'Ativas' },
  { key: 'scheduled', label: 'Agendadas' },
  { key: 'ended', label: 'Encerradas' },
  { key: 'combo', label: 'Combos' },
  { key: 'product', label: 'Produtos' },
];

const SORTS = [
  { key: 'name', label: 'Nome' },
  { key: 'date', label: 'Data' },
  { key: 'status', label: 'Status' },
  { key: 'discount', label: 'Desconto' },
];

export default function PromotionFilters({ search, onSearch, filter, onFilter, sort, onSort }) {
  return (
    <div className="flex flex-col sm:flex-row gap-3">
      <div className="relative flex-1">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
        <Input value={search} onChange={(e) => onSearch(e.target.value)} placeholder="Buscar promoções..." className="pl-9" />
      </div>
      <div className="flex flex-wrap gap-1.5">
        {FILTERS.map((f) => (
          <button
            key={f.key}
            onClick={() => onFilter(f.key)}
            className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-colors ${
              filter === f.key
                ? 'bg-blue-600 text-white'
                : 'bg-muted text-muted-foreground hover:bg-accent'
            }`}
          >
            {f.label}
          </button>
        ))}
      </div>
      <Select value={sort} onValueChange={onSort}>
        <SelectTrigger className="w-36"><SelectValue placeholder="Ordenar" /></SelectTrigger>
        <SelectContent>
          {SORTS.map((s) => <SelectItem key={s.key} value={s.key}>Ordenar: {s.label}</SelectItem>)}
        </SelectContent>
      </Select>
    </div>
  );
}