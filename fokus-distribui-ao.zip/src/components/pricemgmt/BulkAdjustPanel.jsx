import React, { useState } from 'react';
import { SlidersHorizontal, Check, X, Loader2, AlertTriangle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { BULK_TARGETS, ALL_PRICE_FIELDS, FIELD_LABELS, computeNewValue, formatMoney, round2 } from './constants';

export default function BulkAdjustPanel({
  selectedCount,
  selectedProducts,
  onApply,
  onClear,
  onSelectAll,
}) {
  const [target, setTarget] = useState('price');
  const [operation, setOperation] = useState('+');
  const [type, setType] = useState('percent');
  const [value, setValue] = useState('');
  const [preview, setPreview] = useState(null);
  const [applying, setApplying] = useState(false);

  if (selectedCount === 0) return null;

  const targets = target === 'all' ? ALL_PRICE_FIELDS : [target];

  const buildPreview = () => {
    const v = Number(value);
    if (!value || !isFinite(v) || v <= 0) return;
    const rows = [];
    selectedProducts.slice(0, 50).forEach((p) => {
      targets.forEach((f) => {
        const oldVal = p[f] ?? 0;
        const newVal = computeNewValue(oldVal, operation, type, value);
        rows.push({
          name: p.name,
          field: FIELD_LABELS[f],
          old: oldVal,
          new: newVal,
          diff: round2(newVal - oldVal),
        });
      });
    });
    setPreview(rows);
  };

  const handleApply = async () => {
    const v = Number(value);
    if (!value || !isFinite(v) || v <= 0) return;
    setApplying(true);
    try {
      await onApply({ target, operation, type, value: v });
      setPreview(null);
      setValue('');
    } finally {
      setApplying(false);
    }
  };

  return (
    <div className="bg-blue-50/70 dark:bg-blue-950/30 border border-blue-200 dark:border-blue-800 rounded-xl p-4 mb-4 shadow-sm">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 mb-3">
        <div className="flex items-center gap-2 min-w-0">
          <SlidersHorizontal className="w-4 h-4 text-blue-600 shrink-0" />
          <span className="text-sm font-semibold text-foreground truncate">
            Edição em massa — <span className="text-blue-600">{selectedCount}</span> produto(s) selecionado(s)
          </span>
        </div>
        <div className="flex items-center gap-2 shrink-0">
          <Button size="sm" variant="outline" onClick={onSelectAll} className="h-8 text-xs">
            Selecionar todos
          </Button>
          <Button size="sm" variant="ghost" onClick={onClear} className="h-8 text-xs">
            <X className="w-3.5 h-3.5" /> Limpar
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-2 items-end">
        <div>
          <label className="text-xs text-muted-foreground mb-1 block">Aplicar em</label>
          <Select value={target} onValueChange={(v) => { setTarget(v); setPreview(null); }}>
            <SelectTrigger className="w-full"><SelectValue /></SelectTrigger>
            <SelectContent>
              {BULK_TARGETS.map((t) => <SelectItem key={t.key} value={t.key}>{t.label}</SelectItem>)}
            </SelectContent>
          </Select>
        </div>

        <div>
          <label className="text-xs text-muted-foreground mb-1 block">Tipo</label>
          <Select value={type} onValueChange={(v) => { setType(v); setPreview(null); }}>
            <SelectTrigger className="w-full"><SelectValue /></SelectTrigger>
            <SelectContent>
              <SelectItem value="percent">Percentual</SelectItem>
              <SelectItem value="fixed">Valor fixo</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <div>
          <label className="text-xs text-muted-foreground mb-1 block">Operação</label>
          <div className="flex gap-2">
            <button
              onClick={() => { setOperation('+'); setPreview(null); }}
              className={`flex-1 h-9 rounded-md border text-sm font-semibold transition-colors ${
                operation === '+' ? 'bg-green-600 text-white border-green-600' : 'bg-card border-border text-muted-foreground hover:bg-accent'
              }`}
            >+ Aumentar</button>
            <button
              onClick={() => { setOperation('-'); setPreview(null); }}
              className={`flex-1 h-9 rounded-md border text-sm font-semibold transition-colors ${
                operation === '-' ? 'bg-red-600 text-white border-red-600' : 'bg-card border-border text-muted-foreground hover:bg-accent'
              }`}
            >- Diminuir</button>
          </div>
        </div>

        <div>
          <label className="text-xs text-muted-foreground mb-1 block">{type === 'percent' ? 'Percentual (%)' : 'Valor (R$)'}</label>
          <Input
            type="number"
            step="0.01"
            min="0"
            value={value}
            onChange={(e) => { setValue(e.target.value); setPreview(null); }}
            placeholder={type === 'percent' ? 'Ex: 8' : 'Ex: 1.50'}
          />
        </div>

        <div className="flex gap-2">
          <Button onClick={buildPreview} variant="outline" className="flex-1 h-9" disabled={!value}>
            Pré-visualizar
          </Button>
          <Button onClick={handleApply} className="flex-1 h-9 bg-blue-600 hover:bg-blue-700 text-white" disabled={!value || applying}>
            {applying ? <Loader2 className="w-4 h-4 animate-spin" /> : <Check className="w-4 h-4" />}
            Confirmar
          </Button>
        </div>
      </div>

      {preview !== null && (
        <div className="mt-4 border-t border-blue-200 dark:border-blue-800 pt-3">
          <div className="flex items-center gap-2 mb-2">
            <AlertTriangle className="w-4 h-4 text-amber-500" />
            <span className="text-xs font-semibold text-foreground">
              Pré-visualização — {operation === '+' ? 'Aumento' : 'Redução'} de {value}{type === 'percent' ? '%' : ' R$'} em {target === 'all' ? 'todos os preços' : FIELD_LABELS[target]}
            </span>
          </div>
          <div className="max-h-56 overflow-auto rounded-lg border border-border bg-card">
            <table className="w-full text-xs">
              <thead className="sticky top-0 bg-muted/60">
                <tr>
                  <th className="text-left px-3 py-1.5 font-semibold text-muted-foreground">Produto</th>
                  <th className="text-left px-3 py-1.5 font-semibold text-muted-foreground">Campo</th>
                  <th className="text-right px-3 py-1.5 font-semibold text-muted-foreground">Antigo</th>
                  <th className="text-right px-3 py-1.5 font-semibold text-muted-foreground">Novo</th>
                  <th className="text-right px-3 py-1.5 font-semibold text-muted-foreground">Diferença</th>
                </tr>
              </thead>
              <tbody>
                {preview.map((r, i) => (
                  <tr key={i} className="border-t border-border">
                    <td className="px-3 py-1.5 text-foreground truncate max-w-[180px]">{r.name}</td>
                    <td className="px-3 py-1.5 text-muted-foreground">{r.field}</td>
                    <td className="px-3 py-1.5 text-right tabular-nums text-muted-foreground">{formatMoney(r.old)}</td>
                    <td className="px-3 py-1.5 text-right tabular-nums font-medium text-foreground">{formatMoney(r.new)}</td>
                    <td className={`px-3 py-1.5 text-right tabular-nums font-medium ${r.diff >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                      {r.diff >= 0 ? '+' : ''}{formatMoney(r.diff)}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          <p className="text-xs text-muted-foreground mt-2">
            Mostrando {Math.min(preview.length, 50 * targets.length)} de {selectedCount * targets.length} alterações. Clique em "Confirmar" para gravar.
          </p>
        </div>
      )}
    </div>
  );
}