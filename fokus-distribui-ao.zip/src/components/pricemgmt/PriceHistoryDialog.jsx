import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery } from '@tanstack/react-query';
import { History, Undo2, Loader2, X } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { formatMoney, FIELD_LABELS } from './constants';

function formatDate(iso) {
  if (!iso) return '-';
  const d = new Date(iso);
  return d.toLocaleString('pt-BR', { day: '2-digit', month: '2-digit', year: 'numeric', hour: '2-digit', minute: '2-digit' });
}

export default function PriceHistoryDialog({ open, onClose, onRevert }) {
  const [filter, setFilter] = useState('all');
  const [reverting, setReverting] = useState(false);

  const { data: records = [], isLoading } = useQuery({
    queryKey: ['price-history'],
    queryFn: () => base44.entities.PriceHistory.list('-created_date', 500),
    enabled: open,
    staleTime: 30 * 1000,
  });

  if (!open) return null;

  // Group by batch_id for bulk operations
  const batches = {};
  records.forEach((r) => {
    if (r.action_type === 'bulk' && r.batch_id) {
      if (!batches[r.batch_id]) {
        batches[r.batch_id] = { id: r.batch_id, description: r.batch_description, date: r.created_date, count: 0, items: [] };
      }
      batches[r.batch_id].count++;
      batches[r.batch_id].items.push(r);
    }
  });
  const batchList = Object.values(batches).sort((a, b) => new Date(b.date) - new Date(a.date));
  const latestBatch = batchList[0];

  const shown = filter === 'bulk' ? records.filter((r) => r.action_type === 'bulk') : records;

  const handleRevert = async (batch) => {
    setReverting(true);
    try {
      await onRevert(batch);
    } finally {
      setReverting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50" onClick={onClose}>
      <div className="bg-card rounded-xl shadow-2xl w-full max-w-4xl max-h-[85vh] flex flex-col" onClick={(e) => e.stopPropagation()}>
        <div className="flex items-center justify-between px-5 py-4 border-b border-border">
          <div className="flex items-center gap-2">
            <History className="w-5 h-5 text-blue-600" />
            <h2 className="text-base font-semibold text-foreground">Histórico de Alterações de Preço</h2>
          </div>
          <button onClick={onClose} className="text-muted-foreground hover:text-foreground"><X className="w-5 h-5" /></button>
        </div>

        {latestBatch && (
          <div className="px-5 py-3 bg-amber-50 dark:bg-amber-950/30 border-b border-amber-200 dark:border-amber-800 flex items-center justify-between gap-3 flex-wrap">
            <div className="text-xs text-foreground">
              <span className="font-semibold">Última atualização em massa:</span> {formatDate(latestBatch.date)} — {latestBatch.description} ({latestBatch.count} alterações)
            </div>
            <Button size="sm" variant="outline" onClick={() => handleRevert(latestBatch)} disabled={reverting} className="h-8 border-amber-400 text-amber-700 hover:bg-amber-100">
              {reverting ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Undo2 className="w-3.5 h-3.5" />}
              Reverter esta atualização
            </Button>
          </div>
        )}

        <div className="px-5 py-2 border-b border-border flex items-center gap-2">
          <button onClick={() => setFilter('all')} className={`px-3 py-1 text-xs rounded-full ${filter === 'all' ? 'bg-blue-600 text-white' : 'bg-muted text-muted-foreground'}`}>Todas</button>
          <button onClick={() => setFilter('bulk')} className={`px-3 py-1 text-xs rounded-full ${filter === 'bulk' ? 'bg-blue-600 text-white' : 'bg-muted text-muted-foreground'}`}>Em massa</button>
          <span className="ml-auto text-xs text-muted-foreground">{shown.length} registro(s)</span>
        </div>

        <div className="overflow-auto flex-1">
          {isLoading ? (
            <div className="flex items-center justify-center py-12"><Loader2 className="w-6 h-6 animate-spin text-blue-600" /></div>
          ) : shown.length === 0 ? (
            <div className="text-center py-12 text-sm text-muted-foreground">Nenhuma alteração registrada.</div>
          ) : (
            <table className="w-full text-xs">
              <thead className="sticky top-0 bg-muted">
                <tr>
                  <th className="text-left px-3 py-2 font-semibold text-muted-foreground">Data/Hora</th>
                  <th className="text-left px-3 py-2 font-semibold text-muted-foreground">Produto</th>
                  <th className="text-left px-3 py-2 font-semibold text-muted-foreground">Campo</th>
                  <th className="text-right px-3 py-2 font-semibold text-muted-foreground">Antigo</th>
                  <th className="text-right px-3 py-2 font-semibold text-muted-foreground">Novo</th>
                  <th className="text-right px-3 py-2 font-semibold text-muted-foreground">%</th>
                  <th className="text-left px-3 py-2 font-semibold text-muted-foreground">Tipo</th>
                </tr>
              </thead>
              <tbody>
                {shown.map((r) => (
                  <tr key={r.id} className="border-t border-border hover:bg-accent/40">
                    <td className="px-3 py-1.5 text-muted-foreground whitespace-nowrap">{formatDate(r.created_date)}</td>
                    <td className="px-3 py-1.5 text-foreground truncate max-w-[180px]">{r.product_name || '-'}</td>
                    <td className="px-3 py-1.5 text-muted-foreground">{FIELD_LABELS[r.field] || r.field}</td>
                    <td className="px-3 py-1.5 text-right tabular-nums text-muted-foreground">{formatMoney(r.old_value)}</td>
                    <td className="px-3 py-1.5 text-right tabular-nums font-medium text-foreground">{formatMoney(r.new_value)}</td>
                    <td className="px-3 py-1.5 text-right tabular-nums">{r.percent != null ? `${r.percent > 0 ? '+' : ''}${r.percent}%` : '-'}</td>
                    <td className="px-3 py-1.5">
                      <span className={`px-1.5 py-0.5 rounded text-[10px] font-medium ${r.action_type === 'bulk' ? 'bg-purple-100 text-purple-700 dark:bg-purple-950/40 dark:text-purple-400' : 'bg-blue-100 text-blue-700 dark:bg-blue-950/40 dark:text-blue-400'}`}>
                        {r.action_type === 'bulk' ? 'Massa' : 'Individual'}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>
      </div>
    </div>
  );
}