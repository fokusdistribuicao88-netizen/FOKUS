import React, { useState } from 'react';
import { ArrowUp, ArrowDown, ArrowUpDown } from 'lucide-react';
import { formatMoney, computeMargin } from './constants';

const EDITABLE = ['cost', 'price', 'price_wholesale', 'price_cash', 'price_promo', 'retail_price'];

const COLUMNS = [
  { key: 'checkbox', label: '', sticky: 0, w: 44 },
  { key: 'name', label: 'Produto', sortable: true, w: 200 },
  { key: 'category', label: 'Categoria', sortable: true, w: 120 },
  { key: 'volume_ml', label: 'Volume (ml)', sortable: true, w: 95 },
  { key: 'units_per_pack', label: 'Unid./Pack', sortable: true, w: 90 },
  { key: 'stock_quantity', label: 'Estoque', sortable: true, w: 80 },
  { key: 'cost', label: 'Custo', editable: true, sortable: true, w: 95 },
  { key: 'price_cash', label: 'À Vista', editable: true, sortable: true, w: 95 },
  { key: 'price_wholesale', label: 'Atacado', editable: true, sortable: true, w: 95 },
  { key: 'price', label: 'Venda', editable: true, sortable: true, w: 95 },
  { key: 'retail_price', label: 'Cliente Final', editable: true, sortable: true, w: 105 },
  { key: 'price_promo', label: 'Promo', editable: true, sortable: true, w: 95 },
  { key: 'margin', label: 'Margem %', sortable: true, w: 85 },
  { key: 'status', label: 'Status', w: 90 },
];

function EditableCell({ product, field, onSave, canEdit, pending }) {
  const [editing, setEditing] = useState(false);
  const [val, setVal] = useState('');
  const pendingVal = pending?.[product.id]?.[field];
  const isPending = pendingVal !== undefined && pendingVal !== product[field];
  const value = isPending ? pendingVal : product[field];

  const startEdit = (e) => { if (!canEdit) return; e.stopPropagation(); setVal(value ?? ''); setEditing(true); };
  const commit = () => {
    setEditing(false);
    const num = parseFloat(val);
    if (isFinite(num) && num !== value) onSave(product.id, field, num);
  };
  const onKeyDown = (e) => {
    if (e.key === 'Enter') { e.preventDefault(); e.target.blur(); }
    else if (e.key === 'Escape') setEditing(false);
  };

  if (editing) {
    return (
      <input
        autoFocus
        type="number"
        step="0.01"
        value={val}
        onChange={(e) => setVal(e.target.value)}
        onBlur={commit}
        onKeyDown={onKeyDown}
        className="w-full px-1.5 py-1 text-xs border border-blue-500 rounded focus:outline-none focus:ring-1 focus:ring-blue-400 bg-white"
      />
    );
  }
  return (
    <span
      onDoubleClick={startEdit}
      className={`px-1.5 py-1 text-xs rounded transition-colors inline-block w-full tabular-nums ${canEdit ? 'cursor-text hover:bg-blue-50 dark:hover:bg-blue-950/40' : 'cursor-default'} ${isPending ? 'bg-amber-100 dark:bg-amber-950/50 text-amber-700 dark:text-amber-400 font-medium ring-1 ring-amber-300' : ''}`}
      title={canEdit ? (isPending ? 'Alteração não salva' : 'Duplo clique para editar') : 'Somente leitura'}
    >
      {formatMoney(value)}
    </span>
  );
}

function SortHeader({ col, sortField, sortDir, onSort }) {
  const active = sortField === col.key;
  const Icon = active ? (sortDir === 'asc' ? ArrowUp : ArrowDown) : ArrowUpDown;
  return (
    <button
      onClick={() => onSort(col.key)}
      className="flex items-center gap-1 text-xs font-semibold text-muted-foreground hover:text-foreground"
    >
      {col.label}
      <Icon className={`w-3 h-3 ${active ? 'text-blue-500' : 'opacity-40'}`} />
    </button>
  );
}

export default function PriceTable({
  products,
  selectedIds,
  onToggleSelect,
  onToggleSelectPage,
  allPageSelected,
  sortField,
  sortDir,
  onSort,
  onPriceSave,
  onStatusToggle,
  canEdit = true,
  pending = {},
}) {
  return (
    <div className="border border-border rounded-xl overflow-hidden bg-card shadow-sm">
      <div className="overflow-auto" style={{ maxHeight: '70vh' }}>
        <table className="border-collapse text-sm" style={{ minWidth: 1100 }}>
          <thead>
            <tr className="bg-muted/60">
              {COLUMNS.map((col) => (
                <th
                  key={col.key}
                  style={{
                    width: col.w,
                    minWidth: col.w,
                    position: 'sticky',
                    top: 0,
                    background: 'hsl(var(--muted))',
                    ...(col.sticky !== undefined ? { left: col.sticky, zIndex: 40 } : { zIndex: 20 }),
                  }}
                  className="px-2 py-2 text-left border-b border-border whitespace-nowrap top-0"
                >
                  {col.key === 'checkbox' ? (
                    canEdit ? (
                    <input
                      type="checkbox"
                      checked={allPageSelected}
                      onChange={onToggleSelectPage}
                      className="w-4 h-4 cursor-pointer accent-blue-600"
                    /> ) : null
                  ) : col.sortable ? (
                    <SortHeader col={col} sortField={sortField} sortDir={sortDir} onSort={onSort} />
                  ) : (
                    <span className="text-xs font-semibold text-muted-foreground">{col.label}</span>
                  )}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {products.map((p, idx) => {
              const selected = selectedIds.has(p.id);
              const rowBg = selected ? 'bg-blue-50/60 dark:bg-blue-950/20' : (idx % 2 ? 'bg-card' : 'bg-muted/20');
              return (
                <tr key={p.id} className={`${rowBg} hover:bg-accent/40 transition-colors`}>
                  {COLUMNS.map((col) => {
                    const stickyStyle = col.sticky !== undefined
                      ? { position: 'sticky', left: col.sticky, zIndex: 10, background: 'hsl(var(--card))', boxShadow: selected ? 'inset 3px 0 0 hsl(var(--primary))' : '1px 0 0 hsl(var(--border))' }
                      : {};
                    if (col.key === 'checkbox') {
                    return canEdit ? (
                     <td key={col.key} style={{ ...stickyStyle, width: col.w }} className="px-2 py-1.5 border-b border-border">
                       <input
                         type="checkbox"
                         checked={selected}
                         onChange={() => onToggleSelect(p.id)}
                         className="w-4 h-4 cursor-pointer accent-blue-600"
                       />
                     </td>
                    ) : null;
                    }
                    if (col.key === 'status') {
                      return (
                        <td key={col.key} style={{ width: col.w }} className="px-2 py-1.5 border-b border-border">
                          <button
                            onClick={() => canEdit && onStatusToggle(p)}
                            disabled={!canEdit}
                            className={`px-2 py-0.5 text-xs rounded-full font-medium ${
                              p.status === 'inactive'
                                ? 'bg-red-100 text-red-700 dark:bg-red-950/40 dark:text-red-400'
                                : 'bg-green-100 text-green-700 dark:bg-green-950/40 dark:text-green-400'
                            }`}
                          >
                            {p.status === 'inactive' ? 'Inativo' : 'Ativo'}
                          </button>
                        </td>
                      );
                    }
                    if (col.key === 'margin') {
                      const m = computeMargin(p.price, p.cost);
                      return (
                        <td key={col.key} style={{ width: col.w }} className="px-2 py-1.5 border-b border-border text-xs tabular-nums">
                          {m === null ? <span className="text-muted-foreground">-</span> : <span className={m < 0 ? 'text-red-600 font-medium' : 'text-foreground'}>{m}%</span>}
                        </td>
                      );
                    }
                    if (col.key === 'stock_quantity') {
                      const q = p.stock_quantity;
                      const out = !p.in_stock || q === 0;
                      const low = q != null && q <= (p.low_stock_threshold ?? 5);
                      return (
                        <td key={col.key} style={{ width: col.w }} className="px-2 py-1.5 border-b border-border text-xs tabular-nums">
                          <span className={out ? 'text-red-600 font-medium' : low ? 'text-amber-600' : 'text-foreground'}>
                            {q ?? (p.in_stock ? '✓' : '0')}
                          </span>
                        </td>
                      );
                    }
                    if (col.editable) {
                      return (
                        <td key={col.key} style={{ width: col.w, ...stickyStyle }} className="px-1 py-1 border-b border-border">
                          <EditableCell product={p} field={col.key} onSave={onPriceSave} canEdit={canEdit} pending={pending} />
                        </td>
                      );
                    }
                    return (
                      <td key={col.key} style={{ width: col.w, ...stickyStyle }} className="px-2 py-1.5 border-b border-border text-xs text-foreground whitespace-nowrap truncate max-w-[200px]">
                        {p[col.key] || <span className="text-muted-foreground">-</span>}
                      </td>
                    );
                  })}
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
}