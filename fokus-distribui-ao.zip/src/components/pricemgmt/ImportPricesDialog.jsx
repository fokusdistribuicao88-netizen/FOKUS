import React, { useState, useRef } from 'react';
import { base44 } from '@/api/base44Client';
import * as XLSX from 'xlsx';
import { Upload, Loader2, Check, AlertCircle, X } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useToast } from '@/components/ui/use-toast';
import { ALL_PRICE_FIELDS, FIELD_LABELS } from './constants';

const HEADER_MAP = {
  'codigo': 'code', 'código': 'code', 'code': 'code',
  'produto': 'name', 'nome': 'name',
  'custo': 'cost', 'cost': 'cost',
  'venda': 'price', 'preco': 'price', 'preço': 'price', 'preço de venda': 'price',
  'atacado': 'price_wholesale', 'preço atacado': 'price_wholesale',
  'a vista': 'price_cash', 'à vista': 'price_cash', 'vista': 'price_cash', 'a vista (dinheiro)': 'price_cash',
  'promo': 'price_promo', 'promocional': 'price_promo', 'promocao': 'price_promo',
  'varejo': 'retail_price', 'retail': 'retail_price',
};

export default function ImportPricesDialog({ open, onClose, products, onDone }) {
  const { toast } = useToast();
  const fileRef = useRef(null);
  const [parsing, setParsing] = useState(false);
  const [applying, setApplying] = useState(false);
  const [preview, setPreview] = useState(null);

  if (!open) return null;

  const byCode = new Map();
  products.forEach((p) => { if (p.code) byCode.set(String(p.code).trim(), p); });

  const handleFile = async (file) => {
    setParsing(true);
    setPreview(null);
    try {
      const data = await file.arrayBuffer();
      const wb = XLSX.read(data);
      const ws = wb.Sheets[wb.SheetNames[0]];
      const rows = XLSX.utils.sheet_to_json(ws, { defval: '' });
      if (rows.length === 0) {
        toast({ title: 'Arquivo vazio', variant: 'destructive' });
        setParsing(false);
        return;
      }
      // Map headers to fields
      const headers = Object.keys(rows[0]);
      const colMap = {};
      headers.forEach((h) => {
        const key = String(h).toLowerCase().trim();
        const field = HEADER_MAP[key];
        if (field) colMap[h] = field;
      });
      if (!Object.values(colMap).includes('code')) {
        toast({ title: 'Coluna "Código" não encontrada', description: 'A planilha precisa ter uma coluna de código do produto.', variant: 'destructive' });
        setParsing(false);
        return;
      }

      const matched = [];
      const notFound = [];
      rows.forEach((row) => {
        let codeVal = '';
        let rowFields = {};
        Object.entries(colMap).forEach(([h, field]) => {
          const val = row[h];
          if (field === 'code') codeVal = String(val ?? '').trim();
          else if (val !== '' && val !== null && val !== undefined && !isNaN(Number(val))) rowFields[field] = Number(val);
        });
        if (!codeVal) return;
        const product = byCode.get(codeVal);
        if (!product) { notFound.push(codeVal); return; }
        const changes = Object.entries(rowFields).filter(([f, v]) => Number(product[f] ?? 0) !== v);
        if (changes.length) matched.push({ product, changes });
      });

      setPreview({ matched, notFound, total: rows.length });
    } catch (e) {
      toast({ title: 'Erro ao ler arquivo', description: e.message, variant: 'destructive' });
    } finally {
      setParsing(false);
    }
  };

  const handleApply = async () => {
    if (!preview) return;
    setApplying(true);
    try {
      const updates = [];
      const history = [];
      const batchId = crypto?.randomUUID?.() || String(Date.now());
      preview.matched.forEach(({ product, changes }) => {
        const upd = { id: product.id };
        changes.forEach(([field, newVal]) => {
          upd[field] = newVal;
          history.push({
            product_id: product.id,
            product_name: product.name || '',
            field,
            old_value: product[field] ?? 0,
            new_value: newVal,
            percent: product[field] > 0 ? Math.round(((newVal - product[field]) / product[field]) * 10000) / 100 : null,
            batch_id: batchId,
            batch_description: 'Importação Excel',
            action_type: 'bulk',
          });
        });
        updates.push(upd);
      });
      if (updates.length) {
        await base44.entities.Product.bulkUpdate(updates);
        await base44.entities.PriceHistory.bulkCreate(history);
      }
      toast({ title: 'Importação concluída', description: `${preview.matched.length} produto(s) atualizado(s), ${history.length} preço(s) alterado(s).` });
      setPreview(null);
      onDone();
      onClose();
    } catch (e) {
      toast({ title: 'Erro na importação', description: e.message, variant: 'destructive' });
    } finally {
      setApplying(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50" onClick={onClose}>
      <div className="bg-card rounded-xl shadow-2xl w-full max-w-lg flex flex-col" onClick={(e) => e.stopPropagation()}>
        <div className="flex items-center justify-between px-5 py-4 border-b border-border">
          <div className="flex items-center gap-2">
            <Upload className="w-5 h-5 text-blue-600" />
            <h2 className="text-base font-semibold text-foreground">Importar Preços (Excel)</h2>
          </div>
          <button onClick={onClose} className="text-muted-foreground hover:text-foreground"><X className="w-5 h-5" /></button>
        </div>

        <div className="p-5 space-y-4">
          <p className="text-sm text-muted-foreground">
            Selecione uma planilha (.xlsx/.csv). A importação <strong>atualiza apenas os preços</strong> — os demais dados do cadastro são mantidos. A coluna <strong>Código</strong> é obrigatória para identificar cada produto.
          </p>

          <div className="flex items-center gap-2">
            <input
              ref={fileRef}
              type="file"
              accept=".xlsx,.xls,.csv"
              className="hidden"
              onChange={(e) => e.target.files[0] && handleFile(e.target.files[0])}
            />
            <Button variant="outline" onClick={() => fileRef.current?.click()} disabled={parsing || applying}>
              {parsing ? <Loader2 className="w-4 h-4 animate-spin" /> : <Upload className="w-4 h-4" />}
              Selecionar arquivo
            </Button>
            <span className="text-xs text-muted-foreground">Colunas reconhecidas: Código, Custo, Venda, Atacado, À Vista, Promo, Varejo</span>
          </div>

          {preview && (
            <div className="rounded-lg border border-border p-3 space-y-2">
              <div className="flex items-center gap-2 text-sm">
                <Check className="w-4 h-4 text-green-600" />
                <span className="text-foreground"><strong>{preview.matched.length}</strong> produto(s) com alterações de preço</span>
              </div>
              {preview.notFound.length > 0 && (
                <div className="flex items-start gap-2 text-xs text-amber-600">
                  <AlertCircle className="w-4 h-4 mt-0.5 shrink-0" />
                  <span>{preview.notFound.length} código(s) não encontrados: {preview.notFound.slice(0, 8).join(', ')}{preview.notFound.length > 8 ? '…' : ''}</span>
                </div>
              )}
              <div className="max-h-40 overflow-auto rounded border border-border bg-muted/30">
                <table className="w-full text-xs">
                  <thead className="sticky top-0 bg-muted">
                    <tr>
                      <th className="text-left px-2 py-1 font-semibold text-muted-foreground">Produto</th>
                      <th className="text-left px-2 py-1 font-semibold text-muted-foreground">Alterações</th>
                    </tr>
                  </thead>
                  <tbody>
                    {preview.matched.slice(0, 50).map((m, i) => (
                      <tr key={i} className="border-t border-border">
                        <td className="px-2 py-1 text-foreground truncate max-w-[160px]">{m.product.name}</td>
                        <td className="px-2 py-1 text-muted-foreground">{m.changes.map(([f]) => FIELD_LABELS[f]).join(', ')}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
              <div className="flex justify-end gap-2 pt-1">
                <Button variant="ghost" size="sm" onClick={() => setPreview(null)}>Cancelar</Button>
                <Button size="sm" onClick={handleApply} disabled={applying || preview.matched.length === 0} className="bg-blue-600 hover:bg-blue-700 text-white">
                  {applying ? <Loader2 className="w-4 h-4 animate-spin" /> : <Check className="w-4 h-4" />}
                  Confirmar importação
                </Button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}