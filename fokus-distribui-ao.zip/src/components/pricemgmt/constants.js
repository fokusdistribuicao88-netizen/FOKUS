export const PRICE_FIELDS = [
  { key: 'cost', label: 'Custo' },
  { key: 'price', label: 'Preço de Venda' },
  { key: 'price_wholesale', label: 'Atacado' },
  { key: 'price_cash', label: 'À Vista' },
  { key: 'price_promo', label: 'Promocional' },
  { key: 'retail_price', label: 'Cliente Final' },
];

export const ALL_PRICE_FIELDS = [
  'cost', 'price', 'price_wholesale', 'price_cash', 'price_promo', 'retail_price',
];

export const FIELD_LABELS = {
  cost: 'Custo',
  price: 'Venda',
  price_wholesale: 'Atacado',
  price_cash: 'À Vista',
  price_promo: 'Promo',
  retail_price: 'Cliente Final',
  all: 'Todos os preços',
};

export const BULK_TARGETS = [
  ...PRICE_FIELDS,
  { key: 'all', label: 'Todos os preços' },
];

export const round2 = (v) => Math.round((Number(v) + Number.EPSILON) * 100) / 100;

export const computeNewValue = (oldVal, operation, type, value) => {
  const v = Number(oldVal) || 0;
  const adj = Number(value) || 0;
  let result;
  if (type === 'percent') {
    result = operation === '+' ? v * (1 + adj / 100) : v * (1 - adj / 100);
  } else {
    result = operation === '+' ? v + adj : v - adj;
  }
  return round2(result);
};

export const formatMoney = (v) => {
  const n = Number(v);
  if (!isFinite(n) || n === null || n === undefined) return '-';
  return n.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
};

export const computeMargin = (price, cost) => {
  const p = Number(price) || 0;
  const c = Number(cost) || 0;
  if (c <= 0) return null;
  return round2(((p - c) / c) * 100);
};