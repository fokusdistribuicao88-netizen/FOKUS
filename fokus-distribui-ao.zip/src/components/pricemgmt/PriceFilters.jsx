import React from 'react';
import { Search, X } from 'lucide-react';
import { Input } from '@/components/ui/input';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Button } from '@/components/ui/button';

export default function PriceFilters({
  search,
  onSearchChange,
  categories,
  selectedCategory,
  onCategoryChange,
  brands,
  selectedBrand,
  onBrandChange,
  suppliers,
  selectedSupplier,
  onSupplierChange,
  statusFilter,
  onStatusChange,
  stockFilter,
  onStockChange,
  priceMin,
  priceMax,
  onPriceMinChange,
  onPriceMaxChange,
  onClear,
  resultsCount,
  totalCount,
  hasActiveFilters,
}) {
  return (
    <div className="bg-card border border-border rounded-xl p-4 mb-4 shadow-sm">
      <div className="flex items-center justify-between gap-2 mb-3">
        <span className="text-sm font-semibold text-foreground">Busca & Filtros</span>
        <div className="flex items-center gap-2">
          <span className="text-xs text-muted-foreground">
            <span className="font-semibold text-foreground">{resultsCount}</span> de {totalCount} produtos
          </span>
          {hasActiveFilters && (
            <Button size="sm" variant="ghost" onClick={onClear} className="h-7 text-xs">
              <X className="w-3 h-3" /> Limpar
            </Button>
          )}
        </div>
      </div>

      <div className="relative mb-3">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
        <Input
          type="text"
          placeholder="Buscar por nome ou código..."
          value={search}
          onChange={(e) => onSearchChange(e.target.value)}
          className="pl-9"
        />
      </div>

      <div className="grid grid-cols-2 lg:grid-cols-6 gap-2">
        <Select value={selectedCategory || '__all__'} onValueChange={(v) => onCategoryChange(v === '__all__' ? '' : v)}>
          <SelectTrigger className="w-full"><SelectValue placeholder="Categoria" /></SelectTrigger>
          <SelectContent>
            <SelectItem value="__all__">Todas categorias</SelectItem>
            {categories.map((c) => <SelectItem key={c} value={c}>{c}</SelectItem>)}
          </SelectContent>
        </Select>

        <Select value={selectedBrand || '__all__'} onValueChange={(v) => onBrandChange(v === '__all__' ? '' : v)}>
          <SelectTrigger className="w-full"><SelectValue placeholder="Marca" /></SelectTrigger>
          <SelectContent>
            <SelectItem value="__all__">Todas marcas</SelectItem>
            {brands.map((b) => <SelectItem key={b} value={b}>{b}</SelectItem>)}
          </SelectContent>
        </Select>

        <Select value={selectedSupplier || '__all__'} onValueChange={(v) => onSupplierChange(v === '__all__' ? '' : v)}>
          <SelectTrigger className="w-full"><SelectValue placeholder="Fornecedor" /></SelectTrigger>
          <SelectContent>
            <SelectItem value="__all__">Todos fornecedores</SelectItem>
            {suppliers.map((s) => <SelectItem key={s} value={s}>{s}</SelectItem>)}
          </SelectContent>
        </Select>

        <Select value={statusFilter} onValueChange={onStatusChange}>
          <SelectTrigger className="w-full"><SelectValue placeholder="Status" /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">Todos status</SelectItem>
            <SelectItem value="active">Ativos</SelectItem>
            <SelectItem value="inactive">Inativos</SelectItem>
          </SelectContent>
        </Select>

        <Input
          type="number"
          placeholder="Preço mín"
          value={priceMin}
          onChange={(e) => onPriceMinChange(e.target.value)}
          min="0"
        />
        <Input
          type="number"
          placeholder="Preço máx"
          value={priceMax}
          onChange={(e) => onPriceMaxChange(e.target.value)}
          min="0"
        />
      </div>

      <div className="flex flex-wrap items-center gap-2 mt-3">
        <span className="text-xs text-muted-foreground">Estoque:</span>
        {[
          { v: 'all', l: 'Todos' },
          { v: 'in', l: 'Com estoque' },
          { v: 'out', l: 'Sem estoque' },
        ].map((opt) => (
          <button
            key={opt.v}
            onClick={() => onStockChange(opt.v)}
            className={`px-2.5 py-1 text-xs rounded-full border transition-colors ${
              stockFilter === opt.v
                ? 'bg-blue-600 text-white border-blue-600'
                : 'bg-card text-muted-foreground border-border hover:bg-accent'
            }`}
          >
            {opt.l}
          </button>
        ))}
      </div>
    </div>
  );
}