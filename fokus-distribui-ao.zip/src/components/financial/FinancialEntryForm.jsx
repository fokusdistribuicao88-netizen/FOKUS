import React, { useState, useMemo } from "react";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/components/ui/use-toast";
import { base44 } from "@/api/base44Client";
import { useAuth } from "@/lib/AuthContext";
import CustomerPicker from "@/components/customers/CustomerPicker";

const INCOME_CATEGORIES = ["Vendas", "Recebimentos", "Ajustes", "Outras"];
const EXPENSE_CATEGORIES = ["Compras", "Salários", "Impostos", "Marketing", "Energia", "Transporte", "Manutenção", "Outras"];
const PAYMENT_METHODS = ["pix", "credit_card", "debit_card", "boleto", "cash", "transfer", "faturado"];

export default function FinancialEntryForm({ open, onOpenChange, direction, entry, customers }) {
  const { toast } = useToast();
  const { user } = useAuth();
  const [loading, setLoading] = useState(false);
  const isEdit = !!entry;
  const categories = direction === "receivable" ? INCOME_CATEGORIES : EXPENSE_CATEGORIES;

  const [form, setForm] = useState({
    party_name: "",
    party_document: "",
    description: "",
    amount: "",
    paid_amount: "0",
    category: categories[0],
    issue_date: new Date().toISOString().slice(0, 10),
    due_date: "",
    paid_date: "",
    payment_method: "pix",
    cost_center: "",
    notes: "",
  });

  React.useEffect(() => {
    if (open) {
      if (entry) {
        setForm({
          party_name: entry.party_name || "",
          party_document: entry.party_document || "",
          description: entry.description || "",
          amount: entry.amount || "",
          paid_amount: entry.paid_amount || "0",
          category: entry.category || categories[0],
          issue_date: entry.issue_date || new Date().toISOString().slice(0, 10),
          due_date: entry.due_date || "",
          paid_date: entry.paid_date || "",
          payment_method: entry.payment_method || "pix",
          cost_center: entry.cost_center || "",
          notes: entry.notes || "",
        });
      } else {
        setForm({
          party_name: "", party_document: "", description: "", amount: "",
          paid_amount: "0", category: categories[0],
          issue_date: new Date().toISOString().slice(0, 10),
          due_date: "", paid_date: "", payment_method: "pix",
          cost_center: "", notes: "",
        });
      }
    }
  }, [open, entry]);

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!form.party_name || !form.amount || !form.due_date) {
      toast({ title: "Preencha cliente/fornecedor, valor e vencimento", variant: "destructive" });
      return;
    }
    setLoading(true);
    const paid = Number(form.paid_amount) || 0;
    const total = Number(form.amount) || 0;
    let status = "pending";
    if (paid >= total && total > 0) status = "paid";
    else if (paid > 0) status = "partial";

    const payload = {
      direction,
      party_name: form.party_name,
      party_document: form.party_document,
      description: form.description,
      amount: total,
      paid_amount: paid,
      category: form.category,
      issue_date: form.issue_date,
      due_date: form.due_date,
      paid_date: status === "paid" ? form.paid_date || new Date().toISOString().slice(0, 10) : form.paid_date,
      status,
      payment_method: form.payment_method,
      cost_center: form.cost_center,
      responsible: user?.email || user?.full_name || "Sistema",
      notes: form.notes,
    };

    try {
      if (isEdit) await base44.entities.FinancialEntry.update(entry.id, payload);
      else await base44.entities.FinancialEntry.create(payload);
      toast({ title: isEdit ? "Registro atualizado." : "Registro criado." });
      onOpenChange(false);
    } catch (err) {
      toast({ title: "Erro ao salvar", description: String(err), variant: "destructive" });
    } finally {
      setLoading(false);
    }
  };

  const title = `${isEdit ? "Editar" : "Nova"} ${direction === "receivable" ? "Conta a Receber" : "Conta a Pagar"}`;

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-lg">
        <DialogHeader><DialogTitle>{title}</DialogTitle></DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-3">
          <div>
            <Label>{direction === "receivable" ? "Cliente" : "Fornecedor"} *</Label>
            {direction === "receivable" && (customers || []).length > 0 && (
              <div className="mb-2">
                <CustomerPicker
                  customers={customers || []}
                  onSelect={(c) => c && setForm((f) => ({ ...f, party_name: c.name || f.party_name, party_document: c.cpf_cnpj || f.party_document }))}
                  triggerVariant="select"
                  triggerLabel="Selecionar cliente cadastrado..."
                />
              </div>
            )}
            <Input
              value={form.party_name}
              onChange={(e) => setForm({ ...form, party_name: e.target.value })}
              placeholder="Nome"
            />
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <Label>CPF/CNPJ</Label>
              <Input value={form.party_document} onChange={(e) => setForm({ ...form, party_document: e.target.value })} />
            </div>
            <div>
              <Label>Categoria</Label>
              <Select value={form.category} onValueChange={(v) => setForm({ ...form, category: v })}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  {categories.map((c) => <SelectItem key={c} value={c}>{c}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
          </div>
          <div>
            <Label>Descrição</Label>
            <Input value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} />
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <Label>Valor total *</Label>
              <Input type="number" min="0" step="0.01" value={form.amount} onChange={(e) => setForm({ ...form, amount: e.target.value })} />
            </div>
            <div>
              <Label>Valor já recebido/pago</Label>
              <Input type="number" min="0" step="0.01" value={form.paid_amount} onChange={(e) => setForm({ ...form, paid_amount: e.target.value })} />
            </div>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <Label>Data emissão</Label>
              <Input type="date" value={form.issue_date} onChange={(e) => setForm({ ...form, issue_date: e.target.value })} />
            </div>
            <div>
              <Label>Vencimento *</Label>
              <Input type="date" value={form.due_date} onChange={(e) => setForm({ ...form, due_date: e.target.value })} />
            </div>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <Label>Forma de pagamento</Label>
              <Select value={form.payment_method} onValueChange={(v) => setForm({ ...form, payment_method: v })}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  {PAYMENT_METHODS.map((m) => <SelectItem key={m} value={m}>{m}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label>Centro de custo</Label>
              <Input value={form.cost_center} onChange={(e) => setForm({ ...form, cost_center: e.target.value })} />
            </div>
          </div>
          <div>
            <Label>Observações</Label>
            <Textarea rows={2} value={form.notes} onChange={(e) => setForm({ ...form, notes: e.target.value })} />
          </div>
          <DialogFooter>
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>Cancelar</Button>
            <Button type="submit" disabled={loading}>{loading ? "Salvando..." : "Salvar"}</Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}