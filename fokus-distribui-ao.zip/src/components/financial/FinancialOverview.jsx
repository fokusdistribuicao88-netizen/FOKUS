import React from "react";
import { formatBRL, formatDate } from "@/lib/format";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import {
  Wallet, TrendingUp, TrendingDown, DollarSign, Receipt, AlertCircle,
} from "lucide-react";
import {
  BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid,
  Legend, PieChart, Pie, Cell,
} from "recharts";

const today = new Date().toISOString().slice(0, 10);

export default function FinancialOverview({ entries }) {
  const receivables = entries.filter((e) => e.direction === "receivable");
  const payables = entries.filter((e) => e.direction === "payable");

  const totalReceivable = receivables
    .filter((e) => e.status !== "paid" && e.status !== "cancelled")
    .reduce((a, e) => a + (e.amount - (e.paid_amount || 0)), 0);
  const totalPayable = payables
    .filter((e) => e.status !== "paid" && e.status !== "cancelled")
    .reduce((a, e) => a + (e.amount - (e.paid_amount || 0)), 0);

  const paidIncome = receivables
    .filter((e) => e.status === "paid")
    .reduce((a, e) => a + (e.paid_amount || e.amount), 0);
  const paidExpense = payables
    .filter((e) => e.status === "paid")
    .reduce((a, e) => a + (e.paid_amount || e.amount), 0);
  const netProfit = paidIncome - paidExpense;

  const overdueReceivable = receivables.filter(
    (e) => e.status !== "paid" && e.status !== "cancelled" && e.due_date < today
  );
  const overduePayable = payables.filter(
    (e) => e.status !== "paid" && e.status !== "cancelled" && e.due_date < today
  );

  const stats = [
    { label: "Contas a Receber", value: formatBRL(totalReceivable), icon: TrendingUp, color: "text-emerald-600" },
    { label: "Contas a Pagar", value: formatBRL(totalPayable), icon: TrendingDown, color: "text-red-600" },
    { label: "Receitas (pagas)", value: formatBRL(paidIncome), icon: DollarSign, color: "text-green-600" },
    { label: "Despesas (pagas)", value: formatBRL(paidExpense), icon: Receipt, color: "text-orange-600" },
    { label: "Lucro líquido", value: formatBRL(netProfit), icon: Wallet, color: netProfit >= 0 ? "text-emerald-600" : "text-red-600" },
  ];

  // Last 6 months flow
  const flowData = Array.from({ length: 6 }, (_, i) => {
    const d = new Date();
    d.setMonth(d.getMonth() - (5 - i));
    const month = d.toISOString().slice(0, 7);
    const income = receivables
      .filter((e) => (e.paid_date || "").slice(0, 7) === month)
      .reduce((a, e) => a + (e.paid_amount || e.amount), 0);
    const expense = payables
      .filter((e) => (e.paid_date || "").slice(0, 7) === month)
      .reduce((a, e) => a + (e.paid_amount || e.amount), 0);
    return {
      month: d.toLocaleDateString("pt-BR", { month: "short" }),
      receitas: income,
      despesas: expense,
    };
  });

  const categoryData = (() => {
    const map = {};
    payables.filter((e) => e.status === "paid").forEach((e) => {
      const cat = e.category || "Outras";
      map[cat] = (map[cat] || 0) + (e.paid_amount || e.amount);
    });
    return Object.entries(map).map(([name, value]) => ({ name, value }));
  })();

  const PIE_COLORS = ["#6366f1", "#ef4444", "#f59e0b", "#10b981", "#8b5cf6", "#ec4899", "#14b8a6", "#64748b"];

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-2 lg:grid-cols-5 gap-4">
        {stats.map((s) => (
          <Card key={s.label}>
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-xs font-medium text-muted-foreground">{s.label}</CardTitle>
              <s.icon className={`h-4 w-4 ${s.color}`} />
            </CardHeader>
            <CardContent>
              <div className="text-lg font-bold">{s.value}</div>
            </CardContent>
          </Card>
        ))}
      </div>

      {(overdueReceivable.length > 0 || overduePayable.length > 0) && (
        <Card className="border-red-200 bg-red-50">
          <CardContent className="p-4">
            <div className="flex items-center gap-2 text-red-700 font-semibold mb-2">
              <AlertCircle className="h-4 w-4" /> Contas vencidas
            </div>
            <div className="flex flex-wrap gap-2">
              {overdueReceivable.map((e) => (
                <Badge key={e.id} variant="outline" className="border-red-300 text-red-700">
                  Receber: {e.party_name} · {formatBRL(e.amount - (e.paid_amount || 0))} · venc. {formatDate(e.due_date)}
                </Badge>
              ))}
              {overduePayable.map((e) => (
                <Badge key={e.id} variant="outline" className="border-red-300 text-red-700">
                  Pagar: {e.party_name} · {formatBRL(e.amount - (e.paid_amount || 0))} · venc. {formatDate(e.due_date)}
                </Badge>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      <div className="grid lg:grid-cols-2 gap-4">
        <Card>
          <CardHeader><CardTitle className="text-base">Receitas × Despesas (6 meses)</CardTitle></CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={260}>
              <BarChart data={flowData}>
                <CartesianGrid strokeDasharray="3 3" className="opacity-30" />
                <XAxis dataKey="month" fontSize={12} />
                <YAxis fontSize={12} />
                <Tooltip formatter={(v) => formatBRL(v)} />
                <Legend />
                <Bar dataKey="receitas" fill="#10b981" radius={[4, 4, 0, 0]} />
                <Bar dataKey="despesas" fill="#ef4444" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        <Card>
          <CardHeader><CardTitle className="text-base">Despesas por categoria</CardTitle></CardHeader>
          <CardContent>
            {categoryData.length > 0 ? (
              <ResponsiveContainer width="100%" height={260}>
                <PieChart>
                  <Pie data={categoryData} dataKey="value" nameKey="name" cx="50%" cy="50%" outerRadius={90} label={(d) => d.name}>
                    {categoryData.map((_, i) => (
                      <Cell key={i} fill={PIE_COLORS[i % PIE_COLORS.length]} />
                    ))}
                  </Pie>
                  <Tooltip formatter={(v) => formatBRL(v)} />
                </PieChart>
              </ResponsiveContainer>
            ) : (
              <p className="text-sm text-muted-foreground text-center py-20">Sem despesas pagas registradas.</p>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}