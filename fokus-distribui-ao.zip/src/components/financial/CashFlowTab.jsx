import React, { useMemo } from "react";
import { formatBRL, formatDate } from "@/lib/format";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

export default function CashFlowTab({ entries }) {
  const today = new Date().toISOString().slice(0, 10);

  const flow = useMemo(() => {
    const paid = entries.filter((e) => e.status === "paid" && e.paid_date);
    const sorted = [...paid].sort((a, b) => (a.paid_date || "").localeCompare(b.paid_date || ""));

    let runningBalance = 0;
    const rows = sorted.map((e) => {
      const isIncome = e.direction === "receivable";
      const value = e.paid_amount || e.amount;
      const previous = runningBalance;
      runningBalance += isIncome ? value : -value;
      return {
        id: e.id,
        date: e.paid_date,
        description: e.party_name,
        type: isIncome ? "Entrada" : "Saída",
        value,
        previous,
        balance: runningBalance,
        responsible: e.responsible,
      };
    });
    return rows.reverse();
  }, [entries]);

  const totalIncome = entries
    .filter((e) => e.direction === "receivable" && e.status === "paid")
    .reduce((a, e) => a + (e.paid_amount || e.amount), 0);
  const totalExpense = entries
    .filter((e) => e.direction === "payable" && e.status === "paid")
    .reduce((a, e) => a + (e.paid_amount || e.amount), 0);
  const balance = totalIncome - totalExpense;

  const summary = [
    { label: "Total de entradas", value: formatBRL(totalIncome), color: "text-emerald-600" },
    { label: "Total de saídas", value: formatBRL(totalExpense), color: "text-red-600" },
    { label: "Saldo atual", value: formatBRL(balance), color: balance >= 0 ? "text-emerald-600" : "text-red-600" },
  ];

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-3 gap-4">
        {summary.map((s) => (
          <Card key={s.label}>
            <CardHeader className="pb-2"><CardTitle className="text-xs text-muted-foreground">{s.label}</CardTitle></CardHeader>
            <CardContent><div className={`text-lg font-bold ${s.color}`}>{s.value}</div></CardContent>
          </Card>
        ))}
      </div>

      <div className="overflow-x-auto rounded-md border">
        <table className="w-full text-sm">
          <thead className="bg-muted/50">
            <tr>
              <th className="text-left px-3 py-2 font-medium">Data</th>
              <th className="text-left px-3 py-2 font-medium">Descrição</th>
              <th className="text-left px-3 py-2 font-medium">Tipo</th>
              <th className="text-right px-3 py-2 font-medium">Valor</th>
              <th className="text-right px-3 py-2 font-medium">Saldo anterior</th>
              <th className="text-right px-3 py-2 font-medium">Saldo atualizado</th>
              <th className="text-left px-3 py-2 font-medium">Responsável</th>
            </tr>
          </thead>
          <tbody>
            {flow.map((r) => (
              <tr key={r.id} className="border-t hover:bg-muted/30">
                <td className="px-3 py-2 text-xs">{formatDate(r.date)}</td>
                <td className="px-3 py-2 font-medium">{r.description}</td>
                <td className="px-3 py-2">
                  <span className={r.type === "Entrada" ? "text-emerald-600" : "text-red-600"}>{r.type}</span>
                </td>
                <td className="px-3 py-2 text-right">{formatBRL(r.value)}</td>
                <td className="px-3 py-2 text-right text-muted-foreground">{formatBRL(r.previous)}</td>
                <td className="px-3 py-2 text-right font-medium">{formatBRL(r.balance)}</td>
                <td className="px-3 py-2 text-xs">{r.responsible || "-"}</td>
              </tr>
            ))}
            {flow.length === 0 && (
              <tr>
                <td colSpan={7} className="px-3 py-6 text-center text-muted-foreground">
                  Nenhuma movimentação financeira registrada.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}