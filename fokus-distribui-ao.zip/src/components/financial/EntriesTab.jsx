import React, { useState, useMemo } from "react";
import { formatBRL, formatDate } from "@/lib/format";
import { base44 } from "@/api/base44Client";
import { useQueryClient } from "@tanstack/react-query";
import { useToast } from "@/components/ui/use-toast";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import {
  Plus, Search, Pencil, Trash2, CheckCircle, Download,
} from "lucide-react";
import * as XLSX from "xlsx";
import FinancialEntryForm from "@/components/financial/FinancialEntryForm";

const STATUS_META = {
  pending: { label: "Pendente", variant: "secondary" },
  partial: { label: "Parcial", variant: "outline" },
  paid: { label: "Pago", variant: "default" },
  overdue: { label: "Vencido", variant: "destructive" },
  cancelled: { label: "Cancelado", variant: "outline" },
};

const today = new Date().toISOString().slice(0, 10);

export default function EntriesTab({ entries, direction, customers }) {
  const qc = useQueryClient();
  const { toast } = useToast();
  const [search, setSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");
  const [formOpen, setFormOpen] = useState(false);
  const [editEntry, setEditEntry] = useState(null);

  const filtered = useMemo(() => {
    return entries
      .filter((e) => e.direction === direction)
      .filter((e) => {
        const ms =
          e.party_name?.toLowerCase().includes(search.toLowerCase()) ||
          e.description?.toLowerCase().includes(search.toLowerCase()) ||
          e.category?.toLowerCase().includes(search.toLowerCase());
        const mf = statusFilter === "all" || e.status === statusFilter ||
          (statusFilter === "overdue" && e.status !== "paid" && e.status !== "cancelled" && e.due_date < today);
        return ms && mf;
      })
      .sort((a, b) => (b.due_date || "").localeCompare(a.due_date || ""));
  }, [entries, direction, search, statusFilter]);

  const openCreate = () => { setEditEntry(null); setFormOpen(true); };
  const openEdit = (entry) => { setEditEntry(entry); setFormOpen(true); };

  const settle = async (entry) => {
    try {
      await base44.entities.FinancialEntry.update(entry.id, {
        status: "paid",
        paid_amount: entry.amount,
        paid_date: today,
      });
      toast({ title: "Baixa realizada." });
      qc.invalidateQueries(["financialEntries"]);
    } catch (err) {
      toast({ title: "Erro", description: String(err), variant: "destructive" });
    }
  };

  const remove = async (entry) => {
    if (!confirm("Excluir este registro?")) return;
    try {
      await base44.entities.FinancialEntry.delete(entry.id);
      toast({ title: "Registro excluído." });
      qc.invalidateQueries(["financialEntries"]);
    } catch (err) {
      toast({ title: "Erro", description: String(err), variant: "destructive" });
    }
  };

  const exportExcel = () => {
    const rows = filtered.map((e) => ({
      [direction === "receivable" ? "Cliente" : "Fornecedor"]: e.party_name,
      Descrição: e.description || "",
      Categoria: e.category || "",
      Valor: e.amount,
      Pago: e.paid_amount || 0,
      Vencimento: formatDate(e.due_date),
      Status: STATUS_META[e.status]?.label || e.status,
    }));
    const ws = XLSX.utils.json_to_sheet(rows);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, direction === "receivable" ? "Contas a Receber" : "Contas a Pagar");
    XLSX.writeFile(wb, `${direction === "receivable" ? "Contas_Receber" : "Contas_Pagar"}.xlsx`);
  };

  const total = filtered.reduce((a, e) => a + (e.amount - (e.paid_amount || 0)), 0);

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div className="flex flex-wrap gap-2 flex-1">
          <div className="relative flex-1 min-w-[200px]">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input placeholder="Pesquisar..." value={search} onChange={(e) => setSearch(e.target.value)} className="pl-9" />
          </div>
          <Select value={statusFilter} onValueChange={setStatusFilter}>
            <SelectTrigger className="w-[160px]"><SelectValue /></SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Todos</SelectItem>
              <SelectItem value="pending">Pendente</SelectItem>
              <SelectItem value="partial">Parcial</SelectItem>
              <SelectItem value="paid">Pago</SelectItem>
              <SelectItem value="overdue">Vencido</SelectItem>
              <SelectItem value="cancelled">Cancelado</SelectItem>
            </SelectContent>
          </Select>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" size="sm" onClick={exportExcel}><Download className="h-4 w-4" /> Exportar</Button>
          <Button size="sm" onClick={openCreate}><Plus className="h-4 w-4" /> Novo</Button>
        </div>
      </div>

      <div className="text-sm text-muted-foreground">
        Saldo em aberto: <b className="text-foreground">{formatBRL(total)}</b>
      </div>

      <div className="overflow-x-auto rounded-md border">
        <table className="w-full text-sm">
          <thead className="bg-muted/50">
            <tr>
              <th className="text-left px-3 py-2 font-medium">{direction === "receivable" ? "Cliente" : "Fornecedor"}</th>
              <th className="text-left px-3 py-2 font-medium">Descrição</th>
              <th className="text-left px-3 py-2 font-medium">Categoria</th>
              <th className="text-right px-3 py-2 font-medium">Valor</th>
              <th className="text-left px-3 py-2 font-medium">Vencimento</th>
              <th className="text-left px-3 py-2 font-medium">Status</th>
              <th className="text-right px-3 py-2 font-medium">Ações</th>
            </tr>
          </thead>
          <tbody>
            {filtered.map((e) => (
              <tr key={e.id} className="border-t hover:bg-muted/30">
                <td className="px-3 py-2 font-medium">{e.party_name}</td>
                <td className="px-3 py-2">{e.description || "-"}</td>
                <td className="px-3 py-2">{e.category || "-"}</td>
                <td className="px-3 py-2 text-right">{formatBRL(e.amount)}</td>
                <td className="px-3 py-2">{formatDate(e.due_date)}</td>
                <td className="px-3 py-2">
                  <Badge variant={STATUS_META[e.status]?.variant}>{STATUS_META[e.status]?.label}</Badge>
                </td>
                <td className="px-3 py-2">
                  <div className="flex justify-end gap-1">
                    {e.status !== "paid" && (
                      <Button size="icon" variant="ghost" onClick={() => settle(e)} title="Dar baixa">
                        <CheckCircle className="h-4 w-4 text-emerald-600" />
                      </Button>
                    )}
                    <Button size="icon" variant="ghost" onClick={() => openEdit(e)} title="Editar">
                      <Pencil className="h-4 w-4" />
                    </Button>
                    <Button size="icon" variant="ghost" onClick={() => remove(e)} title="Excluir">
                      <Trash2 className="h-4 w-4 text-red-600" />
                    </Button>
                  </div>
                </td>
              </tr>
            ))}
            {filtered.length === 0 && (
              <tr>
                <td colSpan={7} className="px-3 py-6 text-center text-muted-foreground">
                  Nenhum registro encontrado.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>

      <FinancialEntryForm
        open={formOpen}
        onOpenChange={setFormOpen}
        direction={direction}
        entry={editEntry}
        customers={customers}
      />
    </div>
  );
}