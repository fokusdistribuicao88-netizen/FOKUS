import React from 'react';
import { Search, Filter, X } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import {
  Select, SelectTrigger, SelectValue, SelectContent, SelectItem,
} from '@/components/ui/select';
import { QUOTE_STATUS_LIST, QUOTE_STATUS } from './quoteStatus';

export default function QuoteFilters({ filters, setFilters, onClear, totalCount, filteredCount }) {
  const set = (k, v) => setFilters((f) => ({ ...f, [k]: v }));
  const [showAdvanced, setShowAdvanced] = React.useState(false);
  const hasAdvanced = filters.status || filters.price_table_name || filters.responsible || filters.expiring !== 'all';

  return (
    <div className="space-y-3">
      <div className="flex flex-wrap items-center gap-2">
        <div className="relative flex-1 min-w-[200px]">
          <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            value={filters.search}
            onChange={(e) => set('search', e.target.value)}
            placeholder="Buscar por nº, cliente, CPF/CNPJ, telefone..."
            className="pl-8"
          />
        </div>
        <div className="flex items-center gap-2">
          <span className="text-xs text-muted-foreground whitespace-nowrap">{filteredCount} de {totalCount}</span>
          <button
            onClick={() => setShowAdvanced((v) => !v)}
            className={`flex items-center gap-1.5 px-3 py-2 rounded-md text-sm border transition-colors ${
              showAdvanced || hasAdvanced ? 'bg-primary text-primary-foreground border-primary' : 'bg-background border-border hover:bg-accent'
            }`}
          >
            <Filter className="h-4 w-4" /> Filtros
          </button>
          {(hasAdvanced || filters.search) && (
            <button onClick={onClear} className="flex items-center gap-1 px-2 py-2 rounded-md text-sm text-muted-foreground hover:bg-accent">
              <X className="h-4 w-4" /> Limpar
            </button>
          )}
        </div>
      </div>

      {showAdvanced && (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 p-3 rounded-lg border border-border bg-muted/30">
          <div>
            <Label className="text-xs">Status</Label>
            <Select value={filters.status || 'all'} onValueChange={(v) => set('status', v === 'all' ? '' : v)}>
              <SelectTrigger className="h-9"><SelectValue placeholder="Todos" /></SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Todos</SelectItem>
                {QUOTE_STATUS_LIST.map((st) => (
                  <SelectItem key={st} value={st}>{QUOTE_STATUS[st].label}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div>
            <Label className="text-xs">Tabela de preço</Label>
            <Input value={filters.price_table_name || ''} onChange={(e) => set('price_table_name', e.target.value)} placeholder="Nome da tabela" />
          </div>
          <div>
            <Label className="text-xs">Responsável</Label>
            <Input value={filters.responsible || ''} onChange={(e) => set('responsible', e.target.value)} placeholder="Usuário" />
          </div>
          <div>
            <Label className="text-xs">Validade</Label>
            <Select value={filters.expiring || 'all'} onValueChange={(v) => set('expiring', v)}>
              <SelectTrigger className="h-9"><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Todos</SelectItem>
                <SelectItem value="expiring">Próximos da expiração</SelectItem>
                <SelectItem value="expired">Expirados</SelectItem>
                <SelectItem value="valid">Válidos</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div>
            <Label className="text-xs">Data inicial</Label>
            <Input type="date" value={filters.dateFrom || ''} onChange={(e) => set('dateFrom', e.target.value)} />
          </div>
          <div>
            <Label className="text-xs">Data final</Label>
            <Input type="date" value={filters.dateTo || ''} onChange={(e) => set('dateTo', e.target.value)} />
          </div>
          <div>
            <Label className="text-xs">Valor mínimo</Label>
            <Input type="number" step="0.01" value={filters.valueMin || ''} onChange={(e) => set('valueMin', e.target.value)} placeholder="0,00" />
          </div>
          <div>
            <Label className="text-xs">Valor máximo</Label>
            <Input type="number" step="0.01" value={filters.valueMax || ''} onChange={(e) => set('valueMax', e.target.value)} placeholder="0,00" />
          </div>
        </div>
      )}
    </div>
  );
}