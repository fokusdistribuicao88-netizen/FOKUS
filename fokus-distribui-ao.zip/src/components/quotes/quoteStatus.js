// Configuração central de status dos orçamentos — labels, badges e listas.

export const QUOTE_STATUS = {
  rascunho: {
    label: 'Rascunho',
    badge: 'bg-slate-100 text-slate-700',
    dot: 'bg-slate-400',
  },
  salvo: {
    label: 'Salvo',
    badge: 'bg-blue-100 text-blue-700',
    dot: 'bg-blue-500',
  },
  enviado: {
    label: 'Enviado',
    badge: 'bg-indigo-100 text-indigo-700',
    dot: 'bg-indigo-500',
  },
  aguardando_aprovacao: {
    label: 'Aguardando aprovação',
    badge: 'bg-amber-100 text-amber-700',
    dot: 'bg-amber-500',
  },
  aprovado: {
    label: 'Aprovado',
    badge: 'bg-emerald-100 text-emerald-700',
    dot: 'bg-emerald-500',
  },
  recusado: {
    label: 'Recusado',
    badge: 'bg-rose-100 text-rose-700',
    dot: 'bg-rose-500',
  },
  expirado: {
    label: 'Expirado',
    badge: 'bg-orange-100 text-orange-700',
    dot: 'bg-orange-500',
  },
  transformado: {
    label: 'Transformado em pedido',
    badge: 'bg-violet-100 text-violet-700',
    dot: 'bg-violet-500',
  },
  cancelado: {
    label: 'Cancelado',
    badge: 'bg-red-100 text-red-700',
    dot: 'bg-red-500',
  },
};

export const QUOTE_STATUS_LIST = Object.keys(QUOTE_STATUS);

// Status que bloqueiam edição comercial do orçamento
export const QUOTE_LOCKED_STATUSES = ['transformado', 'cancelado'];

// Status que representam orçamento convertido em venda
export const QUOTE_CONVERTED_STATUSES = ['transformado'];

export function quoteStatusInfo(key) {
  return QUOTE_STATUS[key] || { label: key || '—', badge: 'bg-slate-100 text-slate-700', dot: 'bg-slate-400' };
}

export function formatCurrency(value) {
  return `R$ ${(Number(value) || 0).toFixed(2).replace('.', ',')}`;
}

// Calcula dias restantes até a validade (negativo = expirado)
export function daysUntilExpiry(quote) {
  if (!quote?.valid_until) return null;
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  const valid = new Date(quote.valid_until + 'T00:00:00');
  const diff = Math.round((valid - today) / 86400000);
  return diff;
}

// Verifica se o orçamento está próximo da expiração (7, 3 ou 1 dias)
export function expiryWarningLevel(quote) {
  if (QUOTE_CONVERTED_STATUSES.includes(quote?.status)) return null;
  if (QUOTE_LOCKED_STATUSES.includes(quote?.status)) return null;
  const days = daysUntilExpiry(quote);
  if (days === null) return null;
  if (days <= 1) return 1;
  if (days <= 3) return 3;
  if (days <= 7) return 7;
  return null;
}

export function isExpired(quote) {
  const days = daysUntilExpiry(quote);
  return days !== null && days < 0 && !QUOTE_CONVERTED_STATUSES.includes(quote?.status);
}