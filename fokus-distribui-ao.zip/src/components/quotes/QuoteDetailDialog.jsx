import React from 'react';
import {
  User, Phone, Mail, MapPin, CreditCard, Calendar, Package, FileText,
  Truck, Clock, CheckCircle2, Copy, Printer, ArrowRightLeft, Ban, History,
} from 'lucide-react';
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import {
  quoteStatusInfo, formatCurrency, daysUntilExpiry, expiryWarningLevel,
} from './quoteStatus';

function Section({ title, children }) {
  return (
    <div className="space-y-2">
      <h4 className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">{title}</h4>
      {children}
    </div>
  );
}

function Row({ icon: Icon, label, value }) {
  return (
    <div className="flex items-start gap-2 text-sm py-1">
      <Icon className="w-4 h-4 text-muted-foreground mt-0.5 flex-shrink-0" />
      <span className="text-muted-foreground w-24 sm:w-32 flex-shrink-0">{label}:</span>
      <span className="font-medium break-words min-w-0">{value || '—'}</span>
    </div>
  );
}

export default function QuoteDetailDialog({
  quote, productMap, onClose, onEdit, onDuplicate, onPrint, onConvert, onCancel,
}) {
  if (!quote) return null;

  const s = quoteStatusInfo(quote.status);
  const subtotal = (quote.items || []).reduce((acc, i) => acc + (i.subtotal || 0), 0);
  const days = daysUntilExpiry(quote);
  const warn = expiryWarningLevel(quote);
  const locked = ['transformado', 'cancelado'].includes(quote.status);

  return (
    <Dialog open={!!quote} onOpenChange={(op) => !op && onClose()}>
      <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex flex-wrap items-center gap-2">
            Orçamento {quote.quote_number || `#${(quote.id || '').substring(0, 8).toUpperCase()}`}
            <span className={`inline-flex items-center gap-1.5 px-2 py-0.5 rounded-full text-xs font-medium ${s.badge}`}>
              {s.label}
            </span>
          </DialogTitle>
          <DialogDescription>
            Criado em {quote.created_date ? new Date(quote.created_date).toLocaleString('pt-BR') : '—'}
            {quote.responsible ? ` · Responsável: ${quote.responsible}` : ''}
          </DialogDescription>
        </DialogHeader>

        {/* Avisos de expiração */}
        {warn && !locked && (
          <div className={`rounded-lg p-3 text-sm border ${
            warn <= 1 ? 'bg-red-50 border-red-200 text-red-800'
            : warn <= 3 ? 'bg-orange-50 border-orange-200 text-orange-800'
            : 'bg-amber-50 border-amber-200 text-amber-800'
          }`}>
            <Clock className="w-4 h-4 inline mr-1.5" />
            {days < 0
              ? 'Este orçamento está expirado e será excluído automaticamente.'
              : `Este orçamento será excluído automaticamente em ${days} dia(s) caso não seja transformado em venda.`}
          </div>
        )}

        {/* Vínculo com pedido */}
        {quote.converted_order_id && (
          <div className="rounded-lg p-3 text-sm border bg-violet-50 border-violet-200 text-violet-800">
            <CheckCircle2 className="w-4 h-4 inline mr-1.5" />
            Transformado no pedido <strong>#{quote.converted_order_code || (quote.converted_order_id || '').substring(0, 8).toUpperCase()}</strong>
            {quote.converted_at ? ` em ${new Date(quote.converted_at).toLocaleString('pt-BR')}` : ''}
          </div>
        )}

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <Section title="Dados do cliente">
            <Row icon={User} label="Cliente" value={quote.customer_name} />
            <Row icon={Phone} label="Telefone" value={quote.customer_phone} />
            <Row icon={Mail} label="E-mail" value={quote.customer_email} />
            <Row icon={FileText} label="CPF/CNPJ" value={quote.cpf_cnpj} />
          </Section>
          <Section title="Entrega">
            <Row icon={MapPin} label="Endereço" value={quote.customer_address} />
            <Row icon={MapPin} label="Cidade/UF" value={`${quote.city || '—'} - ${quote.state || '—'}`} />
            <Row icon={Truck} label="Forma de entrega" value={quote.delivery_method} />
          </Section>
          <Section title="Condições comerciais">
            <Row icon={CreditCard} label="Pagamento" value={quote.payment_conditions} />
            <Row icon={Calendar} label="Validade" value={`${quote.validity_days || 30} dias (até ${quote.valid_until ? new Date(quote.valid_until + 'T00:00:00').toLocaleDateString('pt-BR') : '—'})`} />
            <Row icon={Clock} label="Dias restantes" value={days === null ? '—' : days < 0 ? 'Expirado' : `${days} dias`} />
            <Row icon={FileText} label="Tabela de preço" value={quote.price_table_name} />
          </Section>
          <Section title="Valores">
            <div className="bg-muted/40 rounded-xl p-3 space-y-1 text-sm">
              <div className="flex justify-between"><span className="text-muted-foreground">Subtotal</span><span>{formatCurrency(subtotal)}</span></div>
              {quote.addition ? <div className="flex justify-between"><span className="text-muted-foreground">Acréscimo</span><span>+{formatCurrency(quote.addition)}</span></div> : null}
              {quote.discount ? <div className="flex justify-between"><span className="text-muted-foreground">Desconto</span><span>-{formatCurrency(quote.discount)}</span></div> : null}
              {quote.freight ? <div className="flex justify-between"><span className="text-muted-foreground">Frete</span><span>{formatCurrency(quote.freight)}</span></div> : null}
              <div className="flex justify-between font-bold text-base pt-1 border-t border-border"><span>Total</span><span>{formatCurrency(quote.total)}</span></div>
            </div>
          </Section>
        </div>

        {/* Produtos */}
        <Section title="Produtos">
          <div className="border border-border rounded-xl overflow-x-auto">
            <table className="w-full text-sm min-w-[400px]">
              <thead className="bg-muted/50 text-muted-foreground">
                <tr>
                  <th className="text-left px-3 py-2 font-medium">Produto</th>
                  <th className="text-center px-3 py-2 font-medium">Qtd</th>
                  <th className="text-right px-3 py-2 font-medium">Unitário</th>
                  <th className="text-right px-3 py-2 font-medium">Subtotal</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-border">
                {(quote.items || []).map((item, i) => (
                  <tr key={i}>
                    <td className="px-3 py-2">{item.product_name}</td>
                    <td className="px-3 py-2 text-center">{item.quantity}</td>
                    <td className="px-3 py-2 text-right">{formatCurrency(item.unit_price)}</td>
                    <td className="px-3 py-2 text-right font-medium">{formatCurrency(item.subtotal)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </Section>

        {quote.notes && (
          <Section title="Observações">
            <p className="text-sm bg-muted/40 rounded-xl p-3">{quote.notes}</p>
          </Section>
        )}

        {/* Timeline */}
        <Section title="Histórico">
          <div className="relative pl-6 space-y-3">
            {(quote.timeline || []).length === 0 && (
              <p className="text-sm text-muted-foreground">Nenhum registro ainda.</p>
            )}
            {(quote.timeline || []).map((entry, i) => (
              <div key={i} className="relative">
                <div className="absolute -left-5 top-1 w-2.5 h-2.5 rounded-full bg-blue-500 ring-4 ring-blue-500/20" />
                <p className="text-sm font-medium">{entry.event}</p>
                <p className="text-xs text-muted-foreground">{entry.author} · {new Date(entry.date).toLocaleString('pt-BR')}</p>
              </div>
            ))}
          </div>
        </Section>

        <DialogFooter className="flex flex-wrap gap-2">
          <Button variant="outline" size="sm" onClick={() => onPrint(quote)} className="gap-1.5">
            <Printer className="w-4 h-4" /> Gerar PDF
          </Button>
          {!locked && (
            <>
              <Button variant="outline" size="sm" onClick={() => onEdit(quote)} className="gap-1.5">
                <FileText className="w-4 h-4" /> Editar
              </Button>
              <Button variant="outline" size="sm" onClick={() => onDuplicate(quote)} className="gap-1.5">
                <Copy className="w-4 h-4" /> Duplicar
              </Button>
              <Button variant="outline" size="sm" onClick={() => onCancel(quote)} className="gap-1.5 text-red-600 hover:text-red-700">
                <Ban className="w-4 h-4" /> Cancelar
              </Button>
              <Button size="sm" onClick={() => onConvert(quote)} className="gap-1.5 bg-emerald-600 hover:bg-emerald-700">
                <ArrowRightLeft className="w-4 h-4" /> Transformar em pedido
              </Button>
            </>
          )}
          <Button variant="ghost" size="sm" onClick={onClose}>Fechar</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}