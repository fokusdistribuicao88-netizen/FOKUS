import React, { useState, useEffect, useMemo, useRef } from 'react';
import { useQuery } from '@tanstack/react-query';
import { Trash2, User, MapPin, Package, StickyNote, Calendar, Truck, CreditCard, Percent } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import {
  Select, SelectTrigger, SelectValue, SelectContent, SelectItem,
} from '@/components/ui/select';
import { formatCurrency } from './quoteStatus';
import { useAuth } from '@/lib/AuthContext';
import OrderProductPicker from '@/components/orders/OrderProductPicker';
import CustomerPicker from '@/components/customers/CustomerPicker';
import QuantityPromptDialog from '@/components/orders/QuantityPromptDialog';
import { SYSTEM_TABLES } from '@/lib/posPriceTables';
import { generateQuoteNumber, computeValidUntil } from '@/lib/quoteService';

const isSystemCode = (id) => SYSTEM_TABLES.some((s) => s.code === id);

const empty = (validityDays = 30) => ({
  quote_number: '',
  customer_name: '', customer_phone: '', customer_email: '', customer_address: '',
  cpf_cnpj: '', city: '', state: '', neighborhood: '', billing_address: '',
  items: [], price_table_id: 'PADRAO', price_table_name: 'Padrão',
  subtotal: 0, discount: 0, addition: 0, freight: 0, total: 0,
  notes: '', internal_notes: '',
  validity_days: validityDays, valid_until: computeValidUntil(validityDays),
  delivery_method: '', payment_conditions: '', responsible: '',
});

export default function QuoteFormDialog({ open, quote, products, defaultValidityDays = 30, onClose, onSave }) {
  const [form, setForm] = useState(() => empty(defaultValidityDays));
  const [saving, setSaving] = useState(false);
  const { user } = useAuth();
  const isAdmin = user?.role === 'admin' || user?.role === 'gerente';

  const { data: customers = [] } = useQuery({
    queryKey: ['customers'],
    queryFn: () => base44.entities.Customer.list(),
    enabled: open,
  });
  const { data: employees = [] } = useQuery({
    queryKey: ['employees'],
    queryFn: () => base44.entities.Employee.list(),
    enabled: open,
  });
  const { data: priceTables = [] } = useQuery({
    queryKey: ['price-tables'],
    queryFn: () => base44.entities.PriceTable.list('-updated_date'),
    enabled: open,
    staleTime: 30 * 1000,
  });

  const pendingRecalc = useRef(false);
  const [pendingProduct, setPendingProduct] = useState(null);

  useEffect(() => {
    if (open && quote) {
      setForm({ ...empty(defaultValidityDays), ...quote });
    } else if (open) {
      setForm(empty(defaultValidityDays));
    }
    pendingRecalc.current = false;
  }, [quote, open, defaultValidityDays]);

  const set = (k, v) => setForm((f) => ({ ...f, [k]: v }));

  const activeTables = useMemo(() => priceTables.filter((t) => t.status !== 'inactive'), [priceTables]);
  const customTables = useMemo(() => activeTables.filter((t) => !isSystemCode(t.code)), [activeTables]);

  useEffect(() => {
    if (!open) return;
    setForm((f) => {
      const id = f.price_table_id;
      if (isSystemCode(id) || activeTables.some((t) => t.id === id)) return f;
      return { ...f, price_table_id: 'PADRAO', price_table_name: 'Padrão' };
    });
  }, [open, activeTables]);

  const selectedId = form.price_table_id || 'PADRAO';
  const sysTable = isSystemCode(selectedId) ? SYSTEM_TABLES.find((s) => s.code === selectedId) : null;
  const entTable = !sysTable ? activeTables.find((t) => t.id === selectedId) : null;
  const itemsEntity = sysTable ? priceTables.find((t) => t.code === sysTable.code) : entTable;
  const itemsEntityId = itemsEntity?.id || null;

  const { data: tableItems = [] } = useQuery({
    queryKey: ['price-table-items', itemsEntityId],
    queryFn: () => base44.entities.PriceTableItem.filter({ price_table_id: itemsEntityId }),
    enabled: open && !!itemsEntityId,
    staleTime: 30 * 1000,
  });

  const itemsByProduct = useMemo(() => {
    const m = {};
    tableItems.forEach((it) => { m[it.product_id] = it; });
    return m;
  }, [tableItems]);

  const priceOf = (product) => {
    if (!product) return 0;
    if (product.price_promo) return product.price_promo;
    const it = itemsByProduct[product.id];
    if (it && Number(it.custom_price) >= 0) return Number(it.custom_price);
    if (sysTable) return Number(product[sysTable.field]) || Number(product.price) || 0;
    return Number(product.price) || 0;
  };

  const subtotal = useMemo(() => (form.items || []).reduce((s, i) => s + (i.subtotal || 0), 0), [form.items]);
  const freight = Number(form.freight) || 0;
  const discount = Number(form.discount) || 0;
  const addition = Number(form.addition) || 0;
  const total = Math.max(0, subtotal + freight + addition - discount);

  const addProduct = (product) => {
    if (!product || !product.id) return;
    const existing = form.items.find((i) => i.product_id === product.id);
    if (existing) {
      set('items', form.items.map((i) => i.product_id === product.id
        ? { ...i, quantity: i.quantity + 1, subtotal: (i.quantity + 1) * i.unit_price }
        : i));
    } else {
      setPendingProduct({ product, price: priceOf(product) });
    }
  };

  const confirmAddProduct = (qty) => {
    if (!pendingProduct) return;
    const { product, price } = pendingProduct;
    set('items', [...form.items, {
      product_id: product.id, product_name: product.name, product_code: product.code || '',
      quantity: qty, unit_type: product.unit_type || '', unit_price: price, discount: 0,
      subtotal: price * qty,
    }]);
    setPendingProduct(null);
  };

  const changePriceTable = (tableId) => {
    const sys = isSystemCode(tableId) ? SYSTEM_TABLES.find((s) => s.code === tableId) : null;
    const ent = !sys ? activeTables.find((t) => t.id === tableId) : null;
    if (!sys && !ent) return;
    const name = sys ? sys.name : ent.name;
    const hasItems = (form.items || []).length > 0;
    const applyTable = () => {
      setForm((f) => ({ ...f, price_table_id: tableId, price_table_name: name }));
      pendingRecalc.current = true;
    };
    if (hasItems) {
      if (window.confirm(`Trocar para "${name}"? Todos os preços dos produtos já adicionados serão recalculados automaticamente.`)) {
        applyTable();
      }
    } else {
      applyTable();
    }
  };

  useEffect(() => {
    if (!pendingRecalc.current) return;
    setForm((f) => {
      if (!f.items || f.items.length === 0) return f;
      const updated = f.items.map((i) => {
        const product = products.find((p) => p.id === i.product_id);
        if (!product) return i;
        const newPrice = priceOf(product);
        return { ...i, unit_price: newPrice, subtotal: newPrice * (i.quantity || 0) };
      });
      return { ...f, items: updated };
    });
    pendingRecalc.current = false;
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [itemsByProduct, selectedId]);

  const updateItem = (idx, key, value) => {
    set('items', form.items.map((i, ii) => {
      if (ii !== idx) return i;
      const updated = { ...i, [key]: value };
      const lineDiscount = Number(updated.discount) || 0;
      updated.subtotal = (updated.unit_price || 0) * (updated.quantity || 0) - lineDiscount;
      return updated;
    }));
  };

  const removeItem = (idx) => set('items', form.items.filter((_, i) => i !== idx));

  const selectCustomer = (c) => {
    if (!c) return;
    setForm((f) => ({
      ...f,
      customer_id: c.id || '',
      customer_name: c.name || f.customer_name,
      customer_phone: c.phone || f.customer_phone,
      customer_email: c.email || c.user_email || f.customer_email,
      cpf_cnpj: c.cpf_cnpj || c.cpf || f.cpf_cnpj,
      city: c.city || f.city,
      state: c.state || f.state,
      customer_address: c.address || f.customer_address,
    }));
  };

  const changeValidity = (days) => {
    const d = Number(days) || 30;
    setForm((f) => ({ ...f, validity_days: d, valid_until: computeValidUntil(d) }));
  };

  const submit = async () => {
    if (!form.customer_name || (form.items || []).length === 0) return;
    setSaving(true);
    try {
      const payload = {
        ...form,
        subtotal,
        freight,
        discount,
        addition,
        total,
        price_table_id: form.price_table_id || 'PADRAO',
        price_table_name: form.price_table_name || 'Padrão',
        responsible: form.responsible || user?.full_name || user?.email || '',
        items: form.items.map((i) => ({
          ...i, unit_price: Number(i.unit_price), quantity: Number(i.quantity),
          discount: Number(i.discount) || 0, subtotal: Number(i.subtotal),
        })),
      };
      if (!payload.quote_number) {
        payload.quote_number = await generateQuoteNumber();
      }
      await onSave(payload);
      onClose();
    } finally {
      setSaving(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={(op) => !op && onClose()}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>{quote ? 'Editar orçamento' : 'Novo orçamento'}</DialogTitle>
        </DialogHeader>

        {isAdmin && (
          <div className="flex items-start gap-3 p-3 rounded-xl bg-violet-50 border border-violet-200">
            <div className="flex-1">
              <Label className="text-xs font-semibold text-violet-700">Tabela de Preços</Label>
              <Select value={selectedId} onValueChange={changePriceTable}>
                <SelectTrigger className="h-8 mt-1"><SelectValue placeholder="Selecione a tabela" /></SelectTrigger>
                <SelectContent className="max-h-60">
                  {SYSTEM_TABLES.map((s) => (
                    <SelectItem key={s.code} value={s.code}>
                      <div className="flex flex-col">
                        <span className="font-medium">{s.name}</span>
                        <span className="text-[10px] text-muted-foreground">Sistema · preço do cadastro</span>
                      </div>
                    </SelectItem>
                  ))}
                  {customTables.map((t) => (
                    <SelectItem key={t.id} value={t.id}>
                      <div className="flex flex-col">
                        <span className="font-medium">{t.name}{t.is_default ? ' (padrão)' : ''}</span>
                        {t.description && <span className="text-[10px] text-muted-foreground">{t.description}</span>}
                      </div>
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="text-right text-xs text-muted-foreground pt-5">
              <div className="font-semibold text-violet-700">{form.price_table_name || 'Padrão'}</div>
              <div>Tabela ativa</div>
            </div>
          </div>
        )}

        {/* Dados do Cliente */}
        <div className="space-y-2">
          <div className="flex items-center gap-1.5 text-xs font-semibold uppercase tracking-wider text-muted-foreground border-b pb-1">
            <User className="w-3.5 h-3.5" /> Dados do Cliente
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div className="sm:col-span-2">
              <div className="flex items-center justify-between">
                <Label className="text-xs">Cliente *</Label>
                <CustomerPicker
                  customers={customers}
                  employees={employees}
                  onSelect={(c) => selectCustomer(c)}
                  triggerVariant="button"
                  triggerLabel="Selecionar cadastrado"
                  triggerClassName="h-6 text-xs px-2 py-0 text-blue-700 border-blue-200 hover:bg-blue-50"
                />
              </div>
              <Input value={form.customer_name} onChange={(e) => set('customer_name', e.target.value)} placeholder="Nome do cliente" />
            </div>
            <div>
              <Label className="text-xs">Telefone *</Label>
              <Input value={form.customer_phone} onChange={(e) => set('customer_phone', e.target.value)} placeholder="(11) 99999-9999" />
            </div>
            <div>
              <Label className="text-xs">E-mail</Label>
              <Input value={form.customer_email} onChange={(e) => set('customer_email', e.target.value)} placeholder="email@exemplo.com" />
            </div>
            <div>
              <Label className="text-xs">CPF/CNPJ</Label>
              <Input value={form.cpf_cnpj} onChange={(e) => set('cpf_cnpj', e.target.value)} placeholder="000.000.000-00" />
            </div>
            <div>
              <Label className="text-xs">Responsável</Label>
              <Input value={form.responsible} onChange={(e) => set('responsible', e.target.value)} placeholder="Vendedor responsável" />
            </div>
          </div>
        </div>

        {/* Endereço */}
        <div className="space-y-2">
          <div className="flex items-center gap-1.5 text-xs font-semibold uppercase tracking-wider text-muted-foreground border-b pb-1">
            <MapPin className="w-3.5 h-3.5" /> Endereço de Entrega
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div className="sm:col-span-2">
              <Label className="text-xs">Endereço</Label>
              <Input value={form.customer_address} onChange={(e) => set('customer_address', e.target.value)} placeholder="Rua, número, bairro..." />
            </div>
            <div>
              <Label className="text-xs">Cidade</Label>
              <Input value={form.city} onChange={(e) => set('city', e.target.value)} placeholder="Cidade" />
            </div>
            <div>
              <Label className="text-xs">Estado (UF)</Label>
              <Input value={form.state} onChange={(e) => set('state', e.target.value)} placeholder="SP" />
            </div>
          </div>
        </div>

        {/* Condições comerciais */}
        <div className="space-y-2">
          <div className="flex items-center gap-1.5 text-xs font-semibold uppercase tracking-wider text-muted-foreground border-b pb-1">
            <CreditCard className="w-3.5 h-3.5" /> Condições Comerciais
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <Label className="text-xs">Forma de entrega</Label>
              <Input value={form.delivery_method} onChange={(e) => set('delivery_method', e.target.value)} placeholder="Retirada, entrega própria, transportadora..." />
            </div>
            <div>
              <Label className="text-xs">Condições de pagamento</Label>
              <Input value={form.payment_conditions} onChange={(e) => set('payment_conditions', e.target.value)} placeholder="À vista, 30/60, crediário..." />
            </div>
            <div>
              <Label className="text-xs">Validade (dias)</Label>
              <Input type="number" value={form.validity_days} onChange={(e) => changeValidity(e.target.value)} placeholder="30" />
            </div>
            <div>
              <Label className="text-xs">Válido até</Label>
              <Input type="date" value={form.valid_until || ''} onChange={(e) => set('valid_until', e.target.value)} />
            </div>
          </div>
        </div>

        {/* Produtos */}
        <div className="space-y-2">
          <div className="flex items-center justify-between border-b pb-1">
            <div className="flex items-center gap-1.5 text-xs font-semibold uppercase tracking-wider text-muted-foreground">
              <Package className="w-3.5 h-3.5" /> Produtos
            </div>
            <OrderProductPicker
              products={products}
              onAdd={addProduct}
              addedIds={(form.items || []).map((i) => i.product_id)}
              priceOf={priceOf}
              priceTableLabel={form.price_table_name || 'Padrão'}
            />
          </div>
          {(form.items || []).length === 0 && (
            <p className="text-xs text-muted-foreground py-3 text-center border border-dashed border-border rounded-lg">Nenhum produto adicionado</p>
          )}
          <div className="space-y-2">
            {(form.items || []).map((item, idx) => (
              <div key={idx} className="flex items-center gap-2">
                <span className="flex-1 text-sm truncate">{item.product_name}</span>
                <Input type="number" value={item.quantity} onChange={(e) => updateItem(idx, 'quantity', Number(e.target.value))} className="w-16 h-8" title="Quantidade" />
                <Input type="number" value={item.unit_price} onChange={(e) => updateItem(idx, 'unit_price', Number(e.target.value))} className="w-24 h-8" title="Preço unitário" />
                <span className="w-24 text-right text-sm font-medium">{formatCurrency(item.subtotal)}</span>
                <Button variant="ghost" size="icon" className="h-8 w-8 text-red-600" onClick={() => removeItem(idx)}><Trash2 className="w-4 h-4" /></Button>
              </div>
            ))}
          </div>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 pt-2">
            <div>
              <Label className="text-xs">Frete (R$)</Label>
              <Input type="number" step="0.01" value={form.freight || ''} onChange={(e) => set('freight', Number(e.target.value))} placeholder="0,00" />
            </div>
            <div>
              <Label className="text-xs">Desconto (R$)</Label>
              <Input type="number" step="0.01" value={form.discount || ''} onChange={(e) => set('discount', Number(e.target.value))} placeholder="0,00" />
            </div>
            <div>
              <Label className="text-xs">Acréscimo (R$)</Label>
              <Input type="number" step="0.01" value={form.addition || ''} onChange={(e) => set('addition', Number(e.target.value))} placeholder="0,00" />
            </div>
            <div className="flex items-end">
              <div className="w-full text-right">
                <div className="text-xs text-muted-foreground">Total</div>
                <div className="text-lg font-bold">{formatCurrency(total)}</div>
              </div>
            </div>
          </div>
          <div className="text-xs text-muted-foreground flex justify-between pt-1 border-t border-border">
            <span>Subtotal: {formatCurrency(subtotal)}</span>
            {freight > 0 && <span>+ Frete: {formatCurrency(freight)}</span>}
            {addition > 0 && <span>+ Acréscimo: {formatCurrency(addition)}</span>}
            {discount > 0 && <span>− Desconto: {formatCurrency(discount)}</span>}
          </div>
        </div>

        {/* Observações */}
        <div className="space-y-2">
          <div className="flex items-center gap-1.5 text-xs font-semibold uppercase tracking-wider text-muted-foreground border-b pb-1">
            <StickyNote className="w-3.5 h-3.5" /> Observações
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <Label className="text-xs">Observações (visíveis ao cliente)</Label>
              <Textarea value={form.notes} onChange={(e) => set('notes', e.target.value)} rows={2} placeholder="Observações do orçamento" />
            </div>
            <div>
              <Label className="text-xs">Observações internas</Label>
              <Textarea value={form.internal_notes} onChange={(e) => set('internal_notes', e.target.value)} rows={2} placeholder="Notas internas (não visíveis ao cliente)" />
            </div>
          </div>
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={onClose}>Cancelar</Button>
          <Button onClick={submit} disabled={saving} className="bg-blue-700 hover:bg-blue-800">
            {saving ? 'Salvando...' : 'Salvar orçamento'}
          </Button>
        </DialogFooter>
      </DialogContent>

      <QuantityPromptDialog
        open={!!pendingProduct}
        product={pendingProduct?.product}
        defaultQty={pendingProduct?.product?.min_order || 1}
        unitPrice={pendingProduct?.price || 0}
        onConfirm={confirmAddProduct}
        onCancel={() => setPendingProduct(null)}
      />
    </Dialog>
  );
}