import React, { useState, useMemo, useEffect } from 'react';
import { useAvailableDocTypes } from '@/lib/useAvailableDocTypes';
import { useQuery } from '@tanstack/react-query';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Select, SelectTrigger, SelectValue, SelectContent, SelectItem } from '@/components/ui/select';
import { Label } from '@/components/ui/label';
import { Printer, FileText, Eye, Loader2, Droplet, X, Layers, Share2 } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { generatePDF, buildPreviewUrl, sharePDF, logEmission } from '@/lib/pdfService';
import PdfViewerDialog from '@/components/PdfViewerDialog';
import { quoteToData } from '@/lib/pdfAdapters';
import { useToast } from '@/components/ui/use-toast';
import { useAuth } from '@/lib/AuthContext';

export default function QuotePrintDialog({ open, onClose, quote, settings, productMap }) {
  const { user } = useAuth();
  const { toast } = useToast();
  const [docType, setDocType] = useState('quote');
  const [wmId, setWmId] = useState('none');
  const [busy, setBusy] = useState(false);
  const [viewer, setViewer] = useState({ open: false, url: '', loading: false });

  const { docs: available } = useAvailableDocTypes();
  useEffect(() => {
    if (available.length && !available.find((t) => t.type === docType)) setDocType('quote');
  }, [available, docType]);

  const { data: watermarks = [] } = useQuery({
    queryKey: ['watermarks'],
    queryFn: () => base44.entities.Watermark.list('-updated_date'),
    staleTime: 60 * 1000,
  });
  const activeWms = useMemo(() => watermarks.filter((w) => w.status === 'active'), [watermarks]);
  const selectedWm = useMemo(() => activeWms.find((w) => w.id === wmId) || null, [activeWms, wmId]);

  if (!quote) return null;
  const code = quote.quote_number || (quote.id || '').substring(0, 8).toUpperCase();
  const data = quoteToData(quote, settings, productMap);

  const handleGenerate = async () => {
    setBusy(true);
    try {
      await generatePDF({ documentType: docType, data, watermark: selectedWm, fileName: `orcamento-${code}.pdf`, module: 'Orçamentos', user, entityId: quote.id });
      toast({ title: 'PDF gerado', description: available.find((t) => t.type === docType)?.label || docType });
    } catch (e) {
      toast({ title: 'Erro ao gerar PDF', description: String(e.message || e), variant: 'destructive' });
    } finally {
      setBusy(false);
    }
  };

  const handleShare = async () => {
    setBusy(true);
    try {
      const { shared } = await sharePDF({ documentType: docType, data, watermark: selectedWm, fileName: `orcamento-${code}.pdf`, module: 'Orçamentos', user, entityId: quote.id });
      toast({ title: shared ? 'Compartilhando PDF' : 'PDF baixado', description: shared ? 'Escolha o aplicativo para enviar.' : 'Compartilhamento não suportado — PDF baixado.' });
    } catch (e) {
      if (e?.name !== 'AbortError') toast({ title: 'Erro ao compartilhar', description: String(e.message || e), variant: 'destructive' });
    } finally {
      setBusy(false);
    }
  };

  const handlePreview = async () => {
    setViewer({ open: true, url: '', loading: true });
    try {
      const { url } = await buildPreviewUrl({ documentType: docType, data, watermark: selectedWm });
      setViewer({ open: true, url, loading: false });
      logEmission({ documentType: docType, templateId: null, version: 1, watermark: selectedWm, module: 'Orçamentos', user, entityId: quote.id, action: 'preview' });
    } catch (e) {
      toast({ title: 'Erro na pré-visualização', description: String(e.message || e), variant: 'destructive' });
      setViewer({ open: false, url: '', loading: false });
    }
  };

  const closeViewer = () => {
    if (viewer.url) URL.revokeObjectURL(viewer.url);
    setViewer({ open: false, url: '', loading: false });
  };

  return (
    <>
    <Dialog open={open} onOpenChange={(o) => !o && onClose()}>
      <DialogContent className="max-w-lg">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2"><Layers className="w-5 h-5" /> Gerar PDF do Orçamento — {code}</DialogTitle>
        </DialogHeader>

        <div className="space-y-4">
          <div>
            <Label className="text-xs font-semibold text-muted-foreground uppercase mb-1.5 flex items-center gap-1.5"><FileText className="w-3.5 h-3.5" /> Modelo de PDF</Label>
            <Select value={docType} onValueChange={setDocType} disabled={available.length === 0}>
              <SelectTrigger className="w-full"><SelectValue placeholder="Nenhum modelo disponível" /></SelectTrigger>
              <SelectContent>
                {available.map((t) => (
                  <SelectItem key={t.type} value={t.type}>{t.label}</SelectItem>
                ))}
              </SelectContent>
            </Select>
            <p className="text-[10px] text-muted-foreground mt-1">{available.length === 0 ? 'Nenhum modelo cadastrado no Gerenciador de Modelos PDF.' : 'O modelo é carregado do Gerenciador de Modelos PDF e pode ser editado pelo administrador.'}</p>
          </div>

          <div>
            <Label className="text-xs font-semibold text-muted-foreground uppercase mb-1.5 flex items-center gap-1.5"><Droplet className="w-3.5 h-3.5" /> Marca d'Água</Label>
            <Select value={wmId} onValueChange={setWmId}>
              <SelectTrigger className="w-full"><SelectValue placeholder="Sem marca d'água" /></SelectTrigger>
              <SelectContent>
                <SelectItem value="none">Sem marca d'água</SelectItem>
                {activeWms.map((w) => (
                  <SelectItem key={w.id} value={w.id}>{w.name}{w.is_default ? ' (padrão)' : ''}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </div>

        <DialogFooter className="flex-col sm:flex-row gap-2">
          <Button variant="outline" onClick={handlePreview} disabled={busy || available.length === 0} className="gap-2 w-full sm:w-auto">
            {busy ? <Loader2 className="w-4 h-4 animate-spin" /> : <Eye className="w-4 h-4" />} Visualizar
          </Button>
          <Button onClick={handleGenerate} disabled={busy || available.length === 0} className="gap-2 w-full sm:w-auto">
            {busy ? <Loader2 className="w-4 h-4 animate-spin" /> : <Printer className="w-4 h-4" />} Gerar PDF
          </Button>
          <Button variant="outline" onClick={handleShare} disabled={busy || available.length === 0} className="gap-2 w-full sm:w-auto">
            {busy ? <Loader2 className="w-4 h-4 animate-spin" /> : <Share2 className="w-4 h-4" />} Compartilhar
          </Button>
          <Button variant="ghost" onClick={onClose} className="gap-2 w-full sm:w-auto"><X className="w-4 h-4" /> Fechar</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
    <PdfViewerDialog open={viewer.open} onClose={closeViewer} url={viewer.url} fileName={`orcamento-${code}.pdf`} loading={viewer.loading} />
    </>
  );
}