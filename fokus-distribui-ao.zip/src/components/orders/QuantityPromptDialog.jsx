import React, { useState, useEffect } from 'react';
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { formatCurrency } from './orderStatus';

export default function QuantityPromptDialog({ open, product, defaultQty = 1, unitPrice = 0, onConfirm, onCancel }) {
  const [qty, setQty] = useState(defaultQty);

  useEffect(() => {
    if (open) setQty(defaultQty);
  }, [open, defaultQty]);

  const handleConfirm = () => {
    const n = Number(qty);
    if (!n || n <= 0) return;
    onConfirm(n);
  };

  return (
    <Dialog open={open} onOpenChange={(o) => !o && onCancel?.()}>
      <DialogContent className="max-w-sm">
        <DialogHeader>
          <DialogTitle>Adicionar produto</DialogTitle>
          <DialogDescription className="truncate">{product?.name}</DialogDescription>
        </DialogHeader>
        <div className="space-y-3 py-2">
          <div>
            <label className="text-xs font-medium text-muted-foreground">Quantidade</label>
            <Input
              type="number"
              min="1"
              autoFocus
              value={qty}
              onChange={(e) => setQty(e.target.value)}
              onKeyDown={(e) => { if (e.key === 'Enter') handleConfirm(); }}
              className="mt-1 text-lg font-semibold"
            />
          </div>
          <div className="flex items-center justify-between text-sm">
            <span className="text-muted-foreground">Preço unit.</span>
            <span className="font-medium">{formatCurrency(unitPrice)}</span>
          </div>
          <div className="flex items-center justify-between text-sm border-t pt-2">
            <span className="text-muted-foreground">Subtotal</span>
            <span className="font-bold text-base">{formatCurrency((Number(qty) || 0) * unitPrice)}</span>
          </div>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={() => onCancel?.()}>Cancelar</Button>
          <Button onClick={handleConfirm} disabled={!Number(qty) || Number(qty) <= 0}>
            Adicionar
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}