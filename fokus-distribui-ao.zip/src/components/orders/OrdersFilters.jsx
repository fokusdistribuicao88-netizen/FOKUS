import React, { useState } from 'react';
import { Filter, X, Search } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import {
  Select, SelectTrigger, SelectValue, SelectContent, SelectItem,
} from '@/components/ui/select';
import {
  ORDER_STATUS_LIST, PAYMENT_STATUS_LIST, DELIVERY_STATUS_LIST, PAYMENT_METHOD_LIST,
  ORDER_STATUS, PAYMENT_STATUS, DELIVERY_STATUS, PAYMENT_METHODS,
} from './orderStatus';

function Field({ label, children, className }) {
  return (
    <div className={className}>
      <Label className="text-xs text-muted-foreground mb-1 block">{label}</Label>
      {children}
    </div>
  );
}

export default function OrdersFilters({ filters, setFilters, products, onApply, onClear, resultsCount }) {
  const [open, setOpen] = useState(false);
  const categories = [...new Set(products.map((p) => p.category).filter(Boolean))].sort();
  const productNames = [...new Set(products.map((p) => p.name).filter(Boolean))].sort((a, b) => a.localeCompare(b));

  const set = (key, value) => setFilters((f) => ({ ...f, [key]: value }));

  return (
    <div className="bg-card border border-border rounded-2xl shadow-sm">
      <div className="flex items-center justify-between gap-3 p-3">
        <div className="flex items-center gap-2 flex-1 min-w-0">
          <div className="relative flex-1 max-w-md">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <Input
              placeholder="Buscar por nº, cliente, email, telefone, produto..."
              value={filters.search}
              onChange={(e) => set('search', e.target.value)}
              className="pl-9"
            />
          </div>
          <span className="text-sm text-muted-foreground whitespace-nowrap hidden sm:inline">{resultsCount} pedido(s)</span>
          {!filters.dateStart && !filters.dateEnd && (
            <span className="text-xs text-blue-700 bg-blue-50 border border-blue-100 rounded-full px-2.5 py-1 whitespace-nowrap hidden md:inline">
              Apenas pedidos de hoje — use o filtro de data para dias anteriores
            </span>
          )}
        </div>
        <div className="flex items-center gap-1 sm:gap-2">
          <Button variant="ghost" size="sm" onClick={() => setOpen((o) => !o)} className="gap-2">
            <Filter className="w-4 h-4" /> <span className="hidden sm:inline">Filtros</span>
          </Button>
          <Button variant="ghost" size="sm" onClick={onClear} className="gap-2 text-muted-foreground">
            <X className="w-4 h-4" /> <span className="hidden sm:inline">Limpar</span>
          </Button>
        </div>
      </div>

      {open && (
        <div className="border-t border-border p-4 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
          <Field label="Cliente">
            <Input placeholder="Nome do cliente" value={filters.customer_name} onChange={(e) => set('customer_name', e.target.value)} />
          </Field>
          <Field label="CPF/CNPJ">
            <Input placeholder="000.000.000-00" value={filters.cpf_cnpj} onChange={(e) => set('cpf_cnpj', e.target.value)} />
          </Field>
          <Field label="E-mail">
            <Input placeholder="email@exemplo.com" value={filters.email} onChange={(e) => set('email', e.target.value)} />
          </Field>
          <Field label="Telefone">
            <Input placeholder="(11) 99999-9999" value={filters.phone} onChange={(e) => set('phone', e.target.value)} />
          </Field>
          <Field label="Produto">
            <Select value={filters.product} onValueChange={(v) => set('product', v)}>
              <SelectTrigger><SelectValue placeholder="Todos" /></SelectTrigger>
              <SelectContent className="max-h-60">
                {productNames.map((p) => <SelectItem key={p} value={p}>{p}</SelectItem>)}
              </SelectContent>
            </Select>
          </Field>
          <Field label="Categoria">
            <Select value={filters.category} onValueChange={(v) => set('category', v)}>
              <SelectTrigger><SelectValue placeholder="Todas" /></SelectTrigger>
              <SelectContent>
                {categories.map((c) => <SelectItem key={c} value={c}>{c}</SelectItem>)}
              </SelectContent>
            </Select>
          </Field>
          <Field label="Data inicial">
            <Input type="date" value={filters.dateStart} onChange={(e) => set('dateStart', e.target.value)} />
          </Field>
          <Field label="Data final">
            <Input type="date" value={filters.dateEnd} onChange={(e) => set('dateEnd', e.target.value)} />
          </Field>
          <Field label="Status do pedido">
            <Select value={filters.status} onValueChange={(v) => set('status', v)}>
              <SelectTrigger><SelectValue placeholder="Todos" /></SelectTrigger>
              <SelectContent>
                {ORDER_STATUS_LIST.map((s) => <SelectItem key={s} value={s}>{ORDER_STATUS[s].label}</SelectItem>)}
              </SelectContent>
            </Select>
          </Field>
          <Field label="Forma de pagamento">
            <Select value={filters.payment_method} onValueChange={(v) => set('payment_method', v)}>
              <SelectTrigger><SelectValue placeholder="Todas" /></SelectTrigger>
              <SelectContent>
                {PAYMENT_METHOD_LIST.map((m) => <SelectItem key={m} value={m}>{PAYMENT_METHODS[m]}</SelectItem>)}
              </SelectContent>
            </Select>
          </Field>
          <Field label="Status do pagamento">
            <Select value={filters.payment_status} onValueChange={(v) => set('payment_status', v)}>
              <SelectTrigger><SelectValue placeholder="Todos" /></SelectTrigger>
              <SelectContent>
                {PAYMENT_STATUS_LIST.map((s) => <SelectItem key={s} value={s}>{PAYMENT_STATUS[s].label}</SelectItem>)}
              </SelectContent>
            </Select>
          </Field>
          <Field label="Status da entrega">
            <Select value={filters.delivery_status} onValueChange={(v) => set('delivery_status', v)}>
              <SelectTrigger><SelectValue placeholder="Todos" /></SelectTrigger>
              <SelectContent>
                {DELIVERY_STATUS_LIST.map((s) => <SelectItem key={s} value={s}>{DELIVERY_STATUS[s].label}</SelectItem>)}
              </SelectContent>
            </Select>
          </Field>
          <Field label="Transportadora">
            <Input placeholder="Transportadora" value={filters.carrier} onChange={(e) => set('carrier', e.target.value)} />
          </Field>
          <Field label="Vendedor">
            <Input placeholder="Responsável" value={filters.seller} onChange={(e) => set('seller', e.target.value)} />
          </Field>
          <Field label="Cidade">
            <Input placeholder="Cidade" value={filters.city} onChange={(e) => set('city', e.target.value)} />
          </Field>
          <Field label="Estado (UF)">
            <Input placeholder="SP" value={filters.state} onChange={(e) => set('state', e.target.value)} />
          </Field>
          <div className="col-span-full flex justify-end">
            <Button size="sm" onClick={onApply} className="bg-blue-700 hover:bg-blue-800 gap-2">
              <Filter className="w-4 h-4" /> Aplicar filtros
            </Button>
          </div>
        </div>
      )}
    </div>
  );
}