import React from 'react';
import { Clock, AlertCircle, CreditCard, Truck, Activity } from 'lucide-react';
import { orderStatusInfo, paymentStatusInfo, formatCurrency } from './orderStatus';

function shortCode(id) {
  return id ? '#' + id.substring(0, 8).toUpperCase() : '—';
}

export default function OrdersSidePanel({ orders, onSelect }) {
  const recent = [...orders].sort((a, b) => new Date(b.created_date) - new Date(a.created_date)).slice(0, 5);
  const pending = orders.filter((o) => ['pending', 'awaiting_payment', 'confirmed'].includes(o.status)).slice(0, 5);
  const paymentsPending = orders.filter((o) => o.payment_status === 'pending' && o.status !== 'cancelled').slice(0, 5);
  const lateDeliveries = orders.filter((o) => {
    const old = new Date(o.created_date) < new Date(Date.now() - 7 * 24 * 60 * 60 * 1000);
    return old && !['delivered', 'completed', 'cancelled'].includes(o.status);
  });

  const activities = orders
    .flatMap((o) => (o.timeline || []).map((t) => ({ ...t, order: shortCode(o.id), customer: o.customer_name })))
    .sort((a, b) => new Date(b.date) - new Date(a.date))
    .slice(0, 6);

  return (
    <aside className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5 gap-4">
      <Panel icon={Clock} title="Últimos pedidos">
        {recent.length === 0 && <Empty />}
        {recent.map((o) => (
          <Row key={o.id} title={o.customer_name} sub={shortCode(o.id)} right={formatCurrency(o.total)} onClick={() => onSelect(o)} />
        ))}
      </Panel>

      <Panel icon={AlertCircle} title="Pedidos pendentes" accent="text-amber-600">
        {pending.length === 0 && <Empty />}
        {pending.map((o) => (
          <Row key={o.id} title={o.customer_name} sub={orderStatusInfo(o.status).label} right={shortCode(o.id)} onClick={() => onSelect(o)} />
        ))}
      </Panel>

      <Panel icon={CreditCard} title="Pagamentos pendentes" accent="text-amber-600">
        {paymentsPending.length === 0 && <Empty />}
        {paymentsPending.map((o) => (
          <Row key={o.id} title={o.customer_name} sub={paymentStatusInfo(o.payment_status).label} right={formatCurrency(o.total)} onClick={() => onSelect(o)} />
        ))}
      </Panel>

      {lateDeliveries.length > 0 && (
        <Panel icon={Truck} title="Entregas atrasadas" accent="text-red-600">
          {lateDeliveries.slice(0, 5).map((o) => (
            <Row key={o.id} title={o.customer_name} sub={shortCode(o.id)} right={formatCurrency(o.total)} onClick={() => onSelect(o)} />
          ))}
        </Panel>
      )}

      <Panel icon={Activity} title="Atividades recentes">
        {activities.length === 0 && <Empty />}
        {activities.map((a, i) => (
          <div key={i} className="text-xs py-1.5 border-b border-border last:border-0">
            <p className="font-medium">{a.event}</p>
            <p className="text-muted-foreground">{a.order} · {a.customer}</p>
          </div>
        ))}
      </Panel>
    </aside>
  );
}

function Panel({ icon: Icon, title, accent, children }) {
  return (
    <div className="bg-card border border-border rounded-2xl shadow-sm p-4">
      <h3 className="flex items-center gap-2 text-sm font-semibold mb-2">
        <Icon className={`w-4 h-4 ${accent || 'text-muted-foreground'}`} />
        {title}
      </h3>
      <div className="space-y-1">{children}</div>
    </div>
  );
}

function Row({ title, sub, right, onClick }) {
  return (
    <button onClick={onClick} className="w-full flex items-center justify-between gap-2 py-1.5 px-2 -mx-2 rounded-lg hover:bg-muted/50 text-left">
      <div className="min-w-0">
        <p className="text-sm font-medium truncate">{title}</p>
        <p className="text-xs text-muted-foreground truncate">{sub}</p>
      </div>
      <span className="text-xs font-medium whitespace-nowrap">{right}</span>
    </button>
  );
}

function Empty() {
  return <p className="text-xs text-muted-foreground py-2">Nenhum registro.</p>;
}