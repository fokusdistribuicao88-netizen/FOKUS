import React, { useMemo } from 'react';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid } from 'recharts';

// Conta pedidos por cidade, priorizando a cidade do cliente cadastrado
// (match por email/telefone) e usando a cidade do pedido como fallback.
export default function OrdersByCityCard({ orders, customers }) {
  const byCity = useMemo(() => {
    const customerMap = {};
    (customers || []).forEach((c) => {
      const key = (c.email || '').toLowerCase() || (c.phone || '');
      if (key) customerMap[key] = c;
    });

    const map = {};
    (orders || []).forEach((o) => {
      let city = '';
      const key = (o.customer_email || '').toLowerCase() || (o.customer_phone || '');
      const customer = key ? customerMap[key] : null;
      if (customer && customer.city) {
        city = customer.city;
      } else {
        city = o.city || '';
      }
      city = (city || '').trim() || 'Sem cidade';
      map[city] = (map[city] || 0) + 1;
    });

    return Object.entries(map)
      .map(([name, value]) => ({ name, value }))
      .sort((a, b) => b.value - a.value)
      .slice(0, 10);
  }, [orders, customers]);

  return (
    <div className="space-y-2">
      <h4 className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">
        Pedidos por cidade
      </h4>
      {byCity.length === 0 ? (
        <p className="text-sm text-muted-foreground py-8 text-center">
          Nenhum pedido com cidade identificada
        </p>
      ) : (
        <ResponsiveContainer width="100%" height={Math.max(200, byCity.length * 32)}>
          <BarChart data={byCity} layout="vertical" margin={{ left: 8, right: 8 }}>
            <CartesianGrid strokeDasharray="3 3" className="stroke-border" />
            <XAxis type="number" tick={{ fontSize: 11 }} allowDecimals={false} />
            <YAxis type="category" dataKey="name" tick={{ fontSize: 11 }} width={110} />
            <Tooltip contentStyle={{ borderRadius: 12, fontSize: 12 }} />
            <Bar dataKey="value" fill="#0891b2" radius={[0, 4, 4, 0]} />
          </BarChart>
        </ResponsiveContainer>
      )}
    </div>
  );
}