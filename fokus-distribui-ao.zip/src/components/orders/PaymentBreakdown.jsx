import React from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Plus, Trash2 } from 'lucide-react';
import {
  Select, SelectTrigger, SelectValue, SelectContent, SelectItem,
} from '@/components/ui/select';
import { PAYMENT_METHODS, PAYMENT_METHOD_LIST, formatCurrency } from './orderStatus';

export default function PaymentBreakdown({ total, payments, onChange }) {
  const paid = payments.reduce((s, p) => s + (Number(p.amount) || 0), 0);
  const remaining = (Number(total) || 0) - paid;
  const isComplete = Math.abs(remaining) < 0.01;

  const addPayment = () => onChange([...payments, { method: '', amount: '' }]);
  const updatePayment = (idx, field, value) =>
    onChange(payments.map((p, i) => (i === idx ? { ...p, [field]: value } : p)));
  const removePayment = (idx) => onChange(payments.filter((_, i) => i !== idx));

  return (
    <div className="space-y-2.5">
      {payments.map((p, idx) => (
        <div key={idx} className="flex items-center gap-2">
          <Select value={p.method} onValueChange={(v) => updatePayment(idx, 'method', v)}>
            <SelectTrigger className="flex-1"><SelectValue placeholder="Forma de pagamento" /></SelectTrigger>
            <SelectContent>
              {PAYMENT_METHOD_LIST.map((m) => (
                <SelectItem key={m} value={m}>{PAYMENT_METHODS[m]}</SelectItem>
              ))}
            </SelectContent>
          </Select>
          <Input
            type="number"
            step="0.01"
            min="0"
            className="w-32 text-right"
            value={p.amount}
            onChange={(e) => updatePayment(idx, 'amount', e.target.value)}
            placeholder="Valor"
          />
          {payments.length > 1 && (
            <Button variant="ghost" size="icon" onClick={() => removePayment(idx)} className="flex-shrink-0">
              <Trash2 className="w-4 h-4 text-destructive" />
            </Button>
          )}
        </div>
      ))}

      <div className="flex items-center justify-between pt-1">
        <Button variant="outline" size="sm" onClick={addPayment} className="gap-1.5">
          <Plus className="w-4 h-4" /> Adicionar meio de pagamento
        </Button>
        <div className="text-sm">
          <span className="text-muted-foreground">Pago: </span>
          <span className={isComplete ? 'text-emerald-600 font-semibold' : 'text-foreground font-medium'}>
            {formatCurrency(paid)}
          </span>
          {remaining > 0.01 && (
            <span className="text-amber-600 ml-2">Faltam {formatCurrency(remaining)}</span>
          )}
          {remaining < -0.01 && (
            <span className="text-red-600 ml-2">Excedeu {formatCurrency(-remaining)}</span>
          )}
        </div>
      </div>
    </div>
  );
}