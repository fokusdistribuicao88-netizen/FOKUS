import React from 'react';
import { Link } from 'react-router-dom';
import { ShieldAlert, ArrowLeft } from 'lucide-react';
import { Button } from '@/components/ui/button';

export default function OrdersAccessDenied() {
  return (
    <div className="min-h-screen flex items-center justify-center p-4">
      <div className="text-center">
        <ShieldAlert className="w-12 h-12 text-amber-500 mx-auto mb-3" />
        <h2 className="text-xl font-semibold mb-2">Acesso restrito</h2>
        <p className="text-muted-foreground mb-6">Esta página é exclusiva para administradores e gerentes.</p>
        <Link to="/Dashboard">
          <Button className="bg-blue-700 hover:bg-blue-800 gap-2"><ArrowLeft className="w-4 h-4" /> Voltar ao Dashboard</Button>
        </Link>
      </div>
    </div>
  );
}