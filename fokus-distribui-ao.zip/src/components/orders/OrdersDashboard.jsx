import React, { useMemo, useState } from 'react';
import { BarChart, Bar, AreaChart, Area, PieChart, Pie, Cell, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid } from 'recharts';
import { ChevronDown, ChevronUp } from 'lucide-react';
import { Button } from '@/components/ui/button';
import {
  ORDER_STATUS, PAYMENT_METHODS, formatCurrency,
} from './orderStatus';
import OrdersByCityCard from './OrdersByCityCard';

const COLORS = ['#2563eb', '#16a34a', '#f59e0b', '#9333ea', '#dc2626', '#0891b2', '#db2777', '#65a30d'];

export default function OrdersDashboard({ orders, customers }) {
  const [open, setOpen] = useState(true);

  const byDay = useMemo(() => {
    const map = {};
    orders.forEach((o) => {
      const day = new Date(o.created_date).toLocaleDateString('pt-BR', { day: '2-digit', month: '2-digit' });
      map[day] = (map[day] || 0) + 1;
    });
    return Object.entries(map).slice(-14).map(([date, pedidos]) => ({ date, pedidos }));
  }, [orders]);

  const revenueByMonth = useMemo(() => {
    const map = {};
    orders.filter((o) => o.status !== 'cancelled').forEach((o) => {
      const m = new Date(o.created_date).toLocaleDateString('pt-BR', { month: 'short', year: '2-digit' });
      map[m] = (map[m] || 0) + (Number(o.total) || 0);
    });
    return Object.entries(map).map(([month, valor]) => ({ month, valor }));
  }, [orders]);

  const byPayment = useMemo(() => {
    const map = {};
    orders.forEach((o) => {
      const m = o.payment_method || 'outros';
      map[m] = (map[m] || 0) + 1;
    });
    return Object.entries(map).map(([key, value]) => ({ name: PAYMENT_METHODS[key] || key, value }));
  }, [orders]);

  const byStatus = useMemo(() => {
    const map = {};
    orders.forEach((o) => {
      const s = ORDER_STATUS[o.status]?.label || o.status || 'outros';
      map[s] = (map[s] || 0) + 1;
    });
    return Object.entries(map).map(([name, value]) => ({ name, value }));
  }, [orders]);

  const cancellationRate = orders.length
    ? ((orders.filter((o) => o.status === 'cancelled').length / orders.length) * 100).toFixed(1)
    : '0.0';

  return (
    <div className="bg-card border border-border rounded-2xl shadow-sm">
      <button onClick={() => setOpen((o) => !o)} className="w-full flex items-center justify-between p-4">
        <h3 className="text-sm font-semibold">Dashboard resumido</h3>
        {open ? <ChevronUp className="w-4 h-4 text-muted-foreground" /> : <ChevronDown className="w-4 h-4 text-muted-foreground" />}
      </button>
      {open && (
        <div className="border-t border-border p-4 grid grid-cols-1 lg:grid-cols-2 gap-6">
          <ChartCard title="Pedidos por dia">
            <ResponsiveContainer width="100%" height={200}>
              <AreaChart data={byDay}>
                <defs><linearGradient id="gDay" x1="0" y1="0" x2="0" y2="1"><stop offset="5%" stopColor="#2563eb" stopOpacity={0.4} /><stop offset="95%" stopColor="#2563eb" stopOpacity={0} /></linearGradient></defs>
                <CartesianGrid strokeDasharray="3 3" className="stroke-border" />
                <XAxis dataKey="date" tick={{ fontSize: 11 }} />
                <YAxis tick={{ fontSize: 11 }} allowDecimals={false} />
                <Tooltip contentStyle={{ borderRadius: 12, fontSize: 12 }} />
                <Area type="monotone" dataKey="pedidos" stroke="#2563eb" fill="url(#gDay)" />
              </AreaChart>
            </ResponsiveContainer>
          </ChartCard>

          <ChartCard title="Faturamento por mês">
            <ResponsiveContainer width="100%" height={200}>
              <BarChart data={revenueByMonth}>
                <CartesianGrid strokeDasharray="3 3" className="stroke-border" />
                <XAxis dataKey="month" tick={{ fontSize: 11 }} />
                <YAxis tick={{ fontSize: 11 }} tickFormatter={(v) => `R$${v > 1000 ? (v / 1000).toFixed(0) + 'k' : v}`} />
                <Tooltip contentStyle={{ borderRadius: 12, fontSize: 12 }} formatter={(v) => formatCurrency(v)} />
                <Bar dataKey="valor" fill="#16a34a" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </ChartCard>

          <ChartCard title="Formas de pagamento">
            <ResponsiveContainer width="100%" height={200}>
              <PieChart>
                <Pie data={byPayment} dataKey="value" nameKey="name" cx="50%" cy="50%" outerRadius={70} label={{ fontSize: 11 }}>
                  {byPayment.map((_, i) => <Cell key={i} fill={COLORS[i % COLORS.length]} />)}
                </Pie>
                <Tooltip contentStyle={{ borderRadius: 12, fontSize: 12 }} />
              </PieChart>
            </ResponsiveContainer>
          </ChartCard>

          <ChartCard title="Status dos pedidos">
            <ResponsiveContainer width="100%" height={200}>
              <BarChart data={byStatus} layout="vertical">
                <CartesianGrid strokeDasharray="3 3" className="stroke-border" />
                <XAxis type="number" tick={{ fontSize: 11 }} allowDecimals={false} />
                <YAxis type="category" dataKey="name" tick={{ fontSize: 11 }} width={120} />
                <Tooltip contentStyle={{ borderRadius: 12, fontSize: 12 }} />
                <Bar dataKey="value" fill="#9333ea" radius={[0, 4, 4, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </ChartCard>

          <OrdersByCityCard orders={orders} customers={customers} />

          <div className="lg:col-span-2 flex flex-wrap gap-4 text-sm">
            <Metric label="Taxa de cancelamento" value={`${cancellationRate}%`} />
            <Metric label="Ticket médio" value={formatCurrency(orders.length ? orders.reduce((s, o) => s + (Number(o.total) || 0), 0) / orders.length : 0)} />
            <Metric label="Pedidos pagos" value={orders.filter((o) => o.payment_status === 'paid').length} />
            <Metric label="Pedidos entregues" value={orders.filter((o) => o.delivery_status === 'delivered').length} />
          </div>
        </div>
      )}
    </div>
  );
}

function ChartCard({ title, children }) {
  return (
    <div className="space-y-2">
      <h4 className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">{title}</h4>
      {children}
    </div>
  );
}

function Metric({ label, value }) {
  return (
    <div className="bg-muted/40 rounded-xl px-4 py-2">
      <p className="text-xs text-muted-foreground">{label}</p>
      <p className="text-base font-bold">{value}</p>
    </div>
  );
}