import React, { useState, useEffect, useMemo, useRef } from 'react';
import { useQuery } from '@tanstack/react-query';
import { Trash2, User, MapPin, CreditCard, Package, StickyNote, Truck, Store, Wallet, CheckCircle2 } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import {
  Select, SelectTrigger, SelectValue, SelectContent, SelectItem,
} from '@/components/ui/select';
import { PAYMENT_METHOD_LIST, PAYMENT_METHODS, formatCurrency } from './orderStatus';
import { useAuth } from '@/lib/AuthContext';
import OrderProductPicker from './OrderProductPicker';
import CustomerPicker from '@/components/customers/CustomerPicker';
import QuantityPromptDialog from './QuantityPromptDialog';
import { SYSTEM_TABLES } from '@/lib/posPriceTables';

const isSystemCode = (id) => SYSTEM_TABLES.some((s) => s.code === id);

const empty = {
  customer_name: '', customer_phone: '', customer_email: '', customer_address: '',
  cpf_cnpj: '', city: '', state: '', billing_address: '',
  payment_method: 'pix', seller: '', notes: '', internal_notes: '',
  freight: 0, discount: 0, items: [], price_table_id: 'PADRAO', price_table_name: 'Padrão',
  delivery_method: 'retirada', delivery_receipt_mode: 'none',
};

export default function OrderFormDialog({ open, order, products, onClose, onSave }) {
  const [form, setForm] = useState(empty);
  const [saving, setSaving] = useState(false);
  const { user } = useAuth();
  const isAdmin = user?.role === 'admin';

  const { data: customers = [] } = useQuery({
    queryKey: ['customers'],
    queryFn: () => base44.entities.Customer.list(),
    enabled: open,
  });
  const { data: employees = [] } = useQuery({
    queryKey: ['employees'],
    queryFn: () => base44.entities.Employee.list(),
    enabled: open,
  });
  const { data: priceTables = [] } = useQuery({
    queryKey: ['price-tables'],
    queryFn: () => base44.entities.PriceTable.list('-updated_date'),
    enabled: open,
    staleTime: 30 * 1000,
  });

  const [selectedEmployee, setSelectedEmployee] = useState(null);
  const [selectedCustomer, setSelectedCustomer] = useState(null);
  const pendingRecalc = useRef(false);
  const [pendingProduct, setPendingProduct] = useState(null);

  useEffect(() => {
    setForm(order ? { ...empty, ...order } : empty);
    setSelectedEmployee(null);
    setSelectedCustomer(null);
    pendingRecalc.current = false;
  }, [order, open]);

  const set = (k, v) => setForm((f) => ({ ...f, [k]: v }));

  const activeTables = useMemo(() => priceTables.filter((t) => t.status !== 'inactive'), [priceTables]);
  const customTables = useMemo(() => activeTables.filter((t) => !isSystemCode(t.code)), [activeTables]);

  // Garante que a tabela selecionada seja válida (código de sistema ou entidade do Gestão)
  useEffect(() => {
    if (!open) return;
    setForm((f) => {
      const id = f.price_table_id;
      if (isSystemCode(id) || activeTables.some((t) => t.id === id)) return f;
      return { ...f, price_table_id: 'PADRAO', price_table_name: 'Padrão' };
    });
  }, [open, activeTables]);

  const selectedId = form.price_table_id || 'PADRAO';
  const sysTable = isSystemCode(selectedId) ? SYSTEM_TABLES.find((s) => s.code === selectedId) : null;
  const entTable = !sysTable ? activeTables.find((t) => t.id === selectedId) : null;
  const itemsEntity = sysTable ? priceTables.find((t) => t.code === sysTable.code) : entTable;
  const itemsEntityId = itemsEntity?.id || null;

  const { data: tableItems = [] } = useQuery({
    queryKey: ['price-table-items', itemsEntityId],
    queryFn: () => base44.entities.PriceTableItem.filter({ price_table_id: itemsEntityId }),
    enabled: open && !!itemsEntityId,
    staleTime: 30 * 1000,
  });

  const itemsByProduct = useMemo(() => {
    const m = {};
    tableItems.forEach((it) => { m[it.product_id] = it; });
    return m;
  }, [tableItems]);

  const priceOf = (product) => {
    if (!product) return 0;
    if (product.price_promo) return product.price_promo;
    const it = itemsByProduct[product.id];
    if (it && Number(it.custom_price) >= 0) return Number(it.custom_price);
    if (sysTable) return Number(product[sysTable.field]) || Number(product.price) || 0;
    return Number(product.price) || 0;
  };

  const subtotal = useMemo(() => (form.items || []).reduce((s, i) => s + (i.subtotal || 0), 0), [form.items]);
  const freight = Number(form.freight) || 0;
  const discount = Number(form.discount) || 0;
  const total = Math.max(0, subtotal + freight - discount);

  const addProduct = (product) => {
    if (!product || !product.id) return;
    const existing = form.items.find((i) => i.product_id === product.id);
    if (existing) {
      // Já está na lista — apenas incrementa
      set('items', form.items.map((i) => i.product_id === product.id
        ? { ...i, quantity: i.quantity + 1, subtotal: (i.quantity + 1) * i.unit_price }
        : i));
    } else {
      // Produto novo — pede a quantidade
      setPendingProduct({ product, price: priceOf(product) });
    }
  };

  const confirmAddProduct = (qty) => {
    if (!pendingProduct) return;
    const { product, price } = pendingProduct;
    set('items', [...form.items, {
      product_id: product.id, product_name: product.name,
      quantity: qty, unit_price: price, subtotal: price * qty,
    }]);
    setPendingProduct(null);
  };

  const changePriceTable = (tableId) => {
    const sys = isSystemCode(tableId) ? SYSTEM_TABLES.find((s) => s.code === tableId) : null;
    const ent = !sys ? activeTables.find((t) => t.id === tableId) : null;
    if (!sys && !ent) return;
    const name = sys ? sys.name : ent.name;
    const hasItems = (form.items || []).length > 0;
    const applyTable = () => {
      setForm((f) => ({ ...f, price_table_id: tableId, price_table_name: name }));
      pendingRecalc.current = true;
    };
    if (hasItems) {
      if (window.confirm(`Trocar para "${name}"? Todos os preços dos produtos já adicionados serão recalculados automaticamente.`)) {
        applyTable();
      }
    } else {
      applyTable();
    }
  };

  // Recalcula os preços dos itens após troca manual de tabela (quando os itens da tabela carregam)
  useEffect(() => {
    if (!pendingRecalc.current) return;
    setForm((f) => {
      if (!f.items || f.items.length === 0) return f;
      const updated = f.items.map((i) => {
        const product = products.find((p) => p.id === i.product_id);
        if (!product) return i;
        const newPrice = priceOf(product);
        return { ...i, unit_price: newPrice, subtotal: newPrice * (i.quantity || 0) };
      });
      return { ...f, items: updated };
    });
    pendingRecalc.current = false;
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [itemsByProduct, selectedId]);

  const updateItem = (idx, key, value) => {
    set('items', form.items.map((i, ii) => {
      if (ii !== idx) return i;
      const updated = { ...i, [key]: value };
      updated.subtotal = (updated.unit_price || 0) * (updated.quantity || 0);
      return updated;
    }));
  };

  const removeItem = (idx) => set('items', form.items.filter((_, i) => i !== idx));

  const selectCustomer = (c) => {
    if (!c) return;
    setForm((f) => ({
      ...f,
      customer_name: c.name || f.customer_name,
      customer_phone: c.phone || f.customer_phone,
      customer_email: c.email || c.user_email || f.customer_email,
      cpf_cnpj: c.cpf_cnpj || c.cpf || f.cpf_cnpj,
      city: c.city || f.city,
      state: c.state || f.state,
      customer_address: c.address || f.customer_address,
    }));
    setSelectedEmployee(c._isEmployee ? c : null);
    setSelectedCustomer(c._isEmployee ? null : c);
  };

  const submit = async () => {
    if (!form.customer_name || !form.customer_phone || (form.items || []).length === 0) return;
    setSaving(true);
    const payload = {
      ...form,
      freight,
      discount,
      total,
      price_table_id: form.price_table_id || 'PADRAO',
      price_table_name: form.price_table_name || 'Padrão',
      items: form.items.map((i) => ({ ...i, unit_price: Number(i.unit_price), quantity: Number(i.quantity), subtotal: Number(i.subtotal) })),
      is_payroll_discount: false,
      payroll_employee_id: selectedEmployee?.id || '',
      payroll_competence: '',
      delivery_method: form.delivery_method || 'retirada',
      delivery_receipt_mode: form.delivery_method === 'entrega' ? (form.delivery_receipt_mode || 'already_paid') : 'none',
    };
    await onSave(payload);
    setSaving(false);
    onClose();
  };

  return (
    <Dialog open={open} onOpenChange={(op) => !op && onClose()}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>{order ? 'Editar pedido' : 'Novo pedido'}</DialogTitle>
        </DialogHeader>

        {isAdmin && (
          <div className="flex items-start gap-3 p-3 rounded-xl bg-violet-50 dark:bg-violet-950/30 border border-violet-200 dark:border-violet-900">
            <div className="flex-1">
              <Label className="text-xs font-semibold text-violet-700 dark:text-violet-400">Tabela de Preços (Admin)</Label>
              <Select value={selectedId} onValueChange={changePriceTable}>
                <SelectTrigger className="h-8 mt-1"><SelectValue placeholder="Selecione a tabela" /></SelectTrigger>
                <SelectContent className="max-h-60">
                  {SYSTEM_TABLES.map((s) => (
                    <SelectItem key={s.code} value={s.code}>
                      <div className="flex flex-col">
                        <span className="font-medium">{s.name}</span>
                        <span className="text-[10px] text-muted-foreground">Sistema · preço do cadastro</span>
                      </div>
                    </SelectItem>
                  ))}
                  {customTables.map((t) => (
                    <SelectItem key={t.id} value={t.id}>
                      <div className="flex flex-col">
                        <span className="font-medium">{t.name}{t.is_default ? ' (padrão)' : ''}</span>
                        {t.description && <span className="text-[10px] text-muted-foreground">{t.description}</span>}
                      </div>
                    </SelectItem>
                  ))}
                  {customTables.length === 0 && activeTables.length === 0 && (
                    <span className="px-3 py-2 text-xs text-muted-foreground">Nenhuma tabela personalizada no Gestão de Tabelas de Preços.</span>
                  )}
                </SelectContent>
              </Select>
            </div>
            <div className="text-right text-xs text-muted-foreground pt-5">
              <div className="font-semibold text-violet-700 dark:text-violet-400">{form.price_table_name || 'Padrão'}</div>
              <div>Tabela ativa</div>
            </div>
          </div>
        )}

        {/* Seção: Dados do Cliente */}
        <div className="space-y-2">
          <div className="flex items-center gap-1.5 text-xs font-semibold uppercase tracking-wider text-muted-foreground border-b pb-1">
            <User className="w-3.5 h-3.5" /> Dados do Cliente
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div className="sm:col-span-2">
              <div className="flex items-center justify-between">
                <Label className="text-xs">Cliente *</Label>
                <CustomerPicker
                  customers={customers}
                  employees={employees}
                  onSelect={(c) => selectCustomer(c)}
                  triggerVariant="button"
                  triggerLabel="Selecionar cadastrado"
                  triggerClassName="h-6 text-xs px-2 py-0 text-blue-700 border-blue-200 hover:bg-blue-50"
                />
              </div>
              <Input value={form.customer_name} onChange={(e) => set('customer_name', e.target.value)} placeholder="Nome do cliente" />
            </div>
            {selectedCustomer && Number(selectedCustomer.credit_limit) > 0 && (() => {
              const limit = Number(selectedCustomer.credit_limit);
              const over = total > limit;
              const remaining = Math.max(0, limit - total);
              return (
                <div className={`rounded-lg border px-3 py-2 text-xs ${over ? 'border-red-300 bg-red-50 text-red-700' : 'border-emerald-200 bg-emerald-50 text-emerald-700'}`}>
                  <div className="flex items-center justify-between font-semibold">
                    <span>Limite de crédito: {formatCurrency(limit)}</span>
                    <span>{over ? '⚠ EXCEDIDO' : 'Disponível: ' + formatCurrency(remaining)}</span>
                  </div>
                  <div className="mt-0.5 opacity-80">Total do pedido: {formatCurrency(total)}</div>
                </div>
              );
            })()}
            <div>
              <Label className="text-xs">Telefone *</Label>
              <Input value={form.customer_phone} onChange={(e) => set('customer_phone', e.target.value)} placeholder="(11) 99999-9999" />
            </div>
            <div>
              <Label className="text-xs">E-mail</Label>
              <Input value={form.customer_email} onChange={(e) => set('customer_email', e.target.value)} placeholder="email@exemplo.com" />
            </div>
            <div>
              <Label className="text-xs">CPF/CNPJ</Label>
              <Input value={form.cpf_cnpj} onChange={(e) => set('cpf_cnpj', e.target.value)} placeholder="000.000.000-00" />
            </div>
          </div>
        </div>

        {/* Seção: Entrega / Retirada */}
        <div className="space-y-2">
          <div className="flex items-center gap-1.5 text-xs font-semibold uppercase tracking-wider text-muted-foreground border-b pb-1">
            <Truck className="w-3.5 h-3.5" /> Entrega / Retirada
          </div>
          <div className="grid grid-cols-2 gap-2">
            <button
              type="button"
              onClick={() => setForm((f) => ({ ...f, delivery_method: 'retirada', delivery_receipt_mode: 'none' }))}
              className={`flex flex-col items-center gap-1 p-2.5 rounded-lg border text-xs transition ${
                form.delivery_method === 'retirada' ? 'border-blue-600 bg-blue-50 text-blue-700 font-semibold' : 'border-border hover:bg-muted/50'
              }`}
            >
              <Store className="w-5 h-5" /> Retirada no local
            </button>
            <button
              type="button"
              onClick={() => setForm((f) => ({ ...f, delivery_method: 'entrega', delivery_receipt_mode: f.delivery_receipt_mode === 'none' ? 'already_paid' : f.delivery_receipt_mode }))}
              className={`flex flex-col items-center gap-1 p-2.5 rounded-lg border text-xs transition ${
                form.delivery_method === 'entrega' ? 'border-blue-600 bg-blue-50 text-blue-700 font-semibold' : 'border-border hover:bg-muted/50'
              }`}
            >
              <Truck className="w-5 h-5" /> Entrega
            </button>
          </div>

          {form.delivery_method === 'entrega' && (
            <>
              <div className="rounded-lg border-2 border-amber-200 bg-amber-50 p-2.5 space-y-2">
                <p className="text-xs font-semibold text-amber-900 uppercase flex items-center gap-1">
                  <Wallet className="w-3.5 h-3.5" /> Recebimento do Pagamento
                </p>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => set('delivery_receipt_mode', 'on_site')}
                    className={`flex flex-col items-center gap-1 p-2 rounded-lg border text-xs transition ${
                      form.delivery_receipt_mode === 'on_site' ? 'border-amber-600 bg-amber-100 text-amber-800 font-semibold' : 'border-amber-200 hover:bg-amber-50 text-amber-700'
                    }`}
                  >
                    <Wallet className="w-4 h-4" /> Receber no local
                  </button>
                  <button
                    type="button"
                    onClick={() => set('delivery_receipt_mode', 'already_paid')}
                    className={`flex flex-col items-center gap-1 p-2 rounded-lg border text-xs transition ${
                      form.delivery_receipt_mode === 'already_paid' ? 'border-green-600 bg-green-100 text-green-800 font-semibold' : 'border-amber-200 hover:bg-amber-50 text-amber-700'
                    }`}
                  >
                    <CheckCircle2 className="w-4 h-4" /> Pagamento já realizado
                  </button>
                </div>
                {form.delivery_receipt_mode === 'on_site' && (
                  <p className="text-xs text-amber-800/80">O valor será recebido pelo entregador no endereço do cliente.</p>
                )}
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div className="sm:col-span-2">
                  <Label className="text-xs">Endereço de entrega</Label>
                  <Input value={form.customer_address} onChange={(e) => set('customer_address', e.target.value)} placeholder="Rua, número, bairro..." />
                </div>
                <div>
                  <Label className="text-xs">Cidade</Label>
                  <Input value={form.city} onChange={(e) => set('city', e.target.value)} placeholder="Cidade" />
                </div>
                <div>
                  <Label className="text-xs">Estado (UF)</Label>
                  <Input value={form.state} onChange={(e) => set('state', e.target.value)} placeholder="SP" />
                </div>
                <div className="sm:col-span-2">
                  <Label className="text-xs">Endereço de cobrança</Label>
                  <Input value={form.billing_address} onChange={(e) => set('billing_address', e.target.value)} placeholder="Cobrança (se diferente da entrega)" />
                </div>
              </div>
            </>
          )}
        </div>

        {/* Seção: Pagamento e Vendedor */}
        <div className="space-y-2">
          <div className="flex items-center gap-1.5 text-xs font-semibold uppercase tracking-wider text-muted-foreground border-b pb-1">
            <CreditCard className="w-3.5 h-3.5" /> Pagamento e Vendedor
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <Label className="text-xs">Forma de pagamento</Label>
              <Select value={form.payment_method} onValueChange={(v) => set('payment_method', v)}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  {PAYMENT_METHOD_LIST.map((m) => <SelectItem key={m} value={m}>{PAYMENT_METHODS[m]}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label className="text-xs">Vendedor responsável</Label>
              <Input value={form.seller} onChange={(e) => set('seller', e.target.value)} placeholder="Responsável" />
            </div>
          </div>
          {selectedEmployee && (
            <div className="rounded-lg border border-blue-200 bg-blue-50 p-2 text-xs text-blue-800">
              <strong>Funcionário selecionado:</strong> {selectedEmployee.name}{selectedEmployee.role ? ` — ${selectedEmployee.role}` : ''}. As opções de convênio e desconto em folha serão exibidas na tela de pagamentos ao finalizar o pedido.
            </div>
          )}
        </div>

        {/* Seção: Produtos */}
        <div className="space-y-2">
          <div className="flex items-center justify-between border-b pb-1">
            <div className="flex items-center gap-1.5 text-xs font-semibold uppercase tracking-wider text-muted-foreground">
              <Package className="w-3.5 h-3.5" /> Produtos
            </div>
            <OrderProductPicker
              products={products}
              onAdd={addProduct}
              addedIds={(form.items || []).map((i) => i.product_id)}
              priceOf={priceOf}
              priceTableLabel={form.price_table_name || 'Padrão'}
            />
          </div>
          {(form.items || []).length === 0 && (
            <p className="text-xs text-muted-foreground py-3 text-center border border-dashed border-border rounded-lg">Nenhum produto adicionado</p>
          )}
          <div className="space-y-2">
            {(form.items || []).map((item, idx) => (
              <div key={idx} className="flex items-center gap-2">
                <span className="flex-1 text-sm truncate">{item.product_name}</span>
                <Input type="number" value={item.quantity} onChange={(e) => updateItem(idx, 'quantity', Number(e.target.value))} className="w-20 h-8" />
                <Input type="number" value={item.unit_price} onChange={(e) => updateItem(idx, 'unit_price', Number(e.target.value))} className="w-24 h-8" />
                <span className="w-24 text-right text-sm font-medium">{formatCurrency(item.subtotal)}</span>
                <Button variant="ghost" size="icon" className="h-8 w-8 text-red-600" onClick={() => removeItem(idx)}><Trash2 className="w-4 h-4" /></Button>
              </div>
            ))}
          </div>
          <div className="grid grid-cols-2 gap-3 pt-2">
            <div>
              <Label className="text-xs">Frete (R$)</Label>
              <Input type="number" step="0.01" value={form.freight || ''} onChange={(e) => set('freight', Number(e.target.value))} placeholder="0,00" />
            </div>
            <div>
              <Label className="text-xs">Desconto (R$)</Label>
              <Input type="number" step="0.01" value={form.discount || ''} onChange={(e) => set('discount', Number(e.target.value))} placeholder="0,00" />
            </div>
          </div>
          <div className="flex justify-between items-center pt-2 border-t border-border">
            <div className="text-xs text-muted-foreground space-y-0.5">
              <div>Subtotal: {formatCurrency(subtotal)}</div>
              {freight > 0 && <div>+ Frete: {formatCurrency(freight)}</div>}
              {discount > 0 && <div>− Desconto: {formatCurrency(discount)}</div>}
            </div>
            <span className="text-lg font-bold">{formatCurrency(total)}</span>
          </div>
        </div>

        {/* Seção: Observações */}
        <div className="space-y-2">
          <div className="flex items-center gap-1.5 text-xs font-semibold uppercase tracking-wider text-muted-foreground border-b pb-1">
            <StickyNote className="w-3.5 h-3.5" /> Observações
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <Label className="text-xs">Observações do cliente</Label>
              <Textarea value={form.notes} onChange={(e) => set('notes', e.target.value)} rows={2} placeholder="Observações do cliente" />
            </div>
            <div>
              <Label className="text-xs">Observações internas</Label>
              <Textarea value={form.internal_notes} onChange={(e) => set('internal_notes', e.target.value)} rows={2} placeholder="Notas internas (não visíveis ao cliente)" />
            </div>
          </div>
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={onClose}>Cancelar</Button>
          <Button onClick={submit} disabled={saving} className="bg-blue-700 hover:bg-blue-800">
            {saving ? 'Salvando...' : 'Salvar pedido'}
          </Button>
        </DialogFooter>
      </DialogContent>

      <QuantityPromptDialog
        open={!!pendingProduct}
        product={pendingProduct?.product}
        defaultQty={pendingProduct?.product?.min_order || 1}
        unitPrice={pendingProduct?.price || 0}
        onConfirm={confirmAddProduct}
        onCancel={() => setPendingProduct(null)}
      />
    </Dialog>
  );
}