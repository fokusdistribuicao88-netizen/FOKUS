import React from 'react';
import { Plus, Download, Upload, RefreshCw, Package, CalendarDays, Clock, CheckCircle2, XCircle, TrendingUp, Loader2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import ExportImportMenu from '@/components/admin/ExportImportMenu';
import { formatCurrency } from './orderStatus';

function StatCard({ icon: Icon, label, value, accent }) {
  return (
    <div className="bg-card border border-border rounded-2xl p-3 sm:p-4 shadow-sm">
      <div className="flex items-center gap-2 sm:gap-3">
        <div className={`w-9 h-9 sm:w-10 sm:h-10 rounded-xl flex items-center justify-center flex-shrink-0 ${accent}`}>
          <Icon className="w-4 h-4 sm:w-5 sm:h-5" />
        </div>
        <div className="min-w-0">
          <p className="text-xs text-muted-foreground leading-tight">{label}</p>
          <p className="text-base sm:text-lg font-bold leading-tight">{value}</p>
        </div>
      </div>
    </div>
  );
}

export default function OrdersHeader({ orders, onNewOrder, onExport, onImport, onRefresh, isRefreshing }) {
  const todayStr = new Date().toDateString();
  const today = orders.filter((o) => new Date(o.created_date).toDateString() === todayStr).length;
  const inProgress = orders.filter((o) => ['awaiting_payment', 'payment_approved', 'confirmed', 'separating', 'preparing', 'shipped', 'in_transit', 'out_for_delivery', 'in_progress'].includes(o.status)).length;
  const completed = orders.filter((o) => ['delivered', 'completed'].includes(o.status)).length;
  const cancelled = orders.filter((o) => o.status === 'cancelled').length;
  const totalSold = orders.filter((o) => o.status !== 'cancelled').reduce((sum, o) => sum + (Number(o.total) || 0), 0);

  return (
    <div className="space-y-4">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Gerenciamento de Pedidos</h1>
          <p className="text-sm text-muted-foreground">Acompanhe e gerencie todo o fluxo de vendas</p>
        </div>
        <div className="flex flex-wrap items-center gap-2">
          <Button variant="outline" size="sm" onClick={onRefresh} disabled={isRefreshing} className="gap-2">
            {isRefreshing ? <Loader2 className="w-4 h-4 animate-spin" /> : <RefreshCw className="w-4 h-4" />}
            
          </Button>
          <ExportImportMenu
            items={[
              { label: 'Importar', icon: Upload, onClick: onImport },
              { label: 'Exportar', icon: Download, onClick: onExport },
            ]}
          />
          <Button size="sm" onClick={onNewOrder} className="gap-2 bg-blue-700 hover:bg-blue-800">
            <Plus className="w-4 h-4" /> Novo Pedido
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
        <StatCard icon={Package} label="Total de pedidos" value={orders.length} accent="bg-slate-100 text-slate-700 dark:bg-slate-800 dark:text-slate-300" />
        <StatCard icon={CalendarDays} label="Pedidos do dia" value={today} accent="bg-blue-100 text-blue-700 dark:bg-blue-900/40 dark:text-blue-300" />
        <StatCard icon={Clock} label="Em andamento" value={inProgress} accent="bg-amber-100 text-amber-700 dark:bg-amber-900/40 dark:text-amber-300" />
        <StatCard icon={CheckCircle2} label="Concluídos" value={completed} accent="bg-green-100 text-green-700 dark:bg-green-900/40 dark:text-green-300" />
        <StatCard icon={XCircle} label="Cancelados" value={cancelled} accent="bg-red-100 text-red-700 dark:bg-red-900/40 dark:text-red-300" />
        <StatCard icon={TrendingUp} label="Valor total vendido" value={formatCurrency(totalSold)} accent="bg-emerald-100 text-emerald-700 dark:bg-emerald-900/40 dark:text-emerald-300" />
      </div>
    </div>
  );
}