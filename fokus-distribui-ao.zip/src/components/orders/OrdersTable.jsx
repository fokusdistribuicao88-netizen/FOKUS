import React, { useState, useMemo } from 'react';
import {
  Eye, Pencil, CheckCircle2, Printer, Copy, XCircle, Trash2, MoreHorizontal,
  ChevronLeft, ChevronRight, ArrowUpDown, Package, Layers,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Checkbox } from '@/components/ui/checkbox';
import {
  DropdownMenu, DropdownMenuTrigger, DropdownMenuContent, DropdownMenuItem,
  DropdownMenuSeparator,
} from '@/components/ui/dropdown-menu';
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent,
  AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle,
} from '@/components/ui/alert-dialog';
import {
  Select, SelectTrigger, SelectValue, SelectContent, SelectItem,
} from '@/components/ui/select';
import {
  orderStatusInfo, paymentStatusInfo, deliveryStatusInfo, PAYMENT_METHODS,
  ORDER_STATUS_LIST, ORDER_STATUS, formatCurrency,
} from './orderStatus';

function Badge({ className, children }) {
  return <span className={`inline-flex items-center gap-1 px-1.5 py-0.5 rounded-full text-[10px] font-medium leading-tight break-words text-center justify-center ${className}`}>{children}</span>;
}

const COLUMNS = [
  { key: 'code', label: 'Pedido', width: '8%' },
  { key: 'created_date', label: 'Data', width: '8%' },
  { key: 'customer_name', label: 'Cliente', width: '23%' },
  { key: 'qty', label: 'Qtd' },
  { key: 'total', label: 'Total', width: '9%' },
  { key: 'payment_method', label: 'Pagamento', width: '9%' },
  { key: 'payment_status', label: 'Pag. status', width: '11%' },
  { key: 'status', label: 'Status', width: '11%' },
  { key: 'delivery_status', label: 'Entrega', width: '11%' },
];

export default function OrdersTable({
  orders, loading, productMap, settings, onAction, onBatchAction,
  sort, setSort, page, setPage, pageSize, total,
  user,
}) {
  const [deleteTarget, setDeleteTarget] = useState(null);
  const [selected, setSelected] = useState({});

  const selectedIds = useMemo(
    () => Object.keys(selected).filter((id) => selected[id]),
    [selected]
  );
  const allOnPageSelected = orders.length > 0 && orders.every((o) => selected[o.id]);
  const someOnPageSelected = orders.some((o) => selected[o.id]);

  const toggleAll = (checked) => {
    setSelected((prev) => {
      const next = { ...prev };
      orders.forEach((o) => { next[o.id] = checked; });
      return next;
    });
  };
  const toggleOne = (id, checked) => setSelected((prev) => ({ ...prev, [id]: checked }));
  const clearSelection = () => setSelected({});

  const handleBulkStatus = (status) => {
    onBatchAction('bulkStatus', selectedIds, { status });
  };
  const handleBulkDelete = () => {
    onBatchAction('bulkDelete', selectedIds);
    clearSelection();
  };
  const handleBulkExport = () => {
    onBatchAction('bulkExport', selectedIds);
  };
  const totalPages = Math.max(1, Math.ceil(total / pageSize));
  const toggleSort = (key) => {
    setSort((s) => (s.key === key ? { key, dir: s.dir === 'asc' ? 'desc' : 'asc' } : { key, dir: 'desc' }));
  };

  const shortCode = (id) => (id ? '#' + id.substring(0, 8).toUpperCase() : '—');
  const fmtDate = (d) => d ? new Date(d).toLocaleDateString('pt-BR', { day: '2-digit', month: '2-digit', year: '2-digit' }) : '—';

  return (
    <div className="bg-card border border-border rounded-2xl shadow-sm overflow-hidden">
      {/* Batch action bar */}
      {selectedIds.length > 0 && (
        <div className="flex flex-wrap items-center gap-2 px-4 py-3 bg-blue-50 dark:bg-blue-950/40 border-b border-blue-200 dark:border-blue-900">
          <Layers className="w-4 h-4 text-blue-600" />
          <span className="text-sm font-medium text-blue-700 dark:text-blue-300">
            {selectedIds.length} pedido(s) selecionado(s)
          </span>
          <div className="flex flex-wrap items-center gap-2 ml-auto">
            <Select value="" onValueChange={handleBulkStatus}>
              <SelectTrigger className="w-48 h-8 bg-card"><SelectValue placeholder="Alterar status" /></SelectTrigger>
              <SelectContent className="max-h-72">
                {ORDER_STATUS_LIST.map((s) => (
                  <SelectItem key={s} value={s}>{ORDER_STATUS[s].label}</SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Button variant="outline" size="sm" onClick={handleBulkExport} className="h-8 gap-1.5">
              <Printer className="w-4 h-4" /> Exportar seleção
            </Button>
            <Button variant="outline" size="sm" onClick={handleBulkDelete} className="h-8 gap-1.5 text-red-600 hover:text-red-700">
              <Trash2 className="w-4 h-4" /> Excluir
            </Button>
            <Button variant="ghost" size="sm" onClick={clearSelection} className="h-8">Limpar</Button>
          </div>
        </div>
      )}

      <div className="overflow-x-auto">
        <table className="w-full text-xs table-fixed min-w-[900px]">
          <thead className="bg-muted/50 text-muted-foreground">
            <tr>
              <th className="w-10 px-2 py-2">
                <Checkbox
                  checked={allOnPageSelected ? true : someOnPageSelected ? 'indeterminate' : false}
                  onCheckedChange={(v) => toggleAll(v === true)}
                />
              </th>
              {COLUMNS.map((col) => (
                <th key={col.key} style={{ width: col.width }} className="text-left font-medium px-2 py-2 whitespace-normal break-words">
                  <button onClick={() => toggleSort(col.key)} className="inline-flex items-center gap-1 hover:text-foreground">
                    {col.label}
                    <ArrowUpDown className="w-3 h-3 opacity-50" />
                  </button>
                </th>
              ))}
              <th style={{ width: '7%' }} className="text-right font-medium px-3 py-3 whitespace-nowrap">Ações</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-border">
            {loading && (
              <tr><td colSpan={COLUMNS.length + 2} className="text-center py-10 text-muted-foreground">Carregando pedidos...</td></tr>
            )}
            {!loading && orders.length === 0 && (
              <tr><td colSpan={COLUMNS.length + 2} className="text-center py-10 text-muted-foreground">
                <Package className="w-8 h-8 mx-auto mb-2 opacity-40" />
                Nenhum pedido encontrado
              </td></tr>
            )}
            {orders.map((order) => {
              const qty = (order.items || []).reduce((s, i) => s + (i.quantity || 0), 0);
              const o = orderStatusInfo(order.status);
              const p = paymentStatusInfo(order.payment_status);
              const d = deliveryStatusInfo(order.delivery_status);
              const isSel = !!selected[order.id];
              return (
                <tr key={order.id} className={`transition-colors ${isSel ? 'bg-blue-50/60 dark:bg-blue-950/30' : 'hover:bg-muted/40'}`}>
                  <td className="px-2 py-2">
                    <Checkbox checked={isSel} onCheckedChange={(v) => toggleOne(order.id, v === true)} />
                  </td>
                  <td className="px-2 py-2 font-medium truncate">{shortCode(order.id)}</td>
                  <td className="px-2 py-2 truncate text-muted-foreground">{fmtDate(order.created_date)}</td>
                  <td className="px-2 py-2 truncate">{order.customer_name}</td>
                  <td className="px-2 py-2 text-muted-foreground">{qty}</td>
                  <td className="px-2 py-2 font-semibold whitespace-nowrap">{formatCurrency(order.total)}</td>
                  <td className="px-2 py-2 truncate text-muted-foreground">{order.payment_method ? PAYMENT_METHODS[order.payment_method] : '—'}</td>
                  <td className="px-2 py-2"><Badge className={p.badge}><span className={`w-1.5 h-1.5 rounded-full ${p.dot}`} />{p.label}</Badge></td>
                  <td className="px-2 py-2"><Badge className={o.badge}><span className={`w-1.5 h-1.5 rounded-full ${o.dot}`} />{o.label}</Badge></td>
                  <td className="px-2 py-2"><Badge className={d.badge}><span className={`w-1.5 h-1.5 rounded-full ${d.dot}`} />{d.label}</Badge></td>
                  <td className="px-2 py-2 text-right">
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button variant="ghost" size="icon" className="h-8 w-8"><MoreHorizontal className="w-4 h-4" /></Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end" className="w-52">
                        <DropdownMenuItem onClick={() => onAction('view', order)}><Eye className="w-4 h-4 mr-2" /> Visualizar detalhes</DropdownMenuItem>
                        <DropdownMenuItem onClick={() => onAction('edit', order)}><Pencil className="w-4 h-4 mr-2" /> Editar</DropdownMenuItem>
                        {order.status !== 'cancelled' && order.status !== 'completed' && order.status !== 'invoiced' && (
                          <DropdownMenuItem onClick={() => onAction('finalize', order)} className="text-emerald-700"><CheckCircle2 className="w-4 h-4 mr-2" /> Finalizar pedido</DropdownMenuItem>
                        )}
                        <DropdownMenuItem onClick={() => onAction('print', order)}><Printer className="w-4 h-4 mr-2" /> Imprimir pedido</DropdownMenuItem>
                        <DropdownMenuItem onClick={() => onAction('duplicate', order)}><Copy className="w-4 h-4 mr-2" /> Duplicar</DropdownMenuItem>
                        <DropdownMenuSeparator />
                        {order.status !== 'cancelled' && (
                          <DropdownMenuItem onClick={() => onAction('cancel', order)} className="text-amber-600"><XCircle className="w-4 h-4 mr-2" /> Cancelar pedido</DropdownMenuItem>
                        )}
                        <DropdownMenuSeparator />
                        <DropdownMenuItem onClick={() => setDeleteTarget(order)} className="text-red-600"><Trash2 className="w-4 h-4 mr-2" /> Excluir pedido</DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>

      <div className="flex items-center justify-between gap-3 px-4 py-3 border-t border-border">
        <p className="text-xs text-muted-foreground">
          Página {page} de {totalPages} · {total} pedido(s)
        </p>
        <div className="flex items-center gap-2">
          <Button variant="outline" size="sm" disabled={page <= 1} onClick={() => setPage((p) => Math.max(1, p - 1))} className="gap-1">
            <ChevronLeft className="w-4 h-4" /> Anterior
          </Button>
          <Button variant="outline" size="sm" disabled={page >= totalPages} onClick={() => setPage((p) => p + 1)} className="gap-1">
            Próxima <ChevronRight className="w-4 h-4" />
          </Button>
        </div>
      </div>

      <AlertDialog open={!!deleteTarget} onOpenChange={(o) => !o && setDeleteTarget(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Excluir pedido?</AlertDialogTitle>
            <AlertDialogDescription>
              Esta ação não pode ser desfeita. O pedido {deleteTarget ? '#' + deleteTarget.id.substring(0, 8).toUpperCase() : ''} será removido permanentemente.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancelar</AlertDialogCancel>
            <AlertDialogAction onClick={() => { onAction('delete', deleteTarget); setDeleteTarget(null); }} className="bg-red-600 hover:bg-red-700">
              Excluir
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}