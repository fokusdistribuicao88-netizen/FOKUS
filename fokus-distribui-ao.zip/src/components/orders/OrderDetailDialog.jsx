import React, { useState, useEffect } from 'react';
import { User, Phone, Mail, MapPin, CreditCard, Truck, Clock, Package, CheckCircle2, FileText, DollarSign } from 'lucide-react';
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription,
} from '@/components/ui/dialog';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import {
  Select, SelectTrigger, SelectValue, SelectContent, SelectItem,
} from '@/components/ui/select';
import {
  ORDER_STATUS_LIST, PAYMENT_STATUS_LIST, DELIVERY_STATUS_LIST, PAYMENT_METHOD_LIST,
  ORDER_STATUS, PAYMENT_STATUS, DELIVERY_STATUS, PAYMENT_METHODS, formatCurrency,
  FINANCIAL_STATUS,
} from './orderStatus';

function Section({ title, children }) {
  return (
    <div className="space-y-2">
      <h4 className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">{title}</h4>
      {children}
    </div>
  );
}

function Row({ icon: Icon, label, value }) {
  return (
    <div className="flex items-start gap-2 text-sm py-1">
      <Icon className="w-4 h-4 text-muted-foreground mt-0.5 flex-shrink-0" />
      <span className="text-muted-foreground w-20 sm:w-28 flex-shrink-0">{label}:</span>
      <span className="font-medium break-words min-w-0">{value || '—'}</span>
    </div>
  );
}

export default function OrderDetailDialog({ order, productMap, onClose, onUpdate, onFinalize }) {
  const [draft, setDraft] = useState(order || {});

  useEffect(() => {
    setDraft(order || {});
  }, [order]);

  if (!order) return null;

  const shortCode = (id) => (id ? '#' + id.substring(0, 8).toUpperCase() : '—');
  const o = ORDER_STATUS[order.status] || { label: order.status };
  const p = PAYMENT_STATUS[order.payment_status] || { label: order.payment_status };
  const d = DELIVERY_STATUS[order.delivery_status] || { label: order.delivery_status };
  const subtotal = (order.items || []).reduce((s, i) => s + (i.subtotal || 0), 0);
  const paidAmount = (order.payments || []).reduce((s, p) => s + (Number(p.amount) || 0), 0);

  const saveField = async (patch, eventLabel) => {
    const timeline = [...(order.timeline || []), { date: new Date().toISOString(), event: eventLabel, author: 'Sistema' }];
    await onUpdate(order.id, { ...patch, timeline });
  };

  return (
    <Dialog open={!!order} onOpenChange={(op) => !op && onClose()}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex flex-wrap items-center gap-2">
            Pedido {shortCode(order.id)}
            <span className={`inline-flex items-center gap-1.5 px-2 py-0.5 rounded-full text-xs font-medium ${o.badge || ''}`}>
              {o.label}
            </span>
          </DialogTitle>
          <DialogDescription>
            Criado em {new Date(order.created_date).toLocaleString('pt-BR')} · Última atualização {new Date(order.updated_date).toLocaleString('pt-BR')}
          </DialogDescription>
        </DialogHeader>

        {order.status !== 'cancelled' && order.status !== 'completed' && order.status !== 'invoiced' && onFinalize && (
          <div className="flex justify-end -mt-1 mb-1">
            <Button size="sm" onClick={() => onFinalize(order)} className="bg-emerald-600 hover:bg-emerald-700 gap-1.5">
              <CheckCircle2 className="w-4 h-4" /> Finalizar pedido
            </Button>
          </div>
        )}

        <Tabs defaultValue="summary">
          <TabsList className="flex w-full overflow-x-auto no-scrollbar sm:grid sm:grid-cols-6 sm:overflow-visible">
            <TabsTrigger value="summary" className="flex-1 whitespace-nowrap sm:flex-initial">Resumo</TabsTrigger>
            <TabsTrigger value="items" className="flex-1 whitespace-nowrap sm:flex-initial">Produtos</TabsTrigger>
            <TabsTrigger value="payment" className="flex-1 whitespace-nowrap sm:flex-initial">Pagamento</TabsTrigger>
            <TabsTrigger value="delivery" className="flex-1 whitespace-nowrap sm:flex-initial">Entrega</TabsTrigger>
            <TabsTrigger value="financial" className="flex-1 whitespace-nowrap sm:flex-initial">Financeiro</TabsTrigger>
            <TabsTrigger value="timeline" className="flex-1 whitespace-nowrap sm:flex-initial">Linha do tempo</TabsTrigger>
          </TabsList>

          <TabsContent value="summary" className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <Section title="Dados do cliente">
                <Row icon={User} label="Cliente" value={order.customer_name} />
                <Row icon={Phone} label="Telefone" value={order.customer_phone} />
                <Row icon={Mail} label="E-mail" value={order.customer_email} />
                <Row icon={FileText} label="CPF/CNPJ" value={order.cpf_cnpj} />
              </Section>
              <Section title="Endereço de entrega">
                <Row icon={MapPin} label="Endereço" value={order.customer_address} />
                <Row icon={MapPin} label="Cidade/UF" value={`${order.city || '—'} - ${order.state || '—'}`} />
              </Section>
              <Section title="Endereço de cobrança">
                <Row icon={MapPin} label="Cobrança" value={order.billing_address} />
              </Section>
              <Section title="Responsável">
                <Row icon={User} label="Vendedor" value={order.seller} />
              </Section>
            </div>
            <Section title="Valores">
              <div className="bg-muted/40 rounded-xl p-3 space-y-1 text-sm">
                <div className="flex justify-between"><span className="text-muted-foreground">Subtotal</span><span>{formatCurrency(subtotal)}</span></div>
                {order.discount ? <div className="flex justify-between"><span className="text-muted-foreground">Desconto</span><span>-{formatCurrency(order.discount)}</span></div> : null}
                {order.freight ? <div className="flex justify-between"><span className="text-muted-foreground">Frete</span><span>{formatCurrency(order.freight)}</span></div> : null}
                <div className="flex justify-between font-bold text-base pt-1 border-t border-border"><span>Total</span><span>{formatCurrency(order.total)}</span></div>
              </div>
            </Section>
          </TabsContent>

          <TabsContent value="items" className="space-y-3">
            <div className="border border-border rounded-xl overflow-x-auto">
              <table className="w-full text-sm min-w-[400px]">
                <thead className="bg-muted/50 text-muted-foreground">
                  <tr>
                    <th className="text-left px-3 py-2 font-medium">Produto</th>
                    <th className="text-center px-3 py-2 font-medium">Qtd</th>
                    <th className="text-right px-3 py-2 font-medium">Unitário</th>
                    <th className="text-right px-3 py-2 font-medium">Subtotal</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-border">
                  {(order.items || []).map((item, i) => {
                    const product = productMap?.[item.product_id];
                    const packInfo = product?.units_per_pack ? ` (${product.units_per_pack} un/${product.unit_type || 'pack'})` : '';
                    return (
                      <tr key={i}>
                        <td className="px-3 py-2">{item.product_name}{packInfo}</td>
                        <td className="px-3 py-2 text-center">{item.quantity}</td>
                        <td className="px-3 py-2 text-right">{formatCurrency(item.unit_price)}</td>
                        <td className="px-3 py-2 text-right font-medium">{formatCurrency(item.subtotal)}</td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
            {order.notes && (
              <Section title="Observações do cliente">
                <p className="text-sm bg-muted/40 rounded-xl p-3">{order.notes}</p>
              </Section>
            )}
          </TabsContent>

          <TabsContent value="payment" className="space-y-4">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <Section title="Forma de pagamento">
                <Select value={draft.payment_method} onValueChange={(v) => setDraft((d) => ({ ...d, payment_method: v }))}>
                  <SelectTrigger><SelectValue placeholder="Selecione" /></SelectTrigger>
                  <SelectContent>
                    {PAYMENT_METHOD_LIST.map((m) => <SelectItem key={m} value={m}>{PAYMENT_METHODS[m]}</SelectItem>)}
                  </SelectContent>
                </Select>
              </Section>
              <Section title="Status do pagamento">
                <Select value={draft.payment_status} onValueChange={(v) => setDraft((d) => ({ ...d, payment_status: v }))}>
                  <SelectTrigger><SelectValue placeholder="Selecione" /></SelectTrigger>
                  <SelectContent>
                    {PAYMENT_STATUS_LIST.map((s) => <SelectItem key={s} value={s}>{PAYMENT_STATUS[s].label}</SelectItem>)}
                  </SelectContent>
                </Select>
              </Section>
            </div>
            <div className="flex justify-end">
              <Button size="sm" onClick={() => saveField({ payment_method: draft.payment_method, payment_status: draft.payment_status }, 'Pagamento atualizado')} className="bg-blue-700 hover:bg-blue-800">
                Salvar pagamento
              </Button>
            </div>
            <div className="flex items-center gap-2">
              <CreditCard className="w-4 h-4 text-muted-foreground" />
              <Badge className={p.badge}>{p.label}</Badge>
            </div>
          </TabsContent>

          <TabsContent value="delivery" className="space-y-4">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <Section title="Status da entrega">
                <Select value={draft.delivery_status} onValueChange={(v) => setDraft((d) => ({ ...d, delivery_status: v }))}>
                  <SelectTrigger><SelectValue placeholder="Selecione" /></SelectTrigger>
                  <SelectContent>
                    {DELIVERY_STATUS_LIST.map((s) => <SelectItem key={s} value={s}>{DELIVERY_STATUS[s].label}</SelectItem>)}
                  </SelectContent>
                </Select>
              </Section>
              <Section title="Status do pedido">
                <Select value={draft.status} onValueChange={(v) => setDraft((d) => ({ ...d, status: v }))}>
                  <SelectTrigger><SelectValue placeholder="Selecione" /></SelectTrigger>
                  <SelectContent>
                    {ORDER_STATUS_LIST.map((s) => <SelectItem key={s} value={s}>{ORDER_STATUS[s].label}</SelectItem>)}
                  </SelectContent>
                </Select>
              </Section>
              <Section title="Transportadora">
                <Input value={draft.carrier || ''} onChange={(e) => setDraft((d) => ({ ...d, carrier: e.target.value }))} placeholder="Transportadora" />
              </Section>
              <Section title="Código de rastreamento">
                <Input value={draft.tracking_code || ''} onChange={(e) => setDraft((d) => ({ ...d, tracking_code: e.target.value }))} placeholder="Código de rastreamento" />
              </Section>
            </div>
            <Section title="Observações internas">
              <Textarea value={draft.internal_notes || ''} onChange={(e) => setDraft((d) => ({ ...d, internal_notes: e.target.value }))} rows={3} placeholder="Observações internas" />
            </Section>
            <div className="flex justify-end">
              <Button size="sm" onClick={() => saveField({
                delivery_status: draft.delivery_status, status: draft.status, carrier: draft.carrier,
                tracking_code: draft.tracking_code, internal_notes: draft.internal_notes,
              }, 'Entrega e status atualizados')} className="bg-blue-700 hover:bg-blue-800">
                Salvar alterações
              </Button>
            </div>
            <div className="flex items-center gap-2">
              <Truck className="w-4 h-4 text-muted-foreground" />
              <Badge className={d.badge}>{d.label}</Badge>
            </div>
          </TabsContent>

          <TabsContent value="financial" className="space-y-4">
            <div className="flex items-center gap-2">
              <DollarSign className="w-4 h-4 text-muted-foreground" />
              {(() => {
                const fs = FINANCIAL_STATUS[order.financial_status || 'not_sent'] || FINANCIAL_STATUS.not_sent;
                return <Badge className={fs.badge}><span className={`w-1.5 h-1.5 rounded-full ${fs.dot}`} />{fs.label}</Badge>;
              })()}
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <Section title="Situação financeira">
                <div className="bg-muted/40 rounded-xl p-3 space-y-1 text-sm">
                  <div className="flex justify-between"><span className="text-muted-foreground">Valor do pedido</span><span className="font-medium">{formatCurrency(order.total)}</span></div>
                  <div className="flex justify-between"><span className="text-muted-foreground">Recebido</span><span className="font-medium">{formatCurrency(paidAmount)}</span></div>
                  <div className="flex justify-between"><span className="text-muted-foreground">Pendente</span><span className="font-medium">{formatCurrency(Math.max(0, (order.total || 0) - paidAmount))}</span></div>
                </div>
              </Section>
              <Section title="Lançamentos vinculados">
                {(order.financial_entry_ids || []).length === 0 ? (
                  <p className="text-sm text-muted-foreground">Nenhum lançamento financeiro vinculado.</p>
                ) : (
                  <div className="space-y-1">
                    {(order.financial_entry_ids || []).map((id, i) => (
                      <div key={i} className="text-sm bg-muted/40 rounded-lg px-2 py-1.5 font-mono text-xs">
                        Lançamento #{id.substring(0, 8).toUpperCase()}
                      </div>
                    ))}
                  </div>
                )}
              </Section>
            </div>
            {(order.financial_status && order.financial_status !== 'not_sent') && (
              <p className="text-xs text-muted-foreground">Este pedido já foi encaminhado ao Contas a Receber.</p>
            )}
          </TabsContent>

          <TabsContent value="timeline" className="space-y-3">
            <div className="relative pl-6 space-y-4">
              {(order.timeline || []).length === 0 && (
                <p className="text-sm text-muted-foreground">Nenhum registro de alteração ainda.</p>
              )}
              {(order.timeline || []).map((entry, i) => (
                <div key={i} className="relative">
                  <div className="absolute -left-5 top-1 w-2.5 h-2.5 rounded-full bg-blue-500 ring-4 ring-blue-500/20" />
                  <p className="text-sm font-medium">{entry.event}</p>
                  <p className="text-xs text-muted-foreground">
                    {entry.author} · {new Date(entry.date).toLocaleString('pt-BR')}
                  </p>
                </div>
              ))}
            </div>
          </TabsContent>
        </Tabs>
      </DialogContent>
    </Dialog>
  );
}

function Badge({ className, children }) {
  return <span className={`inline-flex items-center gap-1.5 px-2 py-0.5 rounded-full text-xs font-medium ${className}`}>{children}</span>;
}