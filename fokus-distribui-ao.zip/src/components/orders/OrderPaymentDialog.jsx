import React, { useState, useMemo, useRef } from 'react';
import { useQuery } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { useAuth } from '@/lib/AuthContext';
import { useToast } from '@/components/ui/use-toast';
import PaymentDialog from '@/components/pos/PaymentDialog';
import { finalizeExistingOrder } from '@/lib/orderFinalizeService';
import { findEmployeeForCustomer } from '@/lib/employeePurchaseSync';
import { logActivity } from '@/lib/activityLog';
import { fmt } from '@/components/pos/payment/paymentMethods';
import { InsufficientStockError } from '@/lib/stockValidation';
import InsufficientStockDialog from '@/components/pos/InsufficientStockDialog';
import CreditLimitDialog from '@/components/customeraccounts/CreditLimitDialog';
import { checkCreditForSale } from '@/lib/customerAccountService';
import { findCustomerByEmailOrPhone } from '@/lib/customerLookup';
import { canOverrideCreditLimit } from '@/lib/userRoles';

const TERM_METHODS = ['contas_receber', 'convenio', 'crediario', 'credit', 'boleto', 'transfer', 'cheque'];
const termAmountOf = (payments) => (payments || []).filter((p) => TERM_METHODS.includes(p.method)).reduce((s, p) => s + (Number(p.amount) || 0), 0);

/**
 * Wrapper que reaproveita o PaymentDialog do PDV para finalizar um pedido
 * EXISTENTE do Gerenciamento de Pedidos. Mesma lógica, cálculos e componentes.
 */
export default function OrderPaymentDialog({ order, onClose, onFinalized }) {
  const { user } = useAuth();
  const { toast } = useToast();
  const [busy, setBusy] = useState(false);
  const [stockIssue, setStockIssue] = useState(null);
  const [creditIssue, setCreditIssue] = useState(null);
  const lastArgs = useRef(null);
  const creditBypass = useRef(false);
  const canOverride = canOverrideCreditLimit(user?.role);

  const { data: settings } = useQuery({
    queryKey: ['settings'],
    queryFn: async () => {
      const list = await base44.entities.Settings.list('-updated_date', 1);
      return list[0] || null;
    },
  });

  const { data: employees = [] } = useQuery({
    queryKey: ['employees'],
    queryFn: () => base44.entities.Employee.list(),
    staleTime: 60 * 1000,
  });

  const cart = useMemo(() => (order?.items || []).map((i) => ({
    product_id: i.product_id, product_name: i.product_name,
    quantity: i.quantity, unit_price: i.unit_price, subtotal: i.subtotal,
  })), [order]);

  const customer = useMemo(() => {
    if (!order) return null;
    const base = {
      name: order.customer_name || 'Consumidor Final',
      phone: order.customer_phone || '',
      email: order.customer_email || '',
      cpf_cnpj: order.cpf_cnpj || '',
      address: order.customer_address || '',
      city: order.city || '',
      state: order.state || '',
    };
    if (order.payroll_employee_id) {
      const emp = employees.find((e) => e.id === order.payroll_employee_id);
      if (emp) return { ...base, ...emp, _isEmployee: true };
    }
    const matched = findEmployeeForCustomer(base, employees);
    if (matched) return { ...base, ...matched, _isEmployee: true };
    return base;
  }, [order, employees]);

  const gross = useMemo(() => cart.reduce((s, i) => s + (Number(i.subtotal) || 0), 0), [cart]);
  const discount = Number(order?.discount) || 0;
  const total = Number(order?.total) || Math.max(0, gross - discount);

  // Pré-preenche a entrega com base no pedido existente (mapeia 'entrega' → 'empresa')
  const initialDelivery = useMemo(() => {
    if (!order) return undefined;
    const isDelivery = order.delivery_method && order.delivery_method !== 'retirada';
    return {
      type: isDelivery ? 'empresa' : 'retirada',
      address: order.customer_address || customer?.address || '',
      date: order.delivery_expected_date || '',
      time: '',
      carrier: order.carrier || '',
      driver: order.driver_name || '',
      freight: Number(order.freight) || 0,
      notes: order.delivery_notes || '',
      receipt_mode: isDelivery ? (order.delivery_receipt_mode || 'already_paid') : 'none',
    };
  }, [order, customer]);

  const handleConfirm = async (payments, delivery, finalTotal, payrollDiscount) => {
    if (!order) return;
    // Verificação de limite de crédito (venda a prazo para cliente — não funcionário)
    const isEmployeeCrediario = !!payrollDiscount?.enabled && payrollDiscount?.type === 'crediario' && payrollDiscount?.employee;
    const termAmount = termAmountOf(payments);
    if (termAmount > 0 && !isEmployeeCrediario && !creditBypass.current) {
      try {
        const cust = await findCustomerByEmailOrPhone(order.customer_email, order.customer_phone);
        if (cust?.credit_limit > 0) {
          const check = await checkCreditForSale({ customer: cust, termAmount });
          if (!check.ok) {
            lastArgs.current = { payments, delivery, finalTotal, payrollDiscount };
            setCreditIssue(check);
            return;
          }
        }
      } catch { /* best-effort: não bloqueia */ }
    }
    setBusy(true);
    try {
      const result = await finalizeExistingOrder({
        order, payments, delivery, user, settings, payrollDiscount,
      });

      const isPayroll = !!result.payrollDiscount;
      const isCrediario = !!result.crediario;
      const partialDesc = result.partialRemaining > 0 ? ` — Parcial (saldo ${fmt(result.partialRemaining)})` : '';
      const payrollDesc = isPayroll ? ` — Desconto em folha (${payrollDiscount?.competence})` : '';
      const crediarioDesc = isCrediario ? ` — Crediário (funcionário: ${payrollDiscount?.employee?.name || customer?.name})` : '';
      logActivity({
        action: isPayroll ? 'order_finalize_payroll' : isCrediario ? 'order_finalize_crediario' : 'order_finalize',
        description: `Pedido #${result.saleCode} finalizado — ${fmt(finalTotal)} — Cliente: ${order.customer_name} — Pag: ${isPayroll ? 'Desconto em folha' : isCrediario ? 'Crediário' : (payments || []).map((p) => p.label).join(', ')}${partialDesc}${payrollDesc}${crediarioDesc}`,
        user, entityType: 'Order', entityId: order.id,
      });

      if (result.lowStockAlerts?.length) {
        const names = result.lowStockAlerts.map((a) => `${a.product_name} (${a.newQty})`).join(', ');
        toast({ title: '⚠️ Alerta de estoque baixo', description: names, variant: 'destructive' });
      }

      if (result.customerAccountError) {
        toast({ title: 'Atenção: conta a receber não criada', description: 'A gestão de parcelas do cliente pode estar incompleta. Verifique o Contas a Receber.', variant: 'destructive' });
      }

      const msg = isPayroll
        ? `#${result.saleCode} — ${fmt(finalTotal)} (desconto em folha — ${payrollDiscount?.competence})`
        : isCrediario
        ? `#${result.saleCode} — ${fmt(finalTotal)} (crediário — ${payrollDiscount?.employee?.name || customer?.name})`
        : result.partialRemaining > 0
        ? `#${result.saleCode} — Recebido ${fmt((payments || []).reduce((s, p) => s + p.amount, 0))} / ${fmt(finalTotal)} (saldo em Contas a Receber)`
        : `#${result.saleCode} — Total: ${fmt(finalTotal)}`;
      toast({ title: isPayroll ? 'Compra lançada para desconto em folha!' : isCrediario ? 'Crediário lançado!' : 'Pedido finalizado!', description: msg });

      onFinalized?.(result.order);
    } catch (e) {
      if (e instanceof InsufficientStockError) {
        setStockIssue(e.insufficient);
      } else {
        toast({ title: 'Erro ao finalizar pedido', description: String(e.message || e), variant: 'destructive' });
      }
    } finally {
      setBusy(false);
      creditBypass.current = false;
    }
  };

  const handlePrePrint = () => {
    // Pré-impressão usa o pedido original (antes de finalizar)
    onFinalized?.(order, { printOnly: true });
  };

  if (!order) return null;

  return (
    <>
      <PaymentDialog
        open={!!order}
        onClose={onClose}
        cart={cart}
        customer={customer}
        gross={gross}
        discount={discount}
        notes={order.notes || ''}
        total={total}
        canCredit={user?.role === 'admin' || user?.role === 'gerente' || user?.role === 'operador'}
        canPartial={user?.role === 'admin' || user?.role === 'gerente'}
        onConfirm={handleConfirm}
        onPrePrint={handlePrePrint}
        operatorName={user?.full_name || user?.email}
        busy={busy}
        initialDelivery={initialDelivery}
      />

      <InsufficientStockDialog
        open={!!stockIssue}
        items={stockIssue}
        onClose={() => setStockIssue(null)}
      />

      <CreditLimitDialog
        open={!!creditIssue}
        info={creditIssue}
        canOverride={canOverride}
        onClose={() => { setCreditIssue(null); }}
        onOverride={async () => {
          creditBypass.current = true;
          setCreditIssue(null);
          if (lastArgs.current) {
            const { payments, delivery, finalTotal, payrollDiscount } = lastArgs.current;
            lastArgs.current = null;
            await handleConfirm(payments, delivery, finalTotal, payrollDiscount);
          }
        }}
      />
    </>
  );
}