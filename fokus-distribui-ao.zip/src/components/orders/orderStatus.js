export const ORDER_STATUS = {
  pending:            { label: 'Pedido recebido',       badge: 'bg-slate-100 text-slate-700 dark:bg-slate-800 dark:text-slate-300',          dot: 'bg-slate-400' },
  awaiting_payment:   { label: 'Aguardando pagamento', badge: 'bg-amber-100 text-amber-700 dark:bg-amber-900/40 dark:text-amber-300',    dot: 'bg-amber-500' },
  payment_approved:   { label: 'Pagamento confirmado', badge: 'bg-blue-100 text-blue-700 dark:bg-blue-900/40 dark:text-blue-300',       dot: 'bg-blue-500' },
  confirmed:          { label: 'Confirmado',           badge: 'bg-indigo-100 text-indigo-700 dark:bg-indigo-900/40 dark:text-indigo-300', dot: 'bg-indigo-500' },
  separating:         { label: 'Em separação',         badge: 'bg-cyan-100 text-cyan-700 dark:bg-cyan-900/40 dark:text-cyan-300',        dot: 'bg-cyan-500' },
  preparing:          { label: 'Em preparação',        badge: 'bg-teal-100 text-teal-700 dark:bg-teal-900/40 dark:text-teal-300',        dot: 'bg-teal-500' },
  checked:            { label: 'Mercadoria conferida',  badge: 'bg-sky-100 text-sky-700 dark:bg-sky-900/40 dark:text-sky-300',           dot: 'bg-sky-500' },
  awaiting_shipment:  { label: 'Aguardando expedição', badge: 'bg-cyan-100 text-cyan-700 dark:bg-cyan-900/40 dark:text-cyan-300',        dot: 'bg-cyan-600' },
  ready_for_delivery: { label: 'Pronto para entrega',  badge: 'bg-lime-100 text-lime-700 dark:bg-lime-900/40 dark:text-lime-300',        dot: 'bg-lime-500' },
  shipped:            { label: 'Enviado',               badge: 'bg-violet-100 text-violet-700 dark:bg-violet-900/40 dark:text-violet-300', dot: 'bg-violet-500' },
  in_transit:         { label: 'Em transporte',        badge: 'bg-purple-100 text-purple-700 dark:bg-purple-900/40 dark:text-purple-300', dot: 'bg-purple-500' },
  in_route:           { label: 'Em rota',              badge: 'bg-orange-100 text-orange-700 dark:bg-orange-900/40 dark:text-orange-300', dot: 'bg-orange-500' },
  out_for_delivery:   { label: 'Saiu para entrega',    badge: 'bg-orange-100 text-orange-700 dark:bg-orange-900/40 dark:text-orange-300', dot: 'bg-orange-600' },
  in_progress:        { label: 'Em andamento',          badge: 'bg-fuchsia-100 text-fuchsia-700 dark:bg-fuchsia-900/40 dark:text-fuchsia-300', dot: 'bg-fuchsia-500' },
  delivered:          { label: 'Entregue',              badge: 'bg-green-100 text-green-700 dark:bg-green-900/40 dark:text-green-300',    dot: 'bg-green-500' },
  completed:          { label: 'Concluído',             badge: 'bg-emerald-100 text-emerald-700 dark:bg-emerald-900/40 dark:text-emerald-300', dot: 'bg-emerald-500' },
  invoiced:           { label: 'Faturado',              badge: 'bg-blue-100 text-blue-700 dark:bg-blue-900/40 dark:text-blue-300',       dot: 'bg-blue-600' },
  customer_absent:    { label: 'Cliente ausente',       badge: 'bg-yellow-100 text-yellow-700 dark:bg-yellow-900/40 dark:text-yellow-300', dot: 'bg-yellow-500' },
  rescheduled:        { label: 'Entrega reagendada',   badge: 'bg-amber-100 text-amber-700 dark:bg-amber-900/40 dark:text-amber-300',    dot: 'bg-amber-600' },
  refused:            { label: 'Entrega recusada',      badge: 'bg-red-100 text-red-700 dark:bg-red-900/40 dark:text-red-300',            dot: 'bg-red-500' },
  occurrence:         { label: 'Ocorrência na entrega', badge: 'bg-rose-100 text-rose-700 dark:bg-rose-900/40 dark:text-rose-300',        dot: 'bg-rose-500' },
  cancelled:          { label: 'Cancelado',             badge: 'bg-red-100 text-red-700 dark:bg-red-900/40 dark:text-red-300',            dot: 'bg-red-500' },
  refunded:           { label: 'Reembolsado',           badge: 'bg-rose-100 text-rose-700 dark:bg-rose-900/40 dark:text-rose-300',        dot: 'bg-rose-500' },
  returned:           { label: 'Devolvido',              badge: 'bg-pink-100 text-pink-700 dark:bg-pink-900/40 dark:text-pink-300',       dot: 'bg-pink-500' },
};

export const LOGISTICS_STATUS = {
  pending:            { label: 'Aguardando conferência', badge: 'bg-slate-100 text-slate-700 dark:bg-slate-800 dark:text-slate-300',   dot: 'bg-slate-400' },
  separating:         { label: 'Em separação',          badge: 'bg-cyan-100 text-cyan-700 dark:bg-cyan-900/40 dark:text-cyan-300',     dot: 'bg-cyan-500' },
  checked:            { label: 'Mercadoria conferida',   badge: 'bg-sky-100 text-sky-700 dark:bg-sky-900/40 dark:text-sky-300',       dot: 'bg-sky-500' },
  awaiting_shipment:  { label: 'Aguardando expedição',  badge: 'bg-cyan-100 text-cyan-700 dark:bg-cyan-900/40 dark:text-cyan-300',     dot: 'bg-cyan-600' },
  ready_for_delivery: { label: 'Pronto para entrega',   badge: 'bg-lime-100 text-lime-700 dark:bg-lime-900/40 dark:text-lime-300',     dot: 'bg-lime-500' },
  in_route:           { label: 'Em rota',                badge: 'bg-orange-100 text-orange-700 dark:bg-orange-900/40 dark:text-orange-300', dot: 'bg-orange-500' },
  out_for_delivery:   { label: 'Saiu para entrega',     badge: 'bg-orange-100 text-orange-700 dark:bg-orange-900/40 dark:text-orange-300', dot: 'bg-orange-600' },
  delivered:          { label: 'Entregue',               badge: 'bg-green-100 text-green-700 dark:bg-green-900/40 dark:text-green-300',  dot: 'bg-green-500' },
  customer_absent:    { label: 'Cliente ausente',       badge: 'bg-yellow-100 text-yellow-700 dark:bg-yellow-900/40 dark:text-yellow-300', dot: 'bg-yellow-500' },
  rescheduled:       { label: 'Entrega reagendada',     badge: 'bg-amber-100 text-amber-700 dark:bg-amber-900/40 dark:text-amber-300', dot: 'bg-amber-600' },
  refused:            { label: 'Entrega recusada',      badge: 'bg-red-100 text-red-700 dark:bg-red-900/40 dark:text-red-300',         dot: 'bg-red-500' },
  occurrence:         { label: 'Ocorrência na entrega', badge: 'bg-rose-100 text-rose-700 dark:bg-rose-900/40 dark:text-rose-300',     dot: 'bg-rose-500' },
  cancelled:          { label: 'Cancelado',             badge: 'bg-red-100 text-red-700 dark:bg-red-900/40 dark:text-red-300',         dot: 'bg-red-500' },
  returned:           { label: 'Devolvido',             badge: 'bg-pink-100 text-pink-700 dark:bg-pink-900/40 dark:text-pink-300',     dot: 'bg-pink-500' },
};
export const LOGISTICS_STATUS_LIST = Object.keys(LOGISTICS_STATUS);

export const FINANCIAL_STATUS = {
  not_sent: { label: 'Não enviado ao Financeiro', badge: 'bg-slate-100 text-slate-700 dark:bg-slate-800 dark:text-slate-300', dot: 'bg-slate-400' },
  sent:     { label: 'Enviado ao Convênio', badge: 'bg-blue-100 text-blue-700 dark:bg-blue-900/40 dark:text-blue-300',   dot: 'bg-blue-500' },
  pending:  { label: 'Recebimento pendente',       badge: 'bg-amber-100 text-amber-700 dark:bg-amber-900/40 dark:text-amber-300', dot: 'bg-amber-500' },
  partial:  { label: 'Recebimento parcial',        badge: 'bg-cyan-100 text-cyan-700 dark:bg-cyan-900/40 dark:text-cyan-300',   dot: 'bg-cyan-500' },
  paid:     { label: 'Recebimento concluído',       badge: 'bg-green-100 text-green-700 dark:bg-green-900/40 dark:text-green-300', dot: 'bg-green-500' },
};

export const DRIVER_STATUSES = ['in_route', 'out_for_delivery', 'delivered', 'customer_absent', 'rescheduled', 'refused', 'occurrence'];
export const MANAGER_STATUSES = ['checked', 'awaiting_shipment', 'ready_for_delivery'];
export const ADMIN_LOGISTICS_STATUSES = [...new Set([...DRIVER_STATUSES, ...MANAGER_STATUSES, 'separating', 'cancelled', 'returned'])];

export const RECEIVABLE_ELIGIBLE_STATUSES = [
  'pending', 'awaiting_payment', 'payment_approved', 'confirmed',
  'separating', 'preparing', 'checked', 'awaiting_shipment',
  'ready_for_delivery', 'shipped', 'in_transit', 'in_route',
  'out_for_delivery', 'in_progress', 'delivered', 'completed', 'invoiced',
];
export const RECEIVABLE_INELIGIBLE_STATUSES = ['cancelled', 'refunded', 'returned'];

export const PAYMENT_STATUS = {
  pending:  { label: 'Pendente',    badge: 'bg-amber-100 text-amber-700 dark:bg-amber-900/40 dark:text-amber-300', dot: 'bg-amber-500' },
  paid:     { label: 'Pago',       badge: 'bg-green-100 text-green-700 dark:bg-green-900/40 dark:text-green-300', dot: 'bg-green-500' },
  refunded: { label: 'Reembolsado', badge: 'bg-rose-100 text-rose-700 dark:bg-rose-900/40 dark:text-rose-300',   dot: 'bg-rose-500' },
  failed:   { label: 'Falhou',     badge: 'bg-red-100 text-red-700 dark:bg-red-900/40 dark:text-red-300',         dot: 'bg-red-500' },
};

export const DELIVERY_STATUS = {
  pending:         { label: 'Aguardando',      badge: 'bg-slate-100 text-slate-700 dark:bg-slate-800 dark:text-slate-300',     dot: 'bg-slate-400' },
  processing:      { label: 'Em processamento', badge: 'bg-cyan-100 text-cyan-700 dark:bg-cyan-900/40 dark:text-cyan-300',   dot: 'bg-cyan-500' },
  shipped:         { label: 'Enviado',          badge: 'bg-violet-100 text-violet-700 dark:bg-violet-900/40 dark:text-violet-300', dot: 'bg-violet-500' },
  in_transit:      { label: 'Em transporte',    badge: 'bg-purple-100 text-purple-700 dark:bg-purple-900/40 dark:text-purple-300', dot: 'bg-purple-500' },
  out_for_delivery: { label: 'Saiu para entrega', badge: 'bg-orange-100 text-orange-700 dark:bg-orange-900/40 dark:text-orange-300', dot: 'bg-orange-500' },
  delivered:       { label: 'Entregue',         badge: 'bg-green-100 text-green-700 dark:bg-green-900/40 dark:text-green-300', dot: 'bg-green-500' },
  returned:        { label: 'Devolvido',        badge: 'bg-pink-100 text-pink-700 dark:bg-pink-900/40 dark:text-pink-300',   dot: 'bg-pink-500' },
};

export const ON_SITE_PAYMENT_STATUS = {
  pending:      { label: 'Aguardando recebimento', badge: 'bg-amber-100 text-amber-700 dark:bg-amber-900/40 dark:text-amber-300', dot: 'bg-amber-500' },
  partial:      { label: 'Recebimento parcial',    badge: 'bg-cyan-100 text-cyan-700 dark:bg-cyan-900/40 dark:text-cyan-300',     dot: 'bg-cyan-500' },
  received:     { label: 'Recebido no local',       badge: 'bg-green-100 text-green-700 dark:bg-green-900/40 dark:text-green-300',  dot: 'bg-green-500' },
  not_received: { label: 'Não recebido',            badge: 'bg-red-100 text-red-700 dark:bg-red-900/40 dark:text-red-300',         dot: 'bg-red-500' },
};
export const ON_SITE_PAYMENT_STATUS_LIST = Object.keys(ON_SITE_PAYMENT_STATUS);

export const PAYMENT_METHODS = {
  pix: 'Pix',
  credit_card: 'Cartão de crédito',
  boleto: 'Boleto',
  cash: 'Dinheiro',
  transfer: 'Transferência',
  convenio: 'Convênio',
  crediario: 'Convênio',
  desconto_folha: 'Desconto em Folha',
};

export const ORDER_STATUS_LIST = Object.keys(ORDER_STATUS);
export const PAYMENT_STATUS_LIST = Object.keys(PAYMENT_STATUS);
export const DELIVERY_STATUS_LIST = Object.keys(DELIVERY_STATUS);
export const PAYMENT_METHOD_LIST = Object.keys(PAYMENT_METHODS);

export const IN_PROGRESS_STATUSES = ['awaiting_payment', 'payment_approved', 'confirmed', 'separating', 'preparing', 'checked', 'awaiting_shipment', 'ready_for_delivery', 'shipped', 'in_transit', 'in_route', 'out_for_delivery', 'in_progress', 'invoiced'];
export const COMPLETED_STATUSES = ['delivered', 'completed'];

export function orderStatusInfo(key) {
  return ORDER_STATUS[key] || { label: key || '—', badge: 'bg-slate-100 text-slate-700 dark:bg-slate-800 dark:text-slate-300', dot: 'bg-slate-400' };
}
export function paymentStatusInfo(key) {
  return PAYMENT_STATUS[key] || { label: key || '—', badge: 'bg-slate-100 text-slate-700 dark:bg-slate-800 dark:text-slate-300', dot: 'bg-slate-400' };
}
export function deliveryStatusInfo(key) {
  return DELIVERY_STATUS[key] || { label: key || '—', badge: 'bg-slate-100 text-slate-700 dark:bg-slate-800 dark:text-slate-300', dot: 'bg-slate-400' };
}

export function formatCurrency(value) {
  return `R$ ${(Number(value) || 0).toFixed(2).replace('.', ',')}`;
}