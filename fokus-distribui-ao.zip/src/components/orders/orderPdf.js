// PDF de Pedido — agora gerado pelo Gerenciador de Modelos PDF.
// Toda geração passa pelo pdfService central (modelo "order" configurável no Editor).
import { generatePDF, sharePDF } from '@/lib/pdfService';
import { orderToData } from '@/lib/pdfAdapters';

// Gera o PDF do pedido usando o modelo central do sistema.
export async function generateOrderPDF(order, settings, productMap) {
  const data = orderToData(order, settings, productMap);
  const code = (order.id || '').substring(0, 8).toUpperCase();
  await generatePDF({
    documentType: 'order',
    data,
    module: 'Pedidos',
    fileName: `pedido-${(order.customer_name || 'cliente').replace(/\s+/g, '-')}-${code}.pdf`,
  });
}

// Compartilha o PDF do pedido via Web Share API (outros aplicativos).
export async function shareOrderPDF(order, settings, productMap) {
  const data = orderToData(order, settings, productMap);
  const code = (order.id || '').substring(0, 8).toUpperCase();
  return sharePDF({
    documentType: 'order',
    data,
    module: 'Pedidos',
    fileName: `pedido-${(order.customer_name || 'cliente').replace(/\s+/g, '-')}-${code}.pdf`,
  });
}