import React, { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { formatBRL } from '@/lib/format';
import { generateInstallments } from '@/lib/customerAccountCalc';

export default function CustomerAccountFormDialog({ open, onClose, onSaved, customers, user }) {
  const today = new Date().toISOString().slice(0, 10);
  const [form, setForm] = useState({
    customer_id: '', customer_name: '', customer_document: '',
    description: '', original_amount: '', issue_date: today,
    first_due_date: today, due_date: today, installment_count: 1, interval_days: 30,
    interest_rate: 0, discount: 0, category: 'Receita de Vendas', cost_center: '',
    expected_payment_method: '', notes: '', responsible: user?.full_name || user?.email || '',
    penalty_percent: 2, daily_interest: 0.033, tolerance_days: 0,
  });
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (open) {
      setForm((f) => ({ ...f, responsible: user?.full_name || user?.email || '' }));
    }
  }, [open, user]);

  const set = (k, v) => setForm((f) => ({ ...f, [k]: v }));

  const installments = generateInstallments({
    original_amount: Number(form.original_amount) || 0,
    installment_count: Number(form.installment_count) || 1,
    first_due_date: form.first_due_date || today,
    interval_days: Number(form.interval_days) || 30,
    interest_rate: Number(form.interest_rate) || 0,
    penalty: 0,
    discount: Number(form.discount) || 0,
  });
  const totalInst = installments.reduce((s, i) => s + i.original_amount, 0);

  const selectCustomer = (id) => {
    const c = customers?.find((x) => x.id === id);
    if (c) setForm((f) => ({ ...f, customer_id: c.id, customer_name: c.name, customer_document: c.cpf_cnpj || '' }));
  };

  const submit = async () => {
    if (!form.customer_name || !form.original_amount) return;
    setSaving(true);
    try {
      await onSaved({
        ...form,
        original_amount: Number(form.original_amount),
        installment_count: Number(form.installment_count) || 1,
        interval_days: Number(form.interval_days) || 30,
        interest_rate: Number(form.interest_rate) || 0,
        discount: Number(form.discount) || 0,
        penalty_config: {
          fixed_penalty: 0,
          penalty_percent: Number(form.penalty_percent) || 0,
          daily_interest: Number(form.daily_interest) || 0,
          monthly_interest: (Number(form.daily_interest) || 0) * 30,
          tolerance_days: Number(form.tolerance_days) || 0,
          early_payment_discount: 0,
        },
      });
      onClose();
    } finally {
      setSaving(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={(o) => !o && onClose()}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Nova Conta a Receber</DialogTitle>
        </DialogHeader>
        <div className="space-y-3">
          <div className="grid grid-cols-2 gap-3">
            <div className="col-span-2">
              <Label>Cliente *</Label>
              <Select value={form.customer_id} onValueChange={selectCustomer}>
                <SelectTrigger><SelectValue placeholder="Selecione o cliente" /></SelectTrigger>
                <SelectContent>
                  {(customers || []).map((c) => (
                    <SelectItem key={c.id} value={c.id}>{c.name}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
              {!form.customer_id && (
                <Input className="mt-2" placeholder="Ou digite o nome do cliente" value={form.customer_name} onChange={(e) => set('customer_name', e.target.value)} />
              )}
            </div>
            <div className="col-span-2">
              <Label>Descrição</Label>
              <Input value={form.description} onChange={(e) => set('description', e.target.value)} placeholder="Descrição da conta" />
            </div>
            <div>
              <Label>Valor original (R$) *</Label>
              <Input type="number" step="0.01" value={form.original_amount} onChange={(e) => set('original_amount', e.target.value)} />
            </div>
            <div>
              <Label>Data de emissão</Label>
              <Input type="date" value={form.issue_date} onChange={(e) => set('issue_date', e.target.value)} />
            </div>
          </div>

          <div className="border-t pt-3">
            <h4 className="text-sm font-semibold mb-2">Parcelamento</h4>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
              <div>
                <Label>Parcelas</Label>
                <Input type="number" min="1" value={form.installment_count} onChange={(e) => set('installment_count', e.target.value)} />
              </div>
              <div>
                <Label>1º vencimento</Label>
                <Input type="date" value={form.first_due_date} onChange={(e) => set('first_due_date', e.target.value)} />
              </div>
              <div>
                <Label>Intervalo (dias)</Label>
                <Input type="number" value={form.interval_days} onChange={(e) => set('interval_days', e.target.value)} />
              </div>
              <div>
                <Label>Juros (%)</Label>
                <Input type="number" step="0.01" value={form.interest_rate} onChange={(e) => set('interest_rate', e.target.value)} />
              </div>
              <div>
                <Label>Desconto (R$)</Label>
                <Input type="number" step="0.01" value={form.discount} onChange={(e) => set('discount', e.target.value)} />
              </div>
            </div>
            <div className="mt-2 text-xs text-muted-foreground">
              Total das parcelas: <span className="font-semibold">{formatBRL(totalInst)}</span> · {installments.length}x
            </div>
          </div>

          <div className="border-t pt-3">
            <h4 className="text-sm font-semibold mb-2">Regras de atraso</h4>
            <div className="grid grid-cols-3 gap-3">
              <div>
                <Label>Multa (%)</Label>
                <Input type="number" step="0.01" value={form.penalty_percent} onChange={(e) => set('penalty_percent', e.target.value)} />
              </div>
              <div>
                <Label>Juros/dia (%)</Label>
                <Input type="number" step="0.001" value={form.daily_interest} onChange={(e) => set('daily_interest', e.target.value)} />
              </div>
              <div>
                <Label>Tolerância (dias)</Label>
                <Input type="number" value={form.tolerance_days} onChange={(e) => set('tolerance_days', e.target.value)} />
              </div>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <Label>Categoria</Label>
              <Input value={form.category} onChange={(e) => set('category', e.target.value)} />
            </div>
            <div>
              <Label>Centro de custo</Label>
              <Input value={form.cost_center} onChange={(e) => set('cost_center', e.target.value)} />
            </div>
            <div>
              <Label>Forma de pagamento prevista</Label>
              <Input value={form.expected_payment_method} onChange={(e) => set('expected_payment_method', e.target.value)} placeholder="PIX, Boleto..." />
            </div>
            <div>
              <Label>Responsável</Label>
              <Input value={form.responsible} onChange={(e) => set('responsible', e.target.value)} />
            </div>
          </div>
          <div>
            <Label>Observações</Label>
            <Textarea rows={2} value={form.notes} onChange={(e) => set('notes', e.target.value)} />
          </div>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={onClose}>Cancelar</Button>
          <Button onClick={submit} disabled={saving || !form.customer_name || !form.original_amount}>
            {saving ? 'Salvando...' : 'Criar Conta'}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}