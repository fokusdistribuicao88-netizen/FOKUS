import React, { useState, useMemo } from 'react';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select, SelectTrigger, SelectValue, SelectContent, SelectItem } from '@/components/ui/select';
import { Card } from '@/components/ui/card';
import { formatBRL, formatDate, formatDateTime } from '@/lib/format';
import { recomputeAccountTotals } from '@/lib/customerAccountCalc';
import {
  computeConsultation,
  getPeriodRange,
  getPeriodLabel,
  filterAccountsByPeriod,
  filterAccountsByStatus,
  PERIOD_OPTIONS,
  STATUS_OPTIONS,
} from '@/lib/customerConsultation';
import { printCustomerConsultation, previewCustomerConsultation, printCustomerConsultationReport, shareCustomerConsultation } from '@/lib/customerAccountPdf';
import { useToast } from '@/components/ui/use-toast';
import CustomerAccountDetailDialog from './CustomerAccountDetailDialog';
import {
  Search, FileText, Printer, Eye, Wallet, TrendingUp, AlertTriangle,
  Clock, Calendar, CreditCard, Receipt, ChevronUp, ChevronDown, Share2,
} from 'lucide-react';

const STATUS_LABELS = {
  open: 'Em aberto', partial: 'Parcial', overdue: 'Vencida', paid: 'Quitada',
  cancelled: 'Cancelada', negotiated: 'Renegociada',
};
const STATUS_TONES = {
  open: 'bg-blue-100 text-blue-700', partial: 'bg-amber-100 text-amber-700',
  overdue: 'bg-red-100 text-red-700', paid: 'bg-emerald-100 text-emerald-700',
  cancelled: 'bg-slate-200 text-slate-500', negotiated: 'bg-purple-100 text-purple-700',
};

function Metric({ icon: Icon, label, value, tone }) {
  const tones = { blue: 'text-blue-600', red: 'text-red-600', emerald: 'text-emerald-600', amber: 'text-amber-600', slate: 'text-slate-600', violet: 'text-violet-600' };
  return (
    <div className="flex items-center gap-2 bg-slate-50 rounded-lg p-2">
      <Icon className={`h-4 w-4 shrink-0 ${tones[tone] || tones.slate}`} />
      <div className="min-w-0">
        <div className="text-[11px] text-muted-foreground truncate">{label}</div>
        <div className="text-sm font-semibold truncate">{value}</div>
      </div>
    </div>
  );
}

export default function CustomerConsultationDialog({ open, onClose, customers, user }) {
  const { toast } = useToast();
  const qc = useQueryClient();
  const [customerId, setCustomerId] = useState('');
  const [search, setSearch] = useState('');
  const [period, setPeriod] = useState('all');
  const [customStart, setCustomStart] = useState('');
  const [customEnd, setCustomEnd] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [sortBy, setSortBy] = useState('due_date');
  const [sortDir, setSortDir] = useState('asc');
  const [detailAccount, setDetailAccount] = useState(null);
  const [busy, setBusy] = useState(false);

  const customer = (customers || []).find((c) => c.id === customerId);

  const { data: accounts = [], isLoading } = useQuery({
    queryKey: ['customerAccounts', customerId],
    queryFn: async () => {
      if (!customerId) return [];
      const list = await base44.entities.CustomerAccount.filter({ customer_id: customerId }, '-created_date', 500);
      return (list || []).map((a) => recomputeAccountTotals(a));
    },
    enabled: !!customerId && open,
  });

  const consultation = useMemo(() => {
    if (!customer || !accounts.length) return null;
    return computeConsultation(customer, accounts);
  }, [customer, accounts]);

  const range = getPeriodRange(period, customStart, customEnd);
  const periodLabel = getPeriodLabel(period, range);

  const filteredAccounts = useMemo(() => {
    if (!consultation) return [];
    let r = filterAccountsByPeriod(consultation.accounts, range);
    r = filterAccountsByStatus(r, statusFilter);
    if (search.trim()) {
      const q = search.toLowerCase();
      r = r.filter((a) => (a.account_number || '').toLowerCase().includes(q) || (a.order_code || '').toLowerCase().includes(q));
    }
    return [...r].sort((a, b) => {
      let av = a[sortBy], bv = b[sortBy];
      if (sortBy === 'due_date' || sortBy === 'issue_date') { av = av || ''; bv = bv || ''; }
      else { av = Number(av) || 0; bv = Number(bv) || 0; }
      if (av < bv) return sortDir === 'asc' ? -1 : 1;
      if (av > bv) return sortDir === 'asc' ? 1 : -1;
      return 0;
    });
  }, [consultation, range, statusFilter, search, sortBy, sortDir]);

  const filteredPayments = useMemo(() => {
    if (!consultation) return [];
    let r = consultation.paymentHistory;
    if (range.start || range.end) {
      r = r.filter((p) => {
        const d = (p.date || '').slice(0, 10);
        if (range.start && d < range.start) return false;
        if (range.end && d > range.end) return false;
        return true;
      });
    }
    return r;
  }, [consultation, range]);

  const totalRecebidoPeriod = useMemo(
    () => filteredPayments.reduce((s, p) => s + (p.amount || 0), 0),
    [filteredPayments]
  );

  const toggleSort = (col) => {
    if (sortBy === col) setSortDir((d) => (d === 'asc' ? 'desc' : 'asc'));
    else { setSortBy(col); setSortDir('asc'); }
  };

  const handlePdf = async () => {
    if (!consultation) return;
    setBusy(true);
    try {
      await printCustomerConsultation({ customer, consultation, periodLabel, user });
      toast({ title: 'PDF gerado com sucesso' });
    } catch (e) {
      toast({ title: 'Erro ao gerar PDF', description: String(e.message || e), variant: 'destructive' });
    } finally { setBusy(false); }
  };

  const handleShare = async () => {
    if (!consultation) return;
    setBusy(true);
    try {
      const { shared } = await shareCustomerConsultation({ customer, consultation, periodLabel, user });
      toast({ title: shared ? 'Compartilhando PDF' : 'PDF baixado', description: shared ? 'Escolha o aplicativo para enviar.' : 'Compartilhamento não suportado — PDF baixado.' });
    } catch (e) {
      if (e?.name !== 'AbortError') toast({ title: 'Erro ao compartilhar', description: String(e.message || e), variant: 'destructive' });
    } finally { setBusy(false); }
  };

  const handlePreview = async () => {
    if (!consultation) return;
    setBusy(true);
    try {
      await previewCustomerConsultation({ customer, consultation, periodLabel, user });
    } catch (e) {
      toast({ title: 'Erro ao pré-visualizar', description: String(e.message || e), variant: 'destructive' });
    } finally { setBusy(false); }
  };

  const handlePrint = async () => {
    if (!consultation) return;
    setBusy(true);
    try {
      await printCustomerConsultationReport({ customer, consultation, periodLabel, user });
      toast({ title: 'Enviado para impressão' });
    } catch (e) {
      toast({ title: 'Erro ao imprimir', description: String(e.message || e), variant: 'destructive' });
    } finally { setBusy(false); }
  };

  const handleSelectCustomer = (id) => {
    setCustomerId(id);
    setSearch('');
    setPeriod('all');
    setStatusFilter('all');
  };

  const SortHeader = ({ col, label, className: cls }) => (
    <th className={`py-1.5 px-2 cursor-pointer select-none ${cls || ''}`} onClick={() => toggleSort(col)}>
      <span className="inline-flex items-center gap-1">
        {label}
        {sortBy === col && (sortDir === 'asc' ? <ChevronUp className="h-3 w-3" /> : <ChevronDown className="h-3 w-3" />)}
      </span>
    </th>
  );

  return (
    <Dialog open={open} onOpenChange={(o) => !o && onClose()}>
      <DialogContent className="max-w-5xl max-h-[92vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Search className="h-5 w-5" /> Consulta Consolidada de Contas
          </DialogTitle>
        </DialogHeader>

        {/* Selecionar cliente */}
        <div className="flex flex-wrap items-end gap-3">
          <div className="flex-1 min-w-[260px]">
            <label className="text-xs text-muted-foreground mb-1 block">Selecionar cliente</label>
            <Select value={customerId} onValueChange={handleSelectCustomer}>
              <SelectTrigger><SelectValue placeholder="Escolha um cliente cadastrado..." /></SelectTrigger>
              <SelectContent>
                {(customers || []).map((c) => (
                  <SelectItem key={c.id} value={c.id}>{c.name}{c.cpf_cnpj ? ` — ${c.cpf_cnpj}` : ''}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </div>

        {!customer ? (
          <div className="text-center py-12 text-muted-foreground">
            <Search className="h-10 w-10 mx-auto mb-2 opacity-30" />
            <p>Selecione um cliente para consultar todas as suas contas.</p>
          </div>
        ) : isLoading ? (
          <div className="text-center py-12">
            <div className="w-8 h-8 border-4 border-slate-200 border-t-slate-800 rounded-full animate-spin mx-auto" />
            <p className="text-sm text-muted-foreground mt-2">Buscando contas...</p>
          </div>
        ) : !consultation || consultation.allAccounts.length === 0 ? (
          <div className="text-center py-12 text-muted-foreground">
            <Wallet className="h-10 w-10 mx-auto mb-2 opacity-30" />
            <p>Nenhuma conta encontrada para este cliente.</p>
          </div>
        ) : (
          <div className="space-y-4">
            {/* Dados do cliente */}
            <Card className="p-3">
              <div className="grid grid-cols-2 md:grid-cols-4 gap-2 text-sm">
                <div><div className="text-[11px] text-muted-foreground">Nome/Razão Social</div><div className="font-medium">{customer.name}</div></div>
                <div><div className="text-[11px] text-muted-foreground">CPF/CNPJ</div><div className="font-medium">{customer.cpf_cnpj || '—'}</div></div>
                <div><div className="text-[11px] text-muted-foreground">Telefone</div><div className="font-medium">{customer.phone || '—'}</div></div>
                <div><div className="text-[11px] text-muted-foreground">Código</div><div className="font-medium font-mono">{(customer.id || '').substring(0, 8).toUpperCase()}</div></div>
                <div className="col-span-2 md:col-span-4"><div className="text-[11px] text-muted-foreground">Endereço</div><div className="font-medium">{[customer.address, customer.city, customer.state].filter(Boolean).join(', ') || '—'}</div></div>
              </div>
            </Card>

            {/* Resumo financeiro */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
              <Metric icon={Receipt} label="Total de contas" value={formatBRL(consultation.summary.totalContas)} tone="slate" />
              <Metric icon={TrendingUp} label="Total pago" value={formatBRL(consultation.summary.totalPago)} tone="emerald" />
              <Metric icon={Wallet} label="Total em aberto" value={formatBRL(consultation.summary.totalAberto)} tone="blue" />
              <Metric icon={AlertTriangle} label="Total vencido" value={formatBRL(consultation.summary.totalVencer)} tone="red" />
              <Metric icon={Calendar} label="Total a vencer" value={formatBRL(consultation.summary.totalVencer)} tone="amber" />
              <Metric icon={AlertTriangle} label="Juros/multas" value={formatBRL(consultation.summary.totalJurosMultas)} tone="amber" />
              <Metric icon={CreditCard} label="Descontos" value={formatBRL(consultation.summary.totalDescontos)} tone="violet" />
              <Metric icon={Wallet} label="Saldo devedor" value={formatBRL(consultation.summary.saldoDevedor)} tone="red" />
            </div>

            {/* Resumo da situação financeira */}
            <Card className="p-3 border-amber-200 bg-amber-50/50">
              <h3 className="text-sm font-semibold mb-2 flex items-center gap-1"><AlertTriangle className="h-4 w-4 text-amber-600" /> Resumo da Situação Financeira</h3>
              <div className="grid grid-cols-2 md:grid-cols-3 gap-2 text-sm">
                <div><div className="text-[11px] text-muted-foreground">Saldo devedor</div><div className="font-semibold text-red-600">{formatBRL(consultation.summary.saldoDevedor)}</div></div>
                <div><div className="text-[11px] text-muted-foreground">Vencido</div><div className="font-semibold text-red-600">{formatBRL(consultation.summary.totalVencido)}</div></div>
                <div><div className="text-[11px] text-muted-foreground">A vencer</div><div className="font-semibold text-amber-600">{formatBRL(consultation.summary.totalVencer)}</div></div>
                <div><div className="text-[11px] text-muted-foreground">Maior atraso</div><div className="font-semibold">{consultation.summary.maxLateDays} dia(s)</div></div>
                <div><div className="text-[11px] text-muted-foreground">Último pagamento</div><div className="font-semibold">{formatBRL(consultation.summary.lastPaymentAmount)}</div></div>
                <div><div className="text-[11px] text-muted-foreground">Data último pagamento</div><div className="font-semibold">{consultation.summary.lastPaymentDate ? formatDate(consultation.summary.lastPaymentDate) : '—'}</div></div>
              </div>
            </Card>

            {/* Filtros */}
            <Card className="p-3">
              <div className="flex flex-wrap items-end gap-2 mb-3">
                <div className="flex-1 min-w-[180px]">
                  <label className="text-xs text-muted-foreground mb-1 block">Período</label>
                  <Select value={period} onValueChange={setPeriod}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>
                      {PERIOD_OPTIONS.map((o) => <SelectItem key={o.value} value={o.value}>{o.label}</SelectItem>)}
                    </SelectContent>
                  </Select>
                </div>
                {period === 'custom' && (
                  <>
                    <div>
                      <label className="text-xs text-muted-foreground mb-1 block">De</label>
                      <Input type="date" value={customStart} onChange={(e) => setCustomStart(e.target.value)} className="w-36" />
                    </div>
                    <div>
                      <label className="text-xs text-muted-foreground mb-1 block">Até</label>
                      <Input type="date" value={customEnd} onChange={(e) => setCustomEnd(e.target.value)} className="w-36" />
                    </div>
                  </>
                )}
                <div className="min-w-[140px]">
                  <label className="text-xs text-muted-foreground mb-1 block">Status</label>
                  <Select value={statusFilter} onValueChange={setStatusFilter}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>
                      {STATUS_OPTIONS.map((o) => <SelectItem key={o.value} value={o.value}>{o.label}</SelectItem>)}
                    </SelectContent>
                  </Select>
                </div>
                <div className="flex-1 min-w-[160px]">
                  <label className="text-xs text-muted-foreground mb-1 block">Buscar</label>
                  <div className="relative">
                    <Search className="h-4 w-4 absolute left-2 top-1/2 -translate-y-1/2 text-muted-foreground" />
                    <Input className="pl-8" placeholder="Conta ou pedido..." value={search} onChange={(e) => setSearch(e.target.value)} />
                  </div>
                </div>
              </div>

              {/* Tabela de contas */}
              <div className="overflow-x-auto">
                <table className="w-full text-xs">
                  <thead>
                    <tr className="text-left text-muted-foreground border-b">
                      <SortHeader col="account_number" label="Conta" />
                      <SortHeader col="order_code" label="Pedido" />
                      <SortHeader col="issue_date" label="Emissão" />
                      <SortHeader col="due_date" label="Vencimento" />
                      <SortHeader col="current_amount" label="Valor" className="text-right" />
                      <SortHeader col="paid_amount" label="Pago" className="text-right" />
                      <SortHeader col="balance" label="Saldo" className="text-right" />
                      <th className="py-1.5 px-2">Status</th>
                      <th className="py-1.5 px-2 text-center">Ação</th>
                    </tr>
                  </thead>
                  <tbody>
                    {filteredAccounts.length === 0 ? (
                      <tr><td colSpan={9} className="text-center py-6 text-muted-foreground">Nenhuma conta no filtro selecionado.</td></tr>
                    ) : filteredAccounts.map((a) => (
                      <tr key={a.id} className="border-b hover:bg-slate-50 cursor-pointer" onClick={() => setDetailAccount(a)}>
                        <td className="py-1.5 px-2 font-mono">{a.account_number}</td>
                        <td className="py-1.5 px-2">{a.order_code || '—'}</td>
                        <td className="py-1.5 px-2">{formatDate(a.issue_date)}</td>
                        <td className="py-1.5 px-2">{formatDate(a.due_date)}</td>
                        <td className="py-1.5 px-2 text-right">{formatBRL(a.current_amount)}</td>
                        <td className="py-1.5 px-2 text-right text-emerald-600">{formatBRL(a.paid_amount)}</td>
                        <td className="py-1.5 px-2 text-right font-semibold text-red-600">{formatBRL(a.balance)}</td>
                        <td className="py-1.5 px-2">
                          <span className={`inline-flex px-1.5 py-0.5 rounded text-[10px] ${STATUS_TONES[a.status] || ''}`}>{STATUS_LABELS[a.status] || a.status}</span>
                        </td>
                        <td className="py-1.5 px-2 text-center" onClick={(e) => e.stopPropagation()}>
                          <Button size="sm" variant="ghost" className="h-6 px-2" onClick={() => setDetailAccount(a)}>
                            <Eye className="h-3.5 w-3.5" />
                          </Button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </Card>

            {/* Histórico de pagamentos */}
            <Card className="p-3">
              <div className="flex items-center justify-between mb-2">
                <h3 className="text-sm font-semibold flex items-center gap-1"><Clock className="h-4 w-4" /> Histórico de Pagamentos</h3>
                <div className="text-sm font-semibold text-emerald-600">
                  Total recebido no período: {formatBRL(totalRecebidoPeriod)}
                </div>
              </div>
              {filteredPayments.length === 0 ? (
                <p className="text-sm text-muted-foreground py-4 text-center">Nenhum pagamento no período selecionado.</p>
              ) : (
                <div className="overflow-x-auto max-h-[240px] overflow-y-auto">
                  <table className="w-full text-xs">
                    <thead className="sticky top-0 bg-white">
                      <tr className="text-left text-muted-foreground border-b">
                        <th className="py-1.5 px-2">Data</th>
                        <th className="py-1.5 px-2">Conta</th>
                        <th className="py-1.5 px-2">Pedido</th>
                        <th className="py-1.5 px-2 text-right">Valor pago</th>
                        <th className="py-1.5 px-2">Forma</th>
                        <th className="py-1.5 px-2">Responsável</th>
                      </tr>
                    </thead>
                    <tbody>
                      {filteredPayments.map((p, idx) => (
                        <tr key={idx} className="border-b">
                          <td className="py-1.5 px-2">{formatDate(p.date)}</td>
                          <td className="py-1.5 px-2 font-mono">{p.account_number}</td>
                          <td className="py-1.5 px-2">{p.order_code || '—'}</td>
                          <td className="py-1.5 px-2 text-right font-medium text-emerald-600">{formatBRL(p.amount)}</td>
                          <td className="py-1.5 px-2">{p.method || '—'}</td>
                          <td className="py-1.5 px-2">{p.responsible || '—'}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </Card>

            {/* Botões de ação */}
            <div className="flex flex-wrap gap-2 justify-end">
              <Button variant="outline" size="sm" onClick={handlePreview} disabled={busy}>
                <Eye className="h-4 w-4 mr-1" /> Visualizar
              </Button>
              <Button variant="outline" size="sm" onClick={handlePrint} disabled={busy}>
                <Printer className="h-4 w-4 mr-1" /> Imprimir Resumo
              </Button>
              <Button size="sm" onClick={handlePdf} disabled={busy}>
                <FileText className="h-4 w-4 mr-1" /> Gerar PDF do Resumo
              </Button>
              <Button variant="outline" size="sm" onClick={handleShare} disabled={busy}>
                <Share2 className="h-4 w-4 mr-1" /> Compartilhar
              </Button>
            </div>
          </div>
        )}
      </DialogContent>

      {detailAccount && (
        <CustomerAccountDetailDialog
          open={!!detailAccount}
          account={detailAccount}
          onClose={() => setDetailAccount(null)}
          onRefresh={() => qc.invalidateQueries({ queryKey: ['customerAccounts', customerId] })}
          user={user}
        />
      )}
    </Dialog>
  );
}