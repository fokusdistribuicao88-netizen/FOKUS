import React, { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { formatBRL, formatDate, formatDateTime } from '@/lib/format';
import { recomputeAccountTotals } from '@/lib/customerAccountCalc';
import { registerCollection, updatePenaltyConfig } from '@/lib/customerAccountService';
import { printInstallmentPlan, shareInstallmentPlan } from '@/lib/customerAccountPdf';
import { canEditPenalty, canManageCollection } from '@/lib/userRoles';
import { useToast } from '@/components/ui/use-toast';
import { HandCoins, Phone, Settings2, History, ListOrdered, Printer, Share2 } from 'lucide-react';

const INST_STATUS = {
  open: 'bg-blue-100 text-blue-700',
  due: 'bg-amber-100 text-amber-700',
  overdue: 'bg-red-100 text-red-700',
  partial: 'bg-amber-100 text-amber-700',
  paid: 'bg-emerald-100 text-emerald-700',
  cancelled: 'bg-slate-200 text-slate-500 line-through',
};
const INST_LABEL = { open: 'A vencer', due: 'Vence hoje', overdue: 'Vencida', partial: 'Parcial', paid: 'Paga', cancelled: 'Cancelada' };

export default function CustomerAccountDetailDialog({ open, account, onClose, onPay, onRefresh, user }) {
  const { toast } = useToast();
  const [tab, setTab] = useState('installments');
  const [collection, setCollection] = useState({ contact_type: '', notes: '', promise_date: '', result: '' });
  const [penalty, setPenalty] = useState(null);

  if (!account) return null;
  const rec = recomputeAccountTotals(account);
  const role = user?.role;
  const canPenalty = canEditPenalty(role);
  const canCollect = canManageCollection(role);

  const handlePrintPlan = async () => {
    try { await printInstallmentPlan(account, user); toast({ title: 'Parcelamento enviado para impressão' }); }
    catch (e) { toast({ title: 'Erro ao gerar PDF', description: String(e.message || e), variant: 'destructive' }); }
  };

  const handleSharePlan = async () => {
    try {
      const { shared } = await shareInstallmentPlan(account, user);
      toast({ title: shared ? 'Compartilhando PDF' : 'PDF baixado', description: shared ? 'Escolha o aplicativo para enviar.' : 'Compartilhamento não suportado — PDF baixado.' });
    } catch (e) {
      if (e?.name !== 'AbortError') toast({ title: 'Erro ao compartilhar', description: String(e.message || e), variant: 'destructive' });
    }
  };

  const saveCollection = async () => {
    try {
      await registerCollection({ account, ...collection, user });
      toast({ title: 'Cobrança registrada' });
      setCollection({ contact_type: '', notes: '', promise_date: '', result: '' });
      onRefresh?.();
    } catch (e) {
      toast({ title: 'Erro', description: String(e.message || e), variant: 'destructive' });
    }
  };

  const savePenalty = async () => {
    try {
      await updatePenaltyConfig({ account, penaltyConfig: penalty, user, reason: 'Ajuste manual' });
      toast({ title: 'Regras de juros atualizadas' });
      onRefresh?.();
    } catch (e) {
      toast({ title: 'Erro', description: String(e.message || e), variant: 'destructive' });
    }
  };

  return (
    <Dialog open={open} onOpenChange={(o) => !o && onClose()}>
      <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <span className="font-mono">{account.account_number}</span>
            <span className="text-sm font-normal text-muted-foreground">— {account.customer_name}</span>
          </DialogTitle>
        </DialogHeader>

        <div className="grid grid-cols-2 md:grid-cols-4 gap-2 text-sm">
          <div className="bg-slate-50 rounded p-2"><div className="text-[11px] text-muted-foreground">Valor atual</div><div className="font-semibold">{formatBRL(rec.current_amount)}</div></div>
          <div className="bg-slate-50 rounded p-2"><div className="text-[11px] text-muted-foreground">Pago</div><div className="font-semibold text-emerald-600">{formatBRL(rec.paid_amount)}</div></div>
          <div className="bg-slate-50 rounded p-2"><div className="text-[11px] text-muted-foreground">Saldo</div><div className="font-semibold text-red-600">{formatBRL(rec.balance)}</div></div>
          <div className="bg-slate-50 rounded p-2"><div className="text-[11px] text-muted-foreground">Parcelas</div><div className="font-semibold">{rec.installments.length}x</div></div>
        </div>

        <Tabs value={tab} onValueChange={setTab}>
          <TabsList className={`w-full ${canCollect && canPenalty ? 'grid-cols-4' : canCollect || canPenalty ? 'grid-cols-3' : 'grid-cols-2'}`}>
            <TabsTrigger value="installments"><ListOrdered className="h-4 w-4 mr-1" />Parcelas</TabsTrigger>
            <TabsTrigger value="payments"><History className="h-4 w-4 mr-1" />Pagamentos</TabsTrigger>
            {canCollect && <TabsTrigger value="collection"><Phone className="h-4 w-4 mr-1" />Cobrança</TabsTrigger>}
            {canPenalty && <TabsTrigger value="rules"><Settings2 className="h-4 w-4 mr-1" />Regras</TabsTrigger>}
          </TabsList>

          <TabsContent value="installments" className="space-y-2">
            <div className="overflow-x-auto">
              <table className="w-full text-xs">
                <thead>
                  <tr className="text-left text-muted-foreground border-b">
                    <th className="py-1.5 px-1">#</th>
                    <th className="py-1.5 px-1">Vencimento</th>
                    <th className="py-1.5 px-1 text-right">Original</th>
                    <th className="py-1.5 px-1 text-right">Juros</th>
                    <th className="py-1.5 px-1 text-right">Atual</th>
                    <th className="py-1.5 px-1 text-right">Pago</th>
                    <th className="py-1.5 px-1 text-right">Saldo</th>
                    <th className="py-1.5 px-1">Status</th>
                    <th className="py-1.5 px-1 text-right">Ação</th>
                  </tr>
                </thead>
                <tbody>
                  {rec.installments.map((i) => (
                    <tr key={i.number} className="border-b">
                      <td className="py-1.5 px-1 font-medium">{i.number}</td>
                      <td className="py-1.5 px-1">{formatDate(i.due_date)}</td>
                      <td className="py-1.5 px-1 text-right">{formatBRL(i.original_amount)}</td>
                      <td className="py-1.5 px-1 text-right text-amber-600">{i.interest > 0 ? formatBRL(i.interest) : '-'}</td>
                      <td className="py-1.5 px-1 text-right">{formatBRL(i.current_amount)}</td>
                      <td className="py-1.5 px-1 text-right text-emerald-600">{formatBRL(i.paid_amount)}</td>
                      <td className="py-1.5 px-1 text-right font-semibold">{formatBRL(i.balance)}</td>
                      <td className="py-1.5 px-1">
                        <span className={`inline-flex px-1.5 py-0.5 rounded text-[10px] ${INST_STATUS[i.status] || ''}`}>{INST_LABEL[i.status] || i.status}</span>
                      </td>
                      <td className="py-1.5 px-1 text-right">
                        {i.balance > 0.01 && i.status !== 'cancelled' && (
                          <Button size="sm" variant="ghost" className="h-6 px-2 text-xs" onClick={() => onPay?.(account, i)}>
                            <HandCoins className="h-3 w-3 mr-1" />Receber
                          </Button>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            <div className="flex gap-2">
              {account.balance > 0.01 && (
                <Button onClick={() => onPay?.(account, null)} className="flex-1">
                  Receber conta inteira
                </Button>
              )}
              <Button variant="outline" onClick={handlePrintPlan}>
                <Printer className="h-4 w-4 mr-1" /> Parcelamento
              </Button>
              <Button variant="outline" onClick={handleSharePlan}>
                <Share2 className="h-4 w-4 mr-1" /> Compartilhar
              </Button>
            </div>
          </TabsContent>

          <TabsContent value="payments" className="space-y-2">
            {(account.payment_history || []).length === 0 ? (
              <p className="text-sm text-muted-foreground py-4 text-center">Nenhum pagamento registrado.</p>
            ) : (
              [...(account.payment_history || [])].reverse().map((h, idx) => (
                <div key={idx} className="flex items-center justify-between border rounded p-2 text-sm">
                  <div>
                    <div className="font-medium">{formatBRL(h.amount)} {h.method && `· ${h.method}`}</div>
                    <div className="text-[11px] text-muted-foreground">{formatDateTime(h.date)} · {h.responsible || ''} {h.installment_number ? `· parc. ${h.installment_number}` : ''}</div>
                    {h.notes && <div className="text-[11px] text-muted-foreground mt-0.5">{h.notes}</div>}
                  </div>
                  <div className="text-xs text-muted-foreground">Saldo: {formatBRL(h.balance_after)}</div>
                </div>
              ))
            )}
          </TabsContent>

          <TabsContent value="collection" className="space-y-3">
            <div className="grid grid-cols-2 gap-2">
              <div>
                <Label>Tipo de contato</Label>
                <Input value={collection.contact_type} onChange={(e) => setCollection((c) => ({ ...c, contact_type: e.target.value }))} placeholder="Telefone, WhatsApp, E-mail..." />
              </div>
              <div>
                <Label>Promessa de pagamento</Label>
                <Input type="date" value={collection.promise_date} onChange={(e) => setCollection((c) => ({ ...c, promise_date: e.target.value }))} />
              </div>
              <div>
                <Label>Resultado</Label>
                <Input value={collection.result} onChange={(e) => setCollection((c) => ({ ...c, result: e.target.value }))} placeholder="Cobrança efetiva, sem resposta..." />
              </div>
              <div className="col-span-2">
                <Label>Observação</Label>
                <Input value={collection.notes} onChange={(e) => setCollection((c) => ({ ...c, notes: e.target.value }))} />
              </div>
            </div>
            <Button onClick={saveCollection} size="sm">Registrar cobrança</Button>

            <div className="border-t pt-2">
              <h4 className="text-sm font-semibold mb-2">Histórico de cobrança</h4>
              {(account.collection_history || []).length === 0 ? (
                <p className="text-xs text-muted-foreground">Nenhum contato registrado.</p>
              ) : (
                [...(account.collection_history || [])].reverse().map((c, idx) => (
                  <div key={idx} className="border rounded p-2 text-xs mb-1">
                    <div className="flex justify-between">
                      <span className="font-medium">{c.contact_type || 'Contato'}</span>
                      <span className="text-muted-foreground">{formatDateTime(c.date)}</span>
                    </div>
                    <div className="text-muted-foreground mt-0.5">{c.responsible} — {c.result || ''}</div>
                    {c.notes && <div className="mt-0.5">{c.notes}</div>}
                    {c.promise_date && <div className="mt-0.5 text-amber-600">Promessa: {formatDate(c.promise_date)}</div>}
                  </div>
                ))
              )}
            </div>
          </TabsContent>

          <TabsContent value="rules" className="space-y-3">
            <PenaltyEditor account={account} penalty={penalty} setPenalty={setPenalty} onSave={savePenalty} />
          </TabsContent>
        </Tabs>
      </DialogContent>
    </Dialog>
  );
}

function PenaltyEditor({ account, penalty, setPenalty, onSave }) {
  const pc = penalty || account.penalty_config || {};
  const upd = (k, v) => setPenalty({ ...pc, [k]: v });
  return (
    <div className="space-y-3">
      <p className="text-xs text-muted-foreground">As regras são aplicadas automaticamente no cálculo de juros/multa das parcelas vencidas.</p>
      <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
        <div>
          <Label>Multa fixa (R$)</Label>
          <Input type="number" step="0.01" value={pc.fixed_penalty || 0} onChange={(e) => upd('fixed_penalty', Number(e.target.value))} />
        </div>
        <div>
          <Label>Multa (%)</Label>
          <Input type="number" step="0.01" value={pc.penalty_percent || 0} onChange={(e) => upd('penalty_percent', Number(e.target.value))} />
        </div>
        <div>
          <Label>Juros/dia (%)</Label>
          <Input type="number" step="0.001" value={pc.daily_interest || 0} onChange={(e) => upd('daily_interest', Number(e.target.value))} />
        </div>
        <div>
          <Label>Juros mensal (%)</Label>
          <Input type="number" step="0.01" value={pc.monthly_interest || 0} onChange={(e) => upd('monthly_interest', Number(e.target.value))} />
        </div>
        <div>
          <Label>Tolerância (dias)</Label>
          <Input type="number" value={pc.tolerance_days || 0} onChange={(e) => upd('tolerance_days', Number(e.target.value))} />
        </div>
        <div>
          <Label>Desc. antecipado (%)</Label>
          <Input type="number" step="0.01" value={pc.early_payment_discount || 0} onChange={(e) => upd('early_payment_discount', Number(e.target.value))} />
        </div>
      </div>
      <Button onClick={onSave} size="sm">Salvar regras e recalcular</Button>
    </div>
  );
}