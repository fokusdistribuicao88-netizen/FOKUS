import React, { useState, useMemo } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { formatBRL } from '@/lib/format';
import { negotiateDebts } from '@/lib/customerAccountService';
import { useToast } from '@/components/ui/use-toast';
import { Handshake } from 'lucide-react';

export default function NegotiateDebtDialog({ open, accounts, onClose, onDone, user }) {
  const { toast } = useToast();
  const [form, setForm] = useState({
    installment_count: 6, first_due_date: new Date().toISOString().slice(0, 10),
    interval_days: 30, discount: 0, interest_rate: 0, notes: '',
  });
  const [saving, setSaving] = useState(false);

  const selected = useMemo(() => accounts || [], [accounts]);
  const consolidated = useMemo(
    () => selected.reduce((s, a) => s + (a.balance || 0), 0),
    [selected]
  );
  const finalAmount = useMemo(() => {
    const v = consolidated - (Number(form.discount) || 0) + consolidated * ((Number(form.interest_rate) || 0) / 100);
    return Math.max(0, v);
  }, [consolidated, form.discount, form.interest_rate]);
  const perParcel = form.installment_count > 0 ? finalAmount / Number(form.installment_count) : 0;

  const submit = async () => {
    if (!selected.length) return;
    setSaving(true);
    try {
      const created = await negotiateDebts({
        accountIds: selected.map((a) => a.id),
        newInstallmentCount: Number(form.installment_count),
        firstDueDate: form.first_due_date,
        intervalDays: Number(form.interval_days),
        discount: Number(form.discount),
        interestRate: Number(form.interest_rate),
        notes: form.notes,
        user,
      });
      toast({ title: 'Negociação criada', description: `Nova conta ${created.account_number} com ${form.installment_count}x` });
      onDone?.(created);
      onClose();
    } catch (e) {
      toast({ title: 'Erro na negociação', description: String(e.message || e), variant: 'destructive' });
    } finally {
      setSaving(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={(o) => !o && onClose()}>
      <DialogContent className="max-w-lg">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2"><Handshake className="h-5 w-5" /> Negociar Dívidas</DialogTitle>
        </DialogHeader>
        <div className="space-y-3">
          <div className="bg-amber-50 border border-amber-200 rounded p-3 text-sm">
            <div className="font-medium">{selected.length} conta(s) selecionada(s)</div>
            <div className="text-muted-foreground">Dívida consolidada: <span className="font-semibold">{formatBRL(consolidated)}</span></div>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <Label>Parcelas</Label>
              <Input type="number" min="1" value={form.installment_count} onChange={(e) => setForm((f) => ({ ...f, installment_count: e.target.value }))} />
            </div>
            <div>
              <Label>1º vencimento</Label>
              <Input type="date" value={form.first_due_date} onChange={(e) => setForm((f) => ({ ...f, first_due_date: e.target.value }))} />
            </div>
            <div>
              <Label>Intervalo (dias)</Label>
              <Input type="number" value={form.interval_days} onChange={(e) => setForm((f) => ({ ...f, interval_days: e.target.value }))} />
            </div>
            <div>
              <Label>Desconto (R$)</Label>
              <Input type="number" step="0.01" value={form.discount} onChange={(e) => setForm((f) => ({ ...f, discount: e.target.value }))} />
            </div>
            <div>
              <Label>Juros (%)</Label>
              <Input type="number" step="0.01" value={form.interest_rate} onChange={(e) => setForm((f) => ({ ...f, interest_rate: e.target.value }))} />
            </div>
            <div>
              <Label>Valor por parcela</Label>
              <Input disabled value={formatBRL(perParcel)} />
            </div>
          </div>
          <div>
            <Label>Observações</Label>
            <Input value={form.notes} onChange={(e) => setForm((f) => ({ ...f, notes: e.target.value }))} placeholder="Motivo/condições do acordo" />
          </div>
          <div className="bg-blue-50 rounded p-2 text-sm flex justify-between">
            <span>Novo valor total</span>
            <span className="font-bold">{formatBRL(finalAmount)}</span>
          </div>
          <p className="text-xs text-muted-foreground">As contas originais serão marcadas como "Renegociada" (histórico preservado).</p>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={onClose}>Cancelar</Button>
          <Button onClick={submit} disabled={saving || !selected.length}>{saving ? 'Negociando...' : 'Confirmar Negociação'}</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}