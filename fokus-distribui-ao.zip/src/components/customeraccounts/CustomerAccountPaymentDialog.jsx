import React, { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { formatBRL } from '@/lib/format';
import { recomputeAccountTotals } from '@/lib/customerAccountCalc';

const METHODS = ['Dinheiro', 'PIX', 'Cartão de Crédito', 'Cartão de Débito', 'Transferência', 'Boleto'];

export default function CustomerAccountPaymentDialog({ open, account, installment, onClose, onConfirm, user }) {
  const [amount, setAmount] = useState('');
  const [method, setMethod] = useState('Dinheiro');
  const [notes, setNotes] = useState('');
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (open) {
      const target = installment || (account?.installments || []).find((i) => i.balance > 0.01);
      setAmount(target ? String(target.balance.toFixed(2)) : '');
      setMethod('Dinheiro');
      setNotes('');
    }
  }, [open, installment, account]);

  if (!account) return null;

  const recomputed = recomputeAccountTotals(account);
  const target = installment || recomputed.installments.find((i) => i.balance > 0.01);
  const pay = Number(amount) || 0;
  const newBalance = target ? Math.max(0, (target.balance || 0) - pay) : Math.max(0, (account.balance || 0) - pay);
  const willBePartial = pay > 0 && pay < (target?.balance || account.balance) - 0.01;
  const willBePaid = pay >= (target?.balance || account.balance) - 0.01;

  const submit = async () => {
    if (pay <= 0) return;
    setSaving(true);
    try {
      await onConfirm({
        installmentNumber: installment?.number ?? null,
        amount: pay,
        method,
        notes,
      });
      onClose();
    } finally {
      setSaving(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={(o) => !o && onClose()}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle>Registrar Pagamento</DialogTitle>
        </DialogHeader>
        <div className="space-y-3">
          <div className="bg-slate-50 rounded-lg p-3 text-sm">
            <div className="flex justify-between"><span className="text-muted-foreground">Conta</span><span className="font-mono">{account.account_number}</span></div>
            <div className="flex justify-between"><span className="text-muted-foreground">Cliente</span><span className="font-medium">{account.customer_name}</span></div>
            {target && (
              <div className="flex justify-between mt-1 pt-1 border-t"><span className="text-muted-foreground">Parcela {target.number}</span><span>{formatBRL(target.balance)}</span></div>
            )}
            <div className="flex justify-between"><span className="text-muted-foreground">Saldo total</span><span className="font-semibold">{formatBRL(account.balance)}</span></div>
          </div>
          <div>
            <Label>Valor recebido (R$) *</Label>
            <Input type="number" step="0.01" value={amount} onChange={(e) => setAmount(e.target.value)} autoFocus />
          </div>
          <div>
            <Label>Forma de pagamento</Label>
            <Select value={method} onValueChange={setMethod}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                {METHODS.map((m) => <SelectItem key={m} value={m}>{m}</SelectItem>)}
              </SelectContent>
            </Select>
          </div>
          <div>
            <Label>Observação</Label>
            <Input value={notes} onChange={(e) => setNotes(e.target.value)} />
          </div>
          <div className="bg-blue-50 rounded-lg p-2 text-xs">
            <div className="flex justify-between"><span>Novo saldo</span><span className="font-semibold">{formatBRL(newBalance)}</span></div>
            <div className="flex justify-between mt-1">
              <span>Status</span>
              <span className="font-medium">{willBePaid ? 'Quitada' : willBePartial ? 'Parcialmente paga' : '—'}</span>
            </div>
          </div>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={onClose}>Cancelar</Button>
          <Button onClick={submit} disabled={saving || pay <= 0}>
            {saving ? 'Registrando...' : 'Confirmar Pagamento'}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}