import React from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { formatBRL } from '@/lib/format';
import { ShieldAlert } from 'lucide-react';

/**
 * Diálogo de bloqueio de limite de crédito.
 * Usuários autorizados (admin/gerente) podem liberar a operação.
 */
export default function CreditLimitDialog({ open, info, canOverride, onOverride, onClose }) {
  if (!info) return null;
  return (
    <Dialog open={open} onOpenChange={(o) => !o && onClose()}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 text-red-600">
            <ShieldAlert className="h-5 w-5" /> Limite de Crédito Excedido
          </DialogTitle>
        </DialogHeader>
        <div className="space-y-2 text-sm">
          <div className="bg-red-50 border border-red-200 rounded-lg p-3">
            <p>Cliente ultrapassa o limite de crédito disponível.</p>
          </div>
          <div className="grid grid-cols-2 gap-2">
            <Row label="Limite" value={formatBRL(info.limit)} />
            <Row label="Utilizado" value={formatBRL(info.used)} />
            <Row label="Disponível" value={formatBRL(info.available)} />
            <Row label="Após esta venda" value={formatBRL(info.projected)} tone="red" />
            <Row label="Excedido em" value={formatBRL(info.exceededAmount)} tone="red" />
          </div>
          {canOverride ? (
            <p className="text-xs text-muted-foreground">Como administrador/gerente, você pode liberar esta operação mesmo acima do limite.</p>
          ) : (
            <p className="text-xs text-amber-600">Apenas administradores ou gerentes podem liberar vendas acima do limite.</p>
          )}
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={onClose}>Cancelar</Button>
          {canOverride && (
            <Button onClick={onOverride} className="bg-amber-600 hover:bg-amber-700">Liberar Operação</Button>
          )}
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

function Row({ label, value, tone }) {
  return (
    <div className="flex justify-between bg-slate-50 rounded px-2 py-1">
      <span className="text-xs text-muted-foreground">{label}</span>
      <span className={`text-sm font-semibold ${tone === 'red' ? 'text-red-600' : ''}`}>{value}</span>
    </div>
  );
}