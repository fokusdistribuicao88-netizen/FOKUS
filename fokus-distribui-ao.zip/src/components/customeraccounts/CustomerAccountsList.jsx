import React from 'react';
import { formatBRL, formatDate } from '@/lib/format';
import { Button } from '@/components/ui/button';
import { Eye, Ban, AlertTriangle } from 'lucide-react';

const STATUS_LABEL = {
  open: 'Em aberto',
  overdue: 'Vencida',
  partial: 'Parcial',
  paid: 'Quitada',
  cancelled: 'Cancelada',
  negotiated: 'Renegociada',
};
const STATUS_TONE = {
  open: 'bg-blue-100 text-blue-700',
  overdue: 'bg-red-100 text-red-700',
  partial: 'bg-amber-100 text-amber-700',
  paid: 'bg-emerald-100 text-emerald-700',
  cancelled: 'bg-slate-200 text-slate-600 line-through',
  negotiated: 'bg-purple-100 text-purple-700',
};

export default function CustomerAccountsList({ accounts, loading, onView, onCancel, onPay, selected, onToggleSelect, onToggleAll, allSelected }) {
  if (loading) {
    return <div className="py-12 text-center text-sm text-muted-foreground">Carregando contas...</div>;
  }
  if (!accounts.length) {
    return (
      <div className="py-16 text-center">
        <p className="text-sm text-muted-foreground">Nenhuma conta encontrada.</p>
        <p className="text-xs text-muted-foreground mt-1">Crie uma conta manualmente ou finalize um pedido em crediário.</p>
      </div>
    );
  }
  const selectable = !!onToggleSelect;
  return (
    <div className="overflow-x-auto">
      <table className="w-full text-sm">
        <thead>
          <tr className="text-left text-xs text-muted-foreground border-b">
            {selectable && (
              <th className="py-2 px-2 w-8">
                <input type="checkbox" checked={!!allSelected} onChange={onToggleAll} />
              </th>
            )}
            <th className="py-2 px-2">Conta</th>
            <th className="py-2 px-2">Cliente</th>
            <th className="py-2 px-2">Origem</th>
            <th className="py-2 px-2 text-right">Valor</th>
            <th className="py-2 px-2 text-right">Pago</th>
            <th className="py-2 px-2 text-right">Saldo</th>
            <th className="py-2 px-2">Vencimento</th>
            <th className="py-2 px-2">Status</th>
            <th className="py-2 px-2 text-right">Ações</th>
          </tr>
        </thead>
        <tbody>
          {accounts.map((a) => (
            <tr key={a.id} className={`border-b hover:bg-slate-50 ${selected?.has(a.id) ? 'bg-blue-50' : ''}`}>
              {selectable && (
                <td className="py-2 px-2">
                  <input
                    type="checkbox"
                    checked={!!selected?.has(a.id)}
                    onChange={() => onToggleSelect(a.id)}
                    disabled={a.status === 'cancelled' || a.status === 'paid' || a.status === 'negotiated'}
                  />
                </td>
              )}
              <td className="py-2 px-2 font-mono text-xs">{a.account_number}</td>
              <td className="py-2 px-2">
                <div className="font-medium truncate max-w-[160px]">{a.customer_name || '—'}</div>
                {a.order_code && <div className="text-[11px] text-muted-foreground">Pedido #{a.order_code}</div>}
              </td>
              <td className="py-2 px-2 text-xs capitalize">{a.origin || 'manual'}</td>
              <td className="py-2 px-2 text-right">{formatBRL(a.current_amount || a.original_amount)}</td>
              <td className="py-2 px-2 text-right text-emerald-600">{formatBRL(a.paid_amount)}</td>
              <td className="py-2 px-2 text-right font-semibold">{formatBRL(a.balance)}</td>
              <td className="py-2 px-2 text-xs">{formatDate(a.due_date)}</td>
              <td className="py-2 px-2">
                <span className={`inline-flex px-2 py-0.5 rounded-full text-[11px] font-medium ${STATUS_TONE[a.status] || ''}`}>
                  {a.status === 'overdue' && <AlertTriangle className="h-3 w-3 mr-1" />}
                  {STATUS_LABEL[a.status] || a.status}
                </span>
              </td>
              <td className="py-2 px-2">
                <div className="flex items-center justify-end gap-1">
                  {a.balance > 0.01 && a.status !== 'cancelled' && a.status !== 'negotiated' && (
                    <Button size="sm" variant="ghost" onClick={() => onPay?.(a)} className="h-7 px-2 text-xs">
                      Receber
                    </Button>
                  )}
                  <Button size="icon" variant="ghost" className="h-7 w-7" onClick={() => onView?.(a)}>
                    <Eye className="h-4 w-4" />
                  </Button>
                  {a.status !== 'cancelled' && a.status !== 'paid' && (
                    <Button size="icon" variant="ghost" className="h-7 w-7 text-red-600" onClick={() => onCancel?.(a)}>
                      <Ban className="h-4 w-4" />
                    </Button>
                  )}
                </div>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}