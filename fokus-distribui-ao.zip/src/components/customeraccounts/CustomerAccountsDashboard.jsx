import React from 'react';
import { formatBRL, formatDate } from '@/lib/format';
import { computeDashboardMetrics, computeAging } from '@/lib/customerAccountCalc';
import { Card } from '@/components/ui/card';
import { AlertTriangle, CalendarClock, Wallet, TrendingUp, Clock, Percent, FileWarning, CheckCircle2 } from 'lucide-react';

const STATUS_COLORS = {
  open: 'bg-blue-50 text-blue-700 border-blue-200',
  overdue: 'bg-red-50 text-red-700 border-red-200',
  partial: 'bg-amber-50 text-amber-700 border-amber-200',
  paid: 'bg-emerald-50 text-emerald-700 border-emerald-200',
};

function MetricCard({ icon: Icon, label, value, tone, sub }) {
  const tones = {
    blue: 'text-blue-600 bg-blue-50',
    red: 'text-red-600 bg-red-50',
    amber: 'text-amber-600 bg-amber-50',
    emerald: 'text-emerald-600 bg-emerald-50',
    slate: 'text-slate-600 bg-slate-100',
  };
  return (
    <Card className="p-4">
      <div className="flex items-start justify-between gap-2">
        <div className="min-w-0">
          <p className="text-xs text-muted-foreground truncate">{label}</p>
          <p className="text-lg font-bold mt-0.5 truncate">{value}</p>
          {sub && <p className="text-[11px] text-muted-foreground mt-0.5 truncate">{sub}</p>}
        </div>
        <div className={`p-2 rounded-lg shrink-0 ${tones[tone] || tones.slate}`}>
          <Icon className="h-4 w-4" />
        </div>
      </div>
    </Card>
  );
}

export default function CustomerAccountsDashboard({ accounts, onFilter }) {
  const m = computeDashboardMetrics(accounts);
  const aging = computeAging(accounts);
  const maxAging = Math.max(1, ...aging.map((b) => b.total));

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3">
        <MetricCard icon={Wallet} label="Total em aberto" value={formatBRL(m.totalOpen)} tone="blue" sub={`${m.openCount} conta(s)`} />
        <MetricCard icon={AlertTriangle} label="Total vencido" value={formatBRL(m.totalOverdue)} tone="red" sub={`${m.overdueCount} conta(s)`} />
        <MetricCard icon={CalendarClock} label="A vencer (7 dias)" value={formatBRL(m.totalDueSoon)} tone="amber" />
        <MetricCard icon={TrendingUp} label="Recebido no mês" value={formatBRL(m.receivedThisMonth)} tone="emerald" />
        <MetricCard icon={CheckCircle2} label="Parcialmente pago" value={formatBRL(m.totalPartial)} tone="amber" />
        <MetricCard icon={Clock} label="Média dias em atraso" value={`${m.avgLateDays} dia(s)`} tone="slate" />
      </div>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        <MetricCard icon={Wallet} label="Previsto a receber" value={formatBRL(m.expectedToReceive)} tone="blue" />
        <MetricCard icon={Percent} label="Inadimplência" value={`${m.inadimplencia}%`} tone="red" />
        <MetricCard icon={FileWarning} label="Contas vencidas" value={m.overdueCount} tone="red" />
        <MetricCard icon={TrendingUp} label="Total pago (período)" value={formatBRL(m.totalPaidPeriod)} tone="emerald" />
      </div>

      <Card className="p-4">
        <div className="flex items-center justify-between mb-3">
          <h3 className="text-sm font-semibold">Aging de recebíveis</h3>
          <button onClick={() => onFilter?.('overdue')} className="text-xs text-blue-600 hover:underline">
            Ver vencidas
          </button>
        </div>
        <div className="space-y-2">
          {aging.map((b) => (
            <div key={b.label} className="flex items-center gap-3">
              <span className="text-xs w-24 shrink-0 text-muted-foreground">{b.label}</span>
              <div className="flex-1 h-5 bg-slate-100 rounded overflow-hidden relative">
                <div
                  className={`h-full ${b.label === 'A vencer' ? 'bg-blue-400' : b.label === '+60 dias' ? 'bg-red-500' : 'bg-amber-400'}`}
                  style={{ width: `${(b.total / maxAging) * 100}%` }}
                />
              </div>
              <span className="text-xs font-medium w-28 text-right">{formatBRL(b.total)}</span>
              <span className="text-[11px] text-muted-foreground w-10 text-right">{b.count}x</span>
            </div>
          ))}
        </div>
      </Card>
    </div>
  );
}