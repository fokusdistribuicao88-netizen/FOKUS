import React, { useMemo } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { formatBRL, formatDate, formatDateTime } from '@/lib/format';
import { computeCustomerCreditReport, recomputeAccountTotals } from '@/lib/customerAccountCalc';
import { printCustomerStatement, shareCustomerStatement } from '@/lib/customerAccountPdf';
import { useToast } from '@/components/ui/use-toast';
import { CreditCard, TrendingUp, AlertTriangle, Clock, FileText, Wallet, Share2 } from 'lucide-react';

function Metric({ icon: Icon, label, value, tone }) {
  const tones = { blue: 'text-blue-600', red: 'text-red-600', emerald: 'text-emerald-600', amber: 'text-amber-600', slate: 'text-slate-600' };
  return (
    <div className="flex items-center gap-2 bg-slate-50 rounded-lg p-2">
      <Icon className={`h-4 w-4 ${tones[tone] || tones.slate}`} />
      <div className="min-w-0">
        <div className="text-[11px] text-muted-foreground truncate">{label}</div>
        <div className="text-sm font-semibold truncate">{value}</div>
      </div>
    </div>
  );
}

export default function CustomerCreditAnalysisDialog({ open, customer, accounts, onClose, user }) {
  const { toast } = useToast();
  const report = useMemo(
    () => customer ? computeCustomerCreditReport(customer, (accounts || []).map((a) => recomputeAccountTotals(a))) : null,
    [customer, accounts]
  );
  if (!customer || !report) return null;

  const customerAccounts = (accounts || [])
    .filter((a) => a.customer_id === customer.id)
    .map((a) => recomputeAccountTotals(a));

  const handleStatement = async () => {
    try {
      await printCustomerStatement({ customer, accounts: customerAccounts, report, user });
      toast({ title: 'Extrato gerado' });
    } catch (e) {
      toast({ title: 'Erro ao gerar extrato', description: String(e.message || e), variant: 'destructive' });
    }
  };

  const handleShare = async () => {
    try {
      const { shared } = await shareCustomerStatement({ customer, accounts: customerAccounts, report, user });
      toast({ title: shared ? 'Compartilhando PDF' : 'PDF baixado', description: shared ? 'Escolha o aplicativo para enviar.' : 'Compartilhamento não suportado — PDF baixado.' });
    } catch (e) {
      if (e?.name !== 'AbortError') toast({ title: 'Erro ao compartilhar', description: String(e.message || e), variant: 'destructive' });
    }
  };

  return (
    <Dialog open={open} onOpenChange={(o) => !o && onClose()}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <CreditCard className="h-5 w-5" /> Análise de Crédito — {customer.name}
          </DialogTitle>
        </DialogHeader>

        <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
          <Metric icon={Wallet} label="Limite" value={formatBRL(report.limit)} tone="blue" />
          <Metric icon={TrendingUp} label="Utilizado" value={formatBRL(report.used)} tone="amber" />
          <Metric icon={CreditCard} label="Disponível" value={formatBRL(report.available)} tone={report.available > 0 ? 'emerald' : 'red'} />
          <Metric icon={AlertTriangle} label="Vencido" value={formatBRL(report.overdueTotal)} tone="red" />
          <Metric icon={Clock} label="Maior atraso" value={`${report.maxLateDays} dia(s)`} tone="red" />
          <Metric icon={AlertTriangle} label="Qtd. atrasos" value={report.lateCount} tone="amber" />
          <Metric icon={TrendingUp} label="Total comprado" value={formatBRL(report.totalPurchased)} tone="slate" />
          <Metric icon={TrendingUp} label="Total pago" value={formatBRL(report.totalPaid)} tone="emerald" />
          <Metric icon={Clock} label="Média p/ pagamento" value={`${report.avgDaysToPay} dia(s)`} tone="slate" />
        </div>

        <Card className="p-3">
          <h4 className="text-sm font-semibold mb-2">Contas do Cliente</h4>
          {customerAccounts.length === 0 ? (
            <p className="text-sm text-muted-foreground">Nenhuma conta registrada.</p>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-xs">
                <thead><tr className="text-left text-muted-foreground border-b">
                  <th className="py-1 px-1">Conta</th><th className="py-1 px-1">Vencimento</th>
                  <th className="py-1 px-1 text-right">Saldo</th><th className="py-1 px-1">Status</th>
                </tr></thead>
                <tbody>
                  {customerAccounts.map((a) => (
                    <tr key={a.id} className="border-b">
                      <td className="py-1 px-1 font-mono">{a.account_number}</td>
                      <td className="py-1 px-1">{formatDate(a.due_date)}</td>
                      <td className="py-1 px-1 text-right font-medium">{formatBRL(a.balance)}</td>
                      <td className="py-1 px-1 capitalize">{a.status}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </Card>

        {report.lastPayment && (
          <div className="text-xs text-muted-foreground">Último pagamento: {formatDateTime(report.lastPayment)}</div>
        )}

        <DialogFooter>
          <Button variant="outline" onClick={handleStatement}><FileText className="h-4 w-4 mr-1" /> Gerar Extrato</Button>
          <Button variant="outline" onClick={handleShare}><Share2 className="h-4 w-4 mr-1" /> Compartilhar</Button>
          <Button onClick={onClose}>Fechar</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}