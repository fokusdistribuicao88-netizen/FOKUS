import React, { useState, useMemo } from 'react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { formatBRL, formatDate } from '@/lib/format';
import { recomputeAccountTotals, computeDashboardMetrics, computeAging } from '@/lib/customerAccountCalc';
import { printOpenAccounts, printOverdueAccounts, printCollectionReport, shareOpenAccounts, shareOverdueAccounts, shareCollectionReport } from '@/lib/customerAccountPdf';
import { useToast } from '@/components/ui/use-toast';
import { FileText, Download, Share2 } from 'lucide-react';

const REPORT_TYPES = [
  { value: 'open', label: 'Contas em aberto' },
  { value: 'overdue', label: 'Contas vencidas' },
  { value: 'receipts', label: 'Recebimentos' },
  { value: 'by_customer', label: 'Por cliente' },
  { value: 'top_debtors', label: 'Maiores devedores' },
  { value: 'aging', label: 'Aging de recebíveis' },
  { value: 'collection', label: 'Cobrança' },
  { value: 'inadimplency', label: 'Inadimplência' },
];

export default function CustomerAccountsReport({ accounts, user }) {
  const { toast } = useToast();
  const [reportType, setReportType] = useState('open');
  const [start, setStart] = useState('');
  const [end, setEnd] = useState('');
  const [customerSearch, setCustomerSearch] = useState('');

  const recomputed = useMemo(() => (accounts || []).map((a) => recomputeAccountTotals(a)), [accounts]);
  const metrics = useMemo(() => computeDashboardMetrics(recomputed), [recomputed]);
  const aging = useMemo(() => computeAging(recomputed), [recomputed]);

  const filtered = useMemo(() => {
    let r = recomputed;
    if (customerSearch.trim()) {
      const q = customerSearch.toLowerCase();
      r = r.filter((a) => (a.customer_name || '').toLowerCase().includes(q));
    }
    if (start) r = r.filter((a) => (a.issue_date || '') >= start);
    if (end) r = r.filter((a) => (a.issue_date || '') <= end);
    return r;
  }, [recomputed, start, end, customerSearch]);

  const byCustomer = useMemo(() => {
    const map = {};
    filtered.forEach((a) => {
      const k = a.customer_name || '—';
      if (!map[k]) map[k] = { name: k, balance: 0, overdue: 0, count: 0, paid: 0 };
      map[k].balance += a.balance || 0;
      map[k].paid += a.paid_amount || 0;
      map[k].count += 1;
      if (a.status === 'overdue') map[k].overdue += a.balance || 0;
    });
    return Object.values(map).sort((a, b) => b.balance - a.balance);
  }, [filtered]);

  const receipts = useMemo(() => {
    const list = [];
    filtered.forEach((a) => {
      (a.payment_history || []).forEach((h) => {
        if (start && (h.date || '').slice(0, 10) < start) return;
        if (end && (h.date || '').slice(0, 10) > end) return;
        list.push({ ...h, customer_name: a.customer_name, account_number: a.account_number });
      });
    });
    return list.sort((a, b) => (b.date || '').localeCompare(a.date || ''));
  }, [filtered, start, end]);

  const topDebtors = useMemo(
    () => byCustomer.filter((c) => c.balance > 0).slice(0, 20),
    [byCustomer]
  );

  const [sharing, setSharing] = useState(false);

  const handlePrint = async () => {
    try {
      if (reportType === 'open') await printOpenAccounts(filtered, user);
      else if (reportType === 'overdue') await printOverdueAccounts(filtered, user);
      else if (reportType === 'collection') await printCollectionReport(filtered, user);
      else toast({ title: 'Relatório gerado' });
    } catch (e) {
      toast({ title: 'Erro ao gerar relatório', description: String(e.message || e), variant: 'destructive' });
    }
  };

  const handleShare = async () => {
    setSharing(true);
    try {
      let res = null;
      if (reportType === 'open') res = await shareOpenAccounts(filtered, user);
      else if (reportType === 'overdue') res = await shareOverdueAccounts(filtered, user);
      else if (reportType === 'collection') res = await shareCollectionReport(filtered, user);
      if (res) toast({ title: res.shared ? 'Compartilhando PDF' : 'PDF baixado', description: res.shared ? 'Escolha o aplicativo para enviar.' : 'Compartilhamento não suportado — PDF baixado.' });
      else toast({ title: 'Relatório sem suporte para compartilhar', description: 'Selecione "Contas em aberto", "Vencidas" ou "Cobrança".' });
    } catch (e) {
      if (e?.name !== 'AbortError') toast({ title: 'Erro ao compartilhar', description: String(e.message || e), variant: 'destructive' });
    } finally { setSharing(false); }
  };

  return (
    <Card className="p-4 space-y-3">
      <div className="flex flex-wrap items-end gap-2">
        <div>
          <label className="text-xs text-muted-foreground">Relatório</label>
          <Select value={reportType} onValueChange={setReportType}>
            <SelectTrigger className="w-48"><SelectValue /></SelectTrigger>
            <SelectContent>
              {REPORT_TYPES.map((r) => <SelectItem key={r.value} value={r.value}>{r.label}</SelectItem>)}
            </SelectContent>
          </Select>
        </div>
        <div>
          <label className="text-xs text-muted-foreground">De</label>
          <Input type="date" value={start} onChange={(e) => setStart(e.target.value)} className="w-40" />
        </div>
        <div>
          <label className="text-xs text-muted-foreground">Até</label>
          <Input type="date" value={end} onChange={(e) => setEnd(e.target.value)} className="w-40" />
        </div>
        <div className="flex-1 min-w-[180px]">
          <label className="text-xs text-muted-foreground">Cliente</label>
          <Input value={customerSearch} onChange={(e) => setCustomerSearch(e.target.value)} placeholder="Filtrar por cliente" />
        </div>
        <Button onClick={handlePrint} variant="outline" disabled={sharing}><Download className="h-4 w-4 mr-1" /> Gerar PDF</Button>
        <Button onClick={handleShare} variant="outline" disabled={sharing}><Share2 className="h-4 w-4 mr-1" /> Compartilhar</Button>
      </div>

      <div className="overflow-x-auto">
        {reportType === 'open' && (
          <Table headers={['Conta', 'Cliente', 'Vencimento', 'Saldo', 'Status']} rows={filtered.filter((a) => a.status !== 'paid' && a.status !== 'cancelled').slice(0, 100).map((a) => [a.account_number, a.customer_name, formatDate(a.due_date), formatBRL(a.balance), a.status])} />
        )}
        {reportType === 'overdue' && (
          <Table headers={['Conta', 'Cliente', 'Vencimento', 'Saldo']} rows={filtered.filter((a) => a.status === 'overdue').map((a) => [a.account_number, a.customer_name, formatDate(a.due_date), formatBRL(a.balance)])} />
        )}
        {reportType === 'receipts' && (
          <Table headers={['Data', 'Cliente', 'Conta', 'Parcela', 'Valor', 'Forma']} rows={receipts.slice(0, 200).map((h) => [formatDate(h.date), h.customer_name, h.account_number, h.installment_number || '—', formatBRL(h.amount), h.method || '—'])} />
        )}
        {reportType === 'by_customer' && (
          <Table headers={['Cliente', 'Contas', 'Saldo', 'Vencido', 'Pago']} rows={byCustomer.map((c) => [c.name, c.count, formatBRL(c.balance), formatBRL(c.overdue), formatBRL(c.paid)])} />
        )}
        {reportType === 'top_debtors' && (
          <Table headers={['Cliente', 'Saldo', 'Vencido', 'Contas']} rows={topDebtors.map((c) => [c.name, formatBRL(c.balance), formatBRL(c.overdue), c.count])} />
        )}
        {reportType === 'aging' && (
          <Table headers={['Faixa', 'Quantidade', 'Total']} rows={aging.map((b) => [b.label, b.count, formatBRL(b.total)])} />
        )}
        {reportType === 'collection' && (
          <Table headers={['Cliente', 'Conta', 'Data', 'Tipo', 'Resultado', 'Promessa']}
            rows={filtered.flatMap((a) => (a.collection_history || []).map((c) => [a.customer_name, a.account_number, formatDate(c.date), c.contact_type, c.result, c.promise_date ? formatDate(c.promise_date) : '—'])).slice(0, 200)} />
        )}
        {reportType === 'inadimplency' && (
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
            <Stat label="Total em aberto" value={formatBRL(metrics.totalOpen)} />
            <Stat label="Total vencido" value={formatBRL(metrics.totalOverdue)} />
            <Stat label="Inadimplência" value={`${metrics.inadimplencia}%`} />
            <Stat label="Contas vencidas" value={metrics.overdueCount} />
            <Stat label="Média dias atraso" value={`${metrics.avgLateDays} dia(s)`} />
            <Stat label="Recebido no mês" value={formatBRL(metrics.receivedThisMonth)} />
            <Stat label="Previsto a receber" value={formatBRL(metrics.expectedToReceive)} />
            <Stat label="A vencer (7d)" value={formatBRL(metrics.totalDueSoon)} />
          </div>
        )}
      </div>
    </Card>
  );
}

function Table({ headers, rows }) {
  if (!rows.length) return <p className="text-sm text-muted-foreground py-4 text-center">Sem dados para o filtro selecionado.</p>;
  return (
    <table className="w-full text-sm">
      <thead><tr className="text-left text-xs text-muted-foreground border-b">{headers.map((h) => <th key={h} className="py-2 px-2">{h}</th>)}</tr></thead>
      <tbody>{rows.map((r, i) => <tr key={i} className="border-b hover:bg-slate-50">{r.map((c, j) => <td key={j} className="py-1.5 px-2">{c}</td>)}</tr>)}</tbody>
    </table>
  );
}
function Stat({ label, value }) {
  return <div className="bg-slate-50 rounded-lg p-3"><div className="text-xs text-muted-foreground">{label}</div><div className="text-lg font-bold">{value}</div></div>;
}