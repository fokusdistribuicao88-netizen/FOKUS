import React, { useMemo } from 'react';
import { Card } from '@/components/ui/card';
import { formatBRL, formatDate } from '@/lib/format';
import { recomputeAccountTotals, daysBetween, todayStr } from '@/lib/customerAccountCalc';
import { Bell, AlertTriangle, CalendarClock } from 'lucide-react';

export default function CustomerAccountsReminders({ accounts, onView }) {
  const today = todayStr();
  const items = useMemo(() => {
    const list = (accounts || []).map((a) => recomputeAccountTotals(a, today));
    const reminders = [];
    list.forEach((a) => {
      if (a.status === 'cancelled' || a.status === 'negotiated') return;
      (a.installments || []).forEach((i) => {
        if (i.status === 'paid' || i.status === 'cancelled') return;
        if (i.balance <= 0.01) return;
        const d = daysBetween(today, i.due_date);
        if (d === 0) reminders.push({ account: a, installment: i, kind: 'today', label: 'Vence hoje' });
        else if (d > 0 && d <= 7) reminders.push({ account: a, installment: i, kind: 'soon', label: `Vence em ${d} dia(s)` });
        else if (d < 0) reminders.push({ account: a, installment: i, kind: 'overdue', label: `Vencida há ${-d} dia(s)` });
      });
    });
    return reminders.sort((x, y) => x.installment.due_date.localeCompare(y.installment.due_date));
  }, [accounts, today]);

  const counts = {
    today: items.filter((i) => i.kind === 'today').length,
    soon: items.filter((i) => i.kind === 'soon').length,
    overdue: items.filter((i) => i.kind === 'overdue').length,
  };

  if (!items.length) return null;

  const tone = {
    today: 'border-amber-300 bg-amber-50',
    soon: 'border-blue-200 bg-blue-50',
    overdue: 'border-red-300 bg-red-50',
  };
  const icon = { today: CalendarClock, soon: Bell, overdue: AlertTriangle };
  const iconColor = { today: 'text-amber-600', soon: 'text-blue-600', overdue: 'text-red-600' };

  return (
    <Card className="p-3">
      <div className="flex items-center justify-between mb-2">
        <h3 className="text-sm font-semibold flex items-center gap-2"><Bell className="h-4 w-4" /> Lembretes de Vencimento</h3>
        <div className="flex gap-2 text-xs">
          <span className="px-2 py-0.5 rounded-full bg-amber-100 text-amber-700">{counts.today} hoje</span>
          <span className="px-2 py-0.5 rounded-full bg-blue-100 text-blue-700">{counts.soon} próximos</span>
          <span className="px-2 py-0.5 rounded-full bg-red-100 text-red-700">{counts.overdue} vencidos</span>
        </div>
      </div>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-2 max-h-64 overflow-y-auto">
        {items.slice(0, 30).map((r, idx) => {
          const Icon = icon[r.kind];
          return (
            <button
              key={idx}
              onClick={() => onView?.(r.account)}
              className={`text-left border rounded-lg p-2 ${tone[r.kind]} hover:shadow-sm transition`}
            >
              <div className="flex items-center justify-between">
                <span className="text-xs font-medium truncate">{r.account.customer_name}</span>
                <Icon className={`h-3.5 w-3.5 ${iconColor[r.kind]}`} />
              </div>
              <div className="text-[11px] text-muted-foreground mt-0.5">
                {r.account.account_number} · parc. {r.installment.number} · vence {formatDate(r.installment.due_date)}
              </div>
              <div className="flex justify-between mt-1">
                <span className={`text-[11px] font-medium ${iconColor[r.kind]}`}>{r.label}</span>
                <span className="text-xs font-semibold">{formatBRL(r.installment.balance)}</span>
              </div>
            </button>
          );
        })}
      </div>
    </Card>
  );
}