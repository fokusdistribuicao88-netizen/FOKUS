import React, { useEffect, useRef, useState, useCallback } from 'react';
import { Loader2, ChevronDown } from 'lucide-react';

const THRESHOLD = 70;
const MAX_PULL = 100;

// Returns true when a Radix/vaul overlay (dialog, drawer, select, popover…)
// is currently open so we don't hijack its touch gestures.
const isOverlayOpen = () => !!document.querySelector('[data-state="open"]');

/**
 * Mobile pull-to-refresh. Attaches touch listeners to the document and shows
 * a small indicator at the top; when the user pulls past THRESHOLD at the top
 * of the page, `onRefresh` is called (use it to refetch React Query data).
 */
export default function PullToRefresh({ onRefresh, disabled }) {
  const [pull, setPull] = useState(0);
  const [refreshing, setRefreshing] = useState(false);
  const startYRef = useRef(0);
  const pullRef = useRef(0);
  const pullingRef = useRef(false);

  const handleRefresh = useCallback(async () => {
    if (refreshing || disabled) return;
    setRefreshing(true);
    try {
      await onRefresh?.();
    } finally {
      setRefreshing(false);
    }
  }, [onRefresh, refreshing, disabled]);

  useEffect(() => {
    if (disabled) return;

    const onTouchStart = (e) => {
      if (window.scrollY > 0 || refreshing || isOverlayOpen()) return;
      startYRef.current = e.touches[0].clientY;
      pullingRef.current = true;
    };

    const onTouchMove = (e) => {
      if (!pullingRef.current || refreshing) return;
      const delta = e.touches[0].clientY - startYRef.current;
      if (delta > 0 && window.scrollY === 0 && !isOverlayOpen()) {
        e.preventDefault();
        const next = Math.min(delta * 0.5, MAX_PULL);
        pullRef.current = next;
        setPull(next);
      } else if (delta <= 0 && pullRef.current !== 0) {
        pullRef.current = 0;
        setPull(0);
      }
    };

    const onTouchEnd = () => {
      if (!pullingRef.current) return;
      pullingRef.current = false;
      if (pullRef.current >= THRESHOLD) {
        handleRefresh();
      }
      pullRef.current = 0;
      setPull(0);
    };

    document.addEventListener('touchstart', onTouchStart, { passive: true });
    document.addEventListener('touchmove', onTouchMove, { passive: false });
    document.addEventListener('touchend', onTouchEnd, { passive: true });
    document.addEventListener('touchcancel', onTouchEnd, { passive: true });

    return () => {
      document.removeEventListener('touchstart', onTouchStart);
      document.removeEventListener('touchmove', onTouchMove);
      document.removeEventListener('touchend', onTouchEnd);
      document.removeEventListener('touchcancel', onTouchEnd);
    };
  }, [refreshing, disabled, handleRefresh]);

  const progress = Math.min(pull / THRESHOLD, 1);
  const show = pull > 0 || refreshing;

  return (
    <div
      className="fixed top-0 inset-x-0 z-40 flex justify-center pointer-events-none"
      style={{
        transform: `translateY(${refreshing ? 24 : pull}px)`,
        opacity: show ? 1 : 0,
        transition: pullingRef.current ? 'none' : 'transform 0.2s ease, opacity 0.2s ease',
      }}
    >
      <div className="mt-2 w-9 h-9 rounded-full bg-card border border-border shadow-md flex items-center justify-center">
        {refreshing ? (
          <Loader2 className="w-5 h-5 text-blue-600 animate-spin" />
        ) : (
          <ChevronDown
            className="w-5 h-5 text-blue-600 transition-transform"
            style={{ transform: `rotate(${180 * progress}deg)` }}
          />
        )}
      </div>
    </div>
  );
}