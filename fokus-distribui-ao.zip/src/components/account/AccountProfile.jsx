import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { User, Building2, Lock, Save, Loader2, Trash2, AlertTriangle } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { useAuth } from '@/lib/AuthContext';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import {
  AlertDialog,
  AlertDialogContent,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogCancel,
  AlertDialogAction,
} from '@/components/ui/alert-dialog';
import { useToast } from '@/components/ui/use-toast';

const FIELDS = {
  personal: [
    { key: 'name', label: 'Nome' },
    { key: 'phone', label: 'Telefone' },
    { key: 'cep', label: 'CEP' },
    { key: 'address', label: 'Endereço' },
    { key: 'city', label: 'Cidade' },
    { key: 'state', label: 'Estado (UF)' },
  ],
  company: [
    { key: 'company_name', label: 'Nome do estabelecimento' },
    { key: 'legal_name', label: 'Razão Social' },
    { key: 'trade_name', label: 'Nome Fantasia' },
    { key: 'cnpj', label: 'CNPJ' },
    { key: 'state_registration', label: 'Inscrição Estadual' },
    { key: 'business_address', label: 'Endereço comercial' },
    { key: 'contacts', label: 'Contatos', textarea: true },
  ],
};

export default function AccountProfile({ user }) {
  const { toast } = useToast();
  const { refreshUser } = useAuth();
  const [profile, setProfile] = useState({});
  const [saving, setSaving] = useState(false);
  const [deleteOpen, setDeleteOpen] = useState(false);
  const [deleteStep, setDeleteStep] = useState(1);
  const [confirmText, setConfirmText] = useState('');
  const [deleting, setDeleting] = useState(false);

  const openDeleteDialog = () => {
    setDeleteStep(1);
    setConfirmText('');
    setDeleteOpen(true);
  };

  const handleDeleteAccount = async () => {
    setDeleting(true);
    try {
      await base44.auth.updateMe({
        data: {
          account_profile: {},
          account_deletion_requested: true,
          deletion_requested_at: new Date().toISOString(),
        },
      });
      await base44.analytics?.track?.({
        eventName: 'account_deletion_requested',
        properties: { user_email: user?.email },
      });
      toast({
        title: 'Exclusão solicitada',
        description:
          'Sua solicitação de exclusão foi registrada. Você será desconectado e seus dados serão removidos.',
      });
      setDeleteOpen(false);
      setTimeout(() => {
        base44.auth.logout('/');
      }, 800);
    } catch (err) {
      toast({
        title: 'Erro ao excluir conta',
        description: err.message || 'Tente novamente ou contate o suporte.',
        variant: 'destructive',
      });
    } finally {
      setDeleting(false);
    }
  };

  useEffect(() => {
    const stored = user?.data?.account_profile || {};
    setProfile({
      name: stored.name || user?.full_name || '',
      phone: stored.phone || user?.phone_number || '',
      cep: stored.cep || '',
      address: stored.address || '',
      city: stored.city || '',
      state: stored.state || '',
      company_name: stored.company_name || '',
      legal_name: stored.legal_name || '',
      trade_name: stored.trade_name || '',
      cnpj: stored.cnpj || '',
      state_registration: stored.state_registration || '',
      business_address: stored.business_address || '',
      contacts: stored.contacts || '',
    });
  }, [user]);

  const setField = (key, value) => setProfile((p) => ({ ...p, [key]: value }));

  const handleSave = async (e) => {
    e.preventDefault();
    setSaving(true);
    try {
      await base44.auth.updateMe({ data: { account_profile: profile } });
      await refreshUser?.();
      toast({ title: 'Dados salvos', description: 'Suas informações foram atualizadas com segurança.' });
    } catch (err) {
      toast({ title: 'Erro ao salvar', description: err.message || 'Tente novamente.', variant: 'destructive' });
    } finally {
      setSaving(false);
    }
  };

  const renderField = ({ key, label, textarea }) => (
    <div key={key} className="space-y-1.5">
      <Label htmlFor={key}>{label}</Label>
      {textarea ? (
        <Textarea id={key} value={profile[key] || ''} onChange={(e) => setField(key, e.target.value)} rows={2} />
      ) : (
        <Input id={key} value={profile[key] || ''} onChange={(e) => setField(key, e.target.value)} />
      )}
    </div>
  );

  return (
    <form onSubmit={handleSave} className="space-y-8">
      <div>
        <div className="flex items-center gap-2 mb-4">
          <div className="w-8 h-8 rounded-lg bg-blue-100 dark:bg-blue-900/40 flex items-center justify-center">
            <User className="w-4 h-4 text-blue-700 dark:text-blue-300" />
          </div>
          <h3 className="font-semibold">Dados pessoais</h3>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div className="space-y-1.5">
            <Label htmlFor="email">E-mail</Label>
            <Input id="email" value={user?.email || ''} disabled />
            <p className="text-xs text-muted-foreground">O e-mail não pode ser alterado.</p>
          </div>
          {FIELDS.personal.map(renderField)}
        </div>
      </div>

      <div>
        <div className="flex items-center gap-2 mb-4">
          <div className="w-8 h-8 rounded-lg bg-amber-100 dark:bg-amber-900/40 flex items-center justify-center">
            <Building2 className="w-4 h-4 text-amber-700 dark:text-amber-300" />
          </div>
          <h3 className="font-semibold">Dados do estabelecimento</h3>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          {FIELDS.company.map(renderField)}
        </div>
      </div>

      <div>
        <div className="flex items-center gap-2 mb-4">
          <div className="w-8 h-8 rounded-lg bg-slate-100 dark:bg-slate-800 flex items-center justify-center">
            <Lock className="w-4 h-4 text-slate-700 dark:text-slate-300" />
          </div>
          <h3 className="font-semibold">Segurança</h3>
        </div>
        <Link to="/forgot-password">
          <Button type="button" variant="outline">Alterar minha senha</Button>
        </Link>
        <p className="text-xs text-muted-foreground mt-2">Você receberá um link por e-mail para definir uma nova senha.</p>
      </div>

      <div className="flex justify-end pt-2 border-t border-border">
        <Button type="submit" disabled={saving} className="bg-blue-700 hover:bg-blue-800">
          {saving ? <><Loader2 className="w-4 h-4 mr-2 animate-spin" />Salvando...</> : <><Save className="w-4 h-4 mr-2" />Salvar alterações</>}
        </Button>
      </div>

      {/* Danger zone — exclusão de conta (App Store compliance) */}
      <div className="rounded-xl border border-red-200 bg-red-50/50 dark:bg-red-950/20 p-5 space-y-3">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-lg bg-red-100 dark:bg-red-900/40 flex items-center justify-center">
            <Trash2 className="w-4 h-4 text-red-700 dark:text-red-300" />
          </div>
          <h3 className="font-semibold text-red-800 dark:text-red-300">Excluir conta</h3>
        </div>
        <p className="text-sm text-muted-foreground">
          A exclusão da conta é permanente e remove todos os seus dados pessoais associados.
          Esta ação não pode ser desfeita.
        </p>
        <Button
          type="button"
          variant="outline"
          onClick={openDeleteDialog}
          className="text-red-700 border-red-300 hover:bg-red-100 dark:text-red-300 dark:border-red-800 dark:hover:bg-red-950/40 min-h-11"
        >
          <Trash2 className="w-4 h-4 mr-2" /> Excluir minha conta
        </Button>
      </div>

      <AlertDialog open={deleteOpen} onOpenChange={(o) => { setDeleteOpen(o); if (!o) setDeleteStep(1); }}>
        <AlertDialogContent>
          {deleteStep === 1 ? (
            <>
              <AlertDialogHeader>
                <AlertDialogTitle className="flex items-center gap-2 text-red-700 dark:text-red-400">
                  <AlertTriangle className="w-5 h-5" /> Excluir conta?
                </AlertDialogTitle>
                <AlertDialogDescription>
                  Você está prestes a excluir sua conta. Todos os dados pessoais — perfil,
                  endereços, contatos e histórico — serão permanentemente removidos. Esta ação
                  <strong> não pode ser desfeita</strong>. Deseja continuar?
                </AlertDialogDescription>
              </AlertDialogHeader>
              <AlertDialogFooter>
                <AlertDialogCancel disabled={deleting}>Cancelar</AlertDialogCancel>
                <AlertDialogAction
                  onClick={(e) => {
                    e.preventDefault();
                    setDeleteStep(2);
                  }}
                  className="bg-red-600 hover:bg-red-700 text-white"
                >
                  Sim, continuar
                </AlertDialogAction>
              </AlertDialogFooter>
            </>
          ) : (
            <>
              <AlertDialogHeader>
                <AlertDialogTitle className="flex items-center gap-2 text-red-700 dark:text-red-400">
                  <AlertTriangle className="w-5 h-5" /> Confirmação final
                </AlertDialogTitle>
                <AlertDialogDescription>
                  Para confirmar a exclusão definitiva, digite <strong>EXCLUIR</strong> no campo
                  abaixo e clique em "Excluir definitivamente".
                </AlertDialogDescription>
              </AlertDialogHeader>
              <div className="space-y-1.5">
                <Label htmlFor="confirm-delete">Digite EXCLUIR para confirmar</Label>
                <Input
                  id="confirm-delete"
                  value={confirmText}
                  onChange={(e) => setConfirmText(e.target.value.toUpperCase())}
                  placeholder="EXCLUIR"
                  className="border-red-300 focus:border-red-500 focus:ring-red-300"
                  autoComplete="off"
                />
              </div>
              <AlertDialogFooter>
                <AlertDialogCancel
                  disabled={deleting}
                  onClick={() => { setDeleteStep(1); setConfirmText(''); }}
                >
                  Voltar
                </AlertDialogCancel>
                <AlertDialogAction
                  disabled={confirmText !== 'EXCLUIR' || deleting}
                  onClick={(e) => {
                    e.preventDefault();
                    handleDeleteAccount();
                  }}
                  className="bg-red-600 hover:bg-red-700 text-white disabled:opacity-50"
                >
                  {deleting ? (
                    <><Loader2 className="w-4 h-4 mr-2 animate-spin" /> Excluindo...</>
                  ) : (
                    'Excluir definitivamente'
                  )}
                </AlertDialogAction>
              </AlertDialogFooter>
            </>
          )}
        </AlertDialogContent>
      </AlertDialog>
    </form>
  );
}