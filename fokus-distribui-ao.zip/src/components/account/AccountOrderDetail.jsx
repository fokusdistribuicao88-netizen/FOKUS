import React, { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { User, Phone, MapPin, CreditCard, Truck, Clock, Package, FileText, FileDown, Download, ExternalLink, Loader2 } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Button } from '@/components/ui/button';
import { ORDER_STATUS, PAYMENT_STATUS, PAYMENT_METHODS, formatCurrency, orderStatusInfo } from '@/components/orders/orderStatus';
import { generateOrderPDF } from '@/components/orders/orderPdf';

function Row({ icon: Icon, label, value }) {
  return (
    <div className="flex items-start gap-2 text-sm py-1">
      <Icon className="w-4 h-4 text-muted-foreground mt-0.5 flex-shrink-0" />
      <span className="text-muted-foreground w-28 flex-shrink-0">{label}:</span>
      <span className="font-medium break-words">{value || '—'}</span>
    </div>
  );
}

function Section({ title, children }) {
  return (
    <div className="space-y-1">
      <h4 className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">{title}</h4>
      <div className="bg-muted/30 rounded-xl p-3">{children}</div>
    </div>
  );
}

function DocumentItem({ doc }) {
  const [signed, setSigned] = useState(null);
  const [loading, setLoading] = useState(false);
  const looksPrivate = doc.url && (doc.url.includes('private') || doc.url.startsWith('files/') || !doc.url.startsWith('http'));

  const handleDownload = async () => {
    if (looksPrivate && !signed) {
      setLoading(true);
      try {
        const res = await base44.integrations.Core.CreateFileSignedUrl({ file_uri: doc.url });
        setSigned(res.signed_url);
        window.open(res.signed_url, '_blank');
      } catch {
        window.open(doc.url, '_blank');
      } finally {
        setLoading(false);
      }
    } else {
      window.open(signed || doc.url, '_blank');
    }
  };

  const date = doc.uploaded_date ? new Date(doc.uploaded_date).toLocaleDateString('pt-BR') : '';
  return (
    <div className="flex items-center justify-between gap-3 rounded-lg border border-border bg-card p-3">
      <div className="flex items-center gap-3 min-w-0">
        <div className="w-9 h-9 rounded-lg bg-blue-100 dark:bg-blue-900/40 flex items-center justify-center flex-shrink-0">
          <FileText className="w-4 h-4 text-blue-700 dark:text-blue-300" />
        </div>
        <div className="min-w-0">
          <p className="text-sm font-medium truncate">{doc.name || 'Documento'}</p>
          <p className="text-xs text-muted-foreground">{doc.type || 'Documento'}{date ? ` · ${date}` : ''}</p>
        </div>
      </div>
      <Button size="sm" variant="outline" onClick={handleDownload} disabled={loading}>
        {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Download className="w-4 h-4" />}
        Baixar
      </Button>
    </div>
  );
}

export default function AccountOrderDetail({ order, productMap, onClose }) {
  const [downloading, setDownloading] = useState(false);
  const { data: settings } = useQuery({
    queryKey: ['settings'],
    queryFn: async () => {
      const list = await base44.entities.Settings.list();
      return list[0] || null;
    },
    staleTime: 10 * 60 * 1000,
  });

  if (!order) return null;
  const o = orderStatusInfo(order.status);
  const p = PAYMENT_STATUS[order.payment_status] || { label: order.payment_status };
  const subtotal = (order.items || []).reduce((s, i) => s + (i.subtotal || 0), 0);
  const shortCode = (id) => '#' + (id || '').substring(0, 8).toUpperCase();
  const documents = order.documents || [];

  const handlePDF = async () => {
    setDownloading(true);
    try {
      await generateOrderPDF(order, settings, productMap);
    } catch (e) {
      console.error(e);
    } finally {
      setDownloading(false);
    }
  };

  return (
    <Dialog open={!!order} onOpenChange={(op) => !op && onClose()}>
      <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <div className="flex items-start justify-between gap-3">
            <div>
              <DialogTitle className="flex items-center gap-2 flex-wrap">
                Pedido {shortCode(order.id)}
                <span className={`inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium ${o.badge || ''}`}>{o.label}</span>
              </DialogTitle>
              <DialogDescription>
                Criado em {new Date(order.created_date).toLocaleString('pt-BR')}
              </DialogDescription>
            </div>
            <Button size="sm" variant="outline" onClick={handlePDF} disabled={downloading}>
              {downloading ? <Loader2 className="w-4 h-4 animate-spin" /> : <FileDown className="w-4 h-4" />}
              Baixar PDF
            </Button>
          </div>
        </DialogHeader>

        <Tabs defaultValue="items">
          <TabsList className={`grid w-full ${documents.length ? 'grid-cols-5' : 'grid-cols-4'}`}>
            <TabsTrigger value="items">Produtos</TabsTrigger>
            <TabsTrigger value="payment">Pagamento</TabsTrigger>
            <TabsTrigger value="delivery">Entrega</TabsTrigger>
            <TabsTrigger value="timeline">Histórico</TabsTrigger>
            {documents.length > 0 && <TabsTrigger value="docs">Comprovantes</TabsTrigger>}
          </TabsList>

          <TabsContent value="items" className="space-y-4">
            <div className="border border-border rounded-xl overflow-hidden">
              <table className="w-full text-sm">
                <thead className="bg-muted/50 text-muted-foreground">
                  <tr>
                    <th className="text-left px-3 py-2 font-medium">Produto</th>
                    <th className="text-center px-3 py-2 font-medium">Qtd</th>
                    <th className="text-right px-3 py-2 font-medium">Unitário</th>
                    <th className="text-right px-3 py-2 font-medium">Subtotal</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-border">
                  {(order.items || []).map((item, i) => {
                    const product = productMap?.[item.product_id];
                    const packInfo = product?.units_per_pack ? ` (${product.units_per_pack} un/${product.unit_type || 'pack'})` : '';
                    return (
                      <tr key={i}>
                        <td className="px-3 py-2">{item.product_name}{packInfo}</td>
                        <td className="px-3 py-2 text-center">{item.quantity}</td>
                        <td className="px-3 py-2 text-right">{formatCurrency(item.unit_price)}</td>
                        <td className="px-3 py-2 text-right font-medium">{formatCurrency(item.subtotal)}</td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
            <div className="bg-muted/40 rounded-xl p-3 space-y-1 text-sm">
              <div className="flex justify-between"><span className="text-muted-foreground">Subtotal</span><span>{formatCurrency(subtotal)}</span></div>
              {order.discount ? <div className="flex justify-between"><span className="text-muted-foreground">Desconto</span><span>-{formatCurrency(order.discount)}</span></div> : null}
              {order.freight ? <div className="flex justify-between"><span className="text-muted-foreground">Frete</span><span>{formatCurrency(order.freight)}</span></div> : null}
              <div className="flex justify-between font-bold text-base pt-1 border-t border-border"><span>Total</span><span>{formatCurrency(order.total)}</span></div>
            </div>
            {order.notes && (
              <Section title="Observações">
                <p className="text-sm">{order.notes}</p>
              </Section>
            )}
          </TabsContent>

          <TabsContent value="payment" className="space-y-3">
            <Section title="Pagamento">
              <Row icon={CreditCard} label="Forma" value={PAYMENT_METHODS[order.payment_method]} />
              <Row icon={Clock} label="Status" value={p.label} />
            </Section>
          </TabsContent>

          <TabsContent value="delivery" className="space-y-3">
            <Section title="Endereço de entrega">
              <Row icon={User} label="Destinatário" value={order.customer_name} />
              <Row icon={Phone} label="Telefone" value={order.customer_phone} />
              <Row icon={MapPin} label="Endereço" value={order.customer_address} />
              <Row icon={MapPin} label="Cidade/UF" value={`${order.city || '—'} - ${order.state || '—'}`} />
            </Section>
            <Section title="Rastreamento">
              <Row icon={Truck} label="Transportadora" value={order.carrier} />
              <Row icon={Package} label="Código" value={order.tracking_code} />
            </Section>
          </TabsContent>

          <TabsContent value="timeline" className="space-y-3">
            <div className="relative pl-6 space-y-4">
              {(order.timeline || []).length === 0 && <p className="text-sm text-muted-foreground">Nenhum registro ainda.</p>}
              {(order.timeline || []).map((entry, i) => (
                <div key={i} className="relative">
                  <div className="absolute -left-5 top-1 w-2.5 h-2.5 rounded-full bg-blue-500 ring-4 ring-blue-500/20" />
                  <p className="text-sm font-medium">{entry.event}</p>
                  <p className="text-xs text-muted-foreground">{entry.author} · {new Date(entry.date).toLocaleString('pt-BR')}</p>
                </div>
              ))}
            </div>
          </TabsContent>

          {documents.length > 0 && (
            <TabsContent value="docs" className="space-y-3">
              <p className="text-sm text-muted-foreground">Documentos e comprovantes vinculados a este pedido pelo time da Fokus.</p>
              <div className="space-y-2">
                {documents.map((doc, i) => <DocumentItem key={i} doc={doc} />)}
              </div>
            </TabsContent>
          )}
        </Tabs>
      </DialogContent>
    </Dialog>
  );
}