import React, { useEffect, useMemo, useState } from 'react';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { useNavigate } from 'react-router-dom';
import { Package, RotateCw, Eye, Truck, MapPin, CreditCard, FileDown, Loader2, Share2 } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { Button } from '@/components/ui/button';
import { useToast } from '@/components/ui/use-toast';
import { ORDER_STATUS, PAYMENT_STATUS, PAYMENT_METHODS, formatCurrency } from '@/components/orders/orderStatus';
import { generateOrderPDF, shareOrderPDF } from '@/components/orders/orderPdf';
import AccountOrderDetail from './AccountOrderDetail';

const statusBadge = (key) => {
  const s = ORDER_STATUS[key] || { label: key, badge: 'bg-slate-100 text-slate-700' };
  return <span className={`inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-xs font-medium ${s.badge}`}><span className={`w-1.5 h-1.5 rounded-full ${s.dot}`} />{s.label}</span>;
};

export default function AccountOrders() {
  const { toast } = useToast();
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const [selected, setSelected] = useState(null);

  const { data: orders = [], isLoading } = useQuery({
    queryKey: ['my-orders'],
    queryFn: () => base44.entities.Order.list('-created_date', 200),
  });

  // Atualiza a lista em tempo real quando o status de algum pedido muda
  useEffect(() => {
    const unsubscribe = base44.entities.Order.subscribe(() => {
      queryClient.invalidateQueries({ queryKey: ['my-orders'] });
    });
    return () => unsubscribe();
  }, [queryClient]);

  // Suporte ao botão de voltar do Android: fecha o modal em vez de sair do WebView
  useEffect(() => {
    if (!selected) return;
    window.history.pushState({ modalOpen: true }, '');
    const onPop = () => setSelected(null);
    window.addEventListener('popstate', onPop);
    return () => {
      window.removeEventListener('popstate', onPop);
      if (window.history.state?.modalOpen) {
        window.history.back();
      }
    };
  }, [selected]);

  const { data: products = [] } = useQuery({
    queryKey: ['products'],
    queryFn: () => base44.entities.Product.list(),
    staleTime: 5 * 60 * 1000,
  });

  const { data: settings } = useQuery({
    queryKey: ['settings'],
    queryFn: async () => {
      const list = await base44.entities.Settings.list();
      return list[0] || null;
    },
    staleTime: 10 * 60 * 1000,
  });

  const [pdfLoadingId, setPdfLoadingId] = useState(null);
  const productMap = useMemo(() => Object.fromEntries(products.map((p) => [p.id, p])), [products]);

  const downloadPDF = async (order) => {
    setPdfLoadingId(order.id);
    try {
      await generateOrderPDF(order, settings, productMap);
    } catch (e) {
      toast({ title: 'Erro ao gerar PDF', description: 'Tente novamente.', variant: 'destructive' });
    } finally {
      setPdfLoadingId(null);
    }
  };

  const sharePDF = async (order) => {
    setPdfLoadingId(order.id);
    try {
      const { shared } = await shareOrderPDF(order, settings, productMap);
      toast({ title: shared ? 'Compartilhando PDF' : 'PDF baixado', description: shared ? 'Escolha o aplicativo para enviar.' : 'Compartilhamento não suportado — PDF baixado.' });
    } catch (e) {
      if (e?.name !== 'AbortError') toast({ title: 'Erro ao compartilhar', description: 'Tente novamente.', variant: 'destructive' });
    } finally {
      setPdfLoadingId(null);
    }
  };

  const repeatOrder = (order) => {
    const newItems = (order.items || []).map((oi) => {
      const p = productMap[oi.product_id];
      if (!p) return null;
      return { ...p, quantity: oi.quantity, originalPrice: p.price };
    }).filter(Boolean);

    if (newItems.length === 0) {
      toast({ title: 'Não foi possível repetir o pedido', description: 'Os produtos não estão mais disponíveis.', variant: 'destructive' });
      return;
    }

    let existing = [];
    try { existing = JSON.parse(localStorage.getItem('cart') || '[]'); } catch { existing = []; }
    const merged = [...existing];
    newItems.forEach((it) => {
      const ex = merged.find((m) => m.id === it.id);
      if (ex) ex.quantity += it.quantity; else merged.push(it);
    });
    localStorage.setItem('cart', JSON.stringify(merged));
    toast({ title: 'Pedido adicionado ao carrinho', description: 'Revise os itens na loja e finalize.' });
    setTimeout(() => navigate('/'), 600);
  };

  if (isLoading) {
    return <div className="space-y-3">{[1, 2, 3].map((i) => <div key={i} className="h-24 rounded-xl bg-muted animate-pulse" />)}</div>;
  }

  if (orders.length === 0) {
    return (
      <div className="text-center py-16">
        <div className="w-16 h-16 bg-muted rounded-full flex items-center justify-center mx-auto mb-4">
          <Package className="w-7 h-7 text-muted-foreground" />
        </div>
        <h3 className="text-lg font-semibold mb-1">Nenhum pedido ainda</h3>
        <p className="text-muted-foreground text-sm mb-4">Quando você fizer seu primeiro pedido, ele aparecerá aqui.</p>
        <Button onClick={() => navigate('/')} className="bg-blue-700 hover:bg-blue-800">Explorar produtos</Button>
      </div>
    );
  }

  return (
    <>
      <div className="space-y-3">
        {orders.map((order) => {
          const itemCount = (order.items || []).reduce((s, i) => s + (i.quantity || 0), 0);
          return (
            <div key={order.id} className="rounded-xl border border-border bg-card p-4 shadow-sm">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div className="min-w-0">
                  <div className="flex items-center gap-2 flex-wrap">
                    <span className="font-semibold">Pedido #{order.id.substring(0, 8).toUpperCase()}</span>
                    {statusBadge(order.status)}
                  </div>
                  <p className="text-xs text-muted-foreground mt-1">
                    {new Date(order.created_date).toLocaleString('pt-BR')} · {itemCount} {itemCount === 1 ? 'item' : 'itens'}
                  </p>
                </div>
                <div className="text-right">
                  <p className="text-lg font-bold">{formatCurrency(order.total)}</p>
                  <p className="text-xs text-muted-foreground">{PAYMENT_METHODS[order.payment_method] || '—'}</p>
                </div>
              </div>

              {order.tracking_code && (
                <div className="mt-3 flex items-center gap-2 text-xs text-muted-foreground bg-muted/40 rounded-lg px-3 py-2">
                  <Truck className="w-4 h-4 text-blue-600" />
                  Rastreamento: <span className="font-mono font-medium text-foreground">{order.tracking_code}</span>
                  {order.carrier && <span>· {order.carrier}</span>}
                </div>
              )}

              <div className="mt-3 flex flex-wrap gap-2">
                <Button size="sm" variant="outline" onClick={() => setSelected(order)}>
                  <Eye className="w-4 h-4" /> Ver detalhes
                </Button>
                <Button size="sm" variant="outline" onClick={() => repeatOrder(order)}>
                  <RotateCw className="w-4 h-4" /> Repetir pedido
                </Button>
                <Button size="sm" variant="outline" onClick={() => downloadPDF(order)} disabled={pdfLoadingId === order.id}>
                  {pdfLoadingId === order.id ? <Loader2 className="w-4 h-4 animate-spin" /> : <FileDown className="w-4 h-4" />}
                  Baixar PDF
                </Button>
                <Button size="sm" variant="outline" onClick={() => sharePDF(order)} disabled={pdfLoadingId === order.id}>
                  {pdfLoadingId === order.id ? <Loader2 className="w-4 h-4 animate-spin" /> : <Share2 className="w-4 h-4" />}
                  Compartilhar
                </Button>
              </div>
            </div>
          );
        })}
      </div>

      <AccountOrderDetail order={selected} productMap={productMap} onClose={() => setSelected(null)} />
    </>
  );
}