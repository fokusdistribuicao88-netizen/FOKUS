import React, { useState, useMemo, useEffect, useRef } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  Search, X, Plus, Check, UserRound, ChevronDown, Building2, Phone, MapPin, Users,
} from "lucide-react";
import { formatBRL } from "@/lib/format";

/**
 * Painel flutuante de busca de clientes — modelo unificado (mesmo padrão do ProductPicker).
 *
 * Controlado: passar `open` + `onOpenChange` (pai desenha o gatilho).
 * Não controlado: desenha o próprio gatilho (triggerVariant).
 *
 * Props:
 *  customers               -> lista de clientes
 *  onSelect(customer|null) -> chamado ao escolher um cliente
 *  selectedId              -> id do cliente selecionado (destaque)
 *  allowConsumerFinal      -> inclui um card "Consumidor Final" que dispara onSelect(null)
 *  consumerFinalLabel      -> texto da opção consumidor final
 *  triggerVariant          -> 'button' | 'select'
 *  triggerLabel            -> texto do gatilho
 *  open / onOpenChange     -> modo controlado
 */
export default function CustomerPicker({
  customers = [],
  employees = [],
  onSelect,
  selectedId = null,
  allowConsumerFinal = false,
  consumerFinalLabel = "Consumidor Final",
  triggerVariant = "button",
  triggerLabel = "Selecionar cliente",
  triggerClassName = "",
  open: controlledOpen,
  onOpenChange,
}) {
  const [internalOpen, setInternalOpen] = useState(false);
  const [query, setQuery] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");
  const searchRef = useRef(null);

  const isControlled = typeof controlledOpen === "boolean";
  const isOpen = isControlled ? controlledOpen : internalOpen;
  const setOpen = (v) => (isControlled ? onOpenChange?.(v) : setInternalOpen(v));

  useEffect(() => {
    if (isOpen) setTimeout(() => searchRef.current?.focus(), 120);
  }, [isOpen]);

  // Funcionários ativos transformados em itens unificados com badge
  const employeeItems = useMemo(() => (employees || [])
    .filter((e) => e.status !== 'inactive')
    .map((e) => ({
      ...e,
      _isEmployee: true,
      company: e.role ? `Cargo: ${e.role}` : 'Funcionário',
    })), [employees]);

  const showEmployees = employeeItems.length > 0;

  const filteredCustomers = useMemo(() => {
    const q = query.trim().toLowerCase();
    return customers.filter((c) => {
      if (statusFilter === "active" && c.status === "inactive") return false;
      if (statusFilter === "inactive" && c.status !== "inactive") return false;
      if (!q) return true;
      return [c.name, c.cpf_cnpj, c.company, c.email, c.phone, c.city, c.state, c.address]
        .some((f) => String(f || "").toLowerCase().includes(q));
    });
  }, [customers, query, statusFilter]);

  const filteredEmployees = useMemo(() => {
    if (!showEmployees) return [];
    const q = query.trim().toLowerCase();
    return employeeItems.filter((e) => {
      if (!q) return true;
      return [e.name, e.cpf, e.phone, e.role, e.user_email]
        .some((f) => String(f || "").toLowerCase().includes(q));
    });
  }, [employeeItems, query, showEmployees]);

  const handlePick = (c) => {
    onSelect?.(c);
    setOpen(false);
    setQuery("");
  };

  const allItems = [...customers, ...employeeItems];
  const selected = selectedId ? allItems.find((c) => c.id === selectedId) : null;

  return (
    <>
      {!isControlled && triggerVariant === "button" && (
        <Button
          type="button"
          variant="outline"
          size="sm"
          onClick={() => setOpen(true)}
          className={`gap-1.5 ${triggerClassName}`}
        >
          <Plus className="h-4 w-4" /> {triggerLabel}
        </Button>
      )}

      {!isControlled && triggerVariant === "select" && (
        <button
          type="button"
          onClick={() => setOpen(true)}
          className={`flex h-9 w-full items-center justify-between rounded-md border border-input bg-transparent px-3 py-2 text-sm shadow-sm hover:bg-accent ${triggerClassName}`}
        >
          <span className={selected ? "text-foreground truncate" : "text-muted-foreground"}>
            {selected ? selected.name : triggerLabel}
          </span>
          <ChevronDown className="h-4 w-4 opacity-50 shrink-0" />
        </button>
      )}

      <AnimatePresence>
        {isOpen && (
          <>
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setOpen(false)}
              className="fixed inset-0 z-[60] bg-black/40"
            />
            <motion.div
              initial={{ x: "100%" }}
              animate={{ x: 0 }}
              exit={{ x: "100%" }}
              transition={{ type: "spring", stiffness: 320, damping: 32 }}
              className="fixed right-0 top-0 bottom-0 z-[61] w-[88vw] max-w-sm bg-card border-l shadow-2xl flex flex-col safe-area-top safe-area-bottom"
            >
              <div className="p-3 border-b bg-muted/30">
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center gap-2">
                    <Users className="h-5 w-5 text-primary" />
                    <h3 className="font-semibold text-sm">Buscar Clientes</h3>
                  </div>
                  <button
                    type="button"
                    onClick={() => setOpen(false)}
                    className="w-9 h-9 flex items-center justify-center rounded-full hover:bg-accent touch-manipulation"
                    aria-label="Fechar"
                  >
                    <X className="h-5 w-5" />
                  </button>
                </div>
                <div className="relative">
                  <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                  <Input
                    ref={searchRef}
                    value={query}
                    onChange={(e) => setQuery(e.target.value)}
                    placeholder="Nome, CPF/CNPJ, empresa, telefone, cidade..."
                    className="pl-8"
                  />
                </div>
                <div className="flex items-center gap-1.5 mt-2 overflow-x-auto pb-1 no-scrollbar">
                  {[
                    { v: "all", l: "Todos" },
                    { v: "active", l: "Ativos" },
                    { v: "inactive", l: "Inativos" },
                  ].map((s) => (
                    <button
                      key={s.v}
                      type="button"
                      onClick={() => setStatusFilter(s.v)}
                      className={`shrink-0 px-2.5 py-1 rounded-full text-xs font-medium border transition-colors ${
                        statusFilter === s.v
                          ? "bg-primary text-primary-foreground border-primary"
                          : "bg-background border-border hover:bg-accent"
                      }`}
                    >
                      {s.l}
                    </button>
                  ))}
                </div>
              </div>

              <div className="flex-1 overflow-y-auto p-2 space-y-2">
                <div className="text-xs text-muted-foreground px-1 pt-1 pb-2">
                  {filteredCustomers.length + filteredEmployees.length} registro(s) — toque para selecionar
                </div>

                {allowConsumerFinal && (
                  <button
                    type="button"
                    onClick={() => handlePick(null)}
                    className="w-full rounded-lg border-2 border-dashed border-primary/40 bg-primary/5 p-3 flex items-center gap-3 hover:bg-primary/10 transition-colors text-left"
                  >
                    <div className="w-10 h-10 shrink-0 rounded-full bg-primary/10 flex items-center justify-center">
                      <UserRound className="h-5 w-5 text-primary" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium">{consumerFinalLabel}</p>
                      <p className="text-xs text-muted-foreground">Venda sem cliente vinculado</p>
                    </div>
                  </button>
                )}

                {filteredCustomers.length === 0 && filteredEmployees.length === 0 && (
                  <div className="text-center py-12 text-muted-foreground text-sm">
                    <Users className="h-10 w-10 mx-auto mb-2 opacity-40" />
                    Nenhum registro encontrado.
                  </div>
                )}

                {showEmployees && filteredEmployees.length > 0 && (
                  <>
                    <p className="text-[10px] font-semibold uppercase tracking-wider text-muted-foreground px-1 pt-1">Funcionários</p>
                    {filteredEmployees.map((e) => {
                      const marked = e.id === selectedId;
                      return (
                        <button
                          key={`emp_${e.id}`}
                          type="button"
                          onClick={() => handlePick(e)}
                          className={`w-full rounded-lg border bg-background p-2.5 flex gap-2.5 hover:border-primary/40 hover:shadow-sm transition-colors text-left ${
                            marked ? "border-emerald-400 bg-emerald-50/50" : "border-border"
                          }`}
                        >
                          <div className="w-11 h-11 shrink-0 rounded-full bg-blue-100 flex items-center justify-center">
                            <UserRound className="h-5 w-5 text-blue-700" />
                          </div>
                          <div className="flex-1 min-w-0">
                            <div className="flex items-start gap-2">
                              <div className="flex-1 min-w-0">
                                <p className="text-sm font-medium leading-tight truncate">{e.name}</p>
                                <div className="flex items-center flex-wrap gap-x-2 gap-y-0.5 mt-0.5 text-xs text-muted-foreground">
                                  {e.role && <span className="truncate">{e.role}</span>}
                                  {e.cpf && <span className="font-mono">{e.cpf}</span>}
                                </div>
                              </div>
                              <Badge className="shrink-0 text-[10px] bg-blue-600 text-white">FUNCIONÁRIO</Badge>
                              {marked && (
                                <span className="flex items-center gap-0.5 text-xs text-emerald-600 font-medium shrink-0">
                                  <Check className="h-3.5 w-3.5" />
                                </span>
                              )}
                            </div>
                            <div className="flex items-center flex-wrap gap-x-3 gap-y-0.5 mt-1 text-xs text-muted-foreground">
                              {e.phone && <span className="flex items-center gap-0.5"><Phone className="h-3 w-3" /> {e.phone}</span>}
                            </div>
                          </div>
                        </button>
                      );
                    })}
                  </>
                )}

                {filteredCustomers.length > 0 && (
                  <>
                    {showEmployees && <p className="text-[10px] font-semibold uppercase tracking-wider text-muted-foreground px-1 pt-1">Clientes</p>}
                    {filteredCustomers.map((c) => {
                      const marked = c.id === selectedId;
                      const inactive = c.status === "inactive";
                      return (
                        <button
                          key={c.id}
                          type="button"
                          onClick={() => handlePick(c)}
                          className={`w-full rounded-lg border bg-background p-2.5 flex gap-2.5 hover:border-primary/40 hover:shadow-sm transition-colors text-left ${
                            marked ? "border-emerald-400 bg-emerald-50/50" : "border-border"
                          }`}
                        >
                          <div className="w-11 h-11 shrink-0 rounded-full bg-muted/50 flex items-center justify-center overflow-hidden">
                            {c.image_url ? (
                              <img src={c.image_url} alt={c.name} className="w-full h-full object-cover" />
                            ) : (
                              <UserRound className="h-5 w-5 text-muted-foreground" />
                            )}
                          </div>
                          <div className="flex-1 min-w-0">
                            <div className="flex items-start gap-2">
                              <div className="flex-1 min-w-0">
                                <p className="text-sm font-medium leading-tight truncate">{c.name}</p>
                                <div className="flex items-center flex-wrap gap-x-2 gap-y-0.5 mt-0.5 text-xs text-muted-foreground">
                                  {c.company && (
                                    <span className="flex items-center gap-0.5 truncate">
                                      <Building2 className="h-3 w-3" /> {c.company}
                                    </span>
                                  )}
                                  {c.cpf_cnpj && <span className="font-mono">{c.cpf_cnpj}</span>}
                                </div>
                              </div>
                              {showEmployees && <Badge variant="outline" className="shrink-0 text-[10px]">CLIENTE</Badge>}
                              {inactive && (
                                <Badge variant="outline" className="shrink-0 text-[10px]">inativo</Badge>
                              )}
                              {marked && (
                                <span className="flex items-center gap-0.5 text-xs text-emerald-600 font-medium shrink-0">
                                  <Check className="h-3.5 w-3.5" />
                                </span>
                              )}
                            </div>
                            <div className="flex items-center flex-wrap gap-x-3 gap-y-0.5 mt-1 text-xs text-muted-foreground">
                              {c.phone && (
                                <span className="flex items-center gap-0.5"><Phone className="h-3 w-3" /> {c.phone}</span>
                              )}
                              {(c.city || c.state) && (
                                <span className="flex items-center gap-0.5">
                                  <MapPin className="h-3 w-3" />{[c.city, c.state].filter(Boolean).join(" - ")}
                                </span>
                              )}
                              {c.credit_limit != null && Number(c.credit_limit) > 0 && (
                                <span>Crédito: {formatBRL(Number(c.credit_limit))}</span>
                              )}
                            </div>
                          </div>
                        </button>
                      );
                    })}
                  </>
                )}
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </>
  );
}