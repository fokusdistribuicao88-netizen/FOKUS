import React, { useMemo, useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { ZoomIn, ZoomOut, FileText } from 'lucide-react';
import { buildTemplatePdf, buildReportPdf, pageMm } from '@/lib/pdfTemplateRender';
import { loadImageDataUrlsForConfig } from '@/lib/pdfTemplateImages';
import { REPORT_DOC_TYPES, sampleSectionsFor } from '@/lib/pdfTemplateDefaults';
import { generatePixBrCode } from '@/lib/pixBrCode';
import QRCode from 'qrcode';

const PX = 3.7795;

export default function TemplatePreview({ config, sampleData, doc }) {
  const [zoom, setZoom] = useState(0.6);
  const [images, setImages] = useState({});

  const imageConfigs = useMemo(() => {
    const make = (i) => (i && i.url ? { url: i.url, rotation: i.rotation || 0 } : null);
    return [make(config?.header?.leftImage), make(config?.header?.rightImage)].filter(Boolean);
  }, [config?.header?.leftImage?.url, config?.header?.leftImage?.rotation, config?.header?.rightImage?.url, config?.header?.rightImage?.rotation]);

  const key = imageConfigs.map((c) => `${c.url}@${c.rotation || 0}`).join('|');
  const pixKey = sampleData?.pixPayment?.pixKey || '';
  const pixAmount = sampleData?.pixPayment?.amount || 0;
  const pixName = sampleData?.pixPayment?.employeeName || '';

  useEffect(() => {
    let active = true;
    const loadAll = async () => {
      const m = {};
      if (key) Object.assign(m, await loadImageDataUrlsForConfig(imageConfigs));
      if (pixKey) {
        try {
          const brCode = generatePixBrCode({ key: pixKey, amount: pixAmount, beneficiary: pixName, city: 'SAO PAULO' });
          const qrDataUrl = await QRCode.toDataURL(brCode, { width: 300, margin: 1 });
          m['__pix_qr__'] = { dataURL: qrDataUrl, w: 300, h: 300 };
        } catch { /* skip QR generation */ }
      }
      if (active) setImages(m);
    };
    loadAll();
    return () => { active = false; };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [key, pixKey, pixAmount, pixName]);

  const isReport = doc ? REPORT_DOC_TYPES.includes(doc.type) : false;

  const url = useMemo(() => {
    try {
      if (isReport) {
        const sections = sampleSectionsFor(doc);
        const meta = { title: config?.body?.title || doc?.label || 'Relatório' };
        // Injeta o BR Code gerado nos dados de exemplo para que a seção PIX
        // (QR Code da folha de pagamento) seja renderizada na pré-visualização.
        const previewData = images['__pix_qr__'] && sampleData?.pixPayment
          ? { ...sampleData, pixPayment: { ...sampleData.pixPayment, brCode: '__preview__' } }
          : sampleData;
        return buildReportPdf(config, sections, meta, images, null, previewData || {}).output('bloburl');
      }
      return buildTemplatePdf(config, sampleData, images).output('bloburl');
    } catch {
      return '';
    }
  }, [config, sampleData, images, isReport, doc]);

  const { w, h } = config ? pageMm(config) : { w: 210, h: 297 };
  const bw = w * PX, bh = h * PX;

  return (
    <div className="flex flex-col h-full">
      <div className="flex items-center justify-between mb-2">
        <span className="text-sm font-semibold flex items-center gap-2"><FileText className="w-4 h-4 text-violet-600" /> Pré-visualização</span>
        <div className="flex items-center gap-1">
          <Button size="icon" variant="outline" className="h-7 w-7" onClick={() => setZoom((z) => Math.max(0.3, z - 0.1))}><ZoomOut className="w-3.5 h-3.5" /></Button>
          <span className="text-xs text-muted-foreground w-10 text-center">{Math.round(zoom * 100)}%</span>
          <Button size="icon" variant="outline" className="h-7 w-7" onClick={() => setZoom((z) => Math.min(1.5, z + 0.1))}><ZoomIn className="w-3.5 h-3.5" /></Button>
        </div>
      </div>
      <div className="flex-1 overflow-auto bg-muted/40 rounded-xl p-4 flex justify-center">
        <div style={{ width: bw * zoom, height: bh * zoom }} className="bg-white shadow-lg shrink-0 relative">
          {url ? (
            <iframe title="preview" src={url} style={{ width: bw, height: bh, transform: `scale(${zoom})`, transformOrigin: 'top left', border: 0 }} />
          ) : (
            <div className="flex items-center justify-center h-full text-xs text-muted-foreground">Gerando...</div>
          )}
          {(config?.spacing?.showGuides || config?.spacing?.showGrid) && (
            <div style={{ position: 'absolute', top: 0, left: 0, width: bw, height: bh, transform: `scale(${zoom})`, transformOrigin: 'top left', pointerEvents: 'none', zIndex: 5 }}>
              {config.spacing.showGrid && Array.from({ length: Math.floor(w / 5) + 1 }, (_, i) => (
                <div key={'vg' + i} style={{ position: 'absolute', left: i * 5 * PX, top: 0, width: 1, height: bh, background: 'rgba(99,102,241,0.12)' }} />
              ))}
              {config.spacing.showGrid && Array.from({ length: Math.floor(h / 5) + 1 }, (_, i) => (
                <div key={'hg' + i} style={{ position: 'absolute', top: i * 5 * PX, left: 0, height: 1, width: bw, background: 'rgba(99,102,241,0.12)' }} />
              ))}
              {config.spacing.showGuides && (() => {
                const mg = config.page?.margin || {};
                const mlg = (mg.left ?? 14) * PX, mtg = (mg.top ?? 18) * PX, mrg = (mg.right ?? 14) * PX, mbg = (mg.bottom ?? 18) * PX;
                return (
                  <>
                    <div style={{ position: 'absolute', left: mlg, top: mtg, width: bw - mlg - mrg, height: bh - mtg - mbg, border: '1px dashed rgba(239,68,68,0.6)' }} />
                    <div style={{ position: 'absolute', left: mlg, top: 0, width: 1, height: bh, background: 'rgba(239,68,68,0.35)' }} />
                    <div style={{ position: 'absolute', left: bw - mrg, top: 0, width: 1, height: bh, background: 'rgba(239,68,68,0.35)' }} />
                    <div style={{ position: 'absolute', top: mtg, left: 0, height: 1, width: bw, background: 'rgba(239,68,68,0.35)' }} />
                    <div style={{ position: 'absolute', top: bh - mbg, left: 0, height: 1, width: bw, background: 'rgba(239,68,68,0.35)' }} />
                  </>
                );
              })()}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}