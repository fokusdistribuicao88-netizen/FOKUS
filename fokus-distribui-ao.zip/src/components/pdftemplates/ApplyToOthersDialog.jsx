import React, { useState } from 'react';
import { PDF_DOCUMENTS } from '@/lib/pdfTemplateDefaults';
import { Button } from '@/components/ui/button';
import { Checkbox } from '@/components/ui/checkbox';
import { Label } from '@/components/ui/label';
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter, DialogClose,
} from '@/components/ui/dialog';
import { Copy, Loader2 } from 'lucide-react';

export default function ApplyToOthersDialog({ open, onOpenChange, currentType, currentLabel, onApply, applying }) {
  const [selected, setSelected] = useState([]);

  const others = PDF_DOCUMENTS.filter((d) => d.type !== currentType && d.type !== '__global_header');

  const toggle = (type) => {
    setSelected((s) => (s.includes(type) ? s.filter((t) => t !== type) : [...s, type]));
  };

  const handleApply = () => onApply(selected);

  const grouped = others.reduce((acc, d) => {
    (acc[d.category] = acc[d.category] || []).push(d);
    return acc;
  }, {});

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-lg max-h-[85vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2"><Copy className="w-5 h-5 text-violet-600" /> Aplicar configuração em outros modelos</DialogTitle>
          <DialogDescription>
            Copia o estilo atual de <strong>{currentLabel}</strong> (cabeçalho, rodapé, corpo, cores, fontes, espaçamento, marca d'água e página) para os modelos selecionados. Os campos/colunas de cada documento são preservados.
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4 py-2 max-h-[50vh] overflow-y-auto pr-1">
          {Object.entries(grouped).map(([cat, docs]) => (
            <div key={cat}>
              <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wide mb-1.5 capitalize">{cat}</p>
              <div className="space-y-1.5">
                {docs.map((d) => (
                  <label key={d.type} className="flex items-center gap-3 rounded-md border border-border px-3 py-2 cursor-pointer hover:bg-accent/50">
                    <Checkbox checked={selected.includes(d.type)} onCheckedChange={() => toggle(d.type)} />
                    <span className="text-sm font-medium">{d.label}</span>
                  </label>
                ))}
              </div>
            </div>
          ))}
        </div>

        {selected.length > 0 && (
          <p className="text-xs text-muted-foreground">{selected.length} modelo(s) selecionado(s).</p>
        )}

        <DialogFooter>
          <DialogClose asChild><Button variant="outline" disabled={applying}>Cancelar</Button></DialogClose>
          <Button onClick={handleApply} disabled={applying || selected.length === 0} className="gap-2 bg-violet-600 hover:bg-violet-700">
            {applying ? <Loader2 className="w-4 h-4 animate-spin" /> : <Copy className="w-4 h-4" />}
            Aplicar ({selected.length})
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}