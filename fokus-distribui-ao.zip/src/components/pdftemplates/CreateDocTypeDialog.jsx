import React, { useState } from 'react';
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from '@/components/ui/select';
import { Loader2, Plus } from 'lucide-react';
import { PDF_CATEGORIES } from '@/lib/pdfTemplateDefaults';

const slugify = (str) =>
  str.toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '')
    .replace(/[^a-z0-9]+/g, '_').replace(/^_+|_+$/g, '').slice(0, 40);

export default function CreateDocTypeDialog({ open, onOpenChange, onCreate, existingTypes = [], creating }) {
  const [label, setLabel] = useState('');
  const [category, setCategory] = useState('vendas');
  const [size, setSize] = useState('A4');
  const [orientation, setOrientation] = useState('portrait');
  const [error, setError] = useState('');

  const reset = () => { setLabel(''); setCategory('vendas'); setSize('A4'); setOrientation('portrait'); setError(''); };

  const handleClose = (v) => { if (!v) reset(); onOpenChange(v); };

  const submit = () => {
    const trimmed = label.trim();
    if (!trimmed) { setError('Informe um nome para o documento.'); return; }
    let type = slugify(trimmed);
    if (!type) type = 'documento_' + Date.now().toString(36);
    if (existingTypes.includes(type)) { setError('Já existe um documento com esse nome. Escolha outro.'); return; }
    onCreate({ type, label: trimmed, category, size, orientation });
    reset();
  };

  return (
    <Dialog open={open} onOpenChange={handleClose}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2"><Plus className="w-5 h-5 text-violet-700" /> Novo tipo de documento</DialogTitle>
          <DialogDescription>Crie um modelo de PDF personalizado que passará a aparecer no sistema.</DialogDescription>
        </DialogHeader>
        <div className="space-y-3 py-2">
          <div className="space-y-1.5">
            <Label>Nome do documento</Label>
            <Input placeholder="Ex: Orçamento Especial" value={label} onChange={(e) => { setLabel(e.target.value); setError(''); }} autoFocus />
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-1.5">
              <Label>Categoria</Label>
              <Select value={category} onValueChange={setCategory}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  {PDF_CATEGORIES.map((c) => <SelectItem key={c.key} value={c.key}>{c.label}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-1.5">
              <Label>Tamanho</Label>
              <Select value={size} onValueChange={setSize}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="58">58mm (Térmica)</SelectItem>
                  <SelectItem value="80">80mm (Térmica)</SelectItem>
                  <SelectItem value="A4">A4</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          <div className="space-y-1.5">
            <Label>Orientação</Label>
            <Select value={orientation} onValueChange={setOrientation}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="portrait">Retrato</SelectItem>
                <SelectItem value="landscape">Paisagem</SelectItem>
              </SelectContent>
            </Select>
          </div>
          {error && <p className="text-xs text-destructive">{error}</p>}
        </div>
        <DialogFooter className="gap-2">
          <Button variant="outline" onClick={() => handleClose(false)}>Cancelar</Button>
          <Button onClick={submit} disabled={creating} className="gap-1.5 bg-violet-700 hover:bg-violet-800">
            {creating ? <Loader2 className="w-4 h-4 animate-spin" /> : <Plus className="w-4 h-4" />} Criar
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}