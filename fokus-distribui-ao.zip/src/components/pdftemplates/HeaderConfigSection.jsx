import React, { useState } from 'react';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { useAuth } from '@/lib/AuthContext';
import { useToast } from '@/components/ui/use-toast';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Button } from '@/components/ui/button';
import { Select, SelectTrigger, SelectValue, SelectContent, SelectItem } from '@/components/ui/select';
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import {
  Trash2, Image as ImageIcon, RotateCcw,
  Building2, MapPin, Type, Eye, EyeOff,
} from 'lucide-react';
import { getImageDimensions } from '@/lib/pdfTemplateImages';
import ImageTools from '@/components/pdftemplates/ImageTools';

const FONTS = [
  { value: 'helvetica', label: 'Helvetica' },
  { value: 'times', label: 'Times' },
  { value: 'courier', label: 'Courier' },
];

function Row({ label, children }) {
  return (
    <div className="flex items-center justify-between gap-3 py-1">
      <Label className="text-xs text-muted-foreground">{label}</Label>
      <div className="flex items-center gap-2">{children}</div>
    </div>
  );
}

function ImageLibraryDialog({ images, onPick, onDelete }) {
  const [q, setQ] = useState('');
  const filtered = (images || []).filter((i) => (i.label || '').toLowerCase().includes(q.toLowerCase()));
  return (
    <DialogContent className="max-w-2xl">
      <DialogHeader><DialogTitle>Biblioteca de imagens</DialogTitle></DialogHeader>
      <Input placeholder="Buscar..." value={q} onChange={(e) => setQ(e.target.value)} className="mb-3" />
      {filtered.length === 0 ? (
        <p className="text-sm text-muted-foreground text-center py-6">Nenhuma imagem enviada ainda.</p>
      ) : (
        <div className="grid grid-cols-3 sm:grid-cols-4 gap-3 max-h-[60vh] overflow-y-auto">
          {filtered.map((im) => (
            <div key={im.id} className="border border-border rounded-lg p-2 flex flex-col gap-1">
              <img src={im.url} alt={im.label} className="h-24 w-full object-contain bg-muted/30 rounded" />
              <span className="text-[10px] truncate" title={im.label}>{im.label || 'imagem'}</span>
              <span className="text-[9px] text-muted-foreground truncate">
                {im.width && im.height ? `${im.width}×${im.height}px` : ''}{im.created_date ? ` · ${new Date(im.created_date).toLocaleDateString('pt-BR')}` : ''}
              </span>
              <div className="flex gap-1">
                <Button size="sm" variant="outline" className="h-7 flex-1" onClick={() => onPick(im.url)}>Usar</Button>
                <Button size="sm" variant="outline" className="h-7" onClick={() => onDelete(im)}><Trash2 className="w-3.5 h-3.5" /></Button>
              </div>
            </div>
          ))}
        </div>
      )}
    </DialogContent>
  );
}

function GroupCard({ title, icon: Icon, children }) {
  return (
    <div className="border border-border rounded-xl p-3">
      <p className="text-xs font-semibold flex items-center gap-1.5 mb-2 text-foreground"><Icon className="w-3.5 h-3.5 text-violet-600" />{title}</p>
      {children}
    </div>
  );
}

function Field({ label, children }) {
  return (
    <div>
      <Label className="text-[10px] text-muted-foreground">{label}</Label>
      {children}
    </div>
  );
}

export default function HeaderConfigSection({ header, onHeaderChange, useGlobal, onUseGlobalChange }) {
  const { user } = useAuth();
  const { toast } = useToast();
  const qc = useQueryClient();
  const [libOpen, setLibOpen] = useState(false);
  const [libSide, setLibSide] = useState('leftImage');

  const { data: images = [] } = useQuery({ queryKey: ['pdf-images'], queryFn: () => base44.entities.PdfTemplateImage.list('-created_date'), staleTime: 30 * 1000 });

  if (!header) return null;
  const update = (patch) => onHeaderChange((prev) => ({ ...prev, ...patch }));
  const updateImg = (side, patch) => onHeaderChange((prev) => ({ ...prev, [side]: { ...prev[side], ...patch } }));
  const updateCenter = (patch) => onHeaderChange((prev) => ({ ...prev, center: { ...prev.center, ...patch } }));

  const upload = async (side, file) => {
    try {
      const { file_url } = await base44.integrations.Core.UploadFile({ file });
      const dims = await getImageDimensions(file_url);
      await base44.entities.PdfTemplateImage.create({ url: file_url, label: file.name, file_name: file.name, width: dims.w, height: dims.h, uploaded_by: user?.email });
      qc.invalidateQueries({ queryKey: ['pdf-images'] });
      updateImg(side, { url: file_url });
      toast({ title: 'Imagem enviada' });
    } catch (e) {
      toast({ title: 'Erro no upload', description: String(e.message || e), variant: 'destructive' });
    }
  };

  const openLib = (side) => { setLibSide(side); setLibOpen(true); };
  const pickFromLib = (url) => { updateImg(libSide, { url }); setLibOpen(false); };
  const deleteImage = async (im) => {
    try { await base44.entities.PdfTemplateImage.delete(im.id); qc.invalidateQueries({ queryKey: ['pdf-images'] }); toast({ title: 'Imagem removida' }); } catch { /* ignore */ }
  };

  const center = header.center || {};
  const centerWidth = Math.max(0, 100 - (header.leftWidth || 0) - (header.rightWidth || 0));

  return (
    <div className="space-y-3">
      <div className="border border-violet-200 bg-violet-50/40 dark:bg-violet-950/20 rounded-xl p-3 flex items-center justify-between gap-2 flex-wrap">
        <div>
          <p className="text-sm font-semibold">🖼️ Cabeçalho do PDF</p>
          <p className="text-xs text-muted-foreground">Imagem à esquerda · informações centrais · imagem à direita.</p>
        </div>
        <div className="flex items-center gap-2">
          <Label className="text-xs">Aplicar em todos</Label>
          <Switch checked={useGlobal} onCheckedChange={onUseGlobalChange} />
        </div>
      </div>

      <div className="border border-border rounded-xl p-3 space-y-1">
        <p className="text-xs font-semibold text-muted-foreground mb-1">Faixa do cabeçalho</p>
        <Row label="Exibir cabeçalho"><Switch checked={!!header.enabled} onCheckedChange={(v) => update({ enabled: v })} /></Row>
        <Row label="Altura (mm)"><Input type="number" value={header.height || 28} onChange={(e) => update({ height: Number(e.target.value) })} className="w-20 h-8 text-xs" /></Row>
        <Row label="Cor de fundo"><input type="color" value={header.bgColor || '#ffffff'} onChange={(e) => update({ bgColor: e.target.value })} className="w-8 h-8 rounded border border-border" /></Row>
        <Row label="Borda inferior"><Switch checked={!!header.showBorder} onCheckedChange={(v) => update({ showBorder: v })} /></Row>
        <div className="flex items-center justify-between pt-1">
          <Label className="text-[10px] text-muted-foreground">Largura das colunas (%)</Label>
          <Button size="sm" variant="ghost" className="h-6 gap-1 text-[10px] px-2" onClick={() => update({ leftWidth: 25, rightWidth: 25 })} title="Restaurar proporção padrão 25/50/25"><RotateCcw className="w-3 h-3" /> Padrão</Button>
        </div>
        <div className="grid grid-cols-3 gap-2">
          <div><Label className="text-[10px] text-muted-foreground">Esq.</Label><Input type="number" min="0" max="45" value={header.leftWidth || 0} onChange={(e) => update({ leftWidth: Number(e.target.value) })} className="h-8 text-xs" /></div>
          <div><Label className="text-[10px] text-muted-foreground">Centro</Label><Input value={centerWidth} readOnly className="h-8 text-xs bg-muted/40" /></div>
          <div><Label className="text-[10px] text-muted-foreground">Dir.</Label><Input type="number" min="0" max="45" value={header.rightWidth || 0} onChange={(e) => update({ rightWidth: Number(e.target.value) })} className="h-8 text-xs" /></div>
        </div>
      </div>

      <Tabs defaultValue="left" className="w-full">
        <TabsList className="grid grid-cols-3 w-full">
          <TabsTrigger value="left" className="text-xs gap-1"><ImageIcon className="w-3.5 h-3.5" /> Imagem Esq.</TabsTrigger>
          <TabsTrigger value="center" className="text-xs gap-1"><Building2 className="w-3.5 h-3.5" /> Empresa</TabsTrigger>
          <TabsTrigger value="right" className="text-xs gap-1"><ImageIcon className="w-3.5 h-3.5" /> Imagem Dir.</TabsTrigger>
        </TabsList>
        <TabsContent value="left" className="mt-3">
          <ImageTools img={header.leftImage} onChange={(p) => updateImg('leftImage', p)} onUpload={(f) => upload('leftImage', f)} onPickFromLibrary={() => openLib('leftImage')} onRemove={() => updateImg('leftImage', { url: '' })} />
        </TabsContent>
        <TabsContent value="center" className="mt-3 space-y-3">
          <GroupCard title="Dados da Empresa" icon={Building2}>
            <div className="grid grid-cols-2 gap-2">
              {[['companyName', 'Nome da empresa'], ['fantasy', 'Nome fantasia'], ['legalName', 'Razão Social'], ['cnpj', 'CNPJ'], ['ie', 'Inscrição Estadual']].map(([k, lbl]) => (
                <Field key={k} label={lbl}><Input value={center[k] || ''} onChange={(e) => updateCenter({ [k]: e.target.value })} className="h-8 text-xs" /></Field>
              ))}
            </div>
          </GroupCard>
          <GroupCard title="Contato" icon={MapPin}>
            <div className="grid grid-cols-2 gap-2">
              {[['address', 'Endereço'], ['city', 'Cidade'], ['state', 'Estado'], ['zip', 'CEP'], ['phones', 'Telefones'], ['whatsapp', 'WhatsApp'], ['email', 'E-mail'], ['site', 'Site']].map(([k, lbl]) => (
                <Field key={k} label={lbl}><Input value={center[k] || ''} onChange={(e) => updateCenter({ [k]: e.target.value })} className="h-8 text-xs" /></Field>
              ))}
            </div>
          </GroupCard>
          <GroupCard title="Visibilidade das Informações" icon={Eye}>
            <p className="text-[10px] text-muted-foreground mb-2">Ative ou desative cada linha de informação da empresa exibida no cabeçalho.</p>
            <div className="space-y-0.5">
              {([
                ['showCompanyName', 'Nome da empresa'],
                ['showFantasy', 'Nome fantasia'],
                ['showLegalName', 'Razão Social'],
                ['showFiscal', 'CNPJ / Inscrição Estadual'],
                ['showAddress', 'Endereço / Cidade / CEP'],
                ['showContact', 'Telefones / WhatsApp'],
                ['showInternet', 'E-mail / Site'],
                ['showCustomText', 'Texto personalizado'],
              ]).map(([k, lbl]) => {
                const fields = center.fields || {};
                const checked = fields[k] !== false;
                return (
                  <div key={k} className="flex items-center justify-between gap-2 py-0.5">
                    <Label className="text-xs text-muted-foreground flex items-center gap-1.5">{checked ? <Eye className="w-3 h-3 text-emerald-600" /> : <EyeOff className="w-3 h-3 text-muted-foreground/50" />}{lbl}</Label>
                    <Switch checked={checked} onCheckedChange={(v) => updateCenter({ fields: { ...fields, [k]: v } })} />
                  </div>
                );
              })}
            </div>
          </GroupCard>
          <GroupCard title="Aparência" icon={Type}>
            <div className="grid grid-cols-2 gap-x-3 gap-y-1">
              <Row label="Fonte">
                <Select value={center.font || 'helvetica'} onValueChange={(v) => updateCenter({ font: v })}>
                  <SelectTrigger className="w-full h-8 text-xs"><SelectValue /></SelectTrigger>
                  <SelectContent>{FONTS.map((f) => <SelectItem key={f.value} value={f.value}>{f.label}</SelectItem>)}</SelectContent>
                </Select>
              </Row>
              <Row label="Cor"><input type="color" value={center.color || '#111827'} onChange={(e) => updateCenter({ color: e.target.value })} className="w-8 h-8 rounded border border-border" /></Row>
              <Row label="Tamanho"><Input type="number" value={center.size || 9} onChange={(e) => updateCenter({ size: Number(e.target.value) })} className="w-16 h-8 text-xs" /></Row>
              <Row label="Espaçamento"><Input type="number" step="0.1" value={center.lineHeight || 1.3} onChange={(e) => updateCenter({ lineHeight: Number(e.target.value) })} className="w-16 h-8 text-xs" /></Row>
            </div>
            <Row label="Alinhamento">
              <Select value={center.align || 'center'} onValueChange={(v) => updateCenter({ align: v })}>
                <SelectTrigger className="w-full h-8 text-xs"><SelectValue /></SelectTrigger>
                <SelectContent><SelectItem value="left">Esquerda</SelectItem><SelectItem value="center">Centro</SelectItem><SelectItem value="right">Direita</SelectItem></SelectContent>
              </Select>
            </Row>
            <div className="grid grid-cols-2 gap-x-3">
              <Row label="Negrito"><Switch checked={!!center.bold} onCheckedChange={(v) => updateCenter({ bold: v })} /></Row>
              <Row label="Itálico"><Switch checked={!!center.italic} onCheckedChange={(v) => updateCenter({ italic: v })} /></Row>
            </div>
          </GroupCard>
        </TabsContent>
        <TabsContent value="right" className="mt-3 space-y-3">
          <div className="border border-border rounded-xl p-3">
            <Row label="QR Code PIX com o valor da nota"><Switch checked={!!header.rightImage?.qrCode} onCheckedChange={(v) => updateImg('rightImage', { qrCode: v })} /></Row>
            <p className="text-[10px] text-muted-foreground mt-1">Quando ativo, gera um QR Code PIX (pagável) com o valor total da nota, usando a chave PIX cadastrada em Configurações, no lugar da imagem à direita.</p>
          </div>
          <ImageTools img={header.rightImage} onChange={(p) => updateImg('rightImage', p)} onUpload={(f) => upload('rightImage', f)} onPickFromLibrary={() => openLib('rightImage')} onRemove={() => updateImg('rightImage', { url: '' })} />
        </TabsContent>
      </Tabs>

      <Dialog open={libOpen} onOpenChange={setLibOpen}>
        <ImageLibraryDialog images={images} onPick={pickFromLib} onDelete={deleteImage} />
      </Dialog>
    </div>
  );
}