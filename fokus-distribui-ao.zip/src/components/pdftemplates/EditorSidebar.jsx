import React, { useEffect, useState } from 'react';
import { Accordion, AccordionItem, AccordionTrigger, AccordionContent } from '@/components/ui/accordion';
import { Input } from '@/components/ui/input';
import { Search, Heading, FileText, PanelBottom, AlignLeft, Palette, Droplet, ListPlus, Brush, Ruler, Briefcase, Layers } from 'lucide-react';
import HeaderConfigSection from '@/components/pdftemplates/HeaderConfigSection';
import ObjectsPanel from '@/components/pdftemplates/ObjectsPanel';
import PagePanel from './panels/PagePanel';
import FooterPanel from './panels/FooterPanel';
import BodyPanel from './panels/BodyPanel';
import StylePanel from './panels/StylePanel';
import WatermarkPanel from './panels/WatermarkPanel';
import FieldsPanel from './panels/FieldsPanel';
import ThemePanel from './panels/ThemePanel';
import SpacingPanel from './panels/SpacingPanel';
import PayrollPanel from './panels/PayrollPanel';

const PANELS = [
  { id: 'header', title: 'Cabeçalho', icon: Heading },
  { id: 'objects', title: 'Objetos', icon: Layers },
  { id: 'page', title: 'Página', icon: FileText },
  { id: 'footer', title: 'Rodapé', icon: PanelBottom },
  { id: 'body', title: 'Corpo', icon: AlignLeft },
  { id: 'style', title: 'Cores e Fontes', icon: Palette },
  { id: 'watermark', title: "Marca d'Água", icon: Droplet },
  { id: 'fields', title: 'Campos Dinâmicos', icon: ListPlus },
  { id: 'theme', title: 'Temas', icon: Brush },
  { id: 'spacing', title: 'Espaçamento', icon: Ruler },
  { id: 'payroll', title: 'Folha de Pagamento', icon: Briefcase },
];

export default function EditorSidebar({ config, onChange, header, onHeaderChange, useGlobal, onUseGlobalChange }) {
  const [open, setOpen] = useState(() => {
    try { return JSON.parse(localStorage.getItem('pdf-editor-panels')) || ['header', 'page']; } catch { return ['header', 'page']; }
  });
  const [q, setQ] = useState('');
  useEffect(() => { localStorage.setItem('pdf-editor-panels', JSON.stringify(open)); }, [open]);

  const ql = q.trim().toLowerCase();
  const visible = ql ? PANELS.filter((p) => p.title.toLowerCase().includes(ql)) : PANELS;
  const effectiveOpen = ql ? visible.map((p) => p.id) : open;

  const renderPanel = (id) => {
    switch (id) {
      case 'header': return <HeaderConfigSection header={header} onHeaderChange={onHeaderChange} useGlobal={useGlobal} onUseGlobalChange={onUseGlobalChange} />;
      case 'objects': return <ObjectsPanel config={config} onChange={onChange} />;
      case 'page': return <PagePanel config={config} onChange={onChange} />;
      case 'footer': return <FooterPanel config={config} onChange={onChange} />;
      case 'body': return <BodyPanel config={config} onChange={onChange} />;
      case 'style': return <StylePanel config={config} onChange={onChange} />;
      case 'watermark': return <WatermarkPanel config={config} onChange={onChange} />;
      case 'fields': return <FieldsPanel config={config} onChange={onChange} />;
      case 'theme': return <ThemePanel config={config} onChange={onChange} />;
      case 'spacing': return <SpacingPanel config={config} onChange={onChange} />;
      case 'payroll': return <PayrollPanel config={config} onChange={onChange} />;
      default: return null;
    }
  };

  return (
    <div className="flex flex-col h-full">
      <div className="p-2 border-b border-border">
        <div className="relative">
          <Search className="w-3.5 h-3.5 absolute left-2 top-2.5 text-muted-foreground" />
          <Input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Pesquisar ferramentas..." className="h-8 text-xs pl-7" />
        </div>
      </div>
      <div className="flex-1 overflow-y-auto p-2">
        <Accordion type="multiple" value={effectiveOpen} onValueChange={setOpen}>
          {visible.map((p) => {
            const Icon = p.icon;
            return (
              <AccordionItem key={p.id} value={p.id} className="border border-border rounded-xl mb-2 px-0 overflow-hidden bg-background">
                <AccordionTrigger className="px-3 py-2 text-sm font-semibold hover:no-underline hover:bg-accent/50">
                  <span className="flex items-center gap-2"><Icon className="w-4 h-4 text-violet-600" />{p.title}</span>
                </AccordionTrigger>
                <AccordionContent className="px-3 pb-3">{renderPanel(p.id)}</AccordionContent>
              </AccordionItem>
            );
          })}
        </Accordion>
      </div>
    </div>
  );
}