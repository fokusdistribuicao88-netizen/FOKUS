import React, { useRef, useState } from 'react';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Button } from '@/components/ui/button';
import { Select, SelectTrigger, SelectValue, SelectContent, SelectItem } from '@/components/ui/select';
import {
  Upload, Trash2, Image as ImageIcon, Library, Loader2, ZoomIn, ZoomOut, Maximize, Scan,
} from 'lucide-react';

const SCALE_PRESETS = [10, 25, 50, 75, 100, 125, 150, 200, 300];

const FIT_OPTIONS = [
  { value: 'contain', label: 'Contido na área' },
  { value: 'cover', label: 'Preencher área (cortar)' },
  { value: 'fill', label: 'Esticar' },
  { value: 'center', label: 'Centralizar' },
];

function Row({ label, children }) {
  return (
    <div className="flex items-center justify-between gap-3 py-1">
      <Label className="text-xs text-muted-foreground">{label}</Label>
      <div className="flex items-center gap-2">{children}</div>
    </div>
  );
}

export default function ImageTools({ img, onChange, onUpload, onPickFromLibrary, onRemove }) {
  const [uploading, setUploading] = useState(false);
  const [viewZoom, setViewZoom] = useState(1);
  const fileRef = useRef(null);

  const handleFile = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setUploading(true);
    try { await onUpload(file); } finally { setUploading(false); e.target.value = ''; }
  };

  const rotation = img?.rotation || 0;
  const scale = img?.scale ?? 100;

  return (
    <div className="space-y-3">
      {/* Pré-visualização com zoom (só afeta a edição, não o PDF) */}
      <div className="relative h-40 w-full rounded-lg border border-dashed border-border bg-muted/30 overflow-hidden flex items-center justify-center">
        {img?.url ? (
          <img
            src={img.url}
            alt=""
            className="max-h-full max-w-full object-contain transition-transform"
            style={{ transform: `scale(${viewZoom}) rotate(${rotation}deg)`, opacity: img?.opacity ?? 1 }}
          />
        ) : (
          <div className="flex flex-col items-center gap-1 text-muted-foreground">
            <ImageIcon className="w-7 h-7" />
            <span className="text-[10px]">Nenhuma imagem</span>
          </div>
        )}
        {img?.url && (
          <div className="absolute bottom-1.5 left-1.5 right-1.5 flex items-center justify-center gap-1 bg-background/80 backdrop-blur rounded-md py-1">
            <Button size="icon" variant="ghost" className="h-6 w-6" onClick={() => setViewZoom((z) => Math.max(0.2, +(z - 0.15).toFixed(2)))} title="Reduzir zoom"><ZoomOut className="w-3.5 h-3.5" /></Button>
            <span className="text-[10px] w-10 text-center tabular-nums">{Math.round(viewZoom * 100)}%</span>
            <Button size="icon" variant="ghost" className="h-6 w-6" onClick={() => setViewZoom((z) => Math.min(3, +(z + 0.15).toFixed(2)))} title="Aumentar zoom"><ZoomIn className="w-3.5 h-3.5" /></Button>
            <Button size="icon" variant="ghost" className="h-6 w-6" onClick={() => setViewZoom(1)} title="Tamanho real (100%)"><Scan className="w-3.5 h-3.5" /></Button>
            <Button size="icon" variant="ghost" className="h-6 w-6" onClick={() => setViewZoom(0.6)} title="Ajustar à tela"><Maximize className="w-3.5 h-3.5" /></Button>
          </div>
        )}
      </div>

      <div className="flex gap-2 flex-wrap">
        <input ref={fileRef} type="file" accept="image/png,image/jpeg,image/webp" className="hidden" onChange={handleFile} />
        <Button size="sm" variant="outline" className="h-8 gap-1.5 flex-1" onClick={() => fileRef.current?.click()} disabled={uploading} title="Enviar imagem do computador">
          {uploading ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Upload className="w-3.5 h-3.5" />} {img?.url ? 'Substituir' : 'Upload'}
        </Button>
        <Button size="sm" variant="outline" className="h-8 gap-1.5" onClick={onPickFromLibrary} title="Escolher da biblioteca de imagens"><Library className="w-3.5 h-3.5" /> Biblioteca</Button>
        {img?.url && <Button size="sm" variant="outline" className="h-8" onClick={onRemove} title="Remover imagem"><Trash2 className="w-3.5 h-3.5" /></Button>}
      </div>

      {/* Escala da imagem */}
      <div className="border border-border rounded-xl p-3 space-y-2">
        <p className="text-[11px] font-semibold flex items-center gap-1.5"><Scan className="w-3.5 h-3.5 text-violet-600" /> Escala da Imagem</p>
        <div className="flex items-center gap-2">
          <Select value={SCALE_PRESETS.includes(scale) ? String(scale) : '__custom'} onValueChange={(v) => onChange({ scale: v === '__custom' ? scale : Number(v) })}>
            <SelectTrigger className="h-8 text-xs flex-1"><SelectValue /></SelectTrigger>
            <SelectContent>
              {SCALE_PRESETS.map((s) => <SelectItem key={s} value={String(s)}>{s}%</SelectItem>)}
              <SelectItem value="__custom">Personalizado</SelectItem>
            </SelectContent>
          </Select>
          <Input type="number" min="10" max="400" value={scale} onChange={(e) => onChange({ scale: Math.max(10, Number(e.target.value) || 100) })} className="w-20 h-8 text-xs" />
        </div>
        <div className="grid grid-cols-2 gap-x-3 gap-y-1">
          <Row label="Largura (mm)"><Input type="number" value={img?.widthMm ?? 20} onChange={(e) => onChange({ widthMm: Number(e.target.value) })} className="w-20 h-8 text-xs" /></Row>
          <Row label="Altura (mm)"><Input type="number" value={img?.heightMm ?? 0} onChange={(e) => onChange({ heightMm: Number(e.target.value) })} className="w-20 h-8 text-xs" /></Row>
          <Row label="Margem (mm)"><Input type="number" value={img?.margin ?? 2} onChange={(e) => onChange({ margin: Number(e.target.value) })} className="w-16 h-8 text-xs" /></Row>
          <Row label="Manter proporção"><Switch checked={img?.lockRatio !== false} onCheckedChange={(v) => onChange({ lockRatio: v })} /></Row>
        </div>
      </div>

      {/* Ajuste da imagem no PDF */}
      <div className="border border-border rounded-xl p-3 space-y-2">
        <p className="text-[11px] font-semibold flex items-center gap-1.5"><Maximize className="w-3.5 h-3.5 text-violet-600" /> Ajuste no PDF</p>
        <Row label="Modo">
          <Select value={img?.fit || 'contain'} onValueChange={(v) => onChange({ fit: v })}>
            <SelectTrigger className="w-full h-8 text-xs"><SelectValue /></SelectTrigger>
            <SelectContent>
              {FIT_OPTIONS.map((o) => <SelectItem key={o.value} value={o.value}>{o.label}</SelectItem>)}
            </SelectContent>
          </Select>
        </Row>
      </div>

      {/* Posicionamento */}
      <div className="border border-border rounded-xl p-3 space-y-1">
        <p className="text-[11px] font-semibold flex items-center gap-1.5"><Scan className="w-3.5 h-3.5 text-violet-600" /> Posicionamento</p>
        <div className="grid grid-cols-2 gap-x-3 gap-y-1">
          <Row label="Posição X (mm)"><Input type="number" value={img?.posX ?? 0} onChange={(e) => onChange({ posX: Number(e.target.value) })} className="w-16 h-8 text-xs" /></Row>
          <Row label="Posição Y (mm)"><Input type="number" value={img?.posY ?? 0} onChange={(e) => onChange({ posY: Number(e.target.value) })} className="w-16 h-8 text-xs" /></Row>
        </div>
        <Row label="Alinhamento horizontal">
          <Select value={img?.hAlign || 'center'} onValueChange={(v) => onChange({ hAlign: v })}>
            <SelectTrigger className="w-full h-8 text-xs"><SelectValue /></SelectTrigger>
            <SelectContent><SelectItem value="left">Esquerda</SelectItem><SelectItem value="center">Centro</SelectItem><SelectItem value="right">Direita</SelectItem></SelectContent>
          </Select>
        </Row>
        <Row label="Alinhamento vertical">
          <Select value={img?.vAlign || 'center'} onValueChange={(v) => onChange({ vAlign: v })}>
            <SelectTrigger className="w-full h-8 text-xs"><SelectValue /></SelectTrigger>
            <SelectContent><SelectItem value="top">Topo</SelectItem><SelectItem value="center">Centro</SelectItem><SelectItem value="bottom">Base</SelectItem></SelectContent>
          </Select>
        </Row>
        <Row label="Rotação">
          <Select value={String(rotation)} onValueChange={(v) => onChange({ rotation: Number(v) })}>
            <SelectTrigger className="w-full h-8 text-xs"><SelectValue /></SelectTrigger>
            <SelectContent><SelectItem value="0">0°</SelectItem><SelectItem value="90">90°</SelectItem><SelectItem value="180">180°</SelectItem><SelectItem value="270">270°</SelectItem></SelectContent>
          </Select>
        </Row>
        <div>
          <Label className="text-xs text-muted-foreground">Transparência</Label>
          <input type="range" min="0.1" max="1" step="0.05" value={img?.opacity ?? 1} onChange={(e) => onChange({ opacity: Number(e.target.value) })} className="w-full" />
        </div>
        <div className="grid grid-cols-2 gap-x-3">
          <Row label="Borda"><Switch checked={!!img?.border} onCheckedChange={(v) => onChange({ border: v })} /></Row>
          <Row label="Cantos arredond."><Switch checked={!!img?.radius} onCheckedChange={(v) => onChange({ radius: v })} /></Row>
        </div>
      </div>
    </div>
  );
}