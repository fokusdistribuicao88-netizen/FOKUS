import React, { useMemo, useState } from 'react';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Switch } from '@/components/ui/switch';
import { Card } from '@/components/ui/card';
import { useToast } from '@/components/ui/use-toast';
import { useAuth } from '@/lib/AuthContext';
import { logActivity } from '@/lib/activityLog';
import { Plus, Search, Pencil, Copy, Trash2, Star, Eye, Layers, Loader2 } from 'lucide-react';
import WatermarkFormDialog from './WatermarkFormDialog';
import { PDF_DOCUMENTS } from '@/lib/pdfTemplateDefaults';

const TYPE_LABEL = { text: 'Texto', image: 'Imagem', mixed: 'Mista' };

export default function WatermarkLibrary() {
  const { user } = useAuth();
  const { toast } = useToast();
  const qc = useQueryClient();
  const [q, setQ] = useState('');
  const [formOpen, setFormOpen] = useState(false);
  const [editing, setEditing] = useState(null);
  const [preview, setPreview] = useState(null);

  const isAdmin = user?.role === 'admin';

  const { data: list = [], isLoading } = useQuery({
    queryKey: ['watermarks'],
    queryFn: () => base44.entities.Watermark.list('-updated_date'),
    staleTime: 20 * 1000,
  });

  const filtered = useMemo(() => {
    const ql = q.trim().toLowerCase();
    return ql ? list.filter((w) => (w.name || '').toLowerCase().includes(ql) || (w.code || '').toLowerCase().includes(ql)) : list;
  }, [list, q]);

  const openNew = () => { setEditing(null); setFormOpen(true); };
  const openEdit = (w) => { setEditing(w); setFormOpen(true); };

  const invalidate = () => qc.invalidateQueries({ queryKey: ['watermarks'] });

  const handleToggle = async (w) => {
    try {
      await base44.entities.Watermark.update(w.id, { status: w.status === 'active' ? 'inactive' : 'active' });
      invalidate();
    } catch (e) { toast({ title: 'Erro', description: String(e.message || e), variant: 'destructive' }); }
  };

  const handleDefault = async (w) => {
    try {
      // remove default from others
      const others = list.filter((x) => x.is_default && x.id !== w.id);
      if (others.length) await base44.entities.Watermark.bulkUpdate(others.map((o) => ({ id: o.id, is_default: false })));
      await base44.entities.Watermark.update(w.id, { is_default: true });
      logActivity({ action: 'watermark_set_default', description: `Marca d'água "${w.name}" definida como padrão`, user, entityType: 'Watermark', entityId: w.id });
      invalidate();
      toast({ title: 'Marca d\'água padrão definida' });
    } catch (e) { toast({ title: 'Erro', description: String(e.message || e), variant: 'destructive' }); }
  };

  const handleDuplicate = async (w) => {
    try {
      const { id, created_date, updated_date, created_by_id, ...rest } = w;
      await base44.entities.Watermark.create({ ...rest, name: `${w.name} (cópia)`, is_default: false, code: `${w.code || ''}-Copia` });
      invalidate();
      toast({ title: 'Marca d\'água duplicada' });
    } catch (e) { toast({ title: 'Erro', description: String(e.message || e), variant: 'destructive' }); }
  };

  const handleDelete = async (w) => {
    if (!confirm(`Excluir a marca d\'água "${w.name}"?`)) return;
    try {
      await base44.entities.Watermark.delete(w.id);
      logActivity({ action: 'watermark_delete', description: `Marca d'água "${w.name}" excluída`, user, entityType: 'Watermark', entityId: w.id });
      invalidate();
      toast({ title: 'Excluída' });
    } catch (e) { toast({ title: 'Erro', description: String(e.message || e), variant: 'destructive' }); }
  };

  const docLabel = (t) => PDF_DOCUMENTS.find((d) => d.type === t)?.label || t;

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between gap-2 flex-wrap">
        <div className="relative flex-1 max-w-sm">
          <Search className="w-4 h-4 absolute left-2.5 top-2.5 text-muted-foreground" />
          <Input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Buscar marca d'água..." className="pl-8" />
        </div>
        {isAdmin && <Button onClick={openNew} className="gap-2 bg-violet-600 hover:bg-violet-700"><Plus className="w-4 h-4" /> Nova Marca d'Água</Button>}
      </div>

      {isLoading ? (
        <div className="flex justify-center py-12"><Loader2 className="w-6 h-6 animate-spin text-violet-600" /></div>
      ) : filtered.length === 0 ? (
        <div className="text-center py-16 text-muted-foreground">
          <Layers className="w-10 h-10 mx-auto mb-3 opacity-40" />
          <p className="font-medium">Nenhuma marca d'água cadastrada</p>
          {isAdmin && <Button onClick={openNew} variant="outline" className="mt-3 gap-2"><Plus className="w-4 h-4" /> Criar primeira marca d'água</Button>}
        </div>
      ) : (
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-3">
          {filtered.map((w) => (
            <Card key={w.id} className="p-3 flex flex-col gap-2 relative">
              <div className="flex items-start justify-between gap-2">
                <div className="min-w-0">
                  <div className="flex items-center gap-1.5">
                    <p className="font-semibold truncate">{w.name}</p>
                    {w.is_default && <Star className="w-3.5 h-3.5 text-amber-500 fill-amber-400 shrink-0" />}
                  </div>
                  {w.code && <p className="text-[10px] text-muted-foreground">{w.code}</p>}
                </div>
                <Badge variant="secondary" className="text-[10px] shrink-0">{TYPE_LABEL[w.content_type]}</Badge>
              </div>

              {/* miniatura */}
              <div className="h-20 rounded-lg bg-muted/40 border border-border flex items-center justify-center overflow-hidden relative">
                {w.content_type === 'text' || (w.content_type === 'mixed' && w.text) ? (
                  <span style={{ color: w.text_color, fontSize: Math.min(22, w.text_size / 3), fontWeight: w.text_bold ? 'bold' : 'normal', fontStyle: w.text_italic ? 'italic' : 'normal', opacity: w.opacity, transform: `rotate(${w.rotation}deg)` }} className="text-center px-2 truncate">
                    {w.text || w.name}
                  </span>
                ) : null}
                {(w.content_type === 'image' || w.content_type === 'mixed') && w.image_url && (
                  <img src={w.image_url} alt="" style={{ opacity: w.opacity, transform: `rotate(${w.rotation}deg)` }} className="max-h-full max-w-full object-contain absolute inset-0 m-auto" />
                )}
              </div>

              <div className="flex items-center justify-between text-[10px] text-muted-foreground">
                <span className="capitalize">{w.category}</span>
                <span>{w.applicable_docs?.length ? `${w.applicable_docs.length} doc(s)` : 'Todos os docs'}</span>
              </div>
              <p className="text-[10px] text-muted-foreground">Atualizado {new Date(w.updated_date || w.created_date).toLocaleDateString('pt-BR')}</p>

              <div className="flex items-center justify-between pt-1 border-t border-border">
                <label className="flex items-center gap-1.5 text-[10px] text-muted-foreground cursor-pointer">
                  <Switch checked={w.status === 'active'} onCheckedChange={() => handleToggle(w)} disabled={!isAdmin} /> {w.status === 'active' ? 'Ativa' : 'Inativa'}
                </label>
                <div className="flex items-center gap-0.5">
                  <Button variant="ghost" size="icon" className="h-7 w-7" title="Visualizar" onClick={() => setPreview(w)}><Eye className="w-3.5 h-3.5" /></Button>
                  {isAdmin && <Button variant="ghost" size="icon" className="h-7 w-7" title="Editar" onClick={() => openEdit(w)}><Pencil className="w-3.5 h-3.5" /></Button>}
                  {isAdmin && <Button variant="ghost" size="icon" className="h-7 w-7" title="Duplicar" onClick={() => handleDuplicate(w)}><Copy className="w-3.5 h-3.5" /></Button>}
                  {isAdmin && <Button variant="ghost" size="icon" className="h-7 w-7" title="Definir padrão" onClick={() => handleDefault(w)}><Star className={`w-3.5 h-3.5 ${w.is_default ? 'fill-amber-400 text-amber-500' : ''}`} /></Button>}
                  {isAdmin && <Button variant="ghost" size="icon" className="h-7 w-7 text-destructive hover:text-destructive" title="Excluir" onClick={() => handleDelete(w)}><Trash2 className="w-3.5 h-3.5" /></Button>}
                </div>
              </div>
            </Card>
          ))}
        </div>
      )}

      <WatermarkFormDialog open={formOpen} onOpenChange={setFormOpen} watermark={editing} onSaved={invalidate} />

      {preview && (
        <div className="fixed inset-0 z-50 bg-black/60 flex items-center justify-center p-4" onClick={() => setPreview(null)}>
          <div className="bg-card rounded-2xl max-w-2xl w-full p-4" onClick={(e) => e.stopPropagation()}>
            <div className="flex items-center justify-between mb-3">
              <h3 className="font-bold flex items-center gap-2"><Layers className="w-5 h-5 text-violet-600" /> {preview.name}</h3>
              <Button variant="ghost" size="icon" onClick={() => setPreview(null)}><Trash2 className="w-4 h-4 rotate-45" /></Button>
            </div>
            <div className="relative h-72 rounded-lg border border-border bg-white overflow-hidden">
              {preview.content_type === 'text' || (preview.content_type === 'mixed' && preview.text) ? (
                <span style={{ color: preview.text_color, fontSize: Math.min(56, preview.text_size), fontWeight: preview.text_bold ? 'bold' : 'normal', fontStyle: preview.text_italic ? 'italic' : 'normal', opacity: preview.opacity, transform: `rotate(${preview.rotation}deg)` }} className="absolute inset-0 flex items-center justify-center text-center px-4">
                  {preview.text || preview.name}
                </span>
              ) : null}
              {(preview.content_type === 'image' || preview.content_type === 'mixed') && preview.image_url && (
                <img src={preview.image_url} alt="" style={{ opacity: preview.opacity, transform: `rotate(${preview.rotation}deg)` }} className="max-h-full max-w-full object-contain absolute inset-0 m-auto" />
              )}
              {preview.repeat && <span className="absolute bottom-2 right-2 text-[10px] text-muted-foreground bg-card/80 px-1.5 py-0.5 rounded">Repetida</span>}
            </div>
            <div className="grid grid-cols-2 gap-2 mt-3 text-xs text-muted-foreground">
              <div>Tipo: <span className="text-foreground font-medium">{TYPE_LABEL[preview.content_type]}</span></div>
              <div>Categoria: <span className="text-foreground font-medium capitalize">{preview.category}</span></div>
              <div>Opacidade: <span className="text-foreground font-medium">{preview.opacity}</span></div>
              <div>Rotação: <span className="text-foreground font-medium">{preview.rotation}°</span></div>
              <div className="col-span-2">Documentos: <span className="text-foreground font-medium">{preview.applicable_docs?.length ? preview.applicable_docs.map(docLabel).join(', ') : 'Todos'}</span></div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}