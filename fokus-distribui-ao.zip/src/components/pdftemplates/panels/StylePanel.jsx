import React from 'react';
import { Select, SelectTrigger, SelectValue, SelectContent, SelectItem } from '@/components/ui/select';
import { Row, FONTS } from './shared';

export default function StylePanel({ config, onChange }) {
  const setColor = (patch) => onChange({ ...config, colors: { ...config.colors, ...patch } });
  const setFont = (patch) => onChange({ ...config, fonts: { ...config.fonts, ...patch } });
  const c = config.colors || {};
  return (
    <div className="space-y-1">
      {[['primary', 'Primária'], ['secondary', 'Secundária'], ['text', 'Texto'], ['muted', 'Suave'], ['background', 'Fundo']].map(([k, lbl]) => (
        <Row key={k} label={lbl}><input type="color" value={c[k] || '#000000'} onChange={(e) => setColor({ [k]: e.target.value })} className="w-8 h-8 rounded border border-border" /></Row>
      ))}
      <Row label="Fonte títulos">
        <Select value={config.fonts?.heading || 'helvetica'} onValueChange={(v) => setFont({ heading: v })}>
          <SelectTrigger className="w-36 h-8 text-xs"><SelectValue /></SelectTrigger>
          <SelectContent>{FONTS.map((f) => <SelectItem key={f.value} value={f.value}>{f.label}</SelectItem>)}</SelectContent>
        </Select>
      </Row>
      <Row label="Fonte corpo">
        <Select value={config.fonts?.body || 'helvetica'} onValueChange={(v) => setFont({ body: v })}>
          <SelectTrigger className="w-36 h-8 text-xs"><SelectValue /></SelectTrigger>
          <SelectContent>{FONTS.map((f) => <SelectItem key={f.value} value={f.value}>{f.label}</SelectItem>)}</SelectContent>
        </Select>
      </Row>
    </div>
  );
}