import React from 'react';
import { Input } from '@/components/ui/input';
import { Switch } from '@/components/ui/switch';
import { Row } from './shared';

export default function WatermarkPanel({ config, onChange }) {
  const setSec = (patch) => onChange({ ...config, watermark: { ...config.watermark, ...patch } });
  const w = config.watermark || {};
  return (
    <div className="space-y-1">
      <Row label="Exibir"><Switch checked={!!w.enabled} onCheckedChange={(v) => setSec({ enabled: v })} /></Row>
      <Row label="Texto"><Input value={w.text || ''} onChange={(e) => setSec({ text: e.target.value })} className="w-32 h-8 text-xs" /></Row>
      <Row label="Opacidade"><Input type="number" step="0.01" min="0.02" max="0.5" value={w.opacity ?? 0.08} onChange={(e) => setSec({ opacity: Number(e.target.value) })} className="w-20 h-8 text-xs" /></Row>
    </div>
  );
}