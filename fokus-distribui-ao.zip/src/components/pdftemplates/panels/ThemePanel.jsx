import React from 'react';
import { Select, SelectTrigger, SelectValue, SelectContent, SelectItem } from '@/components/ui/select';
import { Row } from './shared';
import { PDF_THEMES } from '@/lib/pdfTemplateDefaults';

export default function ThemePanel({ config, onChange }) {
  const apply = (key) => {
    const t = PDF_THEMES[key];
    if (!t) return;
    onChange({
      ...config,
      theme: key,
      colors: { primary: t.primary, secondary: t.secondary, text: t.text, muted: t.muted, background: t.background },
      body: { ...config.body, accent: t.accent },
    });
  };
  return (
    <Row label="Tema pronto">
      <Select value={config.theme || 'empresarial'} onValueChange={apply}>
        <SelectTrigger className="w-44 h-8 text-xs"><SelectValue /></SelectTrigger>
        <SelectContent>{Object.entries(PDF_THEMES).map(([k, t]) => <SelectItem key={k} value={k}>{t.label}</SelectItem>)}</SelectContent>
      </Select>
    </Row>
  );
}