import React from 'react';
import { Switch } from '@/components/ui/switch';
import { Select, SelectTrigger, SelectValue, SelectContent, SelectItem } from '@/components/ui/select';
import { ChevronUp, ChevronDown, X } from 'lucide-react';
import { DYNAMIC_FIELDS } from '@/lib/pdfTemplateDefaults';

export default function FieldsPanel({ config, onChange }) {
  const fields = config.fields || [];
  const update = (next) => onChange({ ...config, fields: next });
  const toggle = (i) => update(fields.map((f, idx) => (idx === i ? { ...f, visible: !f.visible } : f)));
  const remove = (i) => update(fields.filter((_, idx) => idx !== i));
  const move = (i, dir) => {
    const a = [...fields];
    const j = i + dir;
    if (j < 0 || j >= a.length) return;
    [a[i], a[j]] = [a[j], a[i]];
    update(a);
  };
  const add = (key) => {
    const def = DYNAMIC_FIELDS.find((f) => f.key === key);
    if (def && !fields.some((f) => f.key === key)) update([...fields, { ...def, visible: true }]);
  };
  const available = DYNAMIC_FIELDS.filter((f) => !fields.some((ff) => ff.key === f.key));
  return (
    <div className="space-y-1">
      {fields.map((f, i) => (
        <div key={f.key} className="flex items-center gap-2 py-1">
          <Switch checked={f.visible} onCheckedChange={() => toggle(i)} />
          <span className={`text-xs flex-1 ${f.visible ? '' : 'text-muted-foreground line-through'}`}>{f.label}</span>
          <button onClick={() => move(i, -1)} className="text-muted-foreground hover:text-foreground"><ChevronUp className="w-3.5 h-3.5" /></button>
          <button onClick={() => move(i, 1)} className="text-muted-foreground hover:text-foreground"><ChevronDown className="w-3.5 h-3.5" /></button>
          <button onClick={() => remove(i)} className="text-red-500 hover:text-red-700"><X className="w-3.5 h-3.5" /></button>
        </div>
      ))}
      {available.length > 0 && (
        <div className="pt-2 border-t border-border mt-2">
          <Select value="" onValueChange={add}>
            <SelectTrigger className="w-full h-8 text-xs"><SelectValue placeholder="Adicionar campo..." /></SelectTrigger>
            <SelectContent>{available.map((f) => <SelectItem key={f.key} value={f.key}>{f.label}</SelectItem>)}</SelectContent>
          </Select>
        </div>
      )}
    </div>
  );
}