import React from 'react';
import { Input } from '@/components/ui/input';
import { Switch } from '@/components/ui/switch';
import { Button } from '@/components/ui/button';
import { Row } from './shared';
import { RotateCcw } from 'lucide-react';
import { DEFAULT_SPACING } from '@/lib/pdfTemplateDefaults';

function Num({ value, onChange }) {
  return <Input type="number" value={value ?? 0} onChange={(e) => onChange(Number(e.target.value))} className="w-16 h-8 text-xs" />;
}

function Group({ title, children }) {
  return (
    <div className="border border-border rounded-xl p-3">
      <p className="text-xs font-semibold mb-1">{title}</p>
      {children}
    </div>
  );
}

export default function SpacingPanel({ config, onChange }) {
  const sp = config.spacing || {};
  const set = (patch) => onChange({ ...config, spacing: { ...sp, ...patch } });
  const setH = (patch) => set({ header: { ...(sp.header || {}), ...patch } });
  const setB = (patch) => set({ body: { ...(sp.body || {}), ...patch } });
  const setF = (patch) => set({ footer: { ...(sp.footer || {}), ...patch } });
  const restore = () => onChange({ ...config, spacing: JSON.parse(JSON.stringify(DEFAULT_SPACING)) });

  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between">
        <span className="text-xs font-semibold">Espaçamento e Posicionamento</span>
        <Button size="sm" variant="ghost" className="h-7 gap-1 text-[10px] px-2" onClick={restore} title="Restaurar espaçamentos padrão"><RotateCcw className="w-3 h-3" /> Padrão</Button>
      </div>
      <Row label="Guias visuais"><Switch checked={!!sp.showGuides} onCheckedChange={(v) => set({ showGuides: v })} /></Row>
      <Row label="Grade (grid)"><Switch checked={!!sp.showGrid} onCheckedChange={(v) => set({ showGrid: v })} /></Row>

      <Group title="Cabeçalho">
        <Row label="Topo → cabeçalho"><Num value={sp.header?.topToHeader} onChange={(v) => setH({ topToHeader: v })} /></Row>
        <Row label="Img. esq. → centro"><Num value={sp.header?.leftToCenter} onChange={(v) => setH({ leftToCenter: v })} /></Row>
        <Row label="Centro → img. dir."><Num value={sp.header?.centerToRight} onChange={(v) => setH({ centerToRight: v })} /></Row>
        <Row label="Padding interno"><Num value={sp.header?.padding} onChange={(v) => setH({ padding: v })} /></Row>
      </Group>

      <Group title="Corpo do documento">
        <Row label="Cabeçalho → título"><Num value={sp.body?.headerToTitle} onChange={(v) => setB({ headerToTitle: v })} /></Row>
        <Row label="Título → tabela"><Num value={sp.body?.titleToTable} onChange={(v) => setB({ titleToTable: v })} /></Row>
        <Row label="Cliente → produtos"><Num value={sp.body?.customerToProducts} onChange={(v) => setB({ customerToProducts: v })} /></Row>
        <Row label="Produtos → totais"><Num value={sp.body?.productsToTotals} onChange={(v) => setB({ productsToTotals: v })} /></Row>
        <Row label="Totais → observ."><Num value={sp.body?.totalsToObservations} onChange={(v) => setB({ totalsToObservations: v })} /></Row>
        <Row label="Observ. → rodapé"><Num value={sp.body?.observationsToFooter} onChange={(v) => setB({ observationsToFooter: v })} /></Row>
        <Row label="Seção → seção"><Num value={sp.body?.sectionGap} onChange={(v) => setB({ sectionGap: v })} /></Row>
        <Row label="Seção → PIX"><Num value={sp.body?.sectionToPix} onChange={(v) => setB({ sectionToPix: v })} /></Row>
      </Group>

      <Group title="Rodapé">
        <Row label="Conteúdo → rodapé"><Num value={sp.footer?.contentToFooter} onChange={(v) => setF({ contentToFooter: v })} /></Row>
        <Row label="Espaço entre itens"><Num value={sp.footer?.itemGap} onChange={(v) => setF({ itemGap: v })} /></Row>
      </Group>
    </div>
  );
}