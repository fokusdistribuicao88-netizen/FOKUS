import React from 'react';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Select, SelectTrigger, SelectValue, SelectContent, SelectItem } from '@/components/ui/select';
import { Row } from './shared';

export default function BodyPanel({ config, onChange }) {
  const setSec = (patch) => onChange({ ...config, body: { ...config.body, ...patch } });
  const b = config.body || {};
  return (
    <div className="space-y-1">
      <div><Label className="text-xs text-muted-foreground">Título</Label><Input value={b.title || ''} onChange={(e) => setSec({ title: e.target.value })} className="h-8 text-xs" /></div>
      <div><Label className="text-xs text-muted-foreground">Subtítulo</Label><Input value={b.subtitle || ''} onChange={(e) => setSec({ subtitle: e.target.value })} className="h-8 text-xs" /></div>
      <Row label="Estilo da tabela">
        <Select value={b.tableStyle || 'striped'} onValueChange={(v) => setSec({ tableStyle: v })}>
          <SelectTrigger className="w-36 h-8 text-xs"><SelectValue /></SelectTrigger>
          <SelectContent><SelectItem value="striped">Listrado</SelectItem><SelectItem value="plain">Simples</SelectItem></SelectContent>
        </Select>
      </Row>
      <Row label="Cor de destaque"><input type="color" value={b.accent || '#3b82f6'} onChange={(e) => setSec({ accent: e.target.value })} className="w-8 h-8 rounded border border-border" /></Row>
      <Row label="Exibir totais"><Switch checked={!!b.showTotals} onCheckedChange={(v) => setSec({ showTotals: v })} /></Row>
      <Row label="Exibir observações"><Switch checked={!!b.showObservations} onCheckedChange={(v) => setSec({ showObservations: v })} /></Row>
    </div>
  );
}