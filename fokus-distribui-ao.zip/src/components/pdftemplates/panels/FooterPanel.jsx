import React from 'react';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Row } from './shared';

export default function FooterPanel({ config, onChange }) {
  const setSec = (patch) => onChange({ ...config, footer: { ...config.footer, ...patch } });
  const f = config.footer || {};
  return (
    <div className="space-y-1">
      <Row label="Exibir"><Switch checked={!!f.enabled} onCheckedChange={(v) => setSec({ enabled: v })} /></Row>
      <Row label="Altura (mm)"><Input type="number" value={f.height || 18} onChange={(e) => setSec({ height: Number(e.target.value) })} className="w-20 h-8 text-xs" /></Row>
      <Row label="Cor de fundo"><input type="color" value={f.bgColor || '#ffffff'} onChange={(e) => setSec({ bgColor: e.target.value })} className="w-8 h-8 rounded border border-border" /></Row>
      <Row label="Numeração páginas"><Switch checked={!!f.showPageNumber} onCheckedChange={(v) => setSec({ showPageNumber: v })} /></Row>
      <Row label="Data e hora"><Switch checked={!!f.showDateTime} onCheckedChange={(v) => setSec({ showDateTime: v })} /></Row>
      <Row label="Usuário"><Switch checked={!!f.showUser} onCheckedChange={(v) => setSec({ showUser: v })} /></Row>
      <Row label="QR de validação"><Switch checked={!!f.showQR} onCheckedChange={(v) => setSec({ showQR: v })} /></Row>
      <div><Label className="text-xs text-muted-foreground">Texto legal</Label><Input value={f.legalText || ''} onChange={(e) => setSec({ legalText: e.target.value })} className="h-8 text-xs" /></div>
      <div><Label className="text-xs text-muted-foreground">Contato</Label><Input value={f.contactText || ''} onChange={(e) => setSec({ contactText: e.target.value })} className="h-8 text-xs" /></div>
      <div><Label className="text-xs text-muted-foreground">Redes sociais</Label><Input value={f.socialText || ''} onChange={(e) => setSec({ socialText: e.target.value })} className="h-8 text-xs" /></div>
    </div>
  );
}