import React from 'react';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectTrigger, SelectValue, SelectContent, SelectItem } from '@/components/ui/select';
import { Row } from './shared';

export default function PagePanel({ config, onChange }) {
  const setSec = (patch) => onChange({ ...config, page: { ...config.page, ...patch } });
  const setMargin = (patch) => onChange({ ...config, page: { ...config.page, margin: { ...config.page.margin, ...patch } } });
  return (
    <div className="space-y-1">
      <Row label="Tamanho">
        <Select value={config.page.size} onValueChange={(v) => setSec({ size: v })}>
          <SelectTrigger className="w-36 h-8 text-xs"><SelectValue /></SelectTrigger>
          <SelectContent>{['A4', 'A5', 'Carta', 'Oficio', '58', '80'].map((s) => <SelectItem key={s} value={s}>{s === '58' || s === '80' ? `Térmica ${s}mm` : s}</SelectItem>)}</SelectContent>
        </Select>
      </Row>
      <Row label="Orientação">
        <Select value={config.page.orientation} onValueChange={(v) => setSec({ orientation: v })}>
          <SelectTrigger className="w-36 h-8 text-xs"><SelectValue /></SelectTrigger>
          <SelectContent><SelectItem value="portrait">Retrato</SelectItem><SelectItem value="landscape">Paisagem</SelectItem></SelectContent>
        </Select>
      </Row>
      <div className="grid grid-cols-2 gap-2 pt-1">
        {['top', 'right', 'bottom', 'left'].map((k) => (
          <div key={k}>
            <Label className="text-[10px] text-muted-foreground capitalize">Margem {k} (mm)</Label>
            <Input type="number" value={config.page.margin[k]} onChange={(e) => setMargin({ [k]: Number(e.target.value) })} className="h-8 text-xs" />
          </div>
        ))}
      </div>
    </div>
  );
}