import React from 'react';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Select, SelectTrigger, SelectValue, SelectContent, SelectItem } from '@/components/ui/select';
import { Row } from './shared';

export default function PayrollPanel({ config, onChange }) {
  const setEmp = (patch) => onChange({ ...config, employeeInfo: { ...config.employeeInfo, ...patch } });
  const setPix = (patch) => onChange({ ...config, pixPayment: { ...config.pixPayment, ...patch } });
  const emp = config.employeeInfo || {};
  const pix = config.pixPayment || {};

  return (
    <div className="space-y-3">
      {/* Informações do funcionário */}
      <div className="space-y-1">
        <p className="text-xs font-semibold text-violet-700">Dados do Funcionário</p>
        <Row label="Exibir bloco"><Switch checked={!!emp.enabled} onCheckedChange={(v) => setEmp({ enabled: v })} /></Row>
        <Row label="CPF"><Switch checked={!!emp.showCpf} onCheckedChange={(v) => setEmp({ showCpf: v })} /></Row>
        <Row label="Cargo"><Switch checked={!!emp.showRole} onCheckedChange={(v) => setEmp({ showRole: v })} /></Row>
        <Row label="Data de admissão"><Switch checked={!!emp.showAdmissionDate} onCheckedChange={(v) => setEmp({ showAdmissionDate: v })} /></Row>
        <Row label="Competência"><Switch checked={!!emp.showCompetence} onCheckedChange={(v) => setEmp({ showCompetence: v })} /></Row>
        <Row label="Nº da folha"><Switch checked={!!emp.showPayrollId} onCheckedChange={(v) => setEmp({ showPayrollId: v })} /></Row>
        <Row label="Tipo de contratação"><Switch checked={!!emp.showEmployeeType} onCheckedChange={(v) => setEmp({ showEmployeeType: v })} /></Row>
        <Row label="Telefone"><Switch checked={!!emp.showPhone} onCheckedChange={(v) => setEmp({ showPhone: v })} /></Row>
        <Row label="Banco/Conta"><Switch checked={!!emp.showBank} onCheckedChange={(v) => setEmp({ showBank: v })} /></Row>
      </div>

      <div className="border-t border-border pt-2 space-y-1">
        <p className="text-xs font-semibold text-violet-700">QR Code PIX para Pagamento</p>
        <Row label="Ativar QR Code"><Switch checked={!!pix.enabled} onCheckedChange={(v) => setPix({ enabled: v })} /></Row>
        <div>
          <Label className="text-xs text-muted-foreground">Título da seção</Label>
          <Input value={pix.title || ''} onChange={(e) => setPix({ title: e.target.value })} className="h-8 text-xs" />
        </div>
        <Row label="Posição do QR Code">
          <Select value={pix.position || 'center'} onValueChange={(v) => setPix({ position: v })}>
            <SelectTrigger className="w-32 h-8 text-xs"><SelectValue /></SelectTrigger>
            <SelectContent>
              <SelectItem value="left">Esquerda</SelectItem>
              <SelectItem value="center">Centro</SelectItem>
              <SelectItem value="right">Direita</SelectItem>
            </SelectContent>
          </Select>
        </Row>
        <Row label="Tamanho (mm)">
          <Input type="number" min="15" max="60" value={pix.size || 30} onChange={(e) => setPix({ size: Number(e.target.value) || 30 })} className="h-8 w-20 text-xs" />
        </Row>
        <Row label="Exibir valor"><Switch checked={!!pix.showValue} onCheckedChange={(v) => setPix({ showValue: v })} /></Row>
        <Row label="Exibir chave PIX"><Switch checked={!!pix.showKey} onCheckedChange={(v) => setPix({ showKey: v })} /></Row>
        <Row label="Exibir nome do funcionário"><Switch checked={!!pix.showEmployeeName} onCheckedChange={(v) => setPix({ showEmployeeName: v })} /></Row>
        <p className="text-[10px] text-muted-foreground mt-1">
          O QR Code é gerado automaticamente com a chave PIX do funcionário e o valor líquido da folha. A chave é mascarada na exibição textual para segurança.
        </p>
      </div>
    </div>
  );
}