import React, { useState } from 'react';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import {
  Select, SelectTrigger, SelectValue, SelectContent, SelectItem,
} from '@/components/ui/select';
import { ChevronUp, ChevronDown, Eye, EyeOff, Settings2 } from 'lucide-react';

const BODY_BLOCKS = [
  { key: 'title', label: 'Título do Documento' },
  { key: 'meta', label: 'Dados do Documento (Nº, Data, Status)' },
  { key: 'customer', label: 'Cliente e Assinatura' },
  { key: 'items', label: 'Tabela de Itens' },
  { key: 'totals', label: 'Totais' },
  { key: 'observations', label: 'Observações' },
];

const FIXED_BLOCKS = [
  { key: 'header', label: 'Cabeçalho' },
  { key: 'footer', label: 'Rodapé' },
  { key: 'watermark', label: "Marca d'Água" },
];

const FONTS = [
  { value: 'helvetica', label: 'Helvetica' },
  { value: 'times', label: 'Times' },
  { value: 'courier', label: 'Courier' },
];

export default function ObjectsPanel({ config, onChange }) {
  const objects = config?.objects || {};
  const order = config?.objectOrder || BODY_BLOCKS.map((b) => b.key);
  const [expanded, setExpanded] = useState({});

  const setObj = (key, patch) => {
    onChange({ ...config, objects: { ...objects, [key]: { ...(objects[key] || {}), ...patch } } });
  };
  const toggleVis = (key) => setObj(key, { visible: (objects[key]?.visible) === false });
  const move = (idx, dir) => {
    const newOrder = [...order];
    const j = idx + dir;
    if (j < 0 || j >= newOrder.length) return;
    [newOrder[idx], newOrder[j]] = [newOrder[j], newOrder[idx]];
    onChange({ ...config, objectOrder: newOrder });
  };
  const toggleExpand = (key) => setExpanded((e) => ({ ...e, [key]: !e[key] }));

  const renderStyleControls = (key) => {
    const o = objects[key] || {};
    const isItems = key === 'items';
    return (
      <div className="mt-2 space-y-2 pl-1 border-t border-border pt-2">
        {isItems && (
          <div>
            <Label className="text-[10px]">Cor de fundo (cabeçalho da tabela)</Label>
            <Input type="color" value={o.bgColor || '#1e3a8a'} onChange={(e) => setObj(key, { bgColor: e.target.value })} className="h-7 p-1" />
          </div>
        )}
        <div>
          <Label className="text-[10px]">Cor do texto</Label>
          <Input type="color" value={o.color || '#111827'} onChange={(e) => setObj(key, { color: e.target.value })} className="h-7 p-1" />
        </div>
        <div className="grid grid-cols-2 gap-2">
          <div>
            <Label className="text-[10px]">Fonte</Label>
            <Select value={o.font || 'helvetica'} onValueChange={(v) => setObj(key, { font: v })}>
              <SelectTrigger className="h-7 text-xs"><SelectValue /></SelectTrigger>
              <SelectContent>
                {FONTS.map((f) => <SelectItem key={f.value} value={f.value}>{f.label}</SelectItem>)}
              </SelectContent>
            </Select>
          </div>
          <div>
            <Label className="text-[10px]">Tamanho (auto = 0)</Label>
            <Input type="number" min="0" max="36" step="0.5" value={o.fontSize || 0} onChange={(e) => setObj(key, { fontSize: Number(e.target.value) })} className="h-7" />
          </div>
        </div>
        <div className="grid grid-cols-2 gap-2">
          <div>
            <Label className="text-[10px]">Desloc. X (mm)</Label>
            <Input type="number" step="0.5" value={o.offsetX || 0} onChange={(e) => setObj(key, { offsetX: Number(e.target.value) })} className="h-7" />
          </div>
          <div>
            <Label className="text-[10px]">Desloc. Y (mm)</Label>
            <Input type="number" step="0.5" value={o.offsetY || 0} onChange={(e) => setObj(key, { offsetY: Number(e.target.value) })} className="h-7" />
          </div>
        </div>
      </div>
    );
  };

  return (
    <div className="space-y-3">
      <div>
        <p className="text-[11px] font-semibold text-muted-foreground uppercase mb-1.5">Blocos do Documento (reordenáveis)</p>
        <div className="space-y-1.5">
          {order.map((key, idx) => {
            const def = BODY_BLOCKS.find((b) => b.key === key);
            if (!def) return null;
            const visible = objects[key]?.visible !== false;
            return (
              <div key={key} className="rounded-lg border border-border bg-background">
                <div className="flex items-center gap-1 p-1.5">
                  <button type="button" onClick={() => move(idx, -1)} disabled={idx === 0} className="w-6 h-6 flex items-center justify-center rounded hover:bg-muted disabled:opacity-30"><ChevronUp className="w-3.5 h-3.5" /></button>
                  <button type="button" onClick={() => move(idx, 1)} disabled={idx === order.length - 1} className="w-6 h-6 flex items-center justify-center rounded hover:bg-muted disabled:opacity-30"><ChevronDown className="w-3.5 h-3.5" /></button>
                  <span className="flex-1 text-xs font-medium truncate">{def.label}</span>
                  <button type="button" onClick={() => toggleExpand(key)} className={`w-6 h-6 flex items-center justify-center rounded hover:bg-muted ${expanded[key] ? 'text-violet-600 bg-violet-50' : ''}`}><Settings2 className="w-3.5 h-3.5" /></button>
                  <button type="button" onClick={() => toggleVis(key)} className={`w-6 h-6 flex items-center justify-center rounded ${visible ? 'text-blue-600 hover:bg-blue-50' : 'text-muted-foreground hover:bg-muted'}`}>{visible ? <Eye className="w-3.5 h-3.5" /> : <EyeOff className="w-3.5 h-3.5" />}</button>
                </div>
                {expanded[key] && renderStyleControls(key)}
              </div>
            );
          })}
        </div>
      </div>
      <div>
        <p className="text-[11px] font-semibold text-muted-foreground uppercase mb-1.5">Blocos Fixos (mostrar/ocultar)</p>
        <div className="space-y-1.5">
          {FIXED_BLOCKS.map((b) => {
            const visible = objects[b.key]?.visible !== false;
            return (
              <div key={b.key} className="flex items-center gap-2 rounded-lg border border-border bg-background p-1.5">
                <span className="flex-1 text-xs font-medium">{b.label}</span>
                <button type="button" onClick={() => toggleVis(b.key)} className={`w-6 h-6 flex items-center justify-center rounded ${visible ? 'text-blue-600 hover:bg-blue-50' : 'text-muted-foreground hover:bg-muted'}`}>{visible ? <Eye className="w-3.5 h-3.5" /> : <EyeOff className="w-3.5 h-3.5" />}</button>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}