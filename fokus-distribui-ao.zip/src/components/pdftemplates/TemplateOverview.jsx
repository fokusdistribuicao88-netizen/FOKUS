import React, { useMemo, useState } from 'react';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { FileText, Loader2, Droplet, Plus, Trash2 } from 'lucide-react';

import { PDF_CATEGORIES, PDF_DOCUMENTS } from '@/lib/pdfTemplateDefaults';

export default function TemplateOverview({ templates, loading, onSelect, onManageWatermarks, customDocs = [], onCreate, onDelete, deletingId }) {
  const [q, setQ] = useState('');
  const byType = useMemo(() => Object.fromEntries(templates.map((t) => [t.document_type, t])), [templates]);
  const customByType = useMemo(() => Object.fromEntries(customDocs.map((d) => [d.type, d])), [customDocs]);

  // Todos os documentos do sistema: tipos embutidos (PDF_DOCUMENTS) + tipos personalizados + modelos salvos.
  const allDocs = useMemo(() => {
    const map = {};
    PDF_DOCUMENTS.forEach((d) => { map[d.type] = { type: d.type, label: d.label, category: d.category, size: d.size, orientation: d.orientation }; });
    customDocs.forEach((d) => { map[d.type] = { type: d.type, label: d.label, category: d.category, size: d.size, orientation: d.orientation, _custom: true }; });
    templates.forEach((t) => { if (t.document_type && !map[t.document_type]) map[t.document_type] = { type: t.document_type, label: t.document_label || t.document_type, category: t.category }; });
    return Object.values(map);
  }, [templates, customDocs]);

  const groups = PDF_CATEGORIES.map((cat) => ({ ...cat, docs: allDocs.filter((d) => d.category === cat.key) }));
  const ql = q.trim().toLowerCase();
  const filtered = ql
    ? groups.map((g) => ({ ...g, docs: g.docs.filter((d) => d.label.toLowerCase().includes(ql)) })).filter((g) => g.docs.length)
    : groups;

  return (
    <div className="min-h-screen bg-muted/30">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-6 space-y-5">
        <div className="flex items-start justify-between gap-3 flex-wrap">
          <div>
            <h1 className="text-2xl font-bold flex items-center gap-2"><FileText className="w-6 h-6 text-violet-700" /> Gerenciador de Modelos PDF</h1>
            <p className="text-sm text-muted-foreground mt-1">Centralize e personalize o layout de todos os documentos PDF gerados pelo sistema.</p>
          </div>
          <div className="flex items-center gap-2">
            {onCreate && (
              <Button onClick={onCreate} className="gap-2 bg-violet-700 hover:bg-violet-800"><Plus className="w-4 h-4" /> Criar documento</Button>
            )}
            <Button onClick={onManageWatermarks} variant="outline" className="gap-2 border-violet-200 text-violet-700 hover:bg-violet-50"><Droplet className="w-4 h-4" /> Marcas d'Água</Button>
          </div>
        </div>

        <Input placeholder="Buscar documento..." value={q} onChange={(e) => setQ(e.target.value)} className="max-w-sm" />

        {loading ? (
          <div className="flex justify-center py-12"><Loader2 className="w-6 h-6 animate-spin text-violet-600" /></div>
        ) : filtered.length === 0 ? (
          <div className="text-center py-16 text-muted-foreground">
            <FileText className="w-10 h-10 mx-auto mb-3 opacity-40" />
            <p className="text-sm">Nenhum modelo de PDF no gerenciador.</p>
            <p className="text-xs mt-1">Clique em "Criar documento" para adicionar um novo modelo.</p>
          </div>
        ) : (
          filtered.map((g) => (
            <div key={g.key} className="bg-card rounded-2xl border border-border p-4 sm:p-5">
              <h2 className="text-sm font-semibold text-foreground mb-3">{g.label}</h2>
              <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-2">
                {g.docs.map((d) => {
                  const t = byType[d.type];
                  const isDeleting = deletingId === d.type;
                  return (
                    <div
                      key={d.type}
                      className="group text-left flex items-center justify-between gap-2 p-3 rounded-xl border border-border hover:border-violet-400 hover:bg-violet-50/40 dark:hover:bg-violet-950/20 transition-colors"
                    >
                      <button onClick={() => onSelect(d)} className="flex items-center gap-2 min-w-0 flex-1">
                        <FileText className="w-4 h-4 text-violet-600 shrink-0" />
                        <span className="text-sm font-medium truncate">{d.label}</span>
                      </button>
                      <div className="flex items-center gap-1.5 shrink-0">
                        {d._custom && <Badge className="bg-violet-100 text-violet-700 border-transparent">Personalizado</Badge>}
                        {t?.is_published && <Badge className="bg-emerald-100 text-emerald-700 border-transparent">Publicada</Badge>}
                        <span className="text-[10px] text-muted-foreground">{t ? `v${t.version}` : 'Padrão'}</span>
                        {onDelete && (t || d._custom) && (
                          <button
                            onClick={(e) => { e.stopPropagation(); onDelete(d, t); }}
                            disabled={isDeleting}
                            title="Deletar do sistema"
                            className="text-muted-foreground hover:text-destructive disabled:opacity-50 p-1 rounded transition-colors"
                          >
                            {isDeleting ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Trash2 className="w-3.5 h-3.5" />}
                          </button>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
}