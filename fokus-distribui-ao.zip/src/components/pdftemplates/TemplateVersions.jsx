import React from 'react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { RotateCcw, Send } from 'lucide-react';

function fmtDate(iso) {
  if (!iso) return '-';
  const d = new Date(iso);
  return d.toLocaleString('pt-BR', { day: '2-digit', month: '2-digit', year: 'numeric', hour: '2-digit', minute: '2-digit' });
}

export default function TemplateVersions({ versions, currentVersion, onRestore, onPublish }) {
  if (!versions || versions.length === 0) {
    return (
      <div className="text-center text-sm text-muted-foreground py-10">
        Nenhuma versão salva. Clique em <strong>Salvar</strong> ou <strong>Publicar</strong> para criar a primeira versão.
      </div>
    );
  }
  return (
    <div className="space-y-2">
      {versions.map((v) => {
        const isCurrent = v.version === currentVersion;
        return (
          <div key={v.id} className={`flex items-center justify-between gap-2 p-3 rounded-xl border ${v.published ? 'border-emerald-300 bg-emerald-50/50 dark:bg-emerald-950/20' : 'border-border'}`}>
            <div className="min-w-0">
              <div className="flex items-center gap-2 flex-wrap">
                <span className="text-sm font-semibold">v{v.version}</span>
                {v.published && <Badge className="bg-emerald-100 text-emerald-700 border-transparent">Publicada</Badge>}
                {isCurrent && <Badge variant="outline">Atual</Badge>}
              </div>
              <p className="text-xs text-muted-foreground truncate mt-0.5">
                {v.description || 'Sem descrição'} — {v.user_email || '—'} · {fmtDate(v.created_date)}
              </p>
            </div>
            <div className="flex gap-1 shrink-0">
              <Button size="sm" variant="outline" onClick={() => onRestore(v)} className="gap-1 h-8"><RotateCcw className="w-3.5 h-3.5" /> Restaurar</Button>
              {!v.published && <Button size="sm" variant="outline" onClick={() => onPublish(v)} className="gap-1 h-8"><Send className="w-3.5 h-3.5" /> Publicar</Button>}
            </div>
          </div>
        );
      })}
    </div>
  );
}