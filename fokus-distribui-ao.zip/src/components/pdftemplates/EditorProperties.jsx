import React from 'react';
import { Button } from '@/components/ui/button';
import { X } from 'lucide-react';
import TemplateVersions from '@/components/pdftemplates/TemplateVersions';

function Meta({ label, value }) {
  return (
    <div className="flex items-center justify-between py-1 border-b border-border/60">
      <span className="text-xs text-muted-foreground">{label}</span>
      <span className="text-xs font-medium text-right">{value}</span>
    </div>
  );
}

export default function EditorProperties({ doc, template, versions, currentVersion, onRestore, onPublish, onClose }) {
  const orientLabel = doc?.orientation === 'landscape' ? 'Paisagem' : 'Retrato';
  return (
    <div className="flex flex-col h-full">
      <div className="flex items-center justify-between px-3 py-2 border-b border-border">
        <span className="text-sm font-semibold">Propriedades</span>
        <Button size="icon" variant="ghost" className="h-7 w-7" onClick={onClose}><X className="w-4 h-4" /></Button>
      </div>
      <div className="flex-1 overflow-y-auto p-3 space-y-4">
        <div>
          <p className="text-xs font-semibold text-muted-foreground uppercase mb-1">Documento</p>
          <Meta label="Tipo" value={doc?.label || '-'} />
          <Meta label="Categoria" value={(doc?.category || '-')} />
          <Meta label="Tamanho" value={doc?.size || '-'} />
          <Meta label="Orientação" value={orientLabel} />
          <Meta label="Versão" value={template?.version ?? '-'} />
          <Meta label="Publicada" value={template?.is_published ? 'Sim' : 'Não'} />
        </div>
        <div>
          <p className="text-xs font-semibold text-muted-foreground uppercase mb-2">Histórico de versões</p>
          <TemplateVersions versions={versions} currentVersion={currentVersion} onRestore={onRestore} onPublish={onPublish} />
        </div>
      </div>
    </div>
  );
}