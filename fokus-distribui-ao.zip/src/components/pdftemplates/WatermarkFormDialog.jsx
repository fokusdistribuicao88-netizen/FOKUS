import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Switch } from '@/components/ui/switch';
import { Checkbox } from '@/components/ui/checkbox';
import { Badge } from '@/components/ui/badge';
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter, DialogClose,
} from '@/components/ui/dialog';
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs';
import { Select, SelectTrigger, SelectValue, SelectContent, SelectItem } from '@/components/ui/select';
import { Upload, Loader2, Trash2, Image as ImageIcon, Type, Layers } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { useToast } from '@/components/ui/use-toast';
import { useAuth } from '@/lib/AuthContext';
import { PDF_DOCUMENTS } from '@/lib/pdfTemplateDefaults';

const CATS = ['vendas', 'financeiro', 'produtos', 'estoque', 'logistica', 'clientes', 'usuarios', 'dashboard', 'geral'];

const empty = {
  name: '', code: '', description: '', category: 'geral', status: 'active', is_default: false,
  content_type: 'text', image_url: '', text: '', text_font: 'helvetica', text_color: '#9ca3af',
  text_size: 48, text_bold: true, text_italic: false, text_underline: false, text_opacity: 0.12,
  opacity: 0.12, rotation: 30, scale: 100, width: 0, height: 0, pos_x: 'center', pos_y: 'center',
  repeat: false, repeat_distance: 40, applicable_docs: [],
};

export default function WatermarkFormDialog({ open, onOpenChange, watermark, onSaved }) {
  const { user } = useAuth();
  const { toast } = useToast();
  const [form, setForm] = useState(watermark || empty);
  const [saving, setSaving] = useState(false);
  const [uploading, setUploading] = useState(false);

  React.useEffect(() => { setForm(watermark || empty); }, [watermark, open]);

  const set = (k, v) => setForm((f) => ({ ...f, [k]: v }));

  const handleUpload = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setUploading(true);
    try {
      const { file_url } = await base44.integrations.Core.UploadFile({ file });
      set('image_url', file_url);
      if (!form.name) set('name', file.name.replace(/\.[^.]+$/, ''));
      toast({ title: 'Imagem enviada' });
    } catch (err) {
      toast({ title: 'Erro no upload', description: String(err.message || err), variant: 'destructive' });
    } finally {
      setUploading(false);
      e.target.value = '';
    }
  };

  const toggleDoc = (type) => {
    setForm((f) => {
      const docs = f.applicable_docs || [];
      return { ...f, applicable_docs: docs.includes(type) ? docs.filter((d) => d !== type) : [...docs, type] };
    });
  };

  const handleSave = async () => {
    if (!form.name?.trim()) { toast({ title: 'Informe o nome', variant: 'destructive' }); return; }
    setSaving(true);
    try {
      const payload = { ...form, opacity: Number(form.opacity), text_opacity: Number(form.text_opacity), text_size: Number(form.text_size), rotation: Number(form.rotation), scale: Number(form.scale), width: Number(form.width) || 0, height: Number(form.height) || 0, repeat_distance: Number(form.repeat_distance), last_updated_by: user?.email };
      if (form.id) {
        await base44.entities.Watermark.update(form.id, payload);
        toast({ title: 'Marca d\'água atualizada' });
      } else {
        await base44.entities.Watermark.create(payload);
        toast({ title: 'Marca d\'água criada' });
      }
      onSaved?.();
      onOpenChange(false);
    } catch (e) {
      toast({ title: 'Erro ao salvar', description: String(e.message || e), variant: 'destructive' });
    } finally {
      setSaving(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2"><Layers className="w-5 h-5 text-violet-600" /> {form.id ? 'Editar Marca d\'Água' : 'Nova Marca d\'Água'}</DialogTitle>
          <DialogDescription>Crie uma marca d\'água reutilizável em diferentes documentos.</DialogDescription>
        </DialogHeader>

        <Tabs defaultValue="geral">
          <TabsList className="grid grid-cols-4 w-full">
            <TabsTrigger value="geral" className="text-xs">Geral</TabsTrigger>
            <TabsTrigger value="conteudo" className="text-xs">Conteúdo</TabsTrigger>
            <TabsTrigger value="visual" className="text-xs">Visual</TabsTrigger>
            <TabsTrigger value="docs" className="text-xs">Documentos</TabsTrigger>
          </TabsList>

          {/* GERAL */}
          <TabsContent value="geral" className="space-y-3 mt-3">
            <div className="grid grid-cols-2 gap-3">
              <div><Label className="text-xs">Nome *</Label><Input value={form.name} onChange={(e) => set('name', e.target.value)} className="h-9" /></div>
              <div><Label className="text-xs">Código interno</Label><Input value={form.code} onChange={(e) => set('code', e.target.value)} className="h-9" placeholder="ex: VIA_CLIENTE" /></div>
            </div>
            <div><Label className="text-xs">Descrição</Label><Textarea value={form.description} onChange={(e) => set('description', e.target.value)} rows={2} className="text-sm" /></div>
            <div className="grid grid-cols-2 gap-3">
              <div><Label className="text-xs">Categoria</Label>
                <Select value={form.category} onValueChange={(v) => set('category', v)}>
                  <SelectTrigger className="h-9"><SelectValue /></SelectTrigger>
                  <SelectContent>{CATS.map((c) => <SelectItem key={c} value={c} className="capitalize">{c}</SelectItem>)}</SelectContent>
                </Select>
              </div>
              <div><Label className="text-xs">Status</Label>
                <Select value={form.status} onValueChange={(v) => set('status', v)}>
                  <SelectTrigger className="h-9"><SelectValue /></SelectTrigger>
                  <SelectContent><SelectItem value="active">Ativa</SelectItem><SelectItem value="inactive">Inativa</SelectItem></SelectContent>
                </Select>
              </div>
            </div>
            <label className="flex items-center gap-2 text-sm"><Switch checked={!!form.is_default} onCheckedChange={(v) => set('is_default', v)} /> Definir como padrão</label>
          </TabsContent>

          {/* CONTEÚDO */}
          <TabsContent value="conteudo" className="space-y-3 mt-3">
            <div>
              <Label className="text-xs mb-1.5 block">Tipo de conteúdo</Label>
              <div className="grid grid-cols-3 gap-2">
                {[{ k: 'text', l: 'Texto', I: Type }, { k: 'image', l: 'Imagem', I: ImageIcon }, { k: 'mixed', l: 'Imagem + Texto', I: Layers }].map(({ k, l, I }) => (
                  <button key={k} type="button" onClick={() => set('content_type', k)} className={`flex flex-col items-center gap-1 rounded-lg border p-3 text-xs transition ${form.content_type === k ? 'border-violet-500 bg-violet-50 text-violet-700 font-semibold' : 'border-border hover:bg-accent'}`}>
                    <I className="w-4 h-4" /> {l}
                  </button>
                ))}
              </div>
            </div>

            {(form.content_type === 'image' || form.content_type === 'mixed') && (
              <div className="space-y-2 rounded-lg border border-border p-3">
                <Label className="text-xs">Imagem (PNG, JPG, WEBP)</Label>
                <div className="h-32 w-full rounded-lg border border-dashed border-border bg-muted/30 flex items-center justify-center overflow-hidden">
                  {form.image_url ? <img src={form.image_url} alt="" className="h-full w-full object-contain" /> : <ImageIcon className="w-8 h-8 text-muted-foreground" />}
                </div>
                <div className="flex gap-2">
                  <label className="flex-1 cursor-pointer">
                    <input type="file" accept="image/png,image/jpeg,image/webp" className="hidden" onChange={handleUpload} />
                    <Button variant="outline" size="sm" asChild className="w-full gap-1.5 h-8" disabled={uploading}><span>{uploading ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Upload className="w-3.5 h-3.5" />} Enviar imagem</span></Button>
                  </label>
                  {form.image_url && <Button variant="outline" size="sm" className="h-8" onClick={() => set('image_url', '')}><Trash2 className="w-3.5 h-3.5" /></Button>}
                </div>
              </div>
            )}

            {(form.content_type === 'text' || form.content_type === 'mixed') && (
              <div className="space-y-2 rounded-lg border border-border p-3">
                <Label className="text-xs">Texto</Label>
                <Input value={form.text} onChange={(e) => set('text', e.target.value)} className="h-9" placeholder="ex: VIA DO CLIENTE" />
                <div className="grid grid-cols-2 gap-2">
                  <div><Label className="text-xs">Fonte</Label>
                    <Select value={form.text_font} onValueChange={(v) => set('text_font', v)}>
                      <SelectTrigger className="h-9"><SelectValue /></SelectTrigger>
                      <SelectContent><SelectItem value="helvetica">Helvetica</SelectItem><SelectItem value="times">Times</SelectItem><SelectItem value="courier">Courier</SelectItem></SelectContent>
                    </Select>
                  </div>
                  <div><Label className="text-xs">Cor</Label><Input type="color" value={form.text_color} onChange={(e) => set('text_color', e.target.value)} className="h-9 p-1" /></div>
                </div>
                <div className="grid grid-cols-2 gap-2">
                  <div><Label className="text-xs">Tamanho</Label><Input type="number" value={form.text_size} onChange={(e) => set('text_size', Number(e.target.value))} className="h-9" /></div>
                  <div><Label className="text-xs">Opacidade (0-1)</Label><Input type="number" step="0.01" min="0" max="1" value={form.text_opacity} onChange={(e) => set('text_opacity', Number(e.target.value))} className="h-9" /></div>
                </div>
                <div className="flex gap-4">
                  <label className="flex items-center gap-1.5 text-xs"><Switch checked={!!form.text_bold} onCheckedChange={(v) => set('text_bold', v)} /> Negrito</label>
                  <label className="flex items-center gap-1.5 text-xs"><Switch checked={!!form.text_italic} onCheckedChange={(v) => set('text_italic', v)} /> Itálico</label>
                  <label className="flex items-center gap-1.5 text-xs"><Switch checked={!!form.text_underline} onCheckedChange={(v) => set('text_underline', v)} /> Sublinhado</label>
                </div>
              </div>
            )}
          </TabsContent>

          {/* VISUAL */}
          <TabsContent value="visual" className="space-y-3 mt-3">
            <div className="grid grid-cols-3 gap-2">
              <div><Label className="text-xs">Opacidade geral</Label><Input type="number" step="0.01" min="0" max="1" value={form.opacity} onChange={(e) => set('opacity', Number(e.target.value))} className="h-9" /></div>
              <div><Label className="text-xs">Rotação (°)</Label><Input type="number" value={form.rotation} onChange={(e) => set('rotation', Number(e.target.value))} className="h-9" /></div>
              <div><Label className="text-xs">Escala (%)</Label><Input type="number" value={form.scale} onChange={(e) => set('scale', Number(e.target.value))} className="h-9" /></div>
            </div>
            <div className="grid grid-cols-2 gap-2">
              <div><Label className="text-xs">Largura (mm)</Label><Input type="number" value={form.width} onChange={(e) => set('width', Number(e.target.value))} className="h-9" /></div>
              <div><Label className="text-xs">Altura (mm)</Label><Input type="number" value={form.height} onChange={(e) => set('height', Number(e.target.value))} className="h-9" /></div>
            </div>
            <div className="grid grid-cols-2 gap-2">
              <div><Label className="text-xs">Posição horizontal</Label>
                <Select value={form.pos_x} onValueChange={(v) => set('pos_x', v)}>
                  <SelectTrigger className="h-9"><SelectValue /></SelectTrigger>
                  <SelectContent><SelectItem value="left">Esquerda</SelectItem><SelectItem value="center">Centro</SelectItem><SelectItem value="right">Direita</SelectItem></SelectContent>
                </Select>
              </div>
              <div><Label className="text-xs">Posição vertical</Label>
                <Select value={form.pos_y} onValueChange={(v) => set('pos_y', v)}>
                  <SelectTrigger className="h-9"><SelectValue /></SelectTrigger>
                  <SelectContent><SelectItem value="top">Topo</SelectItem><SelectItem value="center">Centro</SelectItem><SelectItem value="bottom">Base</SelectItem></SelectContent>
                </Select>
              </div>
            </div>
            <label className="flex items-center gap-2 text-sm"><Switch checked={!!form.repeat} onCheckedChange={(v) => set('repeat', v)} /> Repetir marca d\'água</label>
            {form.repeat && <div><Label className="text-xs">Distância entre repetições (mm)</Label><Input type="number" value={form.repeat_distance} onChange={(e) => set('repeat_distance', Number(e.target.value))} className="h-9" /></div>}
          </TabsContent>

          {/* DOCUMENTOS */}
          <TabsContent value="docs" className="space-y-2 mt-3">
            <p className="text-xs text-muted-foreground">Selecione em quais documentos esta marca d\'água pode ser utilizada. Deixe vazio para permitir em todos.</p>
            <div className="grid grid-cols-2 gap-2 max-h-60 overflow-y-auto">
              {PDF_DOCUMENTS.map((d) => (
                <label key={d.type} className="flex items-center gap-2 rounded-md border border-border px-3 py-2 cursor-pointer hover:bg-accent/40">
                  <Checkbox checked={(form.applicable_docs || []).includes(d.type)} onCheckedChange={() => toggleDoc(d.type)} />
                  <span className="text-sm">{d.label}</span>
                </label>
              ))}
            </div>
            <div className="flex flex-wrap gap-1.5 pt-1">
              {(form.applicable_docs || []).map((t) => {
                const d = PDF_DOCUMENTS.find((x) => x.type === t);
                return <Badge key={t} variant="secondary" className="text-[10px]">{d?.label || t}</Badge>;
              })}
            </div>
          </TabsContent>
        </Tabs>

        <DialogFooter>
          <DialogClose asChild><Button variant="outline" disabled={saving}>Cancelar</Button></DialogClose>
          <Button onClick={handleSave} disabled={saving} className="gap-2 bg-violet-600 hover:bg-violet-700">{saving ? <Loader2 className="w-4 h-4 animate-spin" /> : <Layers className="w-4 h-4" />} Salvar</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}