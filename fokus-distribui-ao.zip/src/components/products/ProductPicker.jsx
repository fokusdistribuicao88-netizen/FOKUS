import React, { useState, useMemo, useEffect, useRef } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  Search, X, Plus, Check, PackageSearch, Barcode, Boxes, ShoppingCart, ChevronDown,
} from "lucide-react";
import { formatBRL } from "@/lib/format";

const CATEGORIES = [
  "Cervejas", "Refrigerantes", "Águas", "Sucos", "Energéticos",
  "Destilados", "Vinhos", "Outros",
];

/**
 * Painel flutuante de busca de produtos — modelo unificado.
 *
 * mode='add'    → toca para adicionar (onAdd), painel permanece aberto
 * mode='select' → toca para selecionar (onSelect), painel fecha
 *
 * Controlado: passar `open` + `onOpenChange` (pai desenha o gatilho).
 * Não controlado: desenha o próprio gatilho (triggerVariant).
 */
export default function ProductPicker({
  products,
  mode = "add",
  onAdd,
  onSelect,
  addedIds = [],
  selectedId = null,
  priceField = "price",
  priceLabel = "Preço",
  showCost = false,
  stockFilter = "in_stock",
  stockFilterLabel = "Apenas disponíveis em estoque",
  triggerVariant = "button",
  triggerLabel = "Adicionar produto",
  triggerClassName = "",
  open: controlledOpen,
  onOpenChange,
}) {
  const [internalOpen, setInternalOpen] = useState(false);
  const [query, setQuery] = useState("");
  const [category, setCategory] = useState("all");
  const [filterStock, setFilterStock] = useState(false);
  const searchRef = useRef(null);

  const isControlled = typeof controlledOpen === "boolean";
  const isOpen = isControlled ? controlledOpen : internalOpen;
  const setOpen = (v) => (isControlled ? onOpenChange?.(v) : setInternalOpen(v));

  useEffect(() => {
    if (isOpen) setTimeout(() => searchRef.current?.focus(), 120);
  }, [isOpen]);

  const addedSet = useMemo(() => new Set(addedIds), [addedIds]);

  const priceOf = (p) => {
    if (showCost) return Number(p.cost) || 0;
    const v = Number(p[priceField]);
    if (!Number.isNaN(v) && v > 0) return v;
    const promo = Number(p.price_promo);
    if (!Number.isNaN(promo) && promo > 0) return promo;
    return Number(p.price) || 0;
  };

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    return products.filter((p) => {
      if (category !== "all" && p.category !== category) return false;
      if (filterStock) {
        if (stockFilter === "in_stock" && p.in_stock === false) return false;
        if (stockFilter === "low" && (p.stock_quantity ?? 0) > (p.low_stock_threshold ?? 5)) return false;
      }
      if (!q) return true;
      return [p.name, p.code, p.brand, p.category, p.description, p.supplier]
        .some((f) => String(f || "").toLowerCase().includes(q));
    });
  }, [products, query, category, filterStock, stockFilter]);

  const handlePick = (p) => {
    if (mode === "select") {
      onSelect?.(p);
      setOpen(false);
      setQuery("");
    } else {
      onAdd?.(p);
    }
  };

  const selected = mode === "select" && selectedId
    ? products.find((p) => p.id === selectedId)
    : null;

  return (
    <>
      {!isControlled && triggerVariant === "button" && (
        <Button
          type="button"
          variant="outline"
          size="sm"
          onClick={() => setOpen(true)}
          className={`gap-1.5 ${triggerClassName}`}
        >
          <Plus className="h-4 w-4" /> {triggerLabel}
        </Button>
      )}

      {!isControlled && triggerVariant === "select" && (
        <button
          type="button"
          onClick={() => setOpen(true)}
          className={`flex h-9 w-full items-center justify-between rounded-md border border-input bg-transparent px-3 py-2 text-sm shadow-sm hover:bg-accent ${triggerClassName}`}
        >
          <span className={selected ? "text-foreground truncate" : "text-muted-foreground"}>
            {selected ? selected.name : triggerLabel}
          </span>
          <ChevronDown className="h-4 w-4 opacity-50 shrink-0" />
        </button>
      )}

      <AnimatePresence>
        {isOpen && (
          <>
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setOpen(false)}
              className="fixed inset-0 z-[60] bg-black/40"
            />
            <motion.div
              initial={{ x: "100%" }}
              animate={{ x: 0 }}
              exit={{ x: "100%" }}
              transition={{ type: "spring", stiffness: 320, damping: 32 }}
              className="fixed right-0 top-0 bottom-0 z-[61] w-[88vw] max-w-sm bg-card border-l shadow-2xl flex flex-col safe-area-top safe-area-bottom"
            >
              <div className="p-3 border-b bg-muted/30">
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center gap-2">
                    <ShoppingCart className="h-5 w-5 text-primary" />
                    <h3 className="font-semibold text-sm">Buscar Produtos</h3>
                  </div>
                  <button
                    type="button"
                    onClick={() => setOpen(false)}
                    className="w-9 h-9 flex items-center justify-center rounded-full hover:bg-accent touch-manipulation"
                    aria-label="Fechar"
                  >
                    <X className="h-5 w-5" />
                  </button>
                </div>
                <div className="relative">
                  <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                  <Input
                    ref={searchRef}
                    value={query}
                    onChange={(e) => setQuery(e.target.value)}
                    placeholder="Nome, código, marca, fornecedor..."
                    className="pl-8"
                  />
                </div>
                <div className="flex items-center gap-1.5 mt-2 overflow-x-auto pb-1 no-scrollbar">
                  <button
                    type="button"
                    onClick={() => setCategory("all")}
                    className={`shrink-0 px-2.5 py-1 rounded-full text-xs font-medium border transition-colors ${
                      category === "all"
                        ? "bg-primary text-primary-foreground border-primary"
                        : "bg-background border-border hover:bg-accent"
                    }`}
                  >
                    Todas
                  </button>
                  {CATEGORIES.map((c) => (
                    <button
                      key={c}
                      type="button"
                      onClick={() => setCategory(c)}
                      className={`shrink-0 px-2.5 py-1 rounded-full text-xs font-medium border transition-colors ${
                        category === c
                          ? "bg-primary text-primary-foreground border-primary"
                          : "bg-background border-border hover:bg-accent"
                      }`}
                    >
                      {c}
                    </button>
                  ))}
                </div>
                {stockFilter && (
                  <label className="flex items-center gap-2 mt-2 text-xs text-muted-foreground cursor-pointer select-none">
                    <input
                      type="checkbox"
                      checked={filterStock}
                      onChange={(e) => setFilterStock(e.target.checked)}
                      className="h-3.5 w-3.5"
                    />
                    {stockFilterLabel}
                  </label>
                )}
              </div>

              <div className="flex-1 overflow-y-auto p-2 space-y-2">
                <div className="text-xs text-muted-foreground px-1 pt-1 pb-2 flex items-center justify-between">
                  <span>{filtered.length} produto(s)</span>
                  <span className="flex items-center gap-1"><Barcode className="h-3 w-3" /> toque para {mode === "select" ? "selecionar" : "adicionar"}</span>
                </div>
                {filtered.length === 0 && (
                  <div className="text-center py-12 text-muted-foreground text-sm">
                    <Boxes className="h-10 w-10 mx-auto mb-2 opacity-40" />
                    Nenhum produto encontrado.
                  </div>
                )}
                {filtered.map((p) => {
                  const marked = mode === "select"
                    ? p.id === selectedId
                    : addedSet.has(p.id);
                  const stock = p.stock_quantity ?? 0;
                  const low = stock <= (p.low_stock_threshold ?? 5) && p.in_stock !== false;
                  const out = p.in_stock === false;
                  return (
                    <div
                      key={p.id}
                      className="rounded-lg border bg-background p-2.5 flex gap-2.5 hover:border-primary/40 hover:shadow-sm transition-colors"
                    >
                      <div className="w-12 h-12 shrink-0 rounded-md overflow-hidden bg-muted/40 flex items-center justify-center">
                        {p.image_url ? (
                          <img src={p.image_url} alt={p.name} className="w-full h-full object-cover" />
                        ) : (
                          <PackageSearch className="h-5 w-5 text-muted-foreground" />
                        )}
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-start gap-2">
                          <div className="flex-1 min-w-0">
                            <p className="text-sm font-medium leading-tight truncate">{p.name}</p>
                            <div className="flex items-center gap-1.5 mt-0.5 text-xs text-muted-foreground">
                              {p.code && <span className="font-mono">{p.code}</span>}
                              {p.brand && <span>· {p.brand}</span>}
                            </div>
                          </div>
                          <Badge
                            variant={out ? "outline" : low ? "destructive" : "secondary"}
                            className="shrink-0 text-[10px]"
                          >
                            <Boxes className="h-3 w-3 mr-1" />
                            {out ? "sem" : stock}
                          </Badge>
                        </div>
                        <div className="flex items-center justify-between mt-1.5">
                          <span className="text-xs text-muted-foreground">
                            {priceLabel}:{" "}
                            <span className="font-medium text-foreground">{formatBRL(priceOf(p))}</span>
                          </span>
                          {marked && (
                            <span className="flex items-center gap-1 text-xs text-emerald-600 font-medium">
                              <Check className="h-3.5 w-3.5" /> {mode === "select" ? "selecionado" : "na lista"}
                            </span>
                          )}
                        </div>
                      </div>
                      <button
                        type="button"
                        onClick={() => handlePick(p)}
                        aria-label={`${mode === "select" ? "Selecionar" : "Adicionar"} ${p.name}`}
                        className={`shrink-0 self-stretch w-11 flex items-center justify-center rounded-md transition-colors touch-manipulation ${
                          marked
                            ? "bg-emerald-50 text-emerald-600 hover:bg-emerald-100"
                            : "bg-primary text-primary-foreground hover:bg-primary/90"
                        }`}
                      >
                        {mode === "select" && marked ? <Check className="h-5 w-5" /> : <Plus className="h-5 w-5" />}
                      </button>
                    </div>
                  );
                })}
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </>
  );
}