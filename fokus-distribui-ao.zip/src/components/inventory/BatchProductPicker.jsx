import React, { useState, useMemo, useEffect, useRef } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Search, X, Plus, Check, PackageSearch, Barcode, Boxes } from "lucide-react";
import { formatBRL } from "@/lib/format";

const CATEGORIES = [
  "Cervejas", "Refrigerantes", "Águas", "Sucos", "Energéticos",
  "Destilados", "Vinhos", "Outros",
];

export default function BatchProductPicker({ products, onAdd, addedIds = [], open, onOpenChange }) {
  const [query, setQuery] = useState("");
  const [category, setCategory] = useState("all");
  const [onlyLow, setOnlyLow] = useState(false);
  const searchRef = useRef(null);
  const isControlled = typeof open === "boolean";
  const [internalOpen, setInternalOpen] = useState(false);
  const isOpen = isControlled ? open : internalOpen;
  const setOpen = (v) => (isControlled ? onOpenChange?.(v) : setInternalOpen(v));

  useEffect(() => {
    if (isOpen) setTimeout(() => searchRef.current?.focus(), 120);
  }, [isOpen]);

  const addedSet = useMemo(() => new Set(addedIds), [addedIds]);

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    return products.filter((p) => {
      if (category !== "all" && p.category !== category) return false;
      if (onlyLow && (p.stock_quantity ?? 0) > (p.low_stock_threshold ?? 5)) return false;
      if (!q) return true;
      return [p.name, p.code, p.brand, p.category, p.description, p.supplier]
        .some((f) => String(f || "").toLowerCase().includes(q));
    });
  }, [products, query, category, onlyLow]);

  const handleAdd = (p) => {
    onAdd(p);
  };

  return (
    <>
      {/* Aba flutuante (gatilho) */}
      <button
        type="button"
        onClick={() => setOpen(!isOpen)}
        aria-label="Pesquisar produtos"
        className="fixed right-0 top-1/2 -translate-y-1/2 z-[60] flex items-center gap-2 bg-primary text-primary-foreground rounded-l-xl shadow-lg pl-3 pr-2 py-3 hover:pr-3 hover:shadow-xl transition-all touch-manipulation"
      >
        {isOpen ? <X className="h-5 w-5" /> : <PackageSearch className="h-5 w-5" />}
        <span className="text-xs font-medium [writing-mode:vertical-rl] rotate-180 tracking-wide">
          {isOpen ? "Fechar" : "Pesquisar Produtos"}
        </span>
      </button>

      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ x: "100%" }}
            animate={{ x: 0 }}
            exit={{ x: "100%" }}
            transition={{ type: "spring", stiffness: 320, damping: 32 }}
            className="fixed right-0 top-0 bottom-0 z-[55] w-[88vw] max-w-sm bg-card border-l shadow-2xl flex flex-col safe-area-top safe-area-bottom"
          >
            {/* Cabeçalho */}
            <div className="p-3 border-b bg-muted/30">
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center gap-2">
                  <PackageSearch className="h-5 w-5 text-primary" />
                  <h3 className="font-semibold text-sm">Buscar Produtos</h3>
                </div>
                <button
                  type="button"
                  onClick={() => setOpen(false)}
                  className="w-9 h-9 flex items-center justify-center rounded-full hover:bg-accent touch-manipulation"
                  aria-label="Fechar"
                >

                  <X className="h-5 w-5" />
                </button>
              </div>
              <div className="relative">
                <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input
                  ref={searchRef}
                  value={query}
                  onChange={(e) => setQuery(e.target.value)}
                  placeholder="Nome, código, marca, fornecedor..."
                  className="pl-8"
                />
              </div>
              <div className="flex items-center gap-1.5 mt-2 overflow-x-auto pb-1 no-scrollbar">
                <button
                  type="button"
                  onClick={() => setCategory("all")}
                  className={`shrink-0 px-2.5 py-1 rounded-full text-xs font-medium border transition-colors ${
                    category === "all"
                      ? "bg-primary text-primary-foreground border-primary"
                      : "bg-background border-border hover:bg-accent"
                  }`}
                >
                  Todas
                </button>
                {CATEGORIES.map((c) => (
                  <button
                    key={c}
                    type="button"
                    onClick={() => setCategory(c)}
                    className={`shrink-0 px-2.5 py-1 rounded-full text-xs font-medium border transition-colors ${
                      category === c
                        ? "bg-primary text-primary-foreground border-primary"
                        : "bg-background border-border hover:bg-accent"
                    }`}
                  >
                    {c}
                  </button>
                ))}
              </div>
              <label className="flex items-center gap-2 mt-2 text-xs text-muted-foreground cursor-pointer select-none">
                <input
                  type="checkbox"
                  checked={onlyLow}
                  onChange={(e) => setOnlyLow(e.target.checked)}
                  className="h-3.5 w-3.5"
                />
                Mostrar apenas estoque baixo
              </label>
            </div>

            {/* Lista */}
            <div className="flex-1 overflow-y-auto p-2 space-y-2">
              <div className="text-xs text-muted-foreground px-1 pt-1 pb-2 flex items-center justify-between">
                <span>{filtered.length} produto(s)</span>
                <span className="flex items-center gap-1"><Barcode className="h-3 w-3" /> toque para adicionar</span>
              </div>
              {filtered.length === 0 && (
                <div className="text-center py-12 text-muted-foreground text-sm">
                  <Boxes className="h-10 w-10 mx-auto mb-2 opacity-40" />
                  Nenhum produto encontrado.
                </div>
              )}
              {filtered.map((p) => {
                const added = addedSet.has(p.id);
                const stock = p.stock_quantity ?? 0;
                const low = stock <= (p.low_stock_threshold ?? 5);
                return (
                  <div
                    key={p.id}
                    className="rounded-lg border bg-background p-2.5 flex gap-2.5 hover:border-primary/40 hover:shadow-sm transition-colors"
                  >
                    <div className="w-12 h-12 shrink-0 rounded-md overflow-hidden bg-muted/40 flex items-center justify-center">
                      {p.image_url ? (
                        <img src={p.image_url} alt={p.name} className="w-full h-full object-cover" />
                      ) : (
                        <PackageSearch className="h-5 w-5 text-muted-foreground" />
                      )}
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-start gap-2">
                        <div className="flex-1 min-w-0">
                          <p className="text-sm font-medium leading-tight truncate">{p.name}</p>
                          <div className="flex items-center gap-1.5 mt-0.5 text-xs text-muted-foreground">
                            {p.code && <span className="font-mono">{p.code}</span>}
                            {p.brand && <span>· {p.brand}</span>}
                          </div>
                        </div>
                        <Badge
                          variant={low ? "destructive" : "secondary"}
                          className="shrink-0 text-[10px]"
                        >
                          <Boxes className="h-3 w-3 mr-1" />
                          {stock}
                        </Badge>
                      </div>
                      <div className="flex items-center justify-between mt-1.5">
                        <span className="text-xs text-muted-foreground">
                          Custo: <span className="font-medium text-foreground">{p.cost ? formatBRL(p.cost) : "—"}</span>
                        </span>
                        {added ? (
                          <span className="flex items-center gap-1 text-xs text-emerald-600 font-medium">
                            <Check className="h-3.5 w-3.5" /> na lista
                          </span>
                        ) : null}
                      </div>
                    </div>
                    <button
                      type="button"
                      onClick={() => handleAdd(p)}
                      aria-label={`Adicionar ${p.name}`}
                      className={`shrink-0 self-stretch w-11 flex items-center justify-center rounded-md transition-colors touch-manipulation ${
                        added
                          ? "bg-emerald-50 text-emerald-600 hover:bg-emerald-100"
                          : "bg-primary text-primary-foreground hover:bg-primary/90"
                      }`}
                    >
                      <Plus className="h-5 w-5" />
                    </button>
                  </div>
                );
              })}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}