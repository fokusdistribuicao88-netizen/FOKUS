import React from "react";
import { useQuery } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { formatBRL, formatDateTime } from "@/lib/format";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { AlertTriangle, PackageX, Package, TrendingDown, TrendingUp, Boxes } from "lucide-react";
import {
  BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid,
  Legend, LineChart, Line,
} from "recharts";

export default function InventoryOverview({ products, movements }) {
  const totalStock = products.reduce((acc, p) => acc + (p.stock_quantity || 0), 0);
  const stockValue = products.reduce(
    (acc, p) => acc + (p.stock_quantity || 0) * (p.cost || 0),
    0
  );
  const hasStock = (p) => p.stock_quantity != null ? p.stock_quantity > 0 : p.in_stock !== false;
  const lowStock = products.filter(
    (p) => p.stock_quantity != null && p.stock_quantity > 0 && p.stock_quantity <= (p.low_stock_threshold ?? 5)
  );
  const outOfStock = products.filter((p) => p.status !== 'inactive' && !hasStock(p));

  const stats = [
    { label: "Produtos cadastrados", value: products.length, icon: Package, color: "text-blue-600" },
    { label: "Quantidade total em estoque", value: totalStock, icon: Boxes, color: "text-indigo-600" },
    { label: "Valor total do estoque", value: formatBRL(stockValue), icon: TrendingUp, color: "text-emerald-600" },
    { label: "Produtos com estoque baixo", value: lowStock.length, icon: AlertTriangle, color: "text-amber-600" },
    { label: "Produtos sem estoque", value: outOfStock.length, icon: PackageX, color: "text-red-600" },
  ];

  const last7 = Array.from({ length: 7 }, (_, i) => {
    const d = new Date();
    d.setDate(d.getDate() - (6 - i));
    return d.toISOString().slice(0, 10);
  });

  const chartData = last7.map((day) => {
    const dayMovs = movements.filter((m) => (m.created_date || "").slice(0, 10) === day);
    const entries = dayMovs.filter((m) => m.type === "entry").reduce((a, m) => a + m.quantity, 0);
    const exits = dayMovs.filter((m) => m.type === "exit").reduce((a, m) => a + m.quantity, 0);
    return {
      day: day.slice(5),
      entradas: entries,
      saidas: exits,
    };
  });

  const topMoved = Object.values(
    movements.reduce((acc, m) => {
      if (!acc[m.product_id])
        acc[m.product_id] = { name: m.product_name, total: 0 };
      acc[m.product_id].total += m.quantity;
      return acc;
    }, {})
  )
    .sort((a, b) => b.total - a.total)
    .slice(0, 5);

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-2 lg:grid-cols-5 gap-4">
        {stats.map((s) => (
          <Card key={s.label}>
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-xs font-medium text-muted-foreground">
                {s.label}
              </CardTitle>
              <s.icon className={`h-4 w-4 ${s.color}`} />
            </CardHeader>
            <CardContent>
              <div className="text-xl font-bold">{s.value}</div>
            </CardContent>
          </Card>
        ))}
      </div>

      {outOfStock.length > 0 && (
        <Card className="border-red-200 bg-red-50">
          <CardContent className="p-4">
            <div className="flex items-center gap-2 text-red-700 font-semibold mb-2">
              <PackageX className="h-4 w-4" /> Produtos sem estoque
            </div>
            <div className="flex flex-wrap gap-2">
              {outOfStock.map((p) => (
                <Badge key={p.id} variant="destructive">{p.name}</Badge>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {lowStock.length > 0 && (
        <Card className="border-amber-200 bg-amber-50">
          <CardContent className="p-4">
            <div className="flex items-center gap-2 text-amber-700 font-semibold mb-2">
              <AlertTriangle className="h-4 w-4" /> Estoque baixo
            </div>
            <div className="flex flex-wrap gap-2">
              {lowStock.map((p) => (
                <Badge key={p.id} variant="outline" className="border-amber-300 text-amber-700">
                  {p.name} ({p.stock_quantity})
                </Badge>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      <div className="grid lg:grid-cols-2 gap-4">
        <Card>
          <CardHeader>
            <CardTitle className="text-base">Entradas × Saídas (7 dias)</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={260}>
              <BarChart data={chartData}>
                <CartesianGrid strokeDasharray="3 3" className="opacity-30" />
                <XAxis dataKey="day" fontSize={12} />
                <YAxis fontSize={12} />
                <Tooltip />
                <Legend />
                <Bar dataKey="entradas" fill="#10b981" radius={[4, 4, 0, 0]} />
                <Bar dataKey="saidas" fill="#ef4444" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-base">Produtos mais movimentados</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={260}>
              <BarChart data={topMoved} layout="vertical">
                <CartesianGrid strokeDasharray="3 3" className="opacity-30" />
                <XAxis type="number" fontSize={12} />
                <YAxis type="category" dataKey="name" width={120} fontSize={11} />
                <Tooltip />
                <Bar dataKey="total" fill="#6366f1" radius={[0, 4, 4, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="text-base">Últimas movimentações</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-2">
            {movements.slice(0, 8).map((m) => (
              <div key={m.id} className="flex items-center justify-between border-b pb-2">
                <div className="flex items-center gap-2">
                  {m.type === "entry" ? (
                    <TrendingUp className="h-4 w-4 text-emerald-600" />
                  ) : (
                    <TrendingDown className="h-4 w-4 text-red-600" />
                  )}
                  <div>
                    <div className="text-sm font-medium">{m.product_name}</div>
                    <div className="text-xs text-muted-foreground">
                      {formatDateTime(m.created_date)} · {m.responsible || "-"}
                    </div>
                  </div>
                </div>
                <Badge variant={m.type === "entry" ? "secondary" : "outline"}>
                  {m.type === "entry" ? "+" : "-"}{m.quantity}
                </Badge>
              </div>
            ))}
            {movements.length === 0 && (
              <p className="text-sm text-muted-foreground">Nenhuma movimentação registrada.</p>
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}