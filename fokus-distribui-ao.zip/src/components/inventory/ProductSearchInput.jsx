import React, { useState, useRef, useMemo, useEffect } from "react";
import { Input } from "@/components/ui/input";
import { Search, X, Check } from "lucide-react";

/**
 * Campo de pesquisa de produtos por digitacao (autocomplete).
 * Pesquisa por codigo, nome, marca e categoria. Suporta leitor de codigo de barras
 * (Enter seleciona o primeiro resultado) e navegacao por teclado.
 */
export default function ProductSearchInput({
  products,
  value,
  onProductSelect,
  onClear,
  placeholder = "Pesquisar por codigo, nome ou marca...",
  autoFocus,
  excludeIds = [],
  registerInput,
}) {
  const [query, setQuery] = useState("");
  const [open, setOpen] = useState(false);
  const [highlight, setHighlight] = useState(0);
  const containerRef = useRef(null);
  const inputRef = useRef(null);

  const selected = products.find((p) => p.id === value);

  useEffect(() => {
    if (autoFocus && inputRef.current) inputRef.current.focus();
  }, [autoFocus]);

  useEffect(() => {
    if (registerInput && inputRef.current) registerInput(inputRef.current);
  }, [registerInput]);

  useEffect(() => {
    const handler = (e) => {
      if (containerRef.current && !containerRef.current.contains(e.target)) {
        setOpen(false);
      }
    };
    document.addEventListener("mousedown", handler);
    return () => document.removeEventListener("mousedown", handler);
  }, []);

  const results = useMemo(() => {
    let list = products.filter((p) => !excludeIds.includes(p.id));
    if (!query.trim()) return list.slice(0, 8);
    const q = query.toLowerCase().trim();
    return list
      .map((p) => {
        const name = (p.name || "").toLowerCase();
        const code = (p.code || "").toLowerCase();
        const brand = (p.brand || "").toLowerCase();
        const category = (p.category || "").toLowerCase();
        let score = 0;
        if (code === q) score = 100;
        else if (code.startsWith(q)) score = 80;
        else if (code.includes(q)) score = 60;
        if (name === q) score = Math.max(score, 95);
        else if (name.startsWith(q)) score = Math.max(score, 70);
        else if (name.includes(q)) score = Math.max(score, 50);
        if (brand.includes(q)) score = Math.max(score, 30);
        if (category.includes(q)) score = Math.max(score, 20);
        return { p, score };
      })
      .filter((x) => x.score > 0)
      .sort((a, b) => b.score - a.score)
      .slice(0, 10)
      .map((x) => x.p);
  }, [products, query, excludeIds]);

  useEffect(() => setHighlight(0), [query]);

  const handleSelect = (product) => {
    onProductSelect(product);
    setQuery("");
    setOpen(false);
  };

  const handleKeyDown = (e) => {
    if (e.key === "ArrowDown") {
      e.preventDefault();
      setOpen(true);
      setHighlight((h) => Math.min(h + 1, results.length - 1));
    } else if (e.key === "ArrowUp") {
      e.preventDefault();
      setHighlight((h) => Math.max(h - 1, 0));
    } else if (e.key === "Enter") {
      if (open && results.length > 0) {
        e.preventDefault();
        handleSelect(results[highlight] || results[0]);
      }
    } else if (e.key === "Escape") {
      setOpen(false);
    }
  };

  if (selected) {
    return (
      <div className="flex items-center gap-2 rounded-md border bg-muted/40 px-2 py-1.5">
        <div className="flex-1 min-w-0">
          <div className="text-sm font-medium truncate">{selected.name}</div>
          <div className="text-xs text-muted-foreground truncate">
            {selected.code && <span className="font-mono">{selected.code}</span>}
            {selected.code && selected.brand ? " · " : ""}
            {selected.brand || ""} · Estoque: {selected.stock_quantity ?? 0}
          </div>
        </div>
        {onClear && (
          <button
            type="button"
            onClick={onClear}
            className="text-muted-foreground hover:text-foreground"
          >
            <X className="h-4 w-4" />
          </button>
        )}
      </div>
    );
  }

  return (
    <div className="relative" ref={containerRef}>
      <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground pointer-events-none" />
      <Input
        ref={inputRef}
        placeholder={placeholder}
        value={query}
        onChange={(e) => { setQuery(e.target.value); setOpen(true); }}
        onFocus={() => setOpen(true)}
        onKeyDown={handleKeyDown}
        className="pl-8"
      />
      {open && results.length > 0 && (
        <div className="absolute z-50 mt-1 w-full rounded-md border bg-popover shadow-md max-h-72 overflow-y-auto">
          {results.map((p, i) => (
            <button
              key={p.id}
              type="button"
              onMouseEnter={() => setHighlight(i)}
              onClick={() => handleSelect(p)}
              className={`w-full text-left px-3 py-2 text-sm flex items-center justify-between gap-2 border-b last:border-0 ${
                i === highlight ? "bg-accent" : "hover:bg-accent/60"
              }`}
            >
              <div className="min-w-0 flex-1">
                <div className="font-medium truncate">{p.name}</div>
                <div className="text-xs text-muted-foreground truncate">
                  {p.code && <span className="font-mono">{p.code}</span>}
                  {p.code && p.brand ? " · " : ""}
                  {p.brand || ""}
                  {p.category ? ` · ${p.category}` : ""}
                  {" · "}
                  <span className={
                    (p.stock_quantity ?? 0) <= 0 ? "text-red-600 font-medium" : ""
                  }>
                    Est: {p.stock_quantity ?? 0} {p.unit_type || ""}
                  </span>
                </div>
              </div>
              {i === highlight && <Check className="h-3.5 w-3.5 text-muted-foreground shrink-0" />}
            </button>
          ))}
        </div>
      )}
      {open && query.trim() && results.length === 0 && (
        <div className="absolute z-50 mt-1 w-full rounded-md border bg-popover shadow-md px-3 py-4 text-sm text-muted-foreground text-center">
          Nenhum produto encontrado.
        </div>
      )}
    </div>
  );
}