import React, { useState, useEffect, useMemo } from "react";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/components/ui/use-toast";
import { useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { useAuth } from "@/lib/AuthContext";
import { ClipboardCheck, Search, Loader2, AlertTriangle } from "lucide-react";

function generateBatchId() {
  const d = new Date();
  const pad = (n) => String(n).padStart(2, "0");
  return `BAL-${d.getFullYear()}${pad(d.getMonth() + 1)}${pad(d.getDate())}-${pad(d.getHours())}${pad(d.getMinutes())}${pad(d.getSeconds())}`;
}

export default function MassStocktakingDialog({ open, onOpenChange, products }) {
  const { toast } = useToast();
  const { user } = useAuth();
  const queryClient = useQueryClient();
  const [loading, setLoading] = useState(false);
  const [search, setSearch] = useState("");
  const [counts, setCounts] = useState({});
  const [notes, setNotes] = useState("");
  const [batchId] = useState(generateBatchId);

  useEffect(() => {
    if (open) {
      setCounts({});
      setSearch("");
      setNotes("");
    }
  }, [open]);

  const filtered = useMemo(() => {
    const q = search.trim().toLowerCase();
    const list = (products || []).filter((p) => p.status !== "inactive");
    if (!q) return list;
    return list.filter(
      (p) =>
        (p.name || "").toLowerCase().includes(q) ||
        (p.code || "").toLowerCase().includes(q) ||
        (p.brand || "").toLowerCase().includes(q)
    );
  }, [products, search]);

  const diffs = useMemo(() => {
    const map = {};
    filtered.forEach((p) => {
      const counted = counts[p.id];
      if (counted === undefined || counted === "") return;
      const current = Number(p.stock_quantity) || 0;
      const countedNum = Number(counted);
      if (!isNaN(countedNum) && countedNum !== current) {
        map[p.id] = { current, counted: countedNum, diff: countedNum - current };
      }
    });
    return map;
  }, [filtered, counts]);

  const diffCount = Object.keys(diffs).length;
  const totalAdjustment = Object.values(diffs).reduce((s, d) => s + d.diff, 0);

  const handleConfirm = async () => {
    const entries = Object.entries(diffs);
    if (entries.length === 0) {
      toast({ title: "Nenhum ajuste a aplicar.", description: "Informe as quantidades contadas diferentes do estoque atual.", variant: "destructive" });
      return;
    }
    setLoading(true);
    try {
      for (const [productId, info] of entries) {
        const product = products.find((p) => p.id === productId);
        if (!product) continue;
        await base44.entities.InventoryMovement.create({
          product_id: productId,
          product_name: product.name,
          type: "inventory",
          quantity: Math.abs(info.diff),
          reason: info.diff > 0 ? "ajuste_positivo" : "ajuste_negativo",
          previous_quantity: info.current,
          new_quantity: info.counted,
          responsible: user?.email || user?.full_name || "Sistema",
          notes: `Balanço ${batchId}${notes ? ` — ${notes}` : ""}`,
          batch_id: batchId,
        });
        await base44.entities.Product.update(productId, { stock_quantity: info.counted });
      }
      queryClient.invalidateQueries({ queryKey: ["inventory-movements"] });
      queryClient.invalidateQueries({ queryKey: ["products"] });
      toast({
        title: "Balanço em massa concluído",
        description: `${entries.length} produto(s) ajustado(s).`,
      });
      onOpenChange(false);
    } catch (err) {
      toast({ title: "Erro ao aplicar balanço", description: String(err), variant: "destructive" });
    } finally {
      setLoading(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-5xl max-h-[92vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <ClipboardCheck className="h-5 w-5" /> Balanço em Massa
          </DialogTitle>
        </DialogHeader>

        <div className="rounded-lg border p-3 space-y-2 bg-muted/20">
          <div className="flex items-center gap-2 text-sm text-muted-foreground flex-wrap">
            <Badge variant="secondary">{batchId}</Badge>
            <span>·</span>
            <span>Informe a quantidade contada de cada produto. Apenas itens com diferença serão ajustados.</span>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div className="relative">
              <Search className="w-4 h-4 absolute left-2.5 top-3 text-muted-foreground" />
              <Input
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                placeholder="Buscar por nome, código ou marca..."
                className="pl-8"
              />
            </div>
            <div>
              <Label className="text-xs">Observações do balanço</Label>
              <Input value={notes} onChange={(e) => setNotes(e.target.value)} placeholder="Responsável, motivo, etc." />
            </div>
          </div>
        </div>

        {diffCount > 0 && (
          <div className="flex items-start gap-2 rounded-md border border-amber-300 bg-amber-50 p-3 text-sm text-amber-800">
            <AlertTriangle className="h-4 w-4 mt-0.5 shrink-0" />
            <div>
              <span className="font-medium">{diffCount} produto(s) com divergência.</span>{" "}
              Soma das diferenças: <span className="font-semibold">{totalAdjustment > 0 ? "+" : ""}{totalAdjustment}</span>
            </div>
          </div>
        )}

        <div className="rounded-lg border max-h-[50vh] overflow-y-auto">
          <table className="w-full text-sm">
            <thead className="sticky top-0 bg-muted/40 backdrop-blur">
              <tr className="text-left text-xs text-muted-foreground">
                <th className="px-3 py-2 font-medium">Produto</th>
                <th className="px-3 py-2 font-medium text-right">Estoque atual</th>
                <th className="px-3 py-2 font-medium text-right">Qtd. contada</th>
                <th className="px-3 py-2 font-medium text-right">Diferença</th>
              </tr>
            </thead>
            <tbody>
              {filtered.map((p) => {
                const current = Number(p.stock_quantity) || 0;
                const counted = counts[p.id];
                const countedNum = counted === undefined || counted === "" ? null : Number(counted);
                const diff = countedNum !== null && !isNaN(countedNum) ? countedNum - current : null;
                return (
                  <tr key={p.id} className="border-t hover:bg-muted/20">
                    <td className="px-3 py-2">
                      <div className="font-medium truncate">{p.name}</div>
                      <div className="text-xs text-muted-foreground flex gap-1.5">
                        {p.code && <span className="font-mono">{p.code}</span>}
                        {p.unit_type && <span>· {p.unit_type}</span>}
                      </div>
                    </td>
                    <td className="px-3 py-2 text-right">{current}</td>
                    <td className="px-3 py-2 text-right">
                      <Input
                        type="number"
                        min="0"
                        step="1"
                        value={counts[p.id] ?? ""}
                        onChange={(e) => setCounts((c) => ({ ...c, [p.id]: e.target.value }))}
                        className="w-24 h-8 text-right ml-auto"
                        placeholder="—"
                      />
                    </td>
                    <td className={`px-3 py-2 text-right font-medium ${diff === null ? "" : diff > 0 ? "text-emerald-600" : diff < 0 ? "text-red-600" : "text-muted-foreground"}`}>
                      {diff === null ? "—" : (diff > 0 ? "+" : "") + diff}
                    </td>
                  </tr>
                );
              })}
              {filtered.length === 0 && (
                <tr>
                  <td colSpan={4} className="px-3 py-8 text-center text-muted-foreground">Nenhum produto encontrado.</td>
                </tr>
              )}
            </tbody>
          </table>
        </div>

        <DialogFooter className="sm:justify-between gap-2">
          <div className="text-xs text-muted-foreground">
            {filtered.length} produto(s) listado(s) · {diffCount} com divergência
          </div>
          <div className="flex gap-2">
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>Cancelar</Button>
            <Button type="button" onClick={handleConfirm} disabled={loading || diffCount === 0}>
              {loading ? (<><Loader2 className="h-4 w-4 animate-spin" /> Aplicando...</>) : (<><ClipboardCheck className="h-4 w-4" /> Aplicar Balanço</>)}
            </Button>
          </div>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}