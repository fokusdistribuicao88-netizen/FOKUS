import React, { useState, useMemo } from "react";
import { formatBRL } from "@/lib/format";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Search, ArrowUpDown } from "lucide-react";

export default function InventoryCurrentTable({ products }) {
  const [search, setSearch] = useState("");
  const [sortBy, setSortBy] = useState("name");
  const [sortDir, setSortDir] = useState("asc");

  const filtered = useMemo(() => {
    const q = search.toLowerCase();
    let list = products.filter(
      (p) =>
        p.name?.toLowerCase().includes(q) ||
        p.code?.toLowerCase().includes(q) ||
        p.brand?.toLowerCase().includes(q) ||
        p.category?.toLowerCase().includes(q) ||
        p.description?.toLowerCase().includes(q)
    );
    list = [...list].sort((a, b) => {
      const av = a[sortBy] ?? 0;
      const bv = b[sortBy] ?? 0;
      if (typeof av === "string") return sortDir === "asc" ? av.localeCompare(bv) : bv.localeCompare(av);
      return sortDir === "asc" ? av - bv : bv - av;
    });
    return list;
  }, [products, search, sortBy, sortDir]);

  const toggleSort = (key) => {
    if (sortBy === key) setSortDir(sortDir === "asc" ? "desc" : "asc");
    else { setSortBy(key); setSortDir("asc"); }
  };

  const stockStatus = (p) => {
    const q = p.stock_quantity;
    if (q == null) return <Badge variant="secondary">Não rastreado</Badge>;
    if (q <= 0) return <Badge variant="destructive">Sem estoque</Badge>;
    if (q <= (p.low_stock_threshold || 0)) return <Badge variant="outline" className="border-amber-400 text-amber-600">Baixo</Badge>;
    return <Badge variant="outline" className="border-emerald-400 text-emerald-600">OK</Badge>;
  };

  const headers = [
    { key: "code", label: "Código" },
    { key: "name", label: "Nome" },
    { key: "category", label: "Categoria" },
    { key: "brand", label: "Marca" },
    { key: "stock_quantity", label: "Qtd." },
    { key: "cost", label: "Custo" },
    { key: "price", label: "Venda" },
  ];

  return (
    <div className="space-y-4">
      <div className="relative max-w-sm">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
        <Input
          placeholder="Pesquisar por nome, código ou categoria..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          className="pl-9"
        />
      </div>

      <div className="overflow-x-auto rounded-md border">
        <table className="w-full text-sm">
          <thead className="bg-muted/50">
            <tr>
              {headers.map((h) => (
                <th
                  key={h.key}
                  onClick={() => toggleSort(h.key)}
                  className="text-left px-3 py-2 font-medium cursor-pointer hover:bg-muted select-none"
                >
                  <div className="flex items-center gap-1">
                    {h.label}
                    <ArrowUpDown className="h-3 w-3 opacity-50" />
                  </div>
                </th>
              ))}
              <th className="text-left px-3 py-2 font-medium">Status</th>
            </tr>
          </thead>
          <tbody>
            {filtered.map((p) => (
              <tr key={p.id} className="border-t hover:bg-muted/30">
                <td className="px-3 py-2 font-mono text-xs">{p.code || "-"}</td>
                <td className="px-3 py-2 font-medium">{p.name}</td>
                <td className="px-3 py-2">{p.category || "-"}</td>
                <td className="px-3 py-2">{p.brand || "-"}</td>
                <td className="px-3 py-2">{p.stock_quantity ?? "-"}</td>
                <td className="px-3 py-2">{formatBRL(p.cost)}</td>
                <td className="px-3 py-2">{formatBRL(p.price)}</td>
                <td className="px-3 py-2">{stockStatus(p)}</td>
              </tr>
            ))}
            {filtered.length === 0 && (
              <tr>
                <td colSpan={8} className="px-3 py-6 text-center text-muted-foreground">
                  Nenhum produto encontrado.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}