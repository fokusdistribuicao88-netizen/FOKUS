import React, { useMemo, useState } from "react";
import { formatDateTime, formatBRL } from "@/lib/format";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Search } from "lucide-react";

const TYPE_META = {
  entry: { label: "Entrada", variant: "secondary", className: "text-emerald-600" },
  exit: { label: "Saída", variant: "outline", className: "text-red-600" },
  adjustment: { label: "Ajuste", variant: "outline" },
  inventory: { label: "Inventário", variant: "outline" },
};

export default function InventoryHistory({ movements }) {
  const [search, setSearch] = useState("");
  const [typeFilter, setTypeFilter] = useState("all");

  const filtered = useMemo(() => {
    return movements.filter((m) => {
      const matchSearch =
        m.product_name?.toLowerCase().includes(search.toLowerCase()) ||
        m.responsible?.toLowerCase().includes(search.toLowerCase()) ||
        m.reason?.toLowerCase().includes(search.toLowerCase());
      const matchType = typeFilter === "all" || m.type === typeFilter;
      return matchSearch && matchType;
    });
  }, [movements, search, typeFilter]);

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap gap-3">
        <div className="relative flex-1 min-w-[200px]">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Pesquisar produto, responsável ou motivo..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="pl-9"
          />
        </div>
        <div className="flex gap-1">
          {["all", "entry", "exit", "adjustment", "inventory"].map((t) => (
            <button
              key={t}
              onClick={() => setTypeFilter(t)}
              className={`px-3 py-1.5 rounded-md text-sm font-medium border transition ${
                typeFilter === t
                  ? "bg-primary text-primary-foreground border-primary"
                  : "bg-background hover:bg-muted"
              }`}
            >
              {t === "all" ? "Todos" : TYPE_META[t]?.label || t}
            </button>
          ))}
        </div>
      </div>

      <div className="overflow-x-auto rounded-md border">
        <table className="w-full text-sm">
          <thead className="bg-muted/50">
            <tr>
              <th className="text-left px-3 py-2 font-medium">Data/Hora</th>
              <th className="text-left px-3 py-2 font-medium">Produto</th>
              <th className="text-left px-3 py-2 font-medium">Tipo</th>
              <th className="text-left px-3 py-2 font-medium">Motivo</th>
              <th className="text-right px-3 py-2 font-medium">Qtd.</th>
              <th className="text-right px-3 py-2 font-medium">Anterior</th>
              <th className="text-right px-3 py-2 font-medium">Novo</th>
              <th className="text-left px-3 py-2 font-medium">Responsável</th>
            </tr>
          </thead>
          <tbody>
            {filtered.map((m) => {
              const meta = TYPE_META[m.type] || {};
              return (
                <tr key={m.id} className="border-t hover:bg-muted/30">
                  <td className="px-3 py-2 text-xs">{formatDateTime(m.created_date)}</td>
                  <td className="px-3 py-2 font-medium">{m.product_name}</td>
                  <td className="px-3 py-2">
                    <Badge variant={meta.variant} className={meta.className}>{meta.label}</Badge>
                  </td>
                  <td className="px-3 py-2 capitalize">{m.reason || "-"}</td>
                  <td className="px-3 py-2 text-right">{m.quantity}</td>
                  <td className="px-3 py-2 text-right text-muted-foreground">{m.previous_quantity ?? "-"}</td>
                  <td className="px-3 py-2 text-right font-medium">{m.new_quantity ?? "-"}</td>
                  <td className="px-3 py-2 text-xs">{m.responsible || "-"}</td>
                </tr>
              );
            })}
            {filtered.length === 0 && (
              <tr>
                <td colSpan={8} className="px-3 py-6 text-center text-muted-foreground">
                  Nenhuma movimentação encontrada.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}