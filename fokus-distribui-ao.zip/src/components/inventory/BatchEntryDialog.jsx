import React, { useState, useEffect, useMemo, useRef } from "react";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/components/ui/use-toast";
import { useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { useAuth } from "@/lib/AuthContext";
import { formatBRL } from "@/lib/format";
import BatchProductPicker from "@/components/inventory/BatchProductPicker";
import { Plus, Trash2, PackagePlus, AlertTriangle, Loader2, PackageSearch, Boxes } from "lucide-react";

const EMPTY_ROW = () => ({
  product_id: "",
  product_name: "",
  code: "",
  unit_type: "",
  quantity: "",
  unit_cost: "",
  batch: "",
  notes: "",
  stock_before: null,
});

function generateEntryNumber() {
  const d = new Date();
  const pad = (n) => String(n).padStart(2, "0");
  return `ENT-${d.getFullYear()}${pad(d.getMonth() + 1)}${pad(d.getDate())}-${pad(d.getHours())}${pad(d.getMinutes())}${pad(d.getSeconds())}`;
}

export default function BatchEntryDialog({ open, onOpenChange, products }) {
  const { toast } = useToast();
  const { user } = useAuth();
  const queryClient = useQueryClient();
  const [loading, setLoading] = useState(false);
  const [header, setHeader] = useState({
    entry_number: "",
    supplier: "",
    invoice_number: "",
    invoice_series: "",
    responsible: "",
    notes: "",
  });
  const [rows, setRows] = useState([]);
  const [consolidate, setConsolidate] = useState(true);
  const [pickerOpen, setPickerOpen] = useState(false);
  const quantityRefs = useRef([]);

  useEffect(() => {
    if (open) {
      setHeader({
        entry_number: generateEntryNumber(),
        supplier: "",
        invoice_number: "",
        invoice_series: "",
        responsible: user?.email || user?.full_name || "",
        notes: "",
      });
      setRows([]);
    }
  }, [open]);

  const now = new Date();
  const dateStr = now.toLocaleDateString("pt-BR");
  const timeStr = now.toLocaleTimeString("pt-BR", { hour: "2-digit", minute: "2-digit" });

  const updateRow = (idx, patch) => {
    setRows((prev) => prev.map((r, i) => (i === idx ? { ...r, ...patch } : r)));
  };

  const addProduct = (product) => {
    setRows((prev) => {
      const existingIdx = prev.findIndex((r) => r.product_id === product.id);
      if (existingIdx >= 0) {
        // Já está na lista: incrementa quantidade
        return prev.map((r, i) =>
          i === existingIdx
            ? { ...r, quantity: String((Number(r.quantity) || 0) + 1) }
            : r
        );
      }
      return [
        ...prev,
        {
          product_id: product.id,
          product_name: product.name,
          code: product.code || "",
          unit_type: product.unit_type || "",
          quantity: "",
          unit_cost: String(product.cost || ""),
          batch: "",
          notes: "",
          stock_before: product.stock_quantity ?? 0,
        },
      ];
    });
    setTimeout(() => {
      const el = quantityRefs.current[rows.length];
      if (el) el.focus();
    }, 40);
  };

  const removeRow = (idx) => {
    setRows((prev) => prev.filter((_, i) => i !== idx));
  };

  // Duplicatas
  const duplicates = useMemo(() => {
    const seen = {};
    rows.forEach((r, i) => {
      if (!r.product_id) return;
      if (seen[r.product_id]) seen[r.product_id].push(i);
      else seen[r.product_id] = [i];
    });
    return Object.entries(seen)
      .filter(([, idxs]) => idxs.length > 1)
      .map(([pid, idxs]) => ({ pid, idxs, name: rows[idxs[0]].product_name }));
  }, [rows]);

  // Linhas validas (com produto e quantidade > 0)
  const validRows = useMemo(
    () => rows.filter((r) => r.product_id && Number(r.quantity) > 0),
    [rows]
  );

  const grandTotal = useMemo(
    () =>
      validRows.reduce(
        (acc, r) => acc + (Number(r.unit_cost) || 0) * Number(r.quantity),
        0
      ),
    [validRows]
  );

  const handleQuantityKey = (e, idx) => {
    if (e.key === "Enter") {
      e.preventDefault();
      const next = quantityRefs.current[idx + 1];
      if (next) next.focus();
    }
  };

  const handleConfirm = async () => {
    if (!validRows.length) {
      toast({ title: "Adicione ao menos um produto com quantidade valida.", variant: "destructive" });
      return;
    }
    // Validar custos negativos
    const invalidCost = validRows.find((r) => Number(r.unit_cost) < 0);
    if (invalidCost) {
      toast({ title: `Custo invalido para ${invalidCost.product_name}.`, variant: "destructive" });
      return;
    }

    // Consolidar duplicatas se solicitado
    let toProcess = validRows;
    if (duplicates.length && consolidate) {
      const byId = {};
      validRows.forEach((r) => {
        if (!byId[r.product_id]) {
          byId[r.product_id] = { ...r };
        } else {
          const totalQty = Number(byId[r.product_id].quantity) + Number(r.quantity);
          const totalCost =
            (Number(byId[r.product_id].unit_cost) || 0) * Number(byId[r.product_id].quantity) +
            (Number(r.unit_cost) || 0) * Number(r.quantity);
          byId[r.product_id].quantity = String(totalQty);
          byId[r.product_id].unit_cost = String(totalCost / totalQty);
        }
      });
      toProcess = Object.values(byId);
    }

    setLoading(true);
    try {
      const batchId = header.entry_number;
      const productUpdates = {};
      // Buscar estoque atual de cada produto (snapshot fresh)
      for (const r of toProcess) {
        const prod = products.find((p) => p.id === r.product_id);
        const prev = prod?.stock_quantity ?? 0;
        productUpdates[r.product_id] = { prev, newQty: prev + Number(r.quantity) };
      }

      // Criar movimentacoes e atualizar produtos
      for (const r of toProcess) {
        const qty = Number(r.quantity);
        const unitCost = Number(r.unit_cost) || 0;
        const { prev, newQty } = productUpdates[r.product_id];
        const itemNotes = [r.batch && `Lote: ${r.batch}`, r.notes]
          .filter(Boolean)
          .join(" · ");
        const fullNotes = [
          header.notes,
          itemNotes,
          header.invoice_number && `NF: ${header.invoice_number}${header.invoice_series ? `/${header.invoice_series}` : ""}`,
          header.supplier && `Fornecedor: ${header.supplier}`,
        ].filter(Boolean).join(" | ");

        await base44.entities.InventoryMovement.create({
          product_id: r.product_id,
          product_name: r.product_name,
          type: "entry",
          quantity: qty,
          reason: "entrada",
          supplier: header.supplier,
          invoice_number: header.invoice_number,
          unit_cost: unitCost,
          total_cost: unitCost * qty,
          previous_quantity: prev,
          new_quantity: newQty,
          responsible: header.responsible || user?.email || "Sistema",
          notes: fullNotes,
          batch_id: batchId,
        });

        await base44.entities.Product.update(r.product_id, {
          stock_quantity: newQty,
          cost: unitCost || undefined,
        });
      }

      queryClient.invalidateQueries({ queryKey: ["inventory-movements"] });
      queryClient.invalidateQueries({ queryKey: ["products"] });

      toast({
        title: `Entrada em lote registrada`,
        description: `${toProcess.length} produto(s) atualizado(s). Total: ${formatBRL(grandTotal)}`,
      });
      onOpenChange(false);
    } catch (err) {
      toast({ title: "Erro ao registrar entrada em lote", description: String(err), variant: "destructive" });
    } finally {
      setLoading(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-6xl max-h-[92vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <PackagePlus className="h-5 w-5" /> Entrada em Lote
          </DialogTitle>
        </DialogHeader>

        {/* Cabecalho da movimentacao */}
        <div className="rounded-lg border p-4 space-y-3 bg-muted/20">
          <div className="flex items-center gap-2 text-sm text-muted-foreground">
            <Badge variant="secondary">{header.entry_number}</Badge>
            <span>·</span>
            <span>{dateStr}</span>
            <span>·</span>
            <span>{timeStr}</span>
          </div>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
            <div>
              <Label className="text-xs">Fornecedor</Label>
              <Input
                value={header.supplier}
                onChange={(e) => setHeader({ ...header, supplier: e.target.value })}
                placeholder="Nome do fornecedor"
              />
            </div>
            <div>
              <Label className="text-xs">Numero da NF</Label>
              <Input
                value={header.invoice_number}
                onChange={(e) => setHeader({ ...header, invoice_number: e.target.value })}
                placeholder="000.000.000"
              />
            </div>
            <div>
              <Label className="text-xs">Serie</Label>
              <Input
                value={header.invoice_series}
                onChange={(e) => setHeader({ ...header, invoice_series: e.target.value })}
                placeholder="001"
              />
            </div>
            <div>
              <Label className="text-xs">Responsavel</Label>
              <Input
                value={header.responsible}
                onChange={(e) => setHeader({ ...header, responsible: e.target.value })}
                placeholder="Responsavel"
              />
            </div>
          </div>
          <div>
            <Label className="text-xs">Observacoes gerais</Label>
            <Textarea
              rows={2}
              value={header.notes}
              onChange={(e) => setHeader({ ...header, notes: e.target.value })}
              placeholder="Observacoes da entrada..."
            />
          </div>
        </div>

        {/* Alerta de duplicatas */}
        {duplicates.length > 0 && (
          <div className="flex items-start gap-2 rounded-md border border-amber-300 bg-amber-50 p-3 text-sm text-amber-800">
            <AlertTriangle className="h-4 w-4 mt-0.5 shrink-0" />
            <div className="flex-1">
              <span className="font-medium">Produtos duplicados: </span>
              {duplicates.map((d) => d.name).join(", ")}
              <label className="flex items-center gap-2 mt-2 cursor-pointer">
                <input
                  type="checkbox"
                  checked={consolidate}
                  onChange={(e) => setConsolidate(e.target.checked)}
                />
                Consolidar somando as quantidades
              </label>
            </div>
          </div>
        )}

        {/* Lista de produtos (cards) */}
        <div className="rounded-lg border bg-muted/10">
          <div className="flex items-center justify-between px-3 py-2 border-b bg-muted/30">
            <div className="flex items-center gap-2 text-sm font-medium">
              <Boxes className="h-4 w-4" />
              Produtos da entrada
            </div>
            <span className="text-xs text-muted-foreground">
              {validRows.length} válido(s) · {rows.length} linha(s)
            </span>
          </div>

          {rows.length === 0 ? (
            <div className="p-6 text-center text-muted-foreground text-sm">
              <PackageSearch className="h-10 w-10 mx-auto mb-2 opacity-40" />
              Nenhum produto adicionado.
              <br />
              Use a aba <span className="font-medium">Pesquisar Produtos</span> à direita para adicionar.
            </div>
          ) : (
            <div className="p-2 space-y-2">
              {rows.map((row, idx) => (
                <div key={idx} className="rounded-lg border bg-background p-2.5">
                  <div className="flex gap-2.5">
                    {/* Thumb + info */}
                    <div className="w-11 h-11 shrink-0 rounded-md overflow-hidden bg-muted/40 flex items-center justify-center">
                      {products.find((p) => p.id === row.product_id)?.image_url ? (
                        <img
                          src={products.find((p) => p.id === row.product_id).image_url}
                          alt={row.product_name}
                          className="w-full h-full object-cover"
                        />
                      ) : (
                        <Boxes className="h-5 w-5 text-muted-foreground" />
                      )}
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-start gap-2">
                        <div className="flex-1 min-w-0">
                          <p className="text-sm font-medium leading-tight truncate">{row.product_name}</p>
                          <div className="flex items-center flex-wrap gap-x-1.5 gap-y-0.5 mt-0.5 text-xs text-muted-foreground">
                            {row.code && <span className="font-mono">{row.code}</span>}
                            {row.unit_type && <span>· {row.unit_type}</span>}
                            {row.stock_before != null && (
                              <span>· estoque atual: <span className="font-medium text-foreground">{row.stock_before}</span></span>
                            )}
                          </div>
                        </div>
                        <button
                          type="button"
                          onClick={() => removeRow(idx)}
                          aria-label={`Remover ${row.product_name}`}
                          className="shrink-0 w-9 h-9 flex items-center justify-center rounded-full hover:bg-red-50 hover:text-red-600 text-muted-foreground transition-colors touch-manipulation"
                        >
                          <Trash2 className="h-4 w-4" />
                        </button>
                      </div>

                      {/* Inputs em grid responsivo */}
                      <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 mt-2">
                        <div>
                          <Label className="text-[10px] text-muted-foreground">Qtd.</Label>
                          <Input
                            ref={(el) => (quantityRefs.current[idx] = el)}
                            type="number"
                            min="0"
                            step="1"
                            value={row.quantity}
                            onChange={(e) => updateRow(idx, { quantity: e.target.value })}
                            onKeyDown={(e) => handleQuantityKey(e, idx)}
                            className="text-right h-8"
                          />
                        </div>
                        <div>
                          <Label className="text-[10px] text-muted-foreground">Custo unit.</Label>
                          <Input
                            type="number"
                            min="0"
                            step="0.01"
                            value={row.unit_cost}
                            onChange={(e) => updateRow(idx, { unit_cost: e.target.value })}
                            className="text-right h-8"
                          />
                        </div>
                        <div>
                          <Label className="text-[10px] text-muted-foreground">Lote</Label>
                          <Input
                            value={row.batch}
                            onChange={(e) => updateRow(idx, { batch: e.target.value })}
                            className="h-8"
                          />
                        </div>
                        <div>
                          <Label className="text-[10px] text-muted-foreground">Observações</Label>
                          <Input
                            value={row.notes}
                            onChange={(e) => updateRow(idx, { notes: e.target.value })}
                            className="h-8"
                          />
                        </div>
                      </div>

                      <div className="flex items-center justify-between mt-2 text-xs">
                        <span className="text-muted-foreground">Total da linha</span>
                        <span className="font-semibold">
                          {row.quantity
                            ? formatBRL((Number(row.unit_cost) || 0) * Number(row.quantity))
                            : formatBRL(0)}
                        </span>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        <div className="flex items-center justify-between">
          <Button type="button" variant="outline" size="sm" onClick={() => setPickerOpen(true)}>
            <Plus className="h-4 w-4" /> Adicionar Produto
          </Button>
          <div className="text-right">
            <div className="text-xs text-muted-foreground">
              {validRows.length} produto(s) · {rows.length} linha(s)
            </div>
            <div className="text-lg font-bold">
             Total: {formatBRL(grandTotal)}
            </div>
            </div>
            </div>

            {/* Painel flutuante de pesquisa de produtos */}
            <BatchProductPicker
            products={products}
            onAdd={addProduct}
            addedIds={rows.map((r) => r.product_id)}
            open={pickerOpen}
            onOpenChange={setPickerOpen}
            />

            <DialogFooter>
          <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
            Cancelar
          </Button>
          <Button type="button" onClick={handleConfirm} disabled={loading}>
            {loading ? (
              <>
                <Loader2 className="h-4 w-4 animate-spin" /> Registrando...
              </>
            ) : (
              <>
                <PackagePlus className="h-4 w-4" /> Confirmar Entrada
              </>
            )}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}