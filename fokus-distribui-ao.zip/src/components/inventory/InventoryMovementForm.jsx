import React, { useState, useEffect } from "react";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/components/ui/use-toast";
import { useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { useAuth } from "@/lib/AuthContext";
import ProductPicker from "@/components/products/ProductPicker";

const EXIT_REASONS = [
  { value: "venda", label: "Venda" },
  { value: "transferencia", label: "Transferência" },
  { value: "perda", label: "Perda" },
  { value: "avaria", label: "Avaria" },
  { value: "consumo_interno", label: "Consumo interno" },
  { value: "ajuste", label: "Ajuste" },
  { value: "outro", label: "Outro" },
];

export default function InventoryMovementForm({
  open, onOpenChange, type, products,
}) {
  const { toast } = useToast();
  const { user } = useAuth();
  const queryClient = useQueryClient();
  const [loading, setLoading] = useState(false);
  const [form, setForm] = useState({
    product_id: "",
    quantity: "",
    supplier: "",
    invoice_number: "",
    unit_cost: "",
    reason: type === "exit" ? "venda" : "",
    notes: "",
  });

  useEffect(() => {
    setForm({
      product_id: "",
      quantity: "",
      supplier: "",
      invoice_number: "",
      unit_cost: "",
      reason: type === "exit" ? "venda" : type === "adjustment" ? "ajuste" : "",
      notes: "",
    });
  }, [type, open]);

  const selected = products.find((p) => p.id === form.product_id);

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!form.product_id) {
      toast({ title: "Selecione um produto", variant: "destructive" });
      return;
    }
    if (!form.quantity || Number(form.quantity) <= 0) {
      toast({ title: "Quantidade inválida", variant: "destructive" });
      return;
    }
    setLoading(true);
    try {
      const qty = Number(form.quantity);
      const prev = selected.stock_quantity || 0;
      let newQty;
      if (type === "entry") newQty = prev + qty;
      else if (type === "exit") newQty = Math.max(0, prev - qty);
      else newQty = qty; // adjustment = set absolute

      const unitCost = Number(form.unit_cost) || selected.cost || 0;

      await base44.entities.InventoryMovement.create({
        product_id: form.product_id,
        product_name: selected.name,
        type,
        quantity: qty,
        reason: form.reason,
        supplier: form.supplier,
        invoice_number: form.invoice_number,
        unit_cost: unitCost,
        total_cost: unitCost * qty,
        previous_quantity: prev,
        new_quantity: newQty,
        responsible: user?.email || user?.full_name || "Sistema",
        notes: form.notes,
      });

      await base44.entities.Product.update(form.product_id, { stock_quantity: newQty });

      queryClient.invalidateQueries({ queryKey: ["inventory-movements"] });
      queryClient.invalidateQueries({ queryKey: ["products"] });

      toast({ title: "Movimentação registrada e estoque atualizado." });
      onOpenChange(false);
    } catch (err) {
      toast({ title: "Erro ao registrar movimentação", description: String(err), variant: "destructive" });
    } finally {
      setLoading(false);
    }
  };

  const title =
    type === "entry" ? "Entrada de Estoque" :
    type === "exit" ? "Saída de Estoque" : "Ajuste de Estoque";

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-lg">
        <DialogHeader>
          <DialogTitle>{title}</DialogTitle>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-3">
          <div>
            <Label>Produto *</Label>
            <ProductPicker
              products={products}
              mode="select"
              selectedId={form.product_id}
              onSelect={(p) => setForm((f) => ({ ...f, product_id: p.id }))}
              triggerVariant="select"
              triggerLabel="Selecione um produto..."
              showCost
              priceLabel="Custo"
              stockFilter={type === "exit" ? "in_stock" : null}
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <Label>
                {type === "adjustment" ? "Nova quantidade" : "Quantidade"} *
              </Label>
              <Input
                type="number" min="0" step="1"
                value={form.quantity}
                onChange={(e) => setForm({ ...form, quantity: e.target.value })}
              />
            </div>
            <div>
              <Label>Valor unitário (custo)</Label>
              <Input
                type="number" min="0" step="0.01"
                value={form.unit_cost}
                onChange={(e) => setForm({ ...form, unit_cost: e.target.value })}
                placeholder={selected ? String(selected.cost || "") : ""}
              />
            </div>
          </div>

          {type === "entry" && (
            <div className="grid grid-cols-2 gap-3">
              <div>
                <Label>Fornecedor</Label>
                <Input value={form.supplier} onChange={(e) => setForm({ ...form, supplier: e.target.value })} />
              </div>
              <div>
                <Label>Nota Fiscal</Label>
                <Input value={form.invoice_number} onChange={(e) => setForm({ ...form, invoice_number: e.target.value })} />
              </div>
            </div>
          )}

          {type !== "entry" && (
            <div>
              <Label>Motivo</Label>
              <Select value={form.reason} onValueChange={(v) => setForm({ ...form, reason: v })}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  {EXIT_REASONS.map((r) => (
                    <SelectItem key={r.value} value={r.value}>{r.label}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          )}

          <div>
            <Label>Observações</Label>
            <Textarea
              rows={2}
              value={form.notes}
              onChange={(e) => setForm({ ...form, notes: e.target.value })}
            />
          </div>

          {selected && (
            <div className="text-sm text-muted-foreground bg-muted/50 rounded p-2">
              Estoque atual: <b>{selected.stock_quantity ?? 0}</b> → Novo:{" "}
              <b>
                {type === "entry"
                  ? (selected.stock_quantity || 0) + Number(form.quantity || 0)
                  : type === "exit"
                  ? Math.max(0, (selected.stock_quantity || 0) - Number(form.quantity || 0))
                  : Number(form.quantity || 0)}
              </b>
            </div>
          )}

          <DialogFooter>
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>Cancelar</Button>
            <Button type="submit" disabled={loading}>{loading ? "Salvando..." : "Registrar"}</Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}