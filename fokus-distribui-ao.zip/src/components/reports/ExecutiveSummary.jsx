import React from 'react';
import { StatCard, fmtBRL, fmtPct } from './shared';
import { DollarSign, Package, Receipt, TrendingUp, Wallet, Percent } from 'lucide-react';

// Visão executiva: Faturamento | Custos | Despesas | Lucro Bruto | Lucro Líquido | Margem
export default function ExecutiveSummary({ result }) {
  const r = result;
  return (
    <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3">
      <StatCard icon={DollarSign} label="Faturamento" value={fmtBRL(r.faturamento)} color="text-blue-600" sub={`${r.totalPedidos} pedidos`} />
      <StatCard icon={Package} label="Custo mercadorias" value={fmtBRL(r.cmv)} color="text-amber-600" sub={`${fmtPct(r.pctCMV)} do faturamento`} />
      <StatCard icon={Receipt} label="Despesas" value={fmtBRL(r.despesas.total)} color="text-red-600" sub={`${fmtPct(r.pctDespesas)} do faturamento`} />
      <StatCard icon={TrendingUp} label="Lucro bruto" value={fmtBRL(r.lucroBruto)} color="text-emerald-600" sub={`Margem ${fmtPct(r.margemBruta)}`} />
      <StatCard icon={Wallet} label="Lucro líquido" value={fmtBRL(r.lucroLiquido)} color={r.lucroLiquido >= 0 ? 'text-emerald-600' : 'text-red-600'} sub={`Margem ${fmtPct(r.margemLiquida)}`} />
      <StatCard icon={Percent} label="Margem líquida" value={fmtPct(r.margemLiquida)} color="text-violet-600" sub={`Salários: ${fmtPct(r.pctSalarios)}`} />
    </div>
  );
}