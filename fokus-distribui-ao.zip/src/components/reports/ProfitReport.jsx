import React, { useMemo } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { TrendingUp, Percent, AlertTriangle, Package } from 'lucide-react';
import { orderProfit, formatBRL, formatPct } from '@/lib/reportsCalc';

export default function ProfitReport({ orders, products }) {
  const data = useMemo(() => {
    const productMap = {};
    (products || []).forEach((p) => { productMap[p.id] = p; });
    const perOrder = orders.map((o) => {
      const p = orderProfit(o, productMap);
      return { id: o.id, customer: o.customer_name, ...p };
    });
    const totalProfit = perOrder.reduce((s, o) => s + o.profit, 0);
    const totalRevenue = perOrder.reduce((s, o) => s + o.netRevenue, 0);
    const totalCost = perOrder.reduce((s, o) => s + o.cost, 0);
    const avgMargin = totalRevenue > 0 ? (totalProfit / totalRevenue) * 100 : null;
    const profitByProduct = {};
    orders.forEach((o) => {
      (o.items || []).forEach((it) => {
        const prod = productMap[it.product_id];
        const qty = Number(it.quantity) || 0;
        const unit = Number(it.unit_price) || 0;
        const cost = prod ? Number(prod.cost) || 0 : 0;
        const key = it.product_name || prod?.name || '—';
        const cur = profitByProduct[key] || { name: key, revenue: 0, cost: 0, profit: 0, qty: 0 };
        cur.revenue += unit * qty;
        cur.cost += cost * qty;
        cur.profit += (unit - cost) * qty;
        cur.qty += qty;
      });
    });
    const topProducts = Object.values(profitByProduct)
      .filter((p) => p.revenue > 0)
      .sort((a, b) => b.profit - a.profit)
      .slice(0, 10);
    const negative = perOrder.filter((o) => o.profit < 0);
    return { perOrder, totalProfit, totalRevenue, totalCost, avgMargin, topProducts, negative };
  }, [orders, products]);

  const marginClass = (m) =>
    m == null ? 'bg-slate-100 text-slate-700' : m < 0 ? 'bg-red-100 text-red-700' : m < 15 ? 'bg-amber-100 text-amber-700' : 'bg-emerald-100 text-emerald-700';

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        <StatCard icon={TrendingUp} label="Receita líquida" value={formatBRL(data.totalRevenue)} color="text-blue-600" />
        <StatCard icon={Package} label="Custo das mercadorias" value={formatBRL(data.totalCost)} color="text-amber-600" />
        <StatCard icon={Percent} label="Lucro bruto" value={formatBRL(data.totalProfit)} color="text-emerald-600" />
        <StatCard icon={Percent} label="Margem média" value={data.avgMargin == null ? '-' : `${data.avgMargin.toFixed(1)}%`} color="text-violet-600" />
      </div>

      {data.negative.length > 0 && (
        <Card className="border-red-200 bg-red-50">
          <CardContent className="p-4">
            <div className="flex items-center gap-2 text-red-700 font-semibold mb-2">
              <AlertTriangle className="h-4 w-4" /> {data.negative.length} pedido(s) com lucro negativo
            </div>
            <div className="space-y-1">
              {data.negative.slice(0, 5).map((o) => (
                <div key={o.id} className="flex items-center justify-between text-sm">
                  <span className="truncate">#{o.id.substring(0, 8).toUpperCase()} · {o.customer}</span>
                  <span className="font-semibold text-red-600">{formatBRL(o.profit)}</span>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      <Card>
        <CardHeader><CardTitle className="text-base flex items-center gap-2"><TrendingUp className="h-4 w-4 text-emerald-600" /> Produtos mais lucrativos (no período)</CardTitle></CardHeader>
        <CardContent>
          {data.topProducts.length === 0 ? (
            <p className="text-sm text-muted-foreground py-8 text-center">Sem vendas no período.</p>
          ) : (
            <div className="space-y-1.5">
              {data.topProducts.map((p) => {
                const m = p.revenue > 0 ? (p.profit / p.revenue) * 100 : null;
                return (
                  <div key={p.name} className="flex items-center justify-between text-sm border-b pb-1.5">
                    <span className="truncate flex-1">{p.name}</span>
                    <span className="text-muted-foreground mx-3 text-xs">{p.qty} un.</span>
                    <span className="font-semibold mr-3">{formatBRL(p.profit)}</span>
                    <Badge className={marginClass(m)}>{formatPct(m)}</Badge>
                  </div>
                );
              })}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}

function StatCard({ icon: Icon, label, value, color }) {
  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between pb-2">
        <CardTitle className="text-xs font-medium text-muted-foreground">{label}</CardTitle>
        <Icon className={`h-4 w-4 ${color}`} />
      </CardHeader>
      <CardContent><div className="text-xl font-bold">{value}</div></CardContent>
    </Card>
  );
}