import React, { useMemo } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import {
  ResponsiveContainer, BarChart, Bar, XAxis, YAxis, Tooltip, CartesianGrid,
  PieChart, Pie, Cell, Legend,
} from 'recharts';
import { ShoppingCart, Users, CreditCard, Receipt, TrendingUp } from 'lucide-react';
import {
  salesTimeSeries, salesByCustomer, salesBySeller, salesByPaymentMethod,
  salesByStatus, formatBRL,
} from '@/lib/reportsCalc';
import { PAYMENT_METHODS, ORDER_STATUS } from '@/components/orders/orderStatus';

const PIE_COLORS = ['#2563eb', '#16a34a', '#f59e0b', '#dc2626', '#7c3aed', '#0891b2', '#db2777', '#65a30d'];

function MiniChart({ data, dataKey = 'total' }) {
  return (
    <ResponsiveContainer width="100%" height={260}>
      <BarChart data={data} margin={{ top: 10, right: 10, left: 0, bottom: 0 }}>
        <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
        <XAxis dataKey="date" tick={{ fontSize: 10 }} tickFormatter={(d) => d.slice(5)} />
        <YAxis tick={{ fontSize: 10 }} tickFormatter={(v) => `R$ ${v >= 1000 ? (v / 1000).toFixed(0) + 'k' : v}`} />
        <Tooltip formatter={(v) => formatBRL(v)} labelFormatter={(l) => `Data: ${l}`} contentStyle={{ fontSize: 12 }} />
        <Bar dataKey={dataKey} fill="#2563eb" radius={[4, 4, 0, 0]} />
      </BarChart>
    </ResponsiveContainer>
  );
}

export default function SalesReport({ orders }) {
  const data = useMemo(() => {
    const series = salesTimeSeries(orders);
    const customers = salesByCustomer(orders, 10);
    const sellers = salesBySeller(orders);
    const methods = salesByPaymentMethod(orders, PAYMENT_METHODS);
    const statuses = salesByStatus(orders, ORDER_STATUS);
    const totalSales = orders.reduce((s, o) => s + (Number(o.total) || 0), 0);
    const ticket = orders.length ? totalSales / orders.length : 0;
    return { series, customers, sellers, methods, statuses, totalSales, ticket, count: orders.length };
  }, [orders]);

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        <StatCard icon={ShoppingCart} label="Pedidos no período" value={String(data.count)} color="text-blue-600" />
        <StatCard icon={TrendingUp} label="Total vendido" value={formatBRL(data.totalSales)} color="text-emerald-600" />
        <StatCard icon={Receipt} label="Ticket médio" value={formatBRL(data.ticket)} color="text-violet-600" />
        <StatCard icon={Users} label="Clientes únicos" value={String(new Set(orders.map((o) => o.customer_name)).size)} color="text-amber-600" />
      </div>

      <Card>
        <CardHeader><CardTitle className="text-base">Vendas por dia</CardTitle></CardHeader>
        <CardContent>
          {data.series.length === 0 ? (
            <Empty />
          ) : (
            <MiniChart data={data.series} />
          )}
        </CardContent>
      </Card>

      <div className="grid lg:grid-cols-2 gap-4">
        <Card>
          <CardHeader><CardTitle className="text-base flex items-center gap-2"><Users className="h-4 w-4 text-blue-600" /> Top clientes</CardTitle></CardHeader>
          <CardContent>
            {data.customers.length === 0 ? <Empty /> : (
              <div className="space-y-1.5">
                {data.customers.map((c, i) => (
                  <div key={c.name} className="flex items-center justify-between text-sm border-b pb-1.5">
                    <span className="truncate"><span className="text-muted-foreground mr-2">#{i + 1}</span>{c.name}</span>
                    <span className="flex items-center gap-2">
                      <Badge variant="secondary">{c.count} ped.</Badge>
                      <span className="font-semibold">{formatBRL(c.total)}</span>
                    </span>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader><CardTitle className="text-base flex items-center gap-2"><TrendingUp className="h-4 w-4 text-emerald-600" /> Vendas por vendedor</CardTitle></CardHeader>
          <CardContent>
            {data.sellers.length === 0 ? <Empty /> : (
              <div className="space-y-1.5">
                {data.sellers.map((s) => (
                  <div key={s.name} className="flex items-center justify-between text-sm border-b pb-1.5">
                    <span className="truncate">{s.name}</span>
                    <span className="flex items-center gap-2">
                      <Badge variant="secondary">{s.count} ped.</Badge>
                      <span className="font-semibold">{formatBRL(s.total)}</span>
                    </span>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      <div className="grid lg:grid-cols-2 gap-4">
        <Card>
          <CardHeader><CardTitle className="text-base flex items-center gap-2"><CreditCard className="h-4 w-4 text-violet-600" /> Forma de pagamento</CardTitle></CardHeader>
          <CardContent>
            {data.methods.length === 0 ? <Empty /> : (
              <div className="flex flex-col md:flex-row items-center gap-4">
                <ResponsiveContainer width="100%" height={220}>
                  <PieChart>
                    <Pie data={data.methods} dataKey="total" nameKey="label" cx="50%" cy="50%" outerRadius={80} label={(e) => e.label}>
                      {data.methods.map((_, i) => <Cell key={i} fill={PIE_COLORS[i % PIE_COLORS.length]} />)}
                    </Pie>
                    <Tooltip formatter={(v) => formatBRL(v)} contentStyle={{ fontSize: 12 }} />
                    <Legend wrapperStyle={{ fontSize: 11 }} />
                  </PieChart>
                </ResponsiveContainer>
              </div>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader><CardTitle className="text-base">Status dos pedidos</CardTitle></CardHeader>
          <CardContent>
            {data.statuses.length === 0 ? <Empty /> : (
              <div className="space-y-1.5">
                {data.statuses.map((s) => (
                  <div key={s.status} className="flex items-center justify-between text-sm border-b pb-1.5">
                    <span className="truncate">{s.label}</span>
                    <span className="flex items-center gap-2">
                      <Badge variant="secondary">{s.count}</Badge>
                      <span className="font-semibold">{formatBRL(s.total)}</span>
                    </span>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}

function StatCard({ icon: Icon, label, value, color }) {
  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between pb-2">
        <CardTitle className="text-xs font-medium text-muted-foreground">{label}</CardTitle>
        <Icon className={`h-4 w-4 ${color}`} />
      </CardHeader>
      <CardContent><div className="text-xl font-bold">{value}</div></CardContent>
    </Card>
  );
}

function Empty() {
  return <p className="text-sm text-muted-foreground py-8 text-center">Sem dados no período selecionado.</p>;
}