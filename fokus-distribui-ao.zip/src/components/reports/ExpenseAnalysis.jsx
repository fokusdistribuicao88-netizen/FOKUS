import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { ResponsiveContainer, PieChart, Pie, Cell, Tooltip, Legend, BarChart, Bar, XAxis, YAxis, CartesianGrid } from 'recharts';
import { Receipt, CheckCircle2, Clock, AlertCircle, Fuel, Gift } from 'lucide-react';
import { StatCard, fmtBRL, Empty, Row } from './shared';

const PIE_COLORS = ['#3b82f6', '#ef4444', '#f59e0b', '#10b981', '#8b5cf6', '#ec4899', '#06b6d4', '#64748b', '#f97316', '#14b8a6', '#a855f7', '#0ea5e9'];
const GROUP_LABELS = { operacional: 'Operacional', funcionarios: 'Funcionários', veiculos: 'Veículos', impostos: 'Impostos', servicos: 'Serviços', outros: 'Outros' };

export default function ExpenseAnalysis({ result }) {
  const r = result;
  const d = r.despesas;
  return (
    <div className="space-y-4">
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        <StatCard icon={Receipt} label="Total de despesas" value={fmtBRL(d.total)} color="text-red-600" />
        <StatCard icon={CheckCircle2} label="Pagas" value={fmtBRL(d.paid)} color="text-emerald-600" />
        <StatCard icon={Clock} label="Pendentes" value={fmtBRL(d.pending)} color="text-amber-600" />
        <StatCard icon={AlertCircle} label="Vencidas" value={fmtBRL(d.overdue)} color="text-red-600" />
      </div>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        <StatCard icon={Fuel} label="Combustível" value={fmtBRL(d.combustivel)} color="text-orange-600" />
        <StatCard icon={Receipt} label="Salários" value={fmtBRL(r.funcionarios.salariosTotal)} color="text-blue-600" />
        <StatCard icon={Gift} label="Bonificações" value={fmtBRL(r.funcionarios.bonusTotal)} color="text-orange-600" />
        <StatCard icon={Receipt} label="Operacionais" value={fmtBRL(d.porGrupo.find((g) => g.key === 'operacional')?.value || 0)} color="text-violet-600" />
      </div>

      <div className="grid lg:grid-cols-2 gap-4">
        <Card>
          <CardHeader><CardTitle className="text-base">Despesas por categoria</CardTitle></CardHeader>
          <CardContent>
            {d.porCategoria.length === 0 ? <Empty /> : (
              <ResponsiveContainer width="100%" height={280}>
                <PieChart>
                  <Pie data={d.porCategoria} dataKey="value" nameKey="name" cx="50%" cy="50%" outerRadius={90} label={(e) => e.name}>
                    {d.porCategoria.map((_, i) => <Cell key={i} fill={PIE_COLORS[i % PIE_COLORS.length]} />)}
                  </Pie>
                  <Tooltip formatter={(v) => fmtBRL(v)} contentStyle={{ fontSize: 12 }} />
                  <Legend wrapperStyle={{ fontSize: 11 }} />
                </PieChart>
              </ResponsiveContainer>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader><CardTitle className="text-base">Despesas por grupo</CardTitle></CardHeader>
          <CardContent>
            {d.porGrupo.length === 0 ? <Empty /> : (
              <ResponsiveContainer width="100%" height={280}>
                <BarChart data={d.porGrupo.map((g) => ({ name: GROUP_LABELS[g.key] || g.key, value: g.value }))}>
                  <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
                  <XAxis dataKey="name" tick={{ fontSize: 11 }} />
                  <YAxis tick={{ fontSize: 10 }} tickFormatter={(v) => `R$ ${v >= 1000 ? (v / 1000).toFixed(0) + 'k' : v}`} />
                  <Tooltip formatter={(v) => fmtBRL(v)} contentStyle={{ fontSize: 12 }} />
                  <Bar dataKey="value" fill="#ef4444" radius={[4, 4, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            )}
          </CardContent>
        </Card>
      </div>

      <div className="grid lg:grid-cols-2 gap-4">
        <Card>
          <CardHeader><CardTitle className="text-base">Despesas por centro de custo</CardTitle></CardHeader>
          <CardContent>
            {d.porCentro.length === 0 ? <Empty /> : (
              <div className="space-y-1.5">
                {d.porCentro.map((c) => (
                  <div key={c.name} className="flex items-center justify-between text-sm border-b pb-1.5">
                    <span>{c.name}</span>
                    <span className="font-semibold">{fmtBRL(c.value)}</span>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader><CardTitle className="text-base">Despesas por mês</CardTitle></CardHeader>
          <CardContent>
            {r.monthly.length === 0 ? <Empty /> : (
              <ResponsiveContainer width="100%" height={240}>
                <BarChart data={r.monthly}>
                  <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
                  <XAxis dataKey="month" tick={{ fontSize: 11 }} />
                  <YAxis tick={{ fontSize: 10 }} tickFormatter={(v) => `R$ ${v >= 1000 ? (v / 1000).toFixed(0) + 'k' : v}`} />
                  <Tooltip formatter={(v) => fmtBRL(v)} contentStyle={{ fontSize: 12 }} />
                  <Bar dataKey="despesas" fill="#ef4444" radius={[4, 4, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            )}
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader><CardTitle className="text-base">Detalhamento por categoria</CardTitle></CardHeader>
        <CardContent>
          {d.porCategoria.length === 0 ? <Empty /> : (
            <div className="space-y-1">
              {d.porCategoria.map((c) => (
                <Row key={c.name} label={`${c.name} (${GROUP_LABELS[c.group] || c.group})`} value={fmtBRL(c.value)} muted />
              ))}
              <Row label="Total" value={fmtBRL(d.total)} strong />
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}