import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';

export const fmtBRL = (v) => (Number(v) || 0).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
export const fmtPct = (v) => (v == null ? '—' : `${(Number(v) || 0).toFixed(1)}%`);

export function StatCard({ icon: Icon, label, value, color = 'text-blue-600', sub }) {
  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between pb-2 space-y-0">
        <CardTitle className="text-xs font-medium text-muted-foreground">{label}</CardTitle>
        {Icon && <Icon className={`h-4 w-4 ${color}`} />}
      </CardHeader>
      <CardContent>
        <div className="text-xl font-bold">{value}</div>
        {sub && <p className="text-xs text-muted-foreground mt-1">{sub}</p>}
      </CardContent>
    </Card>
  );
}

export function Empty({ msg = 'Sem dados no período selecionado.' }) {
  return <p className="text-sm text-muted-foreground py-8 text-center">{msg}</p>;
}

export function marginClass(m) {
  if (m == null) return 'bg-slate-100 text-slate-700';
  if (m < 0) return 'bg-red-100 text-red-700';
  if (m < 15) return 'bg-amber-100 text-amber-700';
  return 'bg-emerald-100 text-emerald-700';
}

export function Row({ label, value, strong = false, muted = false, negative = false }) {
  return (
    <div className="flex justify-between py-1.5 border-b border-border last:border-0">
      <span className={`text-sm ${muted ? 'text-muted-foreground' : ''}`}>{label}</span>
      <span className={`text-sm tabular-nums ${strong ? 'font-bold' : 'font-medium'} ${negative ? 'text-red-600' : ''}`}>{value}</span>
    </div>
  );
}