import React, { useState, useMemo } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Select, SelectTrigger, SelectValue, SelectContent, SelectItem } from '@/components/ui/select';
import { Briefcase, Clock, Wallet, ShoppingCart, TrendingUp, Users, Gift } from 'lucide-react';
import { StatCard, fmtBRL, fmtPct, Empty, Row } from './shared';

export default function EmployeeAnalysis({ result, payrolls, employees }) {
  const r = result;
  const f = r.funcionarios;
  const [empId, setEmpId] = useState('all');

  const empHistory = useMemo(() => {
    if (empId === 'all') return [];
    return (payrolls || []).filter((p) => p.employee_id === empId && p.status !== 'open').sort((a, b) => b.competence_month.localeCompare(a.competence_month));
  }, [empId, payrolls]);

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3">
        <StatCard icon={Wallet} label="Salários pagos" value={fmtBRL(f.salariosTotal)} color="text-blue-600" />
        <StatCard icon={TrendingUp} label="Salário bruto" value={fmtBRL(f.brutoFolha)} color="text-emerald-600" />
        <StatCard icon={Clock} label="Horas extras" value={fmtBRL(f.horasExtrasTotal)} color="text-amber-600" />
        <StatCard icon={Gift} label="Bonificações" value={fmtBRL(f.bonusTotal)} color="text-orange-600" />
        <StatCard icon={Wallet} label="Adiantamentos" value={fmtBRL(f.adiantamentos)} color="text-violet-600" />
        <StatCard icon={ShoppingCart} label="Compras descontadas" value={fmtBRL(f.compras)} color="text-pink-600" />
      </div>
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        <StatCard icon={Users} label="Funcionários na folha" value={String(f.funcionariosAtivos)} color="text-cyan-600" />
        <StatCard icon={Briefcase} label="INSS descontado" value={fmtBRL(f.inss)} color="text-red-600" />
        <StatCard icon={Briefcase} label="Outros descontos" value={fmtBRL(f.outrosDescontos)} color="text-red-600" />
        <StatCard icon={Gift} label="Bonif. % custo folha" value={fmtPct(f.pctBonusFolha)} color="text-orange-600" />
      </div>

      <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
        <StatCard icon={Briefcase} label="Custo total folha" value={fmtBRL(f.custoTotalFolha)} color="text-blue-600" />
        <StatCard icon={Gift} label="Bonificações no período" value={fmtBRL(f.bonusTotal)} color="text-orange-600" />
        <StatCard icon={Gift} label="Bonif. / custo folha" value={fmtPct(f.pctBonusFolha)} color="text-orange-600" />
      </div>

      <Card>
        <CardHeader><CardTitle className="text-base">Histórico mensal por funcionário</CardTitle></CardHeader>
        <CardContent>
          <div className="mb-3">
            <Select value={empId} onValueChange={setEmpId}>
              <SelectTrigger className="md:w-80"><SelectValue placeholder="Selecione um funcionário" /></SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Todos (resumo)</SelectItem>
                {(employees || []).map((e) => <SelectItem key={e.id} value={e.id}>{e.name}</SelectItem>)}
              </SelectContent>
            </Select>
          </div>

          {empId === 'all' ? (
            <div className="space-y-1">
              <Row label="Salário bruto total" value={fmtBRL(f.brutoFolha)} muted />
              <Row label="Horas extras" value={fmtBRL(f.horasExtrasTotal)} muted />
              <Row label="Bonificações" value={fmtBRL(f.bonusTotal)} muted />
              <Row label="INSS" value={fmtBRL(f.inss)} muted />
              <Row label="Adiantamentos" value={fmtBRL(f.adiantamentos)} muted />
              <Row label="Compras descontadas" value={fmtBRL(f.compras)} muted />
              <Row label="Outros descontos" value={fmtBRL(f.outrosDescontos)} muted />
              <Row label="Salários líquidos pagos" value={fmtBRL(f.salariosTotal)} strong />
            </div>
          ) : empHistory.length === 0 ? (
            <Empty msg="Sem folhas fechadas para este funcionário." />
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead className="text-muted-foreground border-b">
                  <tr><th className="text-left px-2 py-2 font-medium">Competência</th><th className="text-right px-2 py-2 font-medium">Bruto</th><th className="text-right px-2 py-2 font-medium">Horas extras</th><th className="text-right px-2 py-2 font-medium">Descontos</th><th className="text-right px-2 py-2 font-medium">Líquido</th><th className="text-center px-2 py-2 font-medium">Status</th></tr>
                </thead>
                <tbody>
                  {empHistory.map((p) => (
                    <tr key={p.id} className="border-b border-border">
                      <td className="px-2 py-2 font-medium">{p.competence_month}</td>
                      <td className="px-2 py-2 text-right">{fmtBRL(p.gross_salary)}</td>
                      <td className="px-2 py-2 text-right">{fmtBRL(p.overtime_total)}</td>
                      <td className="px-2 py-2 text-right text-red-600">{fmtBRL(p.total_discounts)}</td>
                      <td className="px-2 py-2 text-right font-semibold">{fmtBRL(p.net_salary)}</td>
                      <td className="px-2 py-2 text-center"><Badge variant={p.status === 'paid' ? 'default' : 'secondary'}>{p.status === 'paid' ? 'Paga' : 'Fechada'}</Badge></td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}