import React, { useMemo } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Wallet, TrendingUp, TrendingDown, AlertCircle, ArrowDownRight, ArrowUpRight } from 'lucide-react';
import { financialSummary, formatBRL } from '@/lib/reportsCalc';

export default function FinancialReport({ entries }) {
  const data = useMemo(() => financialSummary(entries), [entries]);

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        <StatCard icon={TrendingUp} label="A receber (total)" value={formatBRL(data.receivableTotal)} color="text-emerald-600" />
        <StatCard icon={ArrowDownRight} label="Já recebido" value={formatBRL(data.receivablePaid)} color="text-blue-600" />
        <StatCard icon={AlertCircle} label="A receber vencido" value={formatBRL(data.receivableOverdue)} color="text-red-600" />
        <StatCard icon={Wallet} label="A receber pendente" value={formatBRL(data.receivablePending)} color="text-amber-600" />
      </div>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        <StatCard icon={TrendingDown} label="A pagar (total)" value={formatBRL(data.payableTotal)} color="text-red-600" />
        <StatCard icon={ArrowUpRight} label="Já pago" value={formatBRL(data.payablePaid)} color="text-blue-600" />
        <StatCard icon={AlertCircle} label="A pagar vencido" value={formatBRL(data.payableOverdue)} color="text-red-600" />
        <StatCard icon={Wallet} label="A pagar pendente" value={formatBRL(data.payablePending)} color="text-amber-600" />
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="text-base flex items-center gap-2">
            <Wallet className="h-4 w-4 text-violet-600" /> Fluxo líquido realizado
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex items-center justify-between p-4 rounded-xl bg-muted/40">
            <div>
              <p className="text-sm text-muted-foreground">Recebido − Pago</p>
              <p className="text-xs text-muted-foreground mt-1">Saldo de caixa no período</p>
            </div>
            <div className="text-right">
              <div className={`text-2xl font-bold ${data.netFlow >= 0 ? 'text-emerald-600' : 'text-red-600'}`}>
                {formatBRL(data.netFlow)}
              </div>
              <Badge variant={data.netFlow >= 0 ? 'secondary' : 'destructive'} className="mt-1">
                {data.netFlow >= 0 ? 'Saldo positivo' : 'Saldo negativo'}
              </Badge>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader><CardTitle className="text-base">Resumo consolidado</CardTitle></CardHeader>
        <CardContent>
          <div className="grid sm:grid-cols-2 gap-4 text-sm">
            <div className="space-y-2">
              <p className="font-semibold text-emerald-700 border-b pb-1">Contas a Receber</p>
              <Row label="Total previsto" value={formatBRL(data.receivableTotal)} />
              <Row label="Já recebido" value={formatBRL(data.receivablePaid)} />
              <Row label="Pendente a receber" value={formatBRL(data.receivablePending)} />
              <Row label="Vencido" value={formatBRL(data.receivableOverdue)} negative />
            </div>
            <div className="space-y-2">
              <p className="font-semibold text-red-700 border-b pb-1">Contas a Pagar</p>
              <Row label="Total previsto" value={formatBRL(data.payableTotal)} />
              <Row label="Já pago" value={formatBRL(data.payablePaid)} />
              <Row label="Pendente a pagar" value={formatBRL(data.payablePending)} />
              <Row label="Vencido" value={formatBRL(data.payableOverdue)} negative />
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

function StatCard({ icon: Icon, label, value, color }) {
  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between pb-2">
        <CardTitle className="text-xs font-medium text-muted-foreground">{label}</CardTitle>
        <Icon className={`h-4 w-4 ${color}`} />
      </CardHeader>
      <CardContent><div className="text-xl font-bold">{value}</div></CardContent>
    </Card>
  );
}

function Row({ label, value, negative }) {
  return (
    <div className="flex items-center justify-between">
      <span className="text-muted-foreground">{label}</span>
      <span className={`font-semibold ${negative ? 'text-red-600' : ''}`}>{value}</span>
    </div>
  );
}