import React, { useMemo } from 'react';
import { useQuery } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { FileText, TrendingUp, CheckCircle2, XCircle, Percent, Users, Package, DollarSign } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { StatCard, fmtBRL, fmtPct, Empty } from './shared';
import { QUOTE_STATUS } from '@/components/quotes/quoteStatus';

export default function QuotesAnalysis({ start, end }) {
  const quotesQ = useQuery({ queryKey: ['quotes'], queryFn: () => base44.entities.Quote.list('-created_date', 2000) });
  const ordersQ = useQuery({ queryKey: ['orders'], queryFn: () => base44.entities.Order.list('-created_date', 2000) });

  const quotes = quotesQ.data || [];
  const orders = ordersQ.data || [];

  const inRange = useMemo(() => {
    return quotes.filter((q) => {
      if (!q.created_date) return false;
      const d = q.created_date.slice(0, 10);
      if (start && d < start) return false;
      if (end && d > end) return false;
      if (q.deleted_at) return false;
      return true;
    });
  }, [quotes, start, end]);

  const metrics = useMemo(() => {
    const total = inRange.length;
    const totalValue = inRange.reduce((s, q) => s + (Number(q.total) || 0), 0);
    const converted = inRange.filter((q) => q.status === 'transformado');
    const convertedCount = converted.length;
    const notConvertedCount = total - convertedCount;
    const conversionRate = total > 0 ? (convertedCount / total) * 100 : 0;

    // Valor convertido em vendas: soma dos pedidos vinculados
    const convertedOrderIds = new Set(converted.map((q) => q.converted_order_id).filter(Boolean));
    const convertedOrders = orders.filter((o) => convertedOrderIds.has(o.id));
    const convertedValue = convertedOrders.reduce((s, o) => s + (Number(o.total) || 0), 0);

    // Valor perdido: orçamentos não convertidos (recusados, expirados, cancelados ou salvo sem conversão)
    const lostQuotes = inRange.filter((q) => q.status !== 'transformado');
    const lostValue = lostQuotes.reduce((s, q) => s + (Number(q.total) || 0), 0);

    // Clientes com mais orçamentos
    const byCustomer = {};
    inRange.forEach((q) => {
      const name = q.customer_name || '—';
      if (!byCustomer[name]) byCustomer[name] = { count: 0, value: 0 };
      byCustomer[name].count++;
      byCustomer[name].value += Number(q.total) || 0;
    });
    const topCustomers = Object.entries(byCustomer).sort((a, b) => b[1].count - a[1].count).slice(0, 10);

    // Produtos mais orçados
    const byProduct = {};
    inRange.forEach((q) => {
      (q.items || []).forEach((it) => {
        const name = it.product_name || '—';
        if (!byProduct[name]) byProduct[name] = { qty: 0, value: 0, count: 0 };
        byProduct[name].qty += Number(it.quantity) || 0;
        byProduct[name].value += Number(it.subtotal) || 0;
        byProduct[name].count++;
      });
    });
    const topProducts = Object.entries(byProduct).sort((a, b) => b[1].qty - a[1].qty).slice(0, 10);

    // Por status
    const byStatus = {};
    inRange.forEach((q) => {
      const s = q.status || '—';
      if (!byStatus[s]) byStatus[s] = { count: 0, value: 0 };
      byStatus[s].count++;
      byStatus[s].value += Number(q.total) || 0;
    });

    return {
      total, totalValue, convertedCount, notConvertedCount, conversionRate,
      convertedValue, lostValue, topCustomers, topProducts, byStatus,
    };
  }, [inRange, orders]);

  if (quotesQ.isLoading) {
    return <div className="flex items-center justify-center py-12"><div className="w-8 h-8 border-4 border-slate-200 border-t-slate-800 rounded-full animate-spin" /></div>;
  }

  if (metrics.total === 0) {
    return <Empty msg="Nenhum orçamento no período selecionado." />;
  }

  return (
    <div className="space-y-4">
      {/* KPIs */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        <StatCard icon={FileText} label="Total de orçamentos" value={metrics.total} color="text-blue-600" />
        <StatCard icon={DollarSign} label="Valor total orçado" value={fmtBRL(metrics.totalValue)} color="text-indigo-600" />
        <StatCard icon={CheckCircle2} label="Convertidos em venda" value={metrics.convertedCount} color="text-emerald-600" sub={fmtBRL(metrics.convertedValue)} />
        <StatCard icon={XCircle} label="Não convertidos" value={metrics.notConvertedCount} color="text-rose-600" sub={fmtBRL(metrics.lostValue)} />
        <StatCard icon={Percent} label="Taxa de conversão" value={fmtPct(metrics.conversionRate)} color="text-violet-600" />
        <StatCard icon={TrendingUp} label="Valor convertido em vendas" value={fmtBRL(metrics.convertedValue)} color="text-emerald-600" />
        <StatCard icon={XCircle} label="Valor perdido" value={fmtBRL(metrics.lostValue)} color="text-red-600" />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {/* Por status */}
        <Card>
          <CardHeader><CardTitle className="text-sm">Orçamentos por status</CardTitle></CardHeader>
          <CardContent>
            <div className="space-y-1.5">
              {Object.entries(metrics.byStatus).sort((a, b) => b[1].value - a[1].value).map(([status, data]) => {
                const s = QUOTE_STATUS[status] || { label: status, badge: 'bg-slate-100 text-slate-700' };
                return (
                  <div key={status} className="flex items-center justify-between py-1.5 border-b border-border last:border-0">
                    <span className={`inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium ${s.badge}`}>{s.label}</span>
                    <div className="flex items-center gap-4 text-sm">
                      <span className="text-muted-foreground">{data.count} orç.</span>
                      <span className="font-medium tabular-nums">{fmtBRL(data.value)}</span>
                    </div>
                  </div>
                );
              })}
            </div>
          </CardContent>
        </Card>

        {/* Clientes com mais orçamentos */}
        <Card>
          <CardHeader><CardTitle className="text-sm flex items-center gap-2"><Users className="h-4 w-4" /> Clientes com mais orçamentos</CardTitle></CardHeader>
          <CardContent>
            {metrics.topCustomers.length === 0 ? <Empty msg="Sem dados." /> : (
              <div className="space-y-1.5">
                {metrics.topCustomers.map(([name, data], i) => (
                  <div key={name} className="flex items-center justify-between py-1.5 border-b border-border last:border-0">
                    <span className="text-sm truncate flex items-center gap-2">
                      <span className="text-xs text-muted-foreground w-5">{i + 1}º</span>
                      {name}
                    </span>
                    <div className="flex items-center gap-4 text-sm">
                      <span className="text-muted-foreground">{data.count} orc.</span>
                      <span className="font-medium tabular-nums">{fmtBRL(data.value)}</span>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>

        {/* Produtos mais orçados */}
        <Card className="lg:col-span-2">
          <CardHeader><CardTitle className="text-sm flex items-center gap-2"><Package className="h-4 w-4" /> Produtos mais orçados</CardTitle></CardHeader>
          <CardContent>
            {metrics.topProducts.length === 0 ? <Empty msg="Sem dados." /> : (
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead className="text-muted-foreground">
                    <tr>
                      <th className="text-left py-1.5 font-medium">#</th>
                      <th className="text-left py-1.5 font-medium">Produto</th>
                      <th className="text-right py-1.5 font-medium">Orçamentos</th>
                      <th className="text-right py-1.5 font-medium">Qtd. total</th>
                      <th className="text-right py-1.5 font-medium">Valor total</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-border">
                    {metrics.topProducts.map(([name, data], i) => (
                      <tr key={name}>
                        <td className="py-1.5 text-muted-foreground">{i + 1}º</td>
                        <td className="py-1.5">{name}</td>
                        <td className="py-1.5 text-right">{data.count}</td>
                        <td className="py-1.5 text-right tabular-nums">{data.qty}</td>
                        <td className="py-1.5 text-right font-medium tabular-nums">{fmtBRL(data.value)}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}