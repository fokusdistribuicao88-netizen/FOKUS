import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { ResponsiveContainer, BarChart, Bar, XAxis, YAxis, Tooltip, CartesianGrid, Legend, ComposedChart, Line, Cell } from 'recharts';
import { fmtBRL, fmtPct, Row } from './shared';
import { ArrowDown, ArrowRight, CheckCircle2 } from 'lucide-react';

function Step({ label, value, tone = 'neutral', isResult = false, pct }) {
  const tones = {
    positive: 'bg-emerald-50 border-emerald-200 text-emerald-800',
    negative: 'bg-red-50 border-red-200 text-red-800',
    neutral: 'bg-blue-50 border-blue-200 text-blue-800',
    result: 'bg-violet-50 border-violet-300 text-violet-900',
  };
  return (
    <div className={`rounded-lg border p-3 ${tones[tone]} ${isResult ? 'ring-2 ring-violet-300' : ''}`}>
      <div className="flex items-center justify-between">
        <span className="text-xs font-medium opacity-80">{label}</span>
        {pct != null && <span className="text-xs font-semibold opacity-70">{pct}</span>}
      </div>
      <p className="text-lg font-bold mt-0.5">{fmtBRL(value)}</p>
    </div>
  );
}

function Connector({ icon: Icon }) {
  return <div className="flex items-center justify-center py-1"><Icon className="w-4 h-4 text-muted-foreground" /></div>;
}

export default function ResultDashboard({ result }) {
  const r = result;
  const monthly = r.monthly;

  const despesasOperacionais = r.despesas.porGrupo.find((g) => g.key === 'operacional')?.value || 0;
  const despesasFuncionarios = r.despesas.porGrupo.find((g) => g.key === 'funcionarios')?.value || 0;
  const despesasVeiculos = r.despesas.porGrupo.find((g) => g.key === 'veiculos')?.value || 0;
  const outrasDespesas = r.despesas.porGrupo.filter((g) => !['operacional', 'funcionarios', 'veiculos'].includes(g.key)).reduce((s, g) => s + g.value, 0);

  return (
    <div className="space-y-4">
      {/* Waterfall do resultado */}
      <Card>
        <CardHeader><CardTitle className="text-base">Resultado da Empresa</CardTitle></CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-2">
            <Step label="Faturamento" value={r.faturamento} tone="neutral" pct="100%" />
            <Step label="(-) Custo das mercadorias" value={-r.cmv} tone="negative" pct={fmtPct(r.pctCMV)} />
            <Step label="= Lucro bruto" value={r.lucroBruto} tone="positive" pct={fmtPct(r.margemBruta)} isResult />
            <Step label="(-) Despesas operacionais" value={-despesasOperacionais} tone="negative" />
            <Step label="(-) Salários e funcionários" value={-despesasFuncionarios} tone="negative" pct={fmtPct(r.pctSalarios)} />
            <Step label="(-) Veículos" value={-despesasVeiculos} tone="negative" />
            <Step label="(-) Outras despesas" value={-outrasDespesas} tone="negative" />
            <Step label="= Lucro líquido" value={r.lucroLiquido} tone={r.lucroLiquido >= 0 ? 'result' : 'negative'} pct={fmtPct(r.margemLiquida)} isResult />
          </div>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mt-4 pt-4 border-t border-border">
            <Row label="Margem bruta" value={fmtPct(r.margemBruta)} strong />
            <Row label="Margem líquida" value={fmtPct(r.margemLiquida)} strong />
            <Row label="Despesas / Faturamento" value={fmtPct(r.pctDespesas)} muted />
            <Row label="Bonificações no período" value={fmtBRL(r.funcionarios.bonusTotal)} muted />
          </div>
        </CardContent>
      </Card>

      {/* Gráficos mensais */}
      <div className="grid lg:grid-cols-2 gap-4">
        <Card>
          <CardHeader><CardTitle className="text-base">Faturamento, custos e despesas por mês</CardTitle></CardHeader>
          <CardContent>
            {monthly.length === 0 ? <p className="text-sm text-muted-foreground py-8 text-center">Sem dados.</p> : (
              <ResponsiveContainer width="100%" height={280}>
                <ComposedChart data={monthly}>
                  <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
                  <XAxis dataKey="month" tick={{ fontSize: 11 }} />
                  <YAxis tick={{ fontSize: 10 }} tickFormatter={(v) => `R$ ${v >= 1000 ? (v / 1000).toFixed(0) + 'k' : v}`} />
                  <Tooltip formatter={(v) => fmtBRL(v)} contentStyle={{ fontSize: 12 }} />
                  <Legend wrapperStyle={{ fontSize: 11 }} />
                  <Bar dataKey="faturamento" name="Faturamento" fill="#3b82f6" radius={[4, 4, 0, 0]} />
                  <Bar dataKey="cmv" name="Custo mercadorias" fill="#f59e0b" radius={[4, 4, 0, 0]} />
                  <Bar dataKey="despesas" name="Despesas" fill="#ef4444" radius={[4, 4, 0, 0]} />
                  <Line dataKey="lucro" name="Lucro" stroke="#10b981" strokeWidth={2} />
                </ComposedChart>
              </ResponsiveContainer>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader><CardTitle className="text-base">Lucro por mês</CardTitle></CardHeader>
          <CardContent>
            {monthly.length === 0 ? <p className="text-sm text-muted-foreground py-8 text-center">Sem dados.</p> : (
              <ResponsiveContainer width="100%" height={280}>
                <BarChart data={monthly}>
                  <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
                  <XAxis dataKey="month" tick={{ fontSize: 11 }} />
                  <YAxis tick={{ fontSize: 10 }} tickFormatter={(v) => `R$ ${v >= 1000 ? (v / 1000).toFixed(0) + 'k' : v}`} />
                  <Tooltip formatter={(v) => fmtBRL(v)} contentStyle={{ fontSize: 12 }} />
                  <Bar dataKey="lucro" name="Lucro" fill="#10b981" radius={[4, 4, 0, 0]}>
                    {monthly.map((m, i) => <Cell key={i} fill={m.lucro >= 0 ? '#10b981' : '#ef4444'} />)}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}