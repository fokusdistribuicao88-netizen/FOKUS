import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { ResponsiveContainer, BarChart, Bar, XAxis, YAxis, Tooltip, CartesianGrid } from 'recharts';
import { ArrowUpRight, ArrowDownRight, Wallet, AlertCircle, Scale } from 'lucide-react';
import { StatCard, fmtBRL, Empty, Row } from './shared';

export default function CashFlowAnalysis({ result }) {
  const r = result;
  const c = r.cashFlow;
  const fin = r.financial;

  return (
    <div className="space-y-4">
      <Card className="border-blue-200 bg-blue-50/50">
        <CardContent className="p-4">
          <div className="flex items-center gap-2 text-blue-800">
            <Scale className="h-4 w-4" />
            <p className="text-sm font-medium">Resultado gerencial × Movimentação de caixa</p>
          </div>
          <p className="text-xs text-blue-700/80 mt-1">
            O <strong>resultado</strong> considera faturamento, custos e despesas do período (regime de competência).
            O <strong>caixa</strong> considera apenas dinheiro efetivamente recebido e pago. Lucro não é o mesmo que dinheiro disponível.
          </p>
        </CardContent>
      </Card>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        <StatCard icon={ArrowUpRight} label="Entradas (recebido)" value={fmtBRL(c.entradas)} color="text-emerald-600" />
        <StatCard icon={ArrowDownRight} label="Saídas (pago)" value={fmtBRL(c.saidas)} color="text-red-600" />
        <StatCard icon={Wallet} label="Saldo de caixa" value={fmtBRL(c.saldo)} color={c.saldo >= 0 ? 'text-emerald-600' : 'text-red-600'} />
        <StatCard icon={AlertCircle} label="A receber (pend.+vencido)" value={fmtBRL(c.aReceber)} color="text-amber-600" />
      </div>

      <div className="grid lg:grid-cols-2 gap-4">
        <Card>
          <CardHeader><CardTitle className="text-base">Resultado do período (gerencial)</CardTitle></CardHeader>
          <CardContent>
            <div className="space-y-1">
              <Row label="Faturamento" value={fmtBRL(r.faturamento)} />
              <Row label="(-) Custo das mercadorias" value={fmtBRL(-r.cmv)} muted negative />
              <Row label="= Lucro bruto" value={fmtBRL(r.lucroBruto)} strong />
              <Row label="(-) Despesas totais" value={fmtBRL(-r.despesas.total)} muted negative />
              <Row label="= Lucro líquido" value={fmtBRL(r.lucroLiquido)} strong />
              <Row label="Margem líquida" value={`${r.margemLiquida.toFixed(1)}%`} muted />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader><CardTitle className="text-base">Caixa do período</CardTitle></CardHeader>
          <CardContent>
            <div className="space-y-1">
              <Row label="Recebido de clientes" value={fmtBRL(fin.receivablePaid)} />
              <Row label="Pago a fornecedores" value={fmtBRL(-fin.payablePaid)} muted negative />
              <Row label="Saldo realizado" value={fmtBRL(fin.netFlow)} strong />
              <Row label="A receber (pendente + vencido)" value={fmtBRL(c.aReceber)} muted />
              <Row label="A pagar (pendente + vencido)" value={fmtBRL(c.aPagar)} muted />
            </div>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader><CardTitle className="text-base">Recebido × Pago por mês</CardTitle></CardHeader>
        <CardContent>
          {r.monthly.length === 0 ? <Empty /> : (
            <ResponsiveContainer width="100%" height={260}>
              <BarChart data={r.monthly}>
                <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
                <XAxis dataKey="month" tick={{ fontSize: 11 }} />
                <YAxis tick={{ fontSize: 10 }} tickFormatter={(v) => `R$ ${v >= 1000 ? (v / 1000).toFixed(0) + 'k' : v}`} />
                <Tooltip formatter={(v) => fmtBRL(v)} contentStyle={{ fontSize: 12 }} />
                <Bar dataKey="faturamento" name="Faturamento" fill="#3b82f6" radius={[4, 4, 0, 0]} />
                <Bar dataKey="despesas" name="Despesas" fill="#ef4444" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          )}
        </CardContent>
      </Card>
    </div>
  );
}