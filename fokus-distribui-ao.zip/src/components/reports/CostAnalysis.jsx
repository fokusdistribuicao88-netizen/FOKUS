import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { ResponsiveContainer, BarChart, Bar, XAxis, YAxis, Tooltip, CartesianGrid, LineChart, Line } from 'recharts';
import { Package, TrendingUp, TrendingDown, Percent } from 'lucide-react';
import { StatCard, fmtBRL, fmtPct, marginClass, Empty } from './shared';

export default function CostAnalysis({ result }) {
  const r = result;
  return (
    <div className="space-y-4">
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        <StatCard icon={Package} label="Custo mercadorias vendidas" value={fmtBRL(r.cmv)} color="text-amber-600" />
        <StatCard icon={TrendingUp} label="Lucro bruto" value={fmtBRL(r.lucroBruto)} color="text-emerald-600" />
        <StatCard icon={Percent} label="Margem média (produtos)" value={fmtPct(r.marginMedia)} color="text-violet-600" />
        <StatCard icon={TrendingDown} label="CMV / Faturamento" value={fmtPct(r.pctCMV)} color="text-red-600" />
      </div>

      <div className="grid lg:grid-cols-2 gap-4">
        <Card>
          <CardHeader><CardTitle className="text-base">Produtos com maior custo</CardTitle></CardHeader>
          <CardContent>
            {r.topProductsByCost.length === 0 ? <Empty /> : (
              <div className="space-y-1.5">
                {r.topProductsByCost.slice(0, 10).map((p) => (
                  <div key={p.product_id || p.name} className="flex items-center justify-between text-sm border-b pb-1.5">
                    <span className="truncate flex-1">{p.name}</span>
                    <span className="text-muted-foreground mx-3 text-xs">{p.qty} un.</span>
                    <span className="font-semibold text-amber-600">{fmtBRL(p.cost_total)}</span>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader><CardTitle className="text-base">Produtos com maior lucro</CardTitle></CardHeader>
          <CardContent>
            {r.topProductsByProfit.length === 0 ? <Empty /> : (
              <div className="space-y-1.5">
                {r.topProductsByProfit.slice(0, 10).map((p) => (
                  <div key={p.product_id || p.name} className="flex items-center justify-between text-sm border-b pb-1.5">
                    <span className="truncate flex-1">{p.name}</span>
                    <Badge className={marginClass(p.margin)}>{fmtPct(p.margin)}</Badge>
                    <span className="font-semibold text-emerald-600 ml-3">{fmtBRL(p.profit)}</span>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader><CardTitle className="text-base">Produtos com menor margem</CardTitle></CardHeader>
        <CardContent>
          {r.lowMarginProducts.length === 0 ? <Empty /> : (
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead className="text-muted-foreground border-b">
                  <tr><th className="text-left px-2 py-2 font-medium">Produto</th><th className="text-right px-2 py-2 font-medium">Qtd</th><th className="text-right px-2 py-2 font-medium">Faturamento</th><th className="text-right px-2 py-2 font-medium">Custo</th><th className="text-right px-2 py-2 font-medium">Lucro</th><th className="text-center px-2 py-2 font-medium">Margem</th></tr>
                </thead>
                <tbody>
                  {r.lowMarginProducts.slice(0, 15).map((p) => (
                    <tr key={p.product_id || p.name} className="border-b border-border">
                      <td className="px-2 py-2 font-medium">{p.name}</td>
                      <td className="px-2 py-2 text-right">{p.qty}</td>
                      <td className="px-2 py-2 text-right">{fmtBRL(p.revenue)}</td>
                      <td className="px-2 py-2 text-right text-muted-foreground">{fmtBRL(p.cost_total)}</td>
                      <td className={`px-2 py-2 text-right ${p.profit < 0 ? 'text-red-600' : ''}`}>{fmtBRL(p.profit)}</td>
                      <td className="px-2 py-2 text-center"><Badge className={marginClass(p.margin)}>{fmtPct(p.margin)}</Badge></td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </CardContent>
      </Card>

      <Card>
        <CardHeader><CardTitle className="text-base">Evolução do custo das mercadorias</CardTitle></CardHeader>
        <CardContent>
          {r.monthly.length === 0 ? <Empty /> : (
            <ResponsiveContainer width="100%" height={260}>
              <LineChart data={r.monthly}>
                <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
                <XAxis dataKey="month" tick={{ fontSize: 11 }} />
                <YAxis tick={{ fontSize: 10 }} tickFormatter={(v) => `R$ ${v >= 1000 ? (v / 1000).toFixed(0) + 'k' : v}`} />
                <Tooltip formatter={(v) => fmtBRL(v)} contentStyle={{ fontSize: 12 }} />
                <Line dataKey="cmv" name="Custo mercadorias" stroke="#f59e0b" strokeWidth={2} />
                <Line dataKey="faturamento" name="Faturamento" stroke="#3b82f6" strokeWidth={2} />
              </LineChart>
            </ResponsiveContainer>
          )}
        </CardContent>
      </Card>
    </div>
  );
}