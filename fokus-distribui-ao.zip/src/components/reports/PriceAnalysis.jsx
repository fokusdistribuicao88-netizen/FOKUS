import React, { useState, useMemo } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Search } from 'lucide-react';
import { fmtBRL, fmtPct, marginClass, Empty } from './shared';

export default function PriceAnalysis({ result }) {
  const r = result;
  const [q, setQ] = useState('');
  const [table, setTable] = useState('all');

  const tables = useMemo(() => {
    const set = new Set();
    r.perProduct.forEach((p) => Object.keys(p.tables).forEach((t) => set.add(t)));
    return [...set].sort();
  }, [r]);

  const filtered = useMemo(() => {
    let list = [...r.perProduct];
    if (table !== 'all') list = list.filter((p) => p.tables[table] > 0);
    const query = q.trim().toLowerCase();
    if (query) list = list.filter((p) => p.name.toLowerCase().includes(query) || (p.code || '').toLowerCase().includes(query));
    return list.sort((a, b) => b.revenue - a.revenue);
  }, [r, q, table]);

  return (
    <div className="space-y-4">
      <div className="flex flex-col md:flex-row gap-2 md:items-center">
        <div className="relative flex-1">
          <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
          <Input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Buscar produto..." className="pl-9" />
        </div>
        <div className="flex gap-1 flex-wrap">
          <button onClick={() => setTable('all')} className={`text-xs px-3 py-1.5 rounded-full border ${table === 'all' ? 'bg-primary text-primary-foreground' : 'bg-background'}`}>Todas</button>
          {tables.map((t) => (
            <button key={t} onClick={() => setTable(t)} className={`text-xs px-3 py-1.5 rounded-full border ${table === t ? 'bg-primary text-primary-foreground' : 'bg-background'}`}>{t}</button>
          ))}
        </div>
      </div>

      <Card>
        <CardHeader><CardTitle className="text-base">Análise de preços e margem por produto</CardTitle></CardHeader>
        <CardContent>
          {filtered.length === 0 ? <Empty /> : (
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead className="text-muted-foreground border-b">
                  <tr>
                    <th className="text-left px-2 py-2 font-medium">Produto</th>
                    <th className="text-right px-2 py-2 font-medium">Qtd</th>
                    <th className="text-right px-2 py-2 font-medium hidden md:table-cell">Custo unit.</th>
                    <th className="text-right px-2 py-2 font-medium hidden md:table-cell">Preço médio</th>
                    <th className="text-right px-2 py-2 font-medium">Faturamento</th>
                    <th className="text-right px-2 py-2 font-medium hidden lg:table-cell">Custo total</th>
                    <th className="text-right px-2 py-2 font-medium">Lucro</th>
                    <th className="text-center px-2 py-2 font-medium">Margem</th>
                    <th className="text-left px-2 py-2 font-medium hidden xl:table-cell">Tabelas usadas</th>
                  </tr>
                </thead>
                <tbody>
                  {filtered.slice(0, 100).map((p) => {
                    const avgPrice = p.qty > 0 ? p.revenue / p.qty : 0;
                    return (
                      <tr key={p.product_id || p.name} className="border-b border-border hover:bg-muted/30">
                        <td className="px-2 py-2 font-medium">{p.name}</td>
                        <td className="px-2 py-2 text-right">{p.qty}</td>
                        <td className="px-2 py-2 text-right hidden md:table-cell text-muted-foreground">{fmtBRL(p.cost)}</td>
                        <td className="px-2 py-2 text-right hidden md:table-cell">{fmtBRL(avgPrice)}</td>
                        <td className="px-2 py-2 text-right font-medium">{fmtBRL(p.revenue)}</td>
                        <td className="px-2 py-2 text-right hidden lg:table-cell text-muted-foreground">{fmtBRL(p.cost_total)}</td>
                        <td className={`px-2 py-2 text-right font-medium ${p.profit < 0 ? 'text-red-600' : ''}`}>{fmtBRL(p.profit)}</td>
                        <td className="px-2 py-2 text-center"><Badge className={marginClass(p.margin)}>{fmtPct(p.margin)}</Badge></td>
                        <td className="px-2 py-2 hidden xl:table-cell text-xs text-muted-foreground">{Object.entries(p.tables).map(([t, v]) => `${t} (${v})`).join(', ')}</td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          )}
        </CardContent>
      </Card>

      <Card>
        <CardHeader><CardTitle className="text-base">Resumo por tabela de preço</CardTitle></CardHeader>
        <CardContent>
          {r.salesByPriceTable.length === 0 ? <Empty /> : (
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead className="text-muted-foreground border-b">
                  <tr><th className="text-left px-2 py-2 font-medium">Tabela</th><th className="text-right px-2 py-2 font-medium">Pedidos</th><th className="text-right px-2 py-2 font-medium">Faturamento</th><th className="text-right px-2 py-2 font-medium">Ticket médio</th></tr>
                </thead>
                <tbody>
                  {r.salesByPriceTable.map((t) => (
                    <tr key={t.name} className="border-b border-border">
                      <td className="px-2 py-2 font-medium">{t.name}</td>
                      <td className="px-2 py-2 text-right">{t.count}</td>
                      <td className="px-2 py-2 text-right font-medium">{fmtBRL(t.total)}</td>
                      <td className="px-2 py-2 text-right text-muted-foreground">{fmtBRL(t.count ? t.total / t.count : 0)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}