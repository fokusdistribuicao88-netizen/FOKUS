import React, { useMemo } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { ResponsiveContainer, BarChart, Bar, XAxis, YAxis, Tooltip, CartesianGrid, PieChart, Pie, Cell, Legend } from 'recharts';
import { ShoppingCart, Users, CreditCard, Receipt, TrendingUp, TrendingDown, XCircle, RotateCcw } from 'lucide-react';
import { StatCard, Empty, fmtBRL } from './shared';

const PIE_COLORS = ['#2563eb', '#16a34a', '#f59e0b', '#dc2626', '#7c3aed', '#0891b2', '#db2777', '#65a30d'];

export default function SalesAnalysis({ result }) {
  const r = result;
  const topProducts = useMemo(() => [...r.perProduct].sort((a, b) => b.revenue - a.revenue).slice(0, 10), [r]);
  return (
    <div className="space-y-4">
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        <StatCard icon={ShoppingCart} label="Total vendido" value={fmtBRL(r.faturamento)} color="text-emerald-600" />
        <StatCard icon={Receipt} label="Pedidos" value={String(r.totalPedidos)} color="text-blue-600" />
        <StatCard icon={TrendingUp} label="Ticket médio" value={fmtBRL(r.ticketMedio)} color="text-violet-600" />
        <StatCard icon={Users} label="Clientes únicos" value={String(r.salesByCustomer.length)} color="text-amber-600" />
      </div>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        <StatCard icon={TrendingUp} label="Produtos vendidos" value={String(r.qtyProdutos)} color="text-blue-600" />
        <StatCard icon={XCircle} label="Cancelamentos" value={String(r.cancelamentos.count)} color="text-red-600" sub={fmtBRL(r.cancelamentos.total)} />
        <StatCard icon={RotateCcw} label="Devoluções" value={String(r.devolucoes.count)} color="text-rose-600" sub={fmtBRL(r.devolucoes.total)} />
        <StatCard icon={CreditCard} label="Formas de pagamento" value={String(r.salesByPayment.length)} color="text-violet-600" />
      </div>

      <div className="grid lg:grid-cols-2 gap-4">
        <Card>
          <CardHeader><CardTitle className="text-base">Produtos mais vendidos</CardTitle></CardHeader>
          <CardContent>
            {topProducts.length === 0 ? <Empty /> : (
              <div className="space-y-1.5">
                {topProducts.map((p) => (
                  <div key={p.product_id || p.name} className="flex items-center justify-between text-sm border-b pb-1.5">
                    <span className="truncate flex-1">{p.name}</span>
                    <Badge variant="secondary" className="mx-2">{p.qty} un.</Badge>
                    <span className="font-semibold">{fmtBRL(p.revenue)}</span>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader><CardTitle className="text-base">Clientes que mais compraram</CardTitle></CardHeader>
          <CardContent>
            {r.salesByCustomer.length === 0 ? <Empty /> : (
              <div className="space-y-1.5">
                {r.salesByCustomer.map((c, i) => (
                  <div key={c.name} className="flex items-center justify-between text-sm border-b pb-1.5">
                    <span className="truncate"><span className="text-muted-foreground mr-2">#{i + 1}</span>{c.name}</span>
                    <span className="flex items-center gap-2"><Badge variant="secondary">{c.count} ped.</Badge><span className="font-semibold">{fmtBRL(c.total)}</span></span>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      <div className="grid lg:grid-cols-2 gap-4">
        <Card>
          <CardHeader><CardTitle className="text-base">Vendas por vendedor</CardTitle></CardHeader>
          <CardContent>
            {r.salesBySeller.length === 0 ? <Empty /> : (
              <div className="space-y-1.5">
                {r.salesBySeller.map((s) => (
                  <div key={s.name} className="flex items-center justify-between text-sm border-b pb-1.5">
                    <span className="truncate">{s.name}</span>
                    <span className="flex items-center gap-2"><Badge variant="secondary">{s.count} ped.</Badge><span className="font-semibold">{fmtBRL(s.total)}</span></span>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader><CardTitle className="text-base">Vendas por forma de pagamento</CardTitle></CardHeader>
          <CardContent>
            {r.salesByPayment.length === 0 ? <Empty /> : (
              <ResponsiveContainer width="100%" height={240}>
                <PieChart>
                  <Pie data={r.salesByPayment} dataKey="total" nameKey="label" cx="50%" cy="50%" outerRadius={80} label={(e) => e.label}>
                    {r.salesByPayment.map((_, i) => <Cell key={i} fill={PIE_COLORS[i % PIE_COLORS.length]} />)}
                  </Pie>
                  <Tooltip formatter={(v) => fmtBRL(v)} contentStyle={{ fontSize: 12 }} />
                  <Legend wrapperStyle={{ fontSize: 11 }} />
                </PieChart>
              </ResponsiveContainer>
            )}
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader><CardTitle className="text-base">Vendas por tabela de preço</CardTitle></CardHeader>
        <CardContent>
          {r.salesByPriceTable.length === 0 ? <Empty /> : (
            <ResponsiveContainer width="100%" height={240}>
              <BarChart data={r.salesByPriceTable}>
                <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
                <XAxis dataKey="name" tick={{ fontSize: 11 }} />
                <YAxis tick={{ fontSize: 10 }} tickFormatter={(v) => `R$ ${v >= 1000 ? (v / 1000).toFixed(0) + 'k' : v}`} />
                <Tooltip formatter={(v) => fmtBRL(v)} contentStyle={{ fontSize: 12 }} />
                <Bar dataKey="total" name="Faturamento" fill="#7c3aed" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          )}
        </CardContent>
      </Card>
    </div>
  );
}