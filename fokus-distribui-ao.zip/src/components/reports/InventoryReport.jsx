import React, { useMemo } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Boxes, DollarSign, TrendingUp, AlertTriangle } from 'lucide-react';
import { inventoryValuation, lowStockProducts, formatBRL } from '@/lib/reportsCalc';

export default function InventoryReport({ products }) {
  const data = useMemo(() => {
    const valuation = inventoryValuation(products);
    const lowStock = lowStockProducts(products);
    const noStock = (products || []).filter((p) => p.in_stock === false || p.stock_quantity == null || p.stock_quantity === '');
    const byCategory = {};
    (products || []).forEach((p) => {
      const cat = p.category || 'Outros';
      const cur = byCategory[cat] || { category: cat, units: 0, costValue: 0, count: 0 };
      cur.units += Number(p.stock_quantity) || 0;
      cur.costValue += (Number(p.cost) || 0) * (Number(p.stock_quantity) || 0);
      cur.count += 1;
      byCategory[cat] = cur;
    });
    const categories = Object.values(byCategory).sort((a, b) => b.costValue - a.costValue);
    return { valuation, lowStock, noStock: noStock.length, categories };
  }, [products]);

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        <StatCard icon={Boxes} label="Itens em estoque" value={String(data.valuation.units)} color="text-blue-600" />
        <StatCard icon={DollarSign} label="Valor a custo" value={formatBRL(data.valuation.costValue)} color="text-amber-600" />
        <StatCard icon={DollarSign} label="Valor a venda" value={formatBRL(data.valuation.priceValue)} color="text-emerald-600" />
        <StatCard icon={TrendingUp} label="Lucro potencial" value={formatBRL(data.valuation.potentialProfit)} color="text-violet-600" />
      </div>

      <div className="grid lg:grid-cols-2 gap-4">
        <Card>
          <CardHeader><CardTitle className="text-base">Valor em estoque por categoria</CardTitle></CardHeader>
          <CardContent>
            {data.categories.length === 0 ? (
              <p className="text-sm text-muted-foreground py-8 text-center">Sem produtos cadastrados.</p>
            ) : (
              <div className="space-y-1.5">
                {data.categories.map((c) => (
                  <div key={c.category} className="flex items-center justify-between text-sm border-b pb-1.5">
                    <span className="truncate">{c.category} <span className="text-muted-foreground text-xs">({c.count} prod.)</span></span>
                    <span className="flex items-center gap-2">
                      <Badge variant="secondary">{c.units} un.</Badge>
                      <span className="font-semibold">{formatBRL(c.costValue)}</span>
                    </span>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>

        <Card className={data.lowStock.length > 0 ? 'border-red-200' : ''}>
          <CardHeader>
            <CardTitle className="text-base flex items-center gap-2">
              <AlertTriangle className={`h-4 w-4 ${data.lowStock.length > 0 ? 'text-red-600' : 'text-muted-foreground'}`} />
              Estoque baixo · {data.lowStock.length}
            </CardTitle>
          </CardHeader>
          <CardContent>
            {data.lowStock.length === 0 ? (
              <p className="text-sm text-muted-foreground py-8 text-center">Nenhum produto com estoque baixo.</p>
            ) : (
              <div className="space-y-1.5 max-h-72 overflow-y-auto">
                {data.lowStock.slice(0, 20).map((p) => (
                  <div key={p.id} className="flex items-center justify-between text-sm border-b pb-1.5">
                    <span className="truncate">{p.name}</span>
                    <Badge variant={p.qty === 0 ? 'destructive' : 'secondary'}>
                      {p.qty} / {p.threshold}
                    </Badge>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}

function StatCard({ icon: Icon, label, value, color }) {
  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between pb-2">
        <CardTitle className="text-xs font-medium text-muted-foreground">{label}</CardTitle>
        <Icon className={`h-4 w-4 ${color}`} />
      </CardHeader>
      <CardContent><div className="text-xl font-bold">{value}</div></CardContent>
    </Card>
  );
}