import React from 'react';
import { Link } from 'react-router-dom';
import { Phone, MapPin, Instagram, MessageCircle, Beer, ShieldCheck, UserCircle } from 'lucide-react';
import { useAuth } from '@/lib/AuthContext';

export default function CatalogFooter({ settings }) {
  const waLink = settings?.whatsapp_number ? `https://wa.me/${settings.whatsapp_number}` : null;
  const year = new Date().getFullYear();
  const { isAuthenticated, user } = useAuth();
  const isCustomer = isAuthenticated && (user?.role || user?.data?.role) !== 'admin';

  return (
    <footer className="relative mt-16 bg-gradient-to-br from-blue-900 via-blue-800 to-blue-900 text-white overflow-hidden">
      <div className="pointer-events-none absolute inset-0">
        <div className="absolute -top-20 right-10 w-72 h-72 rounded-full bg-yellow-400/10 blur-3xl" />
        <div className="absolute bottom-0 left-1/4 w-48 h-48 rounded-full border border-white/5" />
      </div>

      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div>
            <div className="flex items-center gap-2.5 mb-3">
              {settings?.logo_url ? (
                <img src={settings.logo_url} alt="Logo" className="h-12 w-auto object-contain" />
              ) : (
                <div className="w-10 h-10 bg-yellow-400 rounded-xl flex items-center justify-center">
                  <Beer className="w-5 h-5 text-blue-900" />
                </div>
              )}
              <span className="text-lg font-bold">FOKUS DISTRIBUIÇÃO</span>
            </div>
            <p className="text-blue-100/80 text-sm max-w-xs">
              Bebidas no atacado com os melhores preços para revendedores, bares e eventos.
            </p>
          </div>

          <div>
            <h4 className="text-sm font-semibold uppercase tracking-wider text-yellow-400 mb-4">Contato</h4>
            <ul className="space-y-3 text-sm text-blue-100">
              <li className="flex items-center gap-2">
                <Phone className="w-4 h-4 text-yellow-400" /> {settings?.phone_display || '(11) 99999-9999'}
              </li>
              <li className="flex items-center gap-2">
                <MapPin className="w-4 h-4 text-yellow-400" /> {settings?.delivery_info || 'Entrega para toda região'}
              </li>
              {waLink && (
                <li>
                  <a href={waLink} target="_blank" rel="noopener noreferrer" className="flex items-center gap-2 hover:text-yellow-300 transition-colors">
                    <MessageCircle className="w-4 h-4 text-yellow-400" /> WhatsApp
                  </a>
                </li>
              )}
            </ul>
          </div>

          <div>
            <h4 className="text-sm font-semibold uppercase tracking-wider text-yellow-400 mb-4">Redes sociais</h4>
            {settings?.instagram_url ? (
              <a
                href={settings.instagram_url}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-white/10 hover:bg-yellow-400 hover:text-blue-900 text-sm font-medium transition-colors"
              >
                <Instagram className="w-4 h-4" /> Instagram
              </a>
            ) : (
              <span className="text-blue-100/60 text-sm">Em breve.</span>
            )}
          </div>
        </div>

        <div className="mt-10 pt-6 border-t border-white/10 flex flex-col sm:flex-row items-center justify-between gap-4">
          <p className="text-center text-xs text-blue-100/60">
            © {year} Fokus Distribuição. Todos os direitos reservados.
          </p>
          <div className="flex items-center gap-2">
            {isCustomer && (
              <Link
                to="/MinhaConta"
                className="inline-flex items-center gap-2 rounded-full border border-white/15 bg-white/5 px-4 py-2 text-xs font-medium text-blue-100/80 transition-all hover:border-white/40 hover:bg-white/10 hover:text-white focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-white/40"
                title="Minha Conta"
              >
                <UserCircle className="h-4 w-4" />
                Minha Conta
              </Link>
            )}
            <Link
              to="/login"
              className="inline-flex items-center gap-2 rounded-full border border-white/15 bg-white/5 px-4 py-2 text-xs font-medium text-blue-100/80 transition-all hover:border-yellow-400/60 hover:bg-yellow-400/10 hover:text-yellow-200 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-yellow-400/50"
              title="Acesso restrito à equipe"
            >
              <ShieldCheck className="h-4 w-4" />
              Área Administrativa
            </Link>
          </div>
        </div>
      </div>
    </footer>
  );
}