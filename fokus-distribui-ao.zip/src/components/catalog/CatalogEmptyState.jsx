import React from 'react';
import { Search } from 'lucide-react';

export default function CatalogEmptyState({ hasActiveFilters, onClearFilters }) {
  return (
    <div className="text-center py-20">
      <div className="w-20 h-20 bg-blue-50 dark:bg-blue-950/40 rounded-full flex items-center justify-center mx-auto mb-4">
        <Search className="w-8 h-8 text-blue-600 dark:text-blue-400" />
      </div>
      <h3 className="text-lg font-semibold text-foreground mb-1">Nenhum produto encontrado</h3>
      <p className="text-muted-foreground mb-4">Tente buscar com outros termos ou limpe os filtros</p>
      {hasActiveFilters && (
        <button
          onClick={onClearFilters}
          className="px-6 py-2.5 bg-yellow-400 hover:bg-yellow-300 text-blue-900 rounded-full font-semibold transition-colors"
        >
          Limpar Filtros
        </button>
      )}
    </div>
  );
}