import React, { memo, useCallback } from 'react';
import { motion } from 'framer-motion';
import { Plus, Check, Package, Truck, Layers, Tag } from 'lucide-react';
import { Button } from '@/components/ui/button';

const unitTypeLabels = {
  unidade: 'un',
  pack: 'pack',
  fardo: 'fardo',
  caixa: 'cx',
  engravado: 'eng',
};

const ProductCard = memo(function ProductCard({ product, onAddToCart, isInCart, priceOf, tableName }) {
  const handleAddToCart = useCallback((e) => {
    e.stopPropagation();
    onAddToCart(product);
  }, [onAddToCart, product]);

  const hasPromo = product.price_promo && product.price_promo > 0;
  const effectivePrice = priceOf ? priceOf(product) : (product.price_promo || product.price);
  const basePrice = product.price ?? 0;

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="group relative flex flex-col bg-card rounded-2xl overflow-hidden border border-border hover:border-blue-400 transition-all duration-300 hover:shadow-xl hover:shadow-blue-500/10 hover:-translate-y-0.5"
    >
      {/* Image */}
      <div className="relative aspect-square overflow-hidden bg-gradient-to-br from-muted/50 to-muted">
        {product.image_url ? (
          <img
            src={product.image_url}
            alt={product.name}
            className="w-full h-full object-contain p-4 group-hover:scale-105 transition-transform duration-700 ease-out"
            loading="lazy"
            decoding="async"
          />
        ) : (
          <div className="w-full h-full flex items-center justify-center">
            <Package className="w-16 h-16 text-muted-foreground/40" />
          </div>
        )}

        {product.featured && (
          <span className="absolute top-3 left-3 inline-flex items-center gap-1 px-2.5 py-1 text-[10px] font-bold tracking-wider uppercase bg-yellow-400 text-blue-900 rounded-full shadow">
            <Tag className="w-3 h-3" /> Destaque
          </span>
        )}

        {hasPromo && (
          <span className="absolute top-3 right-3 px-2.5 py-1 text-[10px] font-bold uppercase tracking-wider bg-red-500 text-white rounded-full shadow">
            Promo
          </span>
        )}

        {product.brand && (
          <span className="absolute bottom-3 right-3 px-2 py-1 text-[10px] font-medium bg-card/90 backdrop-blur-sm text-card-foreground rounded-full shadow-sm">
            {product.brand}
          </span>
        )}

        {!product.in_stock && (
          <div className="absolute inset-0 bg-card/80 backdrop-blur-sm flex items-center justify-center">
            <span className="text-sm font-semibold text-muted-foreground tracking-wide">Indisponível</span>
          </div>
        )}
      </div>

      {/* Content */}
      <div className="flex flex-col flex-1 p-3 sm:p-4">
        <div className="flex items-center gap-1.5 flex-wrap">
          <span className="text-[10px] sm:text-xs font-semibold text-blue-600 dark:text-blue-400 uppercase tracking-wider">
            {product.category}
          </span>
          {product.volume_ml && (
            <span className="text-[10px] sm:text-xs text-muted-foreground">• {product.volume_ml}ml</span>
          )}
        </div>

        <h3 className="mt-1 text-sm sm:text-base font-semibold text-foreground line-clamp-2 leading-tight">
          {product.name}
        </h3>

        {product.description && (
          <p className="mt-1 text-xs text-muted-foreground line-clamp-2">{product.description}</p>
        )}

        {/* Benefits */}
        <div className="mt-2 flex flex-wrap gap-1.5">
          {product.in_stock && (
            <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-emerald-50 text-emerald-600 dark:bg-emerald-950/40 dark:text-emerald-400 text-[10px] font-medium">
              <Truck className="w-3 h-3" /> Pronta entrega
            </span>
          )}
          {product.unit_type && product.unit_type !== 'unidade' && product.units_per_pack && (
            <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-blue-50 text-blue-600 dark:bg-blue-950/40 dark:text-blue-400 text-[10px] font-medium">
              <Layers className="w-3 h-3" /> {product.units_per_pack} un/{unitTypeLabels[product.unit_type]}
            </span>
          )}
          {product.min_order > 1 && (
            <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-amber-50 text-amber-600 dark:bg-amber-950/40 dark:text-amber-500 text-[10px] font-medium">
              Mín: {product.min_order}
            </span>
          )}
        </div>

        {/* Price + CTA */}
        <div className="mt-auto pt-3 flex items-end justify-between gap-2">
          <div className="min-w-0">
            {hasPromo ? (
              <div>
                <span className="text-lg sm:text-2xl font-extrabold text-blue-900 dark:text-yellow-400">
                  R$ {effectivePrice.toFixed(2).replace('.', ',')}
                </span>
                <span className="block text-xs line-through text-muted-foreground">
                  R$ {basePrice.toFixed(2).replace('.', ',')}
                </span>
              </div>
            ) : (
              <div>
                <span className="text-lg sm:text-2xl font-extrabold text-blue-900 dark:text-foreground">
                  R$ {effectivePrice.toFixed(2).replace('.', ',')}
                </span>
                <span className="text-xs text-muted-foreground ml-1">
                  /{unitTypeLabels[product.unit_type] || 'un'}
                </span>
                {tableName && tableName !== 'Padrão' && (
                  <span className="block text-[10px] font-medium text-violet-600 mt-0.5">
                    Tabela: {tableName}
                  </span>
                )}
              </div>
            )}
          </div>

          <Button
            onClick={handleAddToCart}
            disabled={!product.in_stock}
            size="sm"
            className={`rounded-full flex-shrink-0 px-3 sm:px-4 text-xs sm:text-sm font-semibold transition-colors ${
              isInCart
                ? 'bg-emerald-500 hover:bg-emerald-600 text-white'
                : 'bg-yellow-400 hover:bg-yellow-300 text-blue-900'
            }`}
          >
            {isInCart ? (
              <>
                <Check className="w-3.5 h-3.5 sm:mr-1" />
                <span className="hidden sm:inline">Adicionado</span>
              </>
            ) : (
              <>
                <Plus className="w-3.5 h-3.5 sm:mr-1" />
                <span className="hidden sm:inline">Adicionar</span>
              </>
            )}
          </Button>
        </div>
      </div>
    </motion.div>
  );
});

export default ProductCard;