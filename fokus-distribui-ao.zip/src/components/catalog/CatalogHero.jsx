import React from 'react';
import { motion } from 'framer-motion';
import { ArrowRight, MessageCircle, Truck, ShieldCheck, Tag, Sparkles } from 'lucide-react';

export default function CatalogHero({ settings, onSeeProducts }) {
  const waLink = settings?.whatsapp_number ? `https://wa.me/${settings.whatsapp_number}` : null;

  return (
    <section className="relative overflow-hidden rounded-b-[2.5rem] bg-gradient-to-br from-blue-800 via-blue-700 to-blue-900">
      {/* Geometric shapes */}
      <div className="pointer-events-none absolute inset-0">
        <div className="absolute -top-24 -right-24 w-96 h-96 rounded-full bg-yellow-400/10 blur-3xl" />
        <div className="absolute top-1/2 -left-32 w-80 h-80 rounded-full bg-blue-400/20 blur-3xl" />
        <div className="absolute bottom-6 right-1/4 w-40 h-40 rounded-full border border-yellow-300/20" />
        <div className="absolute top-10 left-1/3 w-24 h-24 rounded-full border border-white/10" />
      </div>

      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 sm:py-20 lg:py-28">
        <div className="max-w-2xl">
          <motion.span
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-yellow-400/15 text-yellow-300 text-xs font-semibold uppercase tracking-wider"
          >
            <Sparkles className="w-3.5 h-3.5" /> Atacado de Bebidas
          </motion.span>

          <motion.h1
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.05 }}
            className="mt-5 text-4xl sm:text-5xl lg:text-6xl font-extrabold tracking-tight text-white leading-[1.05]"
          >
            Bebidas no atacado com o <span className="text-yellow-400">melhor preço</span>
          </motion.h1>

          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="mt-5 text-base sm:text-lg text-blue-100/90 max-w-xl"
          >
            Revendedores, bares, restaurantes e eventos: variedade, qualidade e entrega rápida em um só lugar.
          </motion.p>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.15 }}
            className="mt-8 flex flex-wrap items-center gap-3"
          >
            <button
              onClick={onSeeProducts}
              className="inline-flex items-center gap-2 px-6 py-3 rounded-full bg-yellow-400 hover:bg-yellow-300 text-blue-900 font-bold text-sm shadow-lg shadow-yellow-500/20 transition-colors"
            >
              Ver produtos <ArrowRight className="w-4 h-4" />
            </button>
            {waLink && (
              <a
                href={waLink}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-2 px-6 py-3 rounded-full border border-white/30 hover:bg-white/10 text-white font-semibold text-sm transition-colors"
              >
                <MessageCircle className="w-4 h-4" /> Falar no WhatsApp
              </a>
            )}
          </motion.div>

          <div className="mt-10 grid grid-cols-3 gap-4 max-w-lg">
            {[
              { icon: Tag, label: 'Melhor preço' },
              { icon: Truck, label: 'Entrega rápida' },
              { icon: ShieldCheck, label: 'Qualidade garantida' },
            ].map((b, i) => (
              <div key={i} className="flex items-center gap-2 text-blue-100">
                <b.icon className="w-4 h-4 text-yellow-400 flex-shrink-0" />
                <span className="text-xs sm:text-sm font-medium">{b.label}</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Soft wave at the bottom */}
      <svg className="absolute bottom-0 left-0 w-full h-20" viewBox="0 0 1440 80" fill="none" preserveAspectRatio="none">
        <path d="M0 80L1440 80L1440 20C1200 60 960 0 720 20C480 40 240 60 0 20L0 80Z" className="fill-background" />
      </svg>
    </section>
  );
}