import React from 'react';
import { motion } from 'framer-motion';
import { Search, ShoppingBag, Phone, MapPin, Instagram, Beer, User, LogIn, Shield } from 'lucide-react';
import { Link } from 'react-router-dom';
import { Input } from '@/components/ui/input';
import { isStaffRole } from '@/lib/userRoles';

export default function CatalogHeader({ settings, searchTerm, onSearchChange, isAuthenticated, user, totalItems, onOpenCart }) {
  return (
    <>
      {/* Top utility bar */}
      <div className="bg-blue-900 text-blue-50 text-xs py-2">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex items-center justify-center gap-6 flex-wrap">
          <span className="flex items-center gap-1.5">
            <Phone className="w-3 h-3 text-yellow-400" />
            {settings?.phone_display || '(11) 99999-9999'}
          </span>
          <span className="flex items-center gap-1.5">
            <MapPin className="w-3 h-3 text-yellow-400" />
            {settings?.delivery_info || 'Entrega para toda região'}
          </span>
          {settings?.instagram_url && (
            <a
              href={settings.instagram_url}
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-1.5 hover:text-yellow-300 transition-colors"
            >
              <Instagram className="w-3 h-3 text-yellow-400" />
              Instagram
            </a>
          )}
        </div>
      </div>

      {/* Header */}
      <header className="sticky top-0 z-30 bg-card/95 backdrop-blur-md border-b border-border shadow-sm" style={{ paddingTop: 'env(safe-area-inset-top)' }}>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center gap-3 h-16 lg:h-20">
            <div className="flex items-center gap-2.5 flex-shrink-0">
              {settings?.logo_url ? (
                <img src={settings.logo_url} alt="Logo" className="h-12 lg:h-16 w-auto object-contain" />
              ) : (
                <div className="w-11 h-11 bg-gradient-to-br from-blue-600 to-blue-800 rounded-xl flex items-center justify-center shadow-md">
                  <Beer className="w-6 h-6 text-yellow-400" />
                </div>
              )}
              <div className="hidden sm:block">
                <span className="block text-base lg:text-xl font-bold text-blue-900 dark:text-foreground leading-tight tracking-tight">
                  FOKUS DISTRIBUIÇÃO
                </span>
                <p className="text-xs text-muted-foreground font-medium">Bebidas no Atacado</p>
              </div>
            </div>

            <div className="flex-1 max-w-xl mx-auto">
              <div className="relative">
                <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                <Input
                  type="text"
                  placeholder="Buscar produtos, marcas..."
                  value={searchTerm}
                  onChange={(e) => onSearchChange(e.target.value)}
                  className="pl-10 h-10 lg:h-11 bg-muted/50 border-border rounded-full focus-visible:ring-2 focus-visible:ring-blue-400 focus-visible:border-blue-400 text-sm"
                />
              </div>
            </div>

            <div className="flex items-center gap-1 flex-shrink-0">
              {isAuthenticated && isStaffRole(user?.role) ? (
                <Link
                  to="/Dashboard"
                  className="hidden sm:flex items-center gap-1.5 px-3 h-9 bg-blue-900 text-blue-50 rounded-full text-xs font-semibold hover:bg-blue-800 transition-colors"
                  title="Área Administrativa"
                >
                  <Shield className="w-4 h-4" />
                  Área Admin
                </Link>
              ) : (
                <Link
                  to="/login"
                  className="hidden sm:flex items-center gap-1.5 px-3 h-9 border border-blue-200 text-blue-900 dark:text-blue-300 rounded-full text-xs font-semibold hover:bg-blue-50 dark:hover:bg-blue-950/30 transition-colors"
                  title="Entrar na Área Administrativa"
                >
                  <LogIn className="w-4 h-4" />
                  Entrar
                </Link>
              )}
              <Link
                to="/MinhaConta"
                className="w-11 h-11 flex items-center justify-center hover:bg-accent rounded-full transition-colors touch-manipulation"
                title="Minha Conta"
                aria-label="Minha Conta"
              >
                <User className="w-5 h-5 text-foreground" />
              </Link>
              <button
                onClick={onOpenCart}
                className="relative w-11 h-11 flex items-center justify-center hover:bg-accent rounded-full transition-colors touch-manipulation"
                aria-label="Abrir carrinho"
              >
                <ShoppingBag className="w-5 h-5 text-foreground" />
                {totalItems > 0 && (
                  <motion.span
                    initial={{ scale: 0 }}
                    animate={{ scale: 1 }}
                    className="absolute -top-0.5 -right-0.5 min-w-5 h-5 px-1 bg-yellow-400 text-blue-900 text-xs font-bold rounded-full flex items-center justify-center shadow"
                  >
                    {totalItems}
                  </motion.span>
                )}
              </button>
            </div>
          </div>
        </div>
      </header>
    </>
  );
}