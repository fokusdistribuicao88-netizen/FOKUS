import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Filter, X, ChevronUp } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';

export default function FilterBar({
  categories,
  selectedCategory,
  onCategoryChange,
  brands,
  selectedBrand,
  onBrandChange,
  priceMin,
  priceMax,
  onPriceMinChange,
  onPriceMaxChange,
  onApply,
  onClear,
  resultsCount,
  hasActiveFilters,
  isFiltering,
}) {
  const [open, setOpen] = useState(false);

  return (
    <div className="bg-card border border-border rounded-2xl p-4 sm:p-5 shadow-sm">
      <button
        type="button"
        onClick={() => setOpen((prev) => !prev)}
        className="flex items-center justify-between gap-2 w-full mb-1"
      >
        <div className="flex items-center gap-2">
          <Filter className="w-4 h-4 text-blue-600 dark:text-blue-400" />
          <span className="text-sm font-semibold text-foreground">Filtros avançados</span>
          {isFiltering && (
            <div className="w-4 h-4 border-2 border-muted-foreground/30 border-t-blue-600 rounded-full animate-spin" />
          )}
        </div>
        <div className="flex items-center gap-3">
          <span className="text-sm text-muted-foreground">
            <span className="font-semibold text-blue-700 dark:text-blue-300">{resultsCount}</span>{' '}
            {resultsCount === 1 ? 'produto' : 'produtos'}
          </span>
          <motion.div animate={{ rotate: open ? 0 : 180 }} transition={{ duration: 0.2 }}>
            <ChevronUp className="w-4 h-4 text-muted-foreground" />
          </motion.div>
        </div>
      </button>

      <AnimatePresence initial={false}>
        {open && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            transition={{ duration: 0.2 }}
            className="overflow-hidden"
          >
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 pt-4">
              {/* Brand */}
              <Select
                value={selectedBrand || '__all__'}
                onValueChange={(v) => onBrandChange(v === '__all__' ? '' : v)}
              >
                <SelectTrigger className="w-full">
                  <SelectValue placeholder="Todas as marcas" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="__all__">Todas as marcas</SelectItem>
                  {brands.map((brand) => (
                    <SelectItem key={brand} value={brand}>
                      {brand}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>

              {/* Price Min */}
              <Input
                type="number"
                inputMode="numeric"
                placeholder="Preço mín (R$)"
                value={priceMin}
                onChange={(e) => onPriceMinChange(e.target.value)}
                min="0"
              />

              {/* Price Max */}
              <Input
                type="number"
                inputMode="numeric"
                placeholder="Preço máx (R$)"
                value={priceMax}
                onChange={(e) => onPriceMaxChange(e.target.value)}
                min="0"
              />

              {/* Buttons */}
              <div className="flex gap-2">
                <Button
                  onClick={onApply}
                  className="flex-1 bg-blue-700 hover:bg-blue-800 text-white"
                >
                  <Filter className="w-4 h-4" />
                  <span className="hidden sm:inline">Filtrar</span>
                </Button>
                <Button
                  onClick={onClear}
                  variant="outline"
                  className="flex-1"
                  disabled={!hasActiveFilters}
                >
                  <X className="w-4 h-4" />
                  <span className="hidden sm:inline">Limpar</span>
                </Button>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}