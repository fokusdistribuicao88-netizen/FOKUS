import React, { memo, useCallback, useMemo } from 'react';
import { X, Trash2, Plus, Minus, ShoppingBag } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { useCartRulePricing } from '@/lib/useCartRulePricing';

const CartSidebar = memo(function CartSidebar({ isOpen, onClose, items, onUpdateQuantity, onRemoveItem }) {
  const totalItems = useMemo(() => items.reduce((sum, item) => sum + item.quantity, 0), [items]);
  const { getUnitPrice, isWholesale, wholesaleMinQty } = useCartRulePricing(items);
  const effectivePrice = useCallback((item) => getUnitPrice(item), [getUnitPrice]);
  const total = useMemo(() => items.reduce((sum, item) => sum + effectivePrice(item) * item.quantity, 0), [items, effectivePrice]);

  const handleQuantityChange = useCallback((id, quantity) => {
    onUpdateQuantity(id, quantity);
  }, [onUpdateQuantity]);

  return (
    <>
      {/* Overlay */}
      {isOpen && (
        <div
          className="fixed inset-0 bg-black/40 z-40"
          onClick={onClose}
        />
      )}

      {/* Sidebar */}
      <div className={`fixed top-0 right-0 h-full w-full max-w-md bg-white z-50 shadow-2xl flex flex-col transition-transform duration-300 ease-in-out ${isOpen ? 'translate-x-0' : 'translate-x-full'}`}>
        {/* Header */}
        <div className="flex items-center justify-between p-4 border-b border-gray-100">
          <div className="flex items-center gap-2">
            <ShoppingBag className="w-5 h-5 text-blue-600" />
            <h2 className="text-lg font-semibold text-gray-900">Carrinho</h2>
            {items.length > 0 && (
              <span className="px-2 py-0.5 bg-blue-100 text-blue-700 text-xs font-medium rounded-full">
                {totalItems} itens
              </span>
            )}
          </div>
          <button
            onClick={onClose}
            aria-label="Fechar carrinho"
            className="w-11 h-11 hover:bg-gray-100 rounded-full transition-colors flex items-center justify-center touch-manipulation"
          >
            <X className="w-5 h-5 text-gray-500" />
          </button>
        </div>

        {/* Wholesale badge */}
        {isWholesale && (
          <div className="mx-4 mt-3 px-3 py-2 bg-emerald-50 border border-emerald-200 rounded-lg text-sm text-emerald-700 font-medium">
            🎉 Preço atacado aplicado!
          </div>
        )}
        {!isWholesale && items.length > 0 && (
          <div className="mx-4 mt-3 px-3 py-2 bg-yellow-50 border border-yellow-200 rounded-lg text-xs text-yellow-700">
            Adicione {wholesaleMinQty - totalItems} itens para desbloquear o preço atacado
          </div>
        )}

        {/* Items */}
        <div className="flex-1 overflow-y-auto p-4 space-y-3">
          {items.length === 0 ? (
            <div className="flex flex-col items-center justify-center h-full text-center py-12">
              <ShoppingBag className="w-12 h-12 text-gray-200 mb-3" />
              <p className="text-gray-400 text-sm">Seu carrinho está vazio</p>
            </div>
          ) : (
            items.map((item) => (
              <div key={item.id} className="flex gap-3 p-3 bg-gray-50 rounded-xl">
                {item.image_url ? (
                  <img src={item.image_url} alt={item.name} className="w-14 h-14 object-contain rounded-lg bg-white p-1" />
                ) : (
                  <div className="w-14 h-14 bg-white rounded-lg flex items-center justify-center">
                    <ShoppingBag className="w-6 h-6 text-gray-300" />
                  </div>
                )}
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium text-gray-900 truncate">{item.name}</p>
                  <p className="text-sm font-bold text-blue-600 mt-0.5">
                    R$ {effectivePrice(item)?.toFixed(2).replace('.', ',')}
                  </p>
                  <div className="flex items-center gap-2 mt-1.5">
                    <button
                      onClick={() => handleQuantityChange(item.id, item.quantity - 1)}
                      aria-label="Diminuir quantidade"
                      className="w-11 h-11 rounded-full bg-white border border-gray-200 flex items-center justify-center hover:bg-gray-100 transition-colors touch-manipulation"
                    >
                      <Minus className="w-4 h-4" />
                    </button>
                    <span className="text-sm font-medium w-8 text-center">{item.quantity}</span>
                    <button
                      onClick={() => handleQuantityChange(item.id, item.quantity + 1)}
                      aria-label="Aumentar quantidade"
                      className="w-11 h-11 rounded-full bg-white border border-gray-200 flex items-center justify-center hover:bg-gray-100 transition-colors touch-manipulation"
                    >
                      <Plus className="w-4 h-4" />
                    </button>
                    <button
                      onClick={() => onRemoveItem(item.id)}
                      aria-label="Remover item"
                      className="ml-auto w-11 h-11 rounded-full flex items-center justify-center hover:text-red-500 hover:bg-red-50 text-gray-400 transition-colors touch-manipulation"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              </div>
            ))
          )}
        </div>

        {/* Footer */}
        {items.length > 0 && (
          <div className="p-4 border-t border-gray-100 space-y-3" style={{ paddingBottom: 'max(1rem, env(safe-area-inset-bottom))' }}>
            <div className="flex items-center justify-between">
              <span className="text-gray-600 font-medium">Total</span>
              <span className="text-xl font-bold text-gray-900">
                R$ {total.toFixed(2).replace('.', ',')}
              </span>
            </div>
            <Link to={createPageUrl('Checkout')} onClick={onClose} className="block">
              <Button className="w-full bg-blue-600 hover:bg-blue-700 text-white rounded-xl h-12 text-base font-medium">
                Finalizar Pedido
              </Button>
            </Link>
          </div>
        )}
      </div>
    </>
  );
});

export default CartSidebar;