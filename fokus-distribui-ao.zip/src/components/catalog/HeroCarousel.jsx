import React, { memo } from 'react';
import {
  Carousel,
  CarouselContent,
  CarouselItem,
  CarouselNext,
  CarouselPrevious,
} from "@/components/ui/carousel";

export default function HeroCarousel({ images = [] }) {
  if (!images || images.length === 0) return null;

  return (
    <div className="mb-8">
      <Carousel className="w-full" opts={{ loop: true }}>
        <CarouselContent>
          {images.map((url, index) => (
            <CarouselItem key={index}>
              <div className="relative aspect-[21/9] md:aspect-[3/1] rounded-3xl overflow-hidden shadow-xl ring-1 ring-blue-900/5">
                <img
                  src={url}
                  alt={`Banner ${index + 1}`}
                  className="w-full h-full object-cover"
                  loading={index === 0 ? 'eager' : 'lazy'}
                />
                <div className="absolute inset-0 bg-gradient-to-t from-blue-900/30 to-transparent pointer-events-none" />
              </div>
            </CarouselItem>
          ))}
        </CarouselContent>
        {images.length > 1 && (
          <>
            <CarouselPrevious className="left-4 bg-blue-800/80 hover:bg-blue-700 text-white border-0" />
            <CarouselNext className="right-4 bg-blue-800/80 hover:bg-blue-700 text-white border-0" />
          </>
        )}
      </Carousel>
    </div>
  );
}