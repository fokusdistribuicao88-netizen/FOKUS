import React from 'react';
import { Beer, CupSoda, Droplet, Citrus, Zap, Coffee, Wine, Package } from 'lucide-react';

const ICONS = {
  Cervejas: Beer,
  Refrigerantes: CupSoda,
  Águas: Droplet,
  Sucos: Citrus,
  Energéticos: Zap,
  Destilados: Coffee,
  Vinhos: Wine,
  Outros: Package,
};

export default function CategoryStrip({ categories, activeCategory, onCategoryChange }) {
  return (
    <section id="produtos" className="scroll-mt-24">
      <div className="flex items-center gap-3 mb-4">
        <div className="w-1.5 h-6 rounded-full bg-yellow-400" />
        <h2 className="text-lg sm:text-xl font-bold text-blue-900 dark:text-blue-300">Categorias</h2>
      </div>
      <div className="flex gap-2 overflow-x-auto pb-2 -mx-1 px-1">
        <button
          onClick={() => onCategoryChange(null)}
          className={`flex-shrink-0 inline-flex items-center gap-2 px-4 py-2 rounded-full text-sm font-medium transition-colors border ${
            activeCategory === null
              ? 'bg-blue-700 text-white border-blue-700'
              : 'bg-card text-foreground border-border hover:border-blue-400'
          }`}
        >
          Todas
        </button>
        {categories.map((cat) => {
          const Icon = ICONS[cat] || Package;
          const active = activeCategory === cat;
          return (
            <button
              key={cat}
              onClick={() => onCategoryChange(active ? null : cat)}
              className={`flex-shrink-0 inline-flex items-center gap-2 px-4 py-2 rounded-full text-sm font-medium transition-colors border ${
                active
                  ? 'bg-blue-700 text-white border-blue-700'
                  : 'bg-card text-foreground border-border hover:border-blue-400'
              }`}
            >
              <Icon className="w-4 h-4" /> {cat}
            </button>
          );
        })}
      </div>
    </section>
  );
}