import React, { useState, useEffect } from 'react';
import { useQuery } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Loader2, Sparkles } from 'lucide-react';
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import {
  Select, SelectTrigger, SelectValue, SelectContent, SelectItem, SelectGroup, SelectLabel,
} from '@/components/ui/select';
import { useToast } from '@/components/ui/use-toast';
import { SYSTEM_TABLES } from '@/lib/posPriceTables';
import { loadPriceRules, savePriceRules, DEFAULT_PRICE_RULES } from '@/lib/priceRules';

export default function PriceRulesDialog({ open, onClose }) {
  const { toast } = useToast();
  const [rules, setRules] = useState(DEFAULT_PRICE_RULES);
  const [loading, setLoading] = useState(false);
  const [saving, setSaving] = useState(false);

  const { data: priceTables = [] } = useQuery({
    queryKey: ['price-tables'],
    queryFn: () => base44.entities.PriceTable.list('-updated_date'),
    enabled: open,
    staleTime: 30 * 1000,
  });

  useEffect(() => {
    if (!open) return;
    setLoading(true);
    loadPriceRules()
      .then((r) => setRules(r))
      .finally(() => setLoading(false));
  }, [open]);

  const systemOptions = SYSTEM_TABLES.map((t) => ({ value: t.code, label: t.name }));
  const customOptions = priceTables
    .filter((t) => t.status !== 'inactive' && !SYSTEM_TABLES.some((s) => s.code === t.code))
    .map((t) => ({ value: t.id, label: t.name }));

  const PAYMENT_METHODS = [
    { key: 'cash', label: 'Dinheiro' },
    { key: 'pix', label: 'PIX' },
    { key: 'credit_card', label: 'Cartão de Crédito' },
    { key: 'transfer', label: 'Transferência' },
    { key: 'boleto', label: 'Boleto' },
  ];

  const renderTableSelect = (value, onChange) => (
    <Select value={value || ''} onValueChange={(v) => onChange(v === '__none' ? '' : v)}>
      <SelectTrigger className="h-9"><SelectValue placeholder="Usar preço padrão" /></SelectTrigger>
      <SelectContent>
        <SelectItem value="__none">Usar preço padrão</SelectItem>
        {systemOptions.length > 0 && (
          <SelectGroup>
            <SelectLabel>Tabelas do sistema</SelectLabel>
            {systemOptions.map((o) => <SelectItem key={o.value} value={o.value}>{o.label}</SelectItem>)}
          </SelectGroup>
        )}
        {customOptions.length > 0 && (
          <SelectGroup>
            <SelectLabel>Tabelas criadas</SelectLabel>
            {customOptions.map((o) => <SelectItem key={o.value} value={o.value}>{o.label}</SelectItem>)}
          </SelectGroup>
        )}
      </SelectContent>
    </Select>
  );

  const handleSave = async () => {
    setSaving(true);
    try {
      await savePriceRules(rules);
      toast({ title: 'Regras automáticas salvas' });
      onClose();
    } catch (e) {
      toast({ title: 'Erro ao salvar', description: e.message, variant: 'destructive' });
    } finally {
      setSaving(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={(op) => !op && onClose()}>
      <DialogContent className="max-w-lg max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Sparkles className="w-5 h-5 text-violet-600" />
            Regras do Catálogo
          </DialogTitle>
          <DialogDescription>
            Configure a tabela de preços exibida no catálogo público. Estas regras são aplicadas somente no Catálogo (não afetam PDV nem Pedidos).
          </DialogDescription>
        </DialogHeader>

        {loading ? (
          <div className="flex justify-center py-8"><Loader2 className="w-6 h-6 animate-spin text-muted-foreground" /></div>
        ) : (
          <div className="space-y-4">
            <div className="rounded-lg border border-violet-200 bg-violet-50/40 p-3 space-y-2">
              <Label className="text-sm font-medium text-violet-800">Tabela de Preço do Catálogo</Label>
              <p className="text-xs text-muted-foreground">
                Tabela utilizada nos preços exibidos no catálogo público. A troca reflete imediatamente, sem alterar produto por produto.
              </p>
              {renderTableSelect(rules.catalog_table_id, (v) => setRules((r) => ({ ...r, catalog_table_id: v })))}
            </div>

            <div className="rounded-lg border border-amber-200 bg-amber-50/40 p-3 space-y-2">
              <Label className="text-sm font-medium text-amber-800">Tabela de Atacado (10 caixas)</Label>
              <p className="text-xs text-muted-foreground">
                Aplicada automaticamente quando o carrinho atingir a quantidade mínima de caixas.
              </p>
              <div className="grid grid-cols-[120px_1fr] gap-2">
                <div className="space-y-1">
                  <span className="text-xs text-muted-foreground">Qtd. mínima</span>
                  <Input
                    type="number"
                    min="0"
                    value={rules.wholesale_min_qty ?? 10}
                    onChange={(e) => setRules((r) => ({ ...r, wholesale_min_qty: Number(e.target.value) || 0 }))}
                    className="h-9"
                  />
                </div>
                <div className="space-y-1">
                  <span className="text-xs text-muted-foreground">Tabela</span>
                  {renderTableSelect(rules.wholesale_table_id, (v) => setRules((r) => ({ ...r, wholesale_table_id: v })))}
                </div>
              </div>
            </div>

            <div className="rounded-lg border border-emerald-200 bg-emerald-50/40 p-3 space-y-3">
              <div>
                <Label className="text-sm font-medium text-emerald-800">Tabelas por forma de pagamento</Label>
                <p className="text-xs text-muted-foreground">
                  Aplique uma tabela automaticamente conforme o pagamento escolhido no catálogo.
                </p>
              </div>
              {PAYMENT_METHODS.map((m) => (
                <div key={m.key} className="space-y-1">
                  <span className="text-xs font-medium text-foreground">{m.label}</span>
                  {renderTableSelect(
                    rules.payment_table_map?.[m.key] || '',
                    (v) => setRules((r) => ({ ...r, payment_table_map: { ...(r.payment_table_map || {}), [m.key]: v } }))
                  )}
                </div>
              ))}
            </div>
          </div>
        )}

        <DialogFooter>
          <Button variant="outline" onClick={onClose}>Cancelar</Button>
          <Button onClick={handleSave} disabled={saving || loading} className="bg-violet-600 hover:bg-violet-700">
            {saving ? 'Salvando...' : 'Salvar regras'}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}