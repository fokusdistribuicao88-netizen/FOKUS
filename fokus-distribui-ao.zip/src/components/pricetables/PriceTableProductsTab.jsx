import React, { useMemo, useState, useCallback } from 'react';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { useAuth } from '@/lib/AuthContext';
import { useToast } from '@/components/ui/use-toast';
import { logActivity } from '@/lib/activityLog';
import {
  Search, Loader2, Save, Sparkles, Wand2, CheckSquare, Square,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from '@/components/ui/select';
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription,
} from '@/components/ui/dialog';
import {
  formatMoney, round2, computeMargin, computeProfit, priceFromMargin,
  computeNewValue, applyRounding, ROUND_OPTIONS,
} from '@/lib/priceTables';

const PAGE_SIZE = 25;

export default function PriceTableProductsTab({ table, canEdit }) {
  const queryClient = useQueryClient();
  const { user } = useAuth();
  const { toast } = useToast();

  const [search, setSearch] = useState('');
  const [category, setCategory] = useState('');
  const [brand, setBrand] = useState('');
  const [page, setPage] = useState(1);
  const [selectedIds, setSelectedIds] = useState(new Set());
  const [editing, setEditing] = useState({}); // productId -> custom_price string
  const [savingId, setSavingId] = useState(null);
  const [bulkOpen, setBulkOpen] = useState(false);
  const [marginOpen, setMarginOpen] = useState(false);

  const { data: products = [], isLoading } = useQuery({
    queryKey: ['products'],
    queryFn: () => base44.entities.Product.list(),
    staleTime: 60 * 1000,
  });
  const { data: items = [], isLoading: itemsLoading } = useQuery({
    queryKey: ['price-table-items', table.id],
    queryFn: () => base44.entities.PriceTableItem.filter({ price_table_id: table.id }),
    staleTime: 30 * 1000,
  });

  const itemsByProduct = useMemo(() => {
    const m = {};
    items.forEach((it) => { m[it.product_id] = it; });
    return m;
  }, [items]);

  const categories = useMemo(() => [...new Set(products.map((p) => p.category).filter(Boolean))].sort(), [products]);
  const brands = useMemo(() => [...new Set(products.map((p) => p.brand).filter(Boolean))].sort(), [products]);

  const filtered = useMemo(() => {
    const q = search.toLowerCase().trim();
    return products.filter((p) => {
      if (q && !(p.name?.toLowerCase().includes(q) || p.code?.toLowerCase().includes(q) || p.brand?.toLowerCase().includes(q))) return false;
      if (category && p.category !== category) return false;
      if (brand && p.brand !== brand) return false;
      return true;
    });
  }, [products, search, category, brand]);

  const totalPages = Math.max(1, Math.ceil(filtered.length / PAGE_SIZE));
  const currentPage = Math.min(page, totalPages);
  const pageItems = filtered.slice((currentPage - 1) * PAGE_SIZE, currentPage * PAGE_SIZE);

  const effectivePrice = (p) => {
    const it = itemsByProduct[p.id];
    return it?.custom_price ?? p.price;
  };

  const saveCustomPrice = useCallback(async (product, rawValue) => {
    const val = round2(parseFloat(rawValue));
    if (!isFinite(val) || val < 0) {
      setEditing((e) => { const n = { ...e }; delete n[product.id]; return n; });
      return;
    }
    setSavingId(product.id);
    const existing = itemsByProduct[product.id];
    const standard = Number(product.price) || 0;
    const oldVal = existing?.custom_price ?? standard;
    try {
      const payload = {
        price_table_id: table.id,
        price_table_name: table.name,
        product_id: product.id,
        product_name: product.name,
        product_code: product.code || '',
        category: product.category || '',
        brand: product.brand || '',
        unit_type: product.unit_type || '',
        cost: Number(product.cost) || 0,
        standard_price: standard,
        custom_price: val,
        updated_by: user?.full_name || user?.email || '',
      };
      let saved;
      if (existing) {
        saved = await base44.entities.PriceTableItem.update(existing.id, payload);
      } else {
        saved = await base44.entities.PriceTableItem.create(payload);
        itemsByProduct[product.id] = saved;
      }
      await base44.entities.PriceHistory.create({
        product_id: product.id,
        product_name: product.name,
        field: 'custom_price',
        old_value: oldVal,
        new_value: val,
        percent: oldVal > 0 ? round2(((val - oldVal) / oldVal) * 100) : null,
        action_type: 'single',
        price_table_id: table.id,
        price_table_name: table.name,
        user_email: user?.email || '',
      });
      await base44.entities.PriceTable.update(table.id, {
        products_count: Object.keys({ ...itemsByProduct }).length,
        last_updated_by: user?.full_name || user?.email || '',
      });
      queryClient.invalidateQueries({ queryKey: ['price-table-items', table.id] });
      queryClient.invalidateQueries({ queryKey: ['price-tables'] });
      setEditing((e) => { const n = { ...e }; delete n[product.id]; return n; });
    } catch (e) {
      toast({ title: 'Erro ao salvar preço', description: e.message, variant: 'destructive' });
    } finally {
      setSavingId(null);
    }
  }, [itemsByProduct, table, user, queryClient, toast]);

  const allPageSelected = pageItems.length > 0 && pageItems.every((p) => selectedIds.has(p.id));
  const togglePage = () => {
    setSelectedIds((prev) => {
      const n = new Set(prev);
      if (pageItems.every((p) => n.has(p.id))) pageItems.forEach((p) => n.delete(p.id));
      else pageItems.forEach((p) => n.add(p.id));
      return n;
    });
  };
  const toggleOne = (id) => setSelectedIds((prev) => {
    const n = new Set(prev); n.has(id) ? n.delete(id) : n.add(id); return n;
  });
  const selectAllFiltered = () => setSelectedIds(new Set(filtered.map((p) => p.id)));
  const clearSelection = () => setSelectedIds(new Set());

  return (
    <div className="space-y-4">
      {/* Filters + bulk actions */}
      <div className="flex flex-col lg:flex-row gap-3 lg:items-end">
        <div className="relative flex-1">
          <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
          <Input value={search} onChange={(e) => { setSearch(e.target.value); setPage(1); }} placeholder="Buscar produto..." className="pl-9" />
        </div>
        <Select value={category} onValueChange={(v) => { setCategory(v === '__all' ? '' : v); setPage(1); }}>
          <SelectTrigger className="w-full lg:w-44"><SelectValue placeholder="Categoria" /></SelectTrigger>
          <SelectContent>
            <SelectItem value="__all">Todas categorias</SelectItem>
            {categories.map((c) => <SelectItem key={c} value={c}>{c}</SelectItem>)}
          </SelectContent>
        </Select>
        <Select value={brand} onValueChange={(v) => { setBrand(v === '__all' ? '' : v); setPage(1); }}>
          <SelectTrigger className="w-full lg:w-40"><SelectValue placeholder="Marca" /></SelectTrigger>
          <SelectContent>
            <SelectItem value="__all">Todas marcas</SelectItem>
            {brands.map((b) => <SelectItem key={b} value={b}>{b}</SelectItem>)}
          </SelectContent>
        </Select>
        {canEdit && (
          <div className="flex gap-2">
            <Button variant="outline" size="sm" disabled={selectedIds.size === 0} onClick={() => setBulkOpen(true)} className="gap-2">
              <Wand2 className="w-4 h-4" /> Ajuste em massa {selectedIds.size > 0 && `(${selectedIds.size})`}
            </Button>
            <Button variant="outline" size="sm" disabled={selectedIds.size === 0} onClick={() => setMarginOpen(true)} className="gap-2">
              <Sparkles className="w-4 h-4" /> Margem
            </Button>
          </div>
        )}
      </div>

      {canEdit && selectedIds.size > 0 && (
        <div className="flex items-center gap-2 text-xs">
          <Button variant="ghost" size="sm" onClick={selectAllFiltered}>Selecionar todos ({filtered.length})</Button>
          <Button variant="ghost" size="sm" onClick={clearSelection}>Limpar seleção</Button>
        </div>
      )}

      <div className="bg-card border border-border rounded-xl overflow-x-auto">
        <table className="w-full text-sm">
          <thead className="bg-muted/50 text-xs uppercase text-muted-foreground">
            <tr>
              {canEdit && (
                <th className="px-3 py-3 w-10">
                  <button onClick={togglePage}>{allPageSelected ? <CheckSquare className="w-4 h-4" /> : <Square className="w-4 h-4" />}</button>
                </th>
              )}
              <th className="text-left font-medium px-3 py-3">Produto</th>
              <th className="text-left font-medium px-3 py-3 hidden md:table-cell">Categoria</th>
              <th className="text-left font-medium px-3 py-3 hidden lg:table-cell">Marca</th>
              <th className="text-right font-medium px-3 py-3 hidden md:table-cell">Custo</th>
              <th className="text-right font-medium px-3 py-3">Preço padrão</th>
              <th className="text-right font-medium px-3 py-3">Preço na tabela</th>
              <th className="text-right font-medium px-3 py-3 hidden lg:table-cell">Margem %</th>
              <th className="text-right font-medium px-3 py-3 hidden xl:table-cell">Lucro</th>
            </tr>
          </thead>
          <tbody>
            {(isLoading || itemsLoading) ? (
              <tr><td colSpan={9} className="text-center py-12"><Loader2 className="w-6 h-6 animate-spin text-blue-600 mx-auto" /></td></tr>
            ) : pageItems.length === 0 ? (
              <tr><td colSpan={9} className="text-center py-12 text-muted-foreground">Nenhum produto.</td></tr>
            ) : pageItems.map((p) => {
              const it = itemsByProduct[p.id];
              const eff = effectivePrice(p);
              const margin = computeMargin(eff, p.cost);
              const profit = computeProfit(eff, p.cost);
              const isEditing = editing[p.id] !== undefined;
              const editVal = isEditing ? editing[p.id] : (it ? String(it.custom_price) : '');
              return (
                <tr key={p.id} className="border-t border-border hover:bg-muted/30">
                  {canEdit && (
                    <td className="px-3 py-2">
                      <button onClick={() => toggleOne(p.id)}>{selectedIds.has(p.id) ? <CheckSquare className="w-4 h-4 text-blue-600" /> : <Square className="w-4 h-4" />}</button>
                    </td>
                  )}
                  <td className="px-3 py-2">
                    <p className="font-medium text-foreground truncate max-w-[220px]">{p.name}</p>
                    <p className="text-xs text-muted-foreground">{p.code || '—'}</p>
                  </td>
                  <td className="px-3 py-2 hidden md:table-cell text-muted-foreground">{p.category || '—'}</td>
                  <td className="px-3 py-2 hidden lg:table-cell text-muted-foreground">{p.brand || '—'}</td>
                  <td className="px-3 py-2 hidden md:table-cell text-right text-muted-foreground">{formatMoney(p.cost)}</td>
                  <td className="px-3 py-2 text-right text-muted-foreground">{formatMoney(p.price)}</td>
                  <td className="px-3 py-2 text-right">
                    {canEdit ? (
                      <div className="flex items-center justify-end gap-1">
                        <Input
                          value={editVal}
                          onChange={(e) => setEditing((s) => ({ ...s, [p.id]: e.target.value }))}
                          onFocus={() => setEditing((s) => ({ ...s, [p.id]: it ? String(it.custom_price) : '' }))}
                          onBlur={() => saveCustomPrice(p, editVal)}
                          onKeyDown={(e) => { if (e.key === 'Enter') e.target.blur(); }}
                          type="number"
                          step="0.01"
                          className="h-8 w-28 text-right"
                          placeholder={formatMoney(p.price)}
                          disabled={savingId === p.id}
                        />
                        {savingId === p.id && <Loader2 className="w-3 h-3 animate-spin text-blue-600" />}
                      </div>
                    ) : (
                      <span className={it ? 'font-medium text-foreground' : 'text-muted-foreground'}>{formatMoney(eff)}</span>
                    )}
                    {it && <Badge className="ml-1 bg-blue-50 text-blue-600 dark:bg-blue-950 dark:text-blue-400 text-[10px]">personalizado</Badge>}
                  </td>
                  <td className="px-3 py-2 hidden lg:table-cell text-right">
                    {margin === null ? '—' : <span className={margin >= 0 ? 'text-green-600' : 'text-red-600'}>{margin}%</span>}
                  </td>
                  <td className="px-3 py-2 hidden xl:table-cell text-right text-muted-foreground">{formatMoney(profit)}</td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>

      {/* Pagination */}
      <div className="flex items-center justify-between text-xs text-muted-foreground">
        <span>Página {currentPage} de {totalPages} — {filtered.length} produtos</span>
        <div className="flex gap-2">
          <Button variant="outline" size="sm" disabled={currentPage <= 1} onClick={() => setPage((p) => p - 1)}>Anterior</Button>
          <Button variant="outline" size="sm" disabled={currentPage >= totalPages} onClick={() => setPage((p) => p + 1)}>Próxima</Button>
        </div>
      </div>

      {bulkOpen && (
        <BulkAdjustDialog
          table={table}
          products={filtered.filter((p) => selectedIds.has(p.id))}
          itemsByProduct={itemsByProduct}
          onClose={() => setBulkOpen(false)}
          onDone={() => { queryClient.invalidateQueries({ queryKey: ['price-table-items', table.id] }); queryClient.invalidateQueries({ queryKey: ['price-tables'] }); clearSelection(); }}
        />
      )}

      {marginOpen && (
        <MarginDialog
          table={table}
          products={filtered.filter((p) => selectedIds.has(p.id))}
          itemsByProduct={itemsByProduct}
          onClose={() => setMarginOpen(false)}
          onDone={() => { queryClient.invalidateQueries({ queryKey: ['price-table-items', table.id] }); queryClient.invalidateQueries({ queryKey: ['price-tables'] }); clearSelection(); }}
        />
      )}
    </div>
  );
}

function BulkAdjustDialog({ table, products, itemsByProduct, onClose, onDone }) {
  const { user } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [operation, setOperation] = useState('+');
  const [type, setType] = useState('percent');
  const [value, setValue] = useState('');
  const [rounding, setRounding] = useState('none');
  const [minPrice, setMinPrice] = useState('');
  const [maxPrice, setMaxPrice] = useState('');
  const [reason, setReason] = useState('');
  const [applying, setApplying] = useState(false);

  const preview = useMemo(() => {
    const min = parseFloat(minPrice);
    const max = parseFloat(maxPrice);
    return products.slice(0, 6).map((p) => {
      const it = itemsByProduct[p.id];
      const oldVal = it?.custom_price ?? (Number(p.price) || 0);
      let newVal = computeNewValue(oldVal, operation, type, value);
      newVal = applyRounding(newVal, rounding);
      if (!isNaN(min)) newVal = Math.max(newVal, min);
      if (!isNaN(max)) newVal = Math.min(newVal, max);
      return { name: p.name, oldVal, newVal };
    });
  }, [products, itemsByProduct, operation, type, value, rounding, minPrice, maxPrice]);

  const totalAffected = products.length;

  const apply = async () => {
    setApplying(true);
    const min = parseFloat(minPrice);
    const max = parseFloat(maxPrice);
    const batchId = crypto?.randomUUID?.() || String(Date.now());
    const desc = `${operation === '+' ? 'Aumento' : 'Redução'} de ${value}${type === 'percent' ? '%' : ' R$'} em ${totalAffected} produto(s) — ${ROUND_OPTIONS.find((r) => r.key === rounding)?.label || 'sem arredond.'}`;
    const upserts = [];
    const histories = [];
    products.forEach((p) => {
      const it = itemsByProduct[p.id];
      const oldVal = it?.custom_price ?? (Number(p.price) || 0);
      let newVal = computeNewValue(oldVal, operation, type, value);
      newVal = applyRounding(newVal, rounding);
      if (!isNaN(min)) newVal = Math.max(newVal, min);
      if (!isNaN(max)) newVal = Math.min(newVal, max);
      newVal = round2(newVal);
      if (round2(oldVal) === newVal) return;
      const payload = {
        price_table_id: table.id,
        price_table_name: table.name,
        product_id: p.id,
        product_name: p.name,
        product_code: p.code || '',
        category: p.category || '',
        brand: p.brand || '',
        unit_type: p.unit_type || '',
        cost: Number(p.cost) || 0,
        standard_price: Number(p.price) || 0,
        custom_price: newVal,
        updated_by: user?.full_name || user?.email || '',
        reason: reason || desc,
      };
      upserts.push({ existing: it, payload });
      histories.push({
        product_id: p.id,
        product_name: p.name,
        field: 'custom_price',
        old_value: oldVal,
        new_value: newVal,
        percent: type === 'percent' ? (operation === '+' ? Number(value) : -Number(value)) : null,
        batch_id: batchId,
        batch_description: desc,
        action_type: 'bulk',
        price_table_id: table.id,
        price_table_name: table.name,
        user_email: user?.email || '',
        reason: reason || '',
      });
    });

    try {
      for (const u of upserts) {
        if (u.existing) await base44.entities.PriceTableItem.update(u.existing.id, u.payload);
        else await base44.entities.PriceTableItem.create(u.payload);
      }
      if (histories.length) await base44.entities.PriceHistory.bulkCreate(histories);
      await base44.entities.PriceTable.update(table.id, {
        products_count: Object.keys(itemsByProduct).length + upserts.filter((u) => !u.existing).length,
        last_updated_by: user?.full_name || user?.email || '',
      });
      await logActivity({ action: 'price_table_bulk_adjust', description: desc, user, entityType: 'PriceTable', entityId: table.id, metadata: JSON.stringify({ count: upserts.length }) });
      queryClient.invalidateQueries({ queryKey: ['price-table-items', table.id] });
      queryClient.invalidateQueries({ queryKey: ['price-tables'] });
      queryClient.invalidateQueries({ queryKey: ['price-history'] });
      toast({ title: 'Ajuste aplicado', description: `${upserts.length} preço(s) atualizado(s).` });
      onDone();
      onClose();
    } catch (e) {
      toast({ title: 'Erro no ajuste', description: e.message, variant: 'destructive' });
    } finally {
      setApplying(false);
    }
  };

  return (
    <Dialog open onOpenChange={(o) => !o && onClose()}>
      <DialogContent className="sm:max-w-lg">
        <DialogHeader>
          <DialogTitle>Ajuste em massa — {table.name}</DialogTitle>
          <DialogDescription>{totalAffected} produto(s) selecionado(s). Uma prévia será exibida antes da confirmação.</DialogDescription>
        </DialogHeader>
        <div className="space-y-3">
          <div className="grid grid-cols-3 gap-3">
            <div className="space-y-1.5">
              <Label>Operação</Label>
              <Select value={operation} onValueChange={setOperation}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent><SelectItem value="+">Aumentar</SelectItem><SelectItem value="-">Reduzir</SelectItem></SelectContent>
              </Select>
            </div>
            <div className="space-y-1.5">
              <Label>Tipo</Label>
              <Select value={type} onValueChange={setType}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent><SelectItem value="percent">Percentual (%)</SelectItem><SelectItem value="value">Valor (R$)</SelectItem></SelectContent>
              </Select>
            </div>
            <div className="space-y-1.5">
              <Label>Valor</Label>
              <Input type="number" step="0.01" value={value} onChange={(e) => setValue(e.target.value)} />
            </div>
          </div>
          <div className="grid grid-cols-3 gap-3">
            <div className="space-y-1.5">
              <Label>Arredondamento</Label>
              <Select value={rounding} onValueChange={setRounding}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>{ROUND_OPTIONS.map((r) => <SelectItem key={r.key} value={r.key}>{r.label}</SelectItem>)}</SelectContent>
              </Select>
            </div>
            <div className="space-y-1.5">
              <Label>Preço mínimo</Label>
              <Input type="number" step="0.01" value={minPrice} onChange={(e) => setMinPrice(e.target.value)} placeholder="opcional" />
            </div>
            <div className="space-y-1.5">
              <Label>Preço máximo</Label>
              <Input type="number" step="0.01" value={maxPrice} onChange={(e) => setMaxPrice(e.target.value)} placeholder="opcional" />
            </div>
          </div>
          <div className="space-y-1.5">
            <Label>Motivo (opcional)</Label>
            <Input value={reason} onChange={(e) => setReason(e.target.value)} placeholder="Justificativa da alteração" />
          </div>

          <div className="rounded-lg border border-border bg-muted/30 p-3">
            <p className="text-xs font-medium mb-2">Prévia do impacto</p>
            <div className="space-y-1 max-h-40 overflow-y-auto">
              {preview.map((r, i) => (
                <div key={i} className="flex items-center justify-between text-xs">
                  <span className="truncate flex-1 text-muted-foreground">{r.name}</span>
                  <span className="text-muted-foreground line-through">{formatMoney(r.oldVal)}</span>
                  <span className="mx-1">→</span>
                  <span className="font-medium text-foreground">{formatMoney(r.newVal)}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={onClose}>Cancelar</Button>
          <Button onClick={apply} disabled={applying || !value}>
            {applying && <Loader2 className="w-4 h-4 animate-spin mr-1" />}
            Confirmar e aplicar
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

function MarginDialog({ table, products, itemsByProduct, onClose, onDone }) {
  const { user } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [marginPct, setMarginPct] = useState('');
  const [rounding, setRounding] = useState('none');
  const [applying, setApplying] = useState(false);

  const preview = useMemo(() => {
    const m = parseFloat(marginPct);
    return products.slice(0, 6).map((p) => {
      const it = itemsByProduct[p.id];
      const oldVal = it?.custom_price ?? (Number(p.price) || 0);
      const cost = Number(p.cost) || 0;
      let newVal = priceFromMargin(cost, m);
      newVal = applyRounding(newVal, rounding);
      return { name: p.name, oldVal, newVal };
    });
  }, [products, itemsByProduct, marginPct, rounding]);

  const apply = async () => {
    setApplying(true);
    const m = parseFloat(marginPct);
    const batchId = crypto?.randomUUID?.() || String(Date.now());
    const desc = `Recálculo por margem de ${m}% em ${products.length} produto(s)`;
    const upserts = [];
    const histories = [];
    products.forEach((p) => {
      const cost = Number(p.cost) || 0;
      if (cost <= 0) return;
      const it = itemsByProduct[p.id];
      const oldVal = it?.custom_price ?? (Number(p.price) || 0);
      let newVal = priceFromMargin(cost, m);
      newVal = applyRounding(newVal, rounding);
      newVal = round2(newVal);
      if (round2(oldVal) === newVal) return;
      const payload = {
        price_table_id: table.id, price_table_name: table.name,
        product_id: p.id, product_name: p.name, product_code: p.code || '',
        category: p.category || '', brand: p.brand || '', unit_type: p.unit_type || '',
        cost, standard_price: Number(p.price) || 0, custom_price: newVal,
        updated_by: user?.full_name || user?.email || '', reason: desc,
      };
      upserts.push({ existing: it, payload });
      histories.push({
        product_id: p.id, product_name: p.name, field: 'custom_price',
        old_value: oldVal, new_value: newVal, percent: m,
        batch_id: batchId, batch_description: desc, action_type: 'bulk',
        price_table_id: table.id, price_table_name: table.name, user_email: user?.email || '',
      });
    });
    try {
      for (const u of upserts) {
        if (u.existing) await base44.entities.PriceTableItem.update(u.existing.id, u.payload);
        else await base44.entities.PriceTableItem.create(u.payload);
      }
      if (histories.length) await base44.entities.PriceHistory.bulkCreate(histories);
      await base44.entities.PriceTable.update(table.id, {
        products_count: Object.keys(itemsByProduct).length + upserts.filter((u) => !u.existing).length,
        last_updated_by: user?.full_name || user?.email || '',
      });
      await logActivity({ action: 'price_table_margin_recalc', description: desc, user, entityType: 'PriceTable', entityId: table.id });
      queryClient.invalidateQueries({ queryKey: ['price-table-items', table.id] });
      queryClient.invalidateQueries({ queryKey: ['price-tables'] });
      toast({ title: 'Preços recalculados', description: `${upserts.length} produto(s) atualizado(s) pela margem.` });
      onDone();
      onClose();
    } catch (e) {
      toast({ title: 'Erro', description: e.message, variant: 'destructive' });
    } finally {
      setApplying(false);
    }
  };

  return (
    <Dialog open onOpenChange={(o) => !o && onClose()}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Recalcular por margem — {table.name}</DialogTitle>
          <DialogDescription>Define o preço = custo × (1 + margem%). Produtos sem custo são ignorados.</DialogDescription>
        </DialogHeader>
        <div className="space-y-3">
          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-1.5">
              <Label>Margem desejada (%)</Label>
              <Input type="number" step="0.01" value={marginPct} onChange={(e) => setMarginPct(e.target.value)} placeholder="ex: 30" />
            </div>
            <div className="space-y-1.5">
              <Label>Arredondamento</Label>
              <Select value={rounding} onValueChange={setRounding}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>{ROUND_OPTIONS.map((r) => <SelectItem key={r.key} value={r.key}>{r.label}</SelectItem>)}</SelectContent>
              </Select>
            </div>
          </div>
          <div className="rounded-lg border border-border bg-muted/30 p-3">
            <p className="text-xs font-medium mb-2">Prévia</p>
            <div className="space-y-1">
              {preview.map((r, i) => (
                <div key={i} className="flex items-center justify-between text-xs">
                  <span className="truncate flex-1 text-muted-foreground">{r.name}</span>
                  <span className="text-muted-foreground line-through">{formatMoney(r.oldVal)}</span>
                  <span className="mx-1">→</span>
                  <span className="font-medium">{formatMoney(r.newVal)}</span>
                </div>
              ))}
              {preview.length === 0 && <p className="text-xs text-muted-foreground">Selecione produtos com custo.</p>}
            </div>
          </div>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={onClose}>Cancelar</Button>
          <Button onClick={apply} disabled={applying || !marginPct}>
            {applying && <Loader2 className="w-4 h-4 animate-spin mr-1" />}
            Aplicar margem
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}