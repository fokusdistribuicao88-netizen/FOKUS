import React, { useState } from 'react';
import { useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { useAuth } from '@/lib/AuthContext';
import { useToast } from '@/components/ui/use-toast';
import { logActivity } from '@/lib/activityLog';
import {
  ArrowLeft, Pencil, Copy, Power, Trash2, Download, Star, Loader2, Upload,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs';
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription,
} from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import PriceTableProductsTab from './PriceTableProductsTab';
import PriceTableCustomersTab from './PriceTableCustomersTab';
import PriceTableHistoryTab from './PriceTableHistoryTab';

export default function PriceTableDetail({
  table, onBack, canEdit, onEdit, onDuplicate, onToggleStatus, onDelete, onExport, onSetDefault, onImport,
}) {
  return (
    <div className="space-y-4">
      <div className="flex flex-col sm:flex-row sm:items-center gap-3">
        <Button variant="outline" size="sm" onClick={onBack} className="gap-2 w-fit">
          <ArrowLeft className="w-4 h-4" /> Voltar à lista
        </Button>
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2 flex-wrap">
            <h2 className="text-lg font-bold text-foreground">{table.name}</h2>
            <Badge variant="outline">{table.code}</Badge>
            <Badge variant={table.status === 'active' ? 'default' : 'secondary'} className={table.status === 'active' ? 'bg-green-100 text-green-700 dark:bg-green-950 dark:text-green-400' : ''}>
              {table.status === 'active' ? 'Ativa' : 'Inativa'}
            </Badge>
            {table.is_default && <Badge className="bg-amber-100 text-amber-700 dark:bg-amber-950 dark:text-amber-400 gap-1"><Star className="w-3 h-3" /> Padrão</Badge>}
          </div>
          <p className="text-sm text-muted-foreground mt-0.5">
            {table.description || 'Sem descrição'}
            {table.start_date && ` · Vigência: ${new Date(table.start_date).toLocaleDateString('pt-BR')}${table.end_date ? ' até ' + new Date(table.end_date).toLocaleDateString('pt-BR') : ''}`}
          </p>
        </div>
        <div className="flex items-center gap-1 flex-wrap">
          {canEdit && (
            <>
              <Button variant="outline" size="sm" onClick={() => onEdit(table)} className="gap-2"><Pencil className="w-4 h-4" /> Editar</Button>
              <Button variant="outline" size="sm" onClick={() => onDuplicate(table)} className="gap-2"><Copy className="w-4 h-4" /> Duplicar</Button>
              <Button variant="outline" size="sm" onClick={() => onToggleStatus(table)} className="gap-2"><Power className="w-4 h-4" /> {table.status === 'active' ? 'Desativar' : 'Ativar'}</Button>
              <Button variant="outline" size="sm" onClick={() => onSetDefault(table)} className="gap-2"><Star className="w-4 h-4" /> Padrão</Button>
              <Button variant="outline" size="sm" onClick={() => onImport(table)} className="gap-2"><Upload className="w-4 h-4" /> Importar</Button>
              <Button variant="outline" size="sm" onClick={() => onDelete(table)} className="gap-2 text-destructive hover:text-destructive"><Trash2 className="w-4 h-4" /> Excluir</Button>
            </>
          )}
          <Button variant="outline" size="sm" onClick={() => onExport(table)} className="gap-2"><Download className="w-4 h-4" /> Exportar</Button>
        </div>
      </div>

      <Tabs defaultValue="products">
        <TabsList>
          <TabsTrigger value="products">Produtos</TabsTrigger>
          <TabsTrigger value="customers">Clientes vinculados</TabsTrigger>
          <TabsTrigger value="history">Histórico</TabsTrigger>
        </TabsList>
        <TabsContent value="products" className="mt-4">
          <PriceTableProductsTab table={table} canEdit={canEdit} />
        </TabsContent>
        <TabsContent value="customers" className="mt-4">
          <PriceTableCustomersTab table={table} canEdit={canEdit} />
        </TabsContent>
        <TabsContent value="history" className="mt-4">
          <PriceTableHistoryTab table={table} />
        </TabsContent>
      </Tabs>
    </div>
  );
}

export function DuplicateDialog({ open, onClose, table, onDone }) {
  const { user } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [newName, setNewName] = useState('');
  const [newCode, setNewCode] = useState('');
  const [busy, setBusy] = useState(false);

  React.useEffect(() => {
    if (open && table) {
      setNewName(`${table.name} (cópia)`);
      setNewCode(`${table.code || 'TAB'}-CP`);
    }
  }, [open, table]);

  const duplicate = async () => {
    setBusy(true);
    try {
      const created = await base44.entities.PriceTable.create({
        name: newName.trim(),
        code: newCode.trim(),
        description: table.description || '',
        status: 'inactive',
        is_default: false,
        start_date: table.start_date || '',
        end_date: table.end_date || '',
        notes: (table.notes || '') + ` (Duplicada de ${table.name})`,
        products_count: 0,
        customers_count: 0,
        last_updated_by: user?.full_name || user?.email || '',
      });
      const items = await base44.entities.PriceTableItem.filter({ price_table_id: table.id });
      if (items.length) {
        const copies = items.map((it) => ({
          price_table_id: created.id,
          price_table_name: newName.trim(),
          product_id: it.product_id,
          product_name: it.product_name,
          product_code: it.product_code || '',
          category: it.category || '',
          brand: it.brand || '',
          unit_type: it.unit_type || '',
          cost: it.cost || 0,
          standard_price: it.standard_price || 0,
          custom_price: it.custom_price,
          min_price: it.min_price,
          max_price: it.max_price,
          updated_by: user?.full_name || user?.email || '',
          reason: `Duplicado de ${table.name}`,
        }));
        await base44.entities.PriceTableItem.bulkCreate(copies);
        await base44.entities.PriceTable.update(created.id, { products_count: copies.length });
      }
      await logActivity({ action: 'price_table_duplicate', description: `Tabela ${table.name} duplicada como ${newName}`, user, entityType: 'PriceTable', entityId: created.id });
      queryClient.invalidateQueries({ queryKey: ['price-tables'] });
      toast({ title: 'Tabela duplicada', description: `${newName} criada com ${items.length} preço(s).` });
      onDone(created);
      onClose();
    } catch (e) {
      toast({ title: 'Erro ao duplicar', description: e.message, variant: 'destructive' });
    } finally {
      setBusy(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={(o) => !o && onClose()}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Duplicar tabela</DialogTitle>
          <DialogDescription>Copia todos os preços e configurações para uma nova tabela.</DialogDescription>
        </DialogHeader>
        <div className="space-y-3">
          <div className="space-y-1.5">
            <Label>Nome da nova tabela *</Label>
            <Input value={newName} onChange={(e) => setNewName(e.target.value)} />
          </div>
          <div className="space-y-1.5">
            <Label>Código *</Label>
            <Input value={newCode} onChange={(e) => setNewCode(e.target.value)} />
          </div>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={onClose}>Cancelar</Button>
          <Button onClick={duplicate} disabled={busy || !newName.trim() || !newCode.trim()}>
            {busy && <Loader2 className="w-4 h-4 animate-spin mr-1" />} Duplicar
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}