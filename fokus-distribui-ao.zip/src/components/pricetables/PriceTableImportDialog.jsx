import React, { useState, useMemo } from 'react';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { useAuth } from '@/lib/AuthContext';
import { useToast } from '@/components/ui/use-toast';
import { logActivity } from '@/lib/activityLog';
import * as XLSX from 'xlsx';
import { Upload, Loader2, AlertTriangle, CheckCircle2, FileSpreadsheet } from 'lucide-react';
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';

export default function PriceTableImportDialog({ open, onClose, table, onDone }) {
  const queryClient = useQueryClient();
  const { user } = useAuth();
  const { toast } = useToast();
  const [rows, setRows] = useState([]);
  const [fileName, setFileName] = useState('');
  const [parsing, setParsing] = useState(false);
  const [applying, setApplying] = useState(false);

  const { data: products = [] } = useQuery({
    queryKey: ['products'],
    queryFn: () => base44.entities.Product.list(),
    staleTime: 60 * 1000,
    enabled: open,
  });
  const { data: existingItems = [] } = useQuery({
    queryKey: ['price-table-items', table?.id],
    queryFn: () => base44.entities.PriceTableItem.filter({ price_table_id: table.id }),
    staleTime: 30 * 1000,
    enabled: open && !!table?.id,
  });

  const productByCode = useMemo(() => {
    const m = {};
    products.forEach((p) => { if (p.code) m[p.code.toLowerCase()] = p; });
    return m;
  }, [products]);
  const itemByProductId = useMemo(() => {
    const m = {};
    existingItems.forEach((it) => { m[it.product_id] = it; });
    return m;
  }, [existingItems]);

  const handleFile = async (file) => {
    setParsing(true);
    setRows([]);
    setFileName(file.name);
    try {
      const buf = await file.arrayBuffer();
      const wb = XLSX.read(buf, { type: 'array' });
      const ws = wb.Sheets[wb.SheetNames[0]];
      const json = XLSX.utils.sheet_to_json(ws, { defval: '' });
      const seen = new Set();
      const parsed = json.map((r) => {
        const code = String(r['Código'] || r['code'] || r['Codigo'] || '').trim();
        const price = parseFloat(String(r['Preço na tabela'] || r['custom_price'] || r['Preço'] || r['price'] || '').replace(',', '.'));
        const product = code ? productByCode[code.toLowerCase()] : null;
        const errors = [];
        if (!code) errors.push('Código vazio');
        if (!product) errors.push('Produto inexistente');
        if (seen.has(code.toLowerCase())) errors.push('Código duplicado no arquivo');
        else if (code) seen.add(code.toLowerCase());
        if (!isFinite(price) || price < 0) errors.push('Valor inválido');
        return { code, price, product, errors, name: product?.name || r['Produto'] || r['name'] || '' };
      });
      setRows(parsed);
    } catch (e) {
      toast({ title: 'Erro ao ler arquivo', description: e.message, variant: 'destructive' });
    } finally {
      setParsing(false);
    }
  };

  const validRows = rows.filter((r) => r.errors.length === 0);
  const invalidRows = rows.filter((r) => r.errors.length > 0);

  const apply = async () => {
    setApplying(true);
    try {
      const upserts = [];
      const histories = [];
      validRows.forEach((r) => {
        const existing = itemByProductId[r.product.id];
        const oldVal = existing?.custom_price ?? (Number(r.product.price) || 0);
        upserts.push({ existing, payload: {
          price_table_id: table.id, price_table_name: table.name,
          product_id: r.product.id, product_name: r.product.name, product_code: r.product.code || '',
          category: r.product.category || '', brand: r.product.brand || '', unit_type: r.product.unit_type || '',
          cost: Number(r.product.cost) || 0, standard_price: Number(r.product.price) || 0,
          custom_price: r.price, updated_by: user?.full_name || user?.email || '', reason: 'Importação',
        }});
        histories.push({
          product_id: r.product.id, product_name: r.product.name, field: 'custom_price',
          old_value: oldVal, new_value: r.price, action_type: 'bulk',
          batch_description: `Importação de preços — ${fileName}`, price_table_id: table.id, price_table_name: table.name,
          user_email: user?.email || '', reason: 'Importação',
        });
      });
      for (const u of upserts) {
        if (u.existing) await base44.entities.PriceTableItem.update(u.existing.id, u.payload);
        else await base44.entities.PriceTableItem.create(u.payload);
      }
      if (histories.length) await base44.entities.PriceHistory.bulkCreate(histories);
      await base44.entities.PriceTable.update(table.id, {
        products_count: Object.keys(itemByProductId).length + upserts.filter((u) => !u.existing).length,
        last_updated_by: user?.full_name || user?.email || '',
      });
      await logActivity({ action: 'price_table_import', description: `Importação de ${validRows.length} preços na tabela ${table.name}`, user, entityType: 'PriceTable', entityId: table.id });
      queryClient.invalidateQueries({ queryKey: ['price-table-items', table.id] });
      queryClient.invalidateQueries({ queryKey: ['price-tables'] });
      queryClient.invalidateQueries({ queryKey: ['price-history'] });
      toast({ title: 'Importação concluída', description: `${validRows.length} preço(s) importado(s).` });
      onDone?.();
      onClose();
      setRows([]);
      setFileName('');
    } catch (e) {
      toast({ title: 'Erro na importação', description: e.message, variant: 'destructive' });
    } finally {
      setApplying(false);
    }
  };

  const downloadTemplate = () => {
    const ws = XLSX.utils.json_to_sheet(products.slice(0, 20).map((p) => ({
      'Código': p.code || '', 'Produto': p.name, 'Preço na tabela': p.price || 0,
    })));
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'Modelo');
    XLSX.writeFile(wb, 'modelo-importacao-tabela.xlsx');
  };

  return (
    <Dialog open={open} onOpenChange={(o) => !o && onClose()}>
      <DialogContent className="sm:max-w-lg">
        <DialogHeader>
          <DialogTitle>Importar preços — {table?.name}</DialogTitle>
          <DialogDescription>Arquivo Excel/CSV com colunas "Código" e "Preço na tabela".</DialogDescription>
        </DialogHeader>
        <div className="space-y-3">
          <div className="flex gap-2">
            <label className="flex-1 cursor-pointer">
              <div className="border-2 border-dashed border-border rounded-lg p-4 text-center hover:bg-muted/30 transition-colors">
                {parsing ? <Loader2 className="w-5 h-5 animate-spin mx-auto" /> : <Upload className="w-5 h-5 mx-auto text-muted-foreground" />}
                <p className="text-sm mt-1 text-muted-foreground">{fileName || 'Selecionar arquivo'}</p>
              </div>
              <input type="file" accept=".xlsx,.xls,.csv" className="hidden" onChange={(e) => e.target.files[0] && handleFile(e.target.files[0])} />
            </label>
            <Button variant="outline" size="sm" onClick={downloadTemplate} className="gap-2 h-fit">
              <FileSpreadsheet className="w-4 h-4" /> Modelo
            </Button>
          </div>

          {rows.length > 0 && (
            <div className="space-y-2">
              <div className="flex items-center gap-3 text-sm">
                <span className="flex items-center gap-1 text-green-600"><CheckCircle2 className="w-4 h-4" /> {validRows.length} válidos</span>
                {invalidRows.length > 0 && <span className="flex items-center gap-1 text-red-600"><AlertTriangle className="w-4 h-4" /> {invalidRows.length} com erro</span>}
              </div>
              <div className="max-h-56 overflow-y-auto border border-border rounded-lg">
                {rows.map((r, i) => (
                  <div key={i} className="flex items-center justify-between px-3 py-1.5 border-b border-border text-xs">
                    <span className="truncate flex-1">{r.code || '—'} · {r.name || '—'}</span>
                    <span className="text-muted-foreground mx-2">{r.price != null ? r.price : '—'}</span>
                    {r.errors.length === 0 ? (
                      <Badge className="bg-green-50 text-green-600 text-[10px]">ok</Badge>
                    ) : (
                      <Badge variant="destructive" className="text-[10px]">{r.errors.join(', ')}</Badge>
                    )}
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={onClose}>Cancelar</Button>
          <Button onClick={apply} disabled={applying || validRows.length === 0}>
            {applying && <Loader2 className="w-4 h-4 animate-spin mr-1" />} Importar {validRows.length} preço(s)
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}