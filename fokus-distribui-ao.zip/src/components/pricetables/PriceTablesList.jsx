import React, { useMemo, useState } from 'react';
import {
  Search, Eye, Pencil, Copy, Power, Trash2, Users, Download, Star, Loader2,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { formatMoney } from '@/lib/priceTables';
import { SYSTEM_TABLES, isSystemCode } from '@/lib/posPriceTables';

const fmtDate = (d) =>
  d ? new Date(d).toLocaleDateString('pt-BR', { day: '2-digit', month: '2-digit', year: 'numeric' }) : '—';

export default function PriceTablesList({
  tables, loading, canEdit,
  onSelect, onEdit, onDuplicate, onToggleStatus, onDelete, onApplyToCustomers, onExport, onSetDefault,
}) {
  const [search, setSearch] = useState('');
  const [status, setStatus] = useState('all');

  const filtered = useMemo(() => {
    const q = search.toLowerCase().trim();
    return tables.filter((t) => {
      if (q && !(t.name?.toLowerCase().includes(q) || t.code?.toLowerCase().includes(q) || t.description?.toLowerCase().includes(q))) return false;
      if (status !== 'all' && (t.status || 'active') !== status) return false;
      return true;
    });
  }, [tables, search, status]);

  return (
    <div className="bg-card border border-border rounded-2xl shadow-sm overflow-hidden">
      <div className="p-4 flex flex-col sm:flex-row gap-3 border-b border-border">
        <div className="relative flex-1">
          <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
          <Input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Buscar por nome, código ou descrição..."
            className="pl-9"
          />
        </div>
        <Select value={status} onValueChange={setStatus}>
          <SelectTrigger className="w-full sm:w-44">
            <SelectValue placeholder="Status" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">Todos os status</SelectItem>
            <SelectItem value="active">Ativas</SelectItem>
            <SelectItem value="inactive">Inativas</SelectItem>
          </SelectContent>
        </Select>
      </div>

      <div className="overflow-x-auto">
        <table className="w-full text-sm">
          <thead className="bg-muted/50 text-xs uppercase text-muted-foreground">
            <tr>
              <th className="text-left font-medium px-4 py-3">Nome / Código</th>
              <th className="text-left font-medium px-4 py-3 hidden md:table-cell">Status</th>
              <th className="text-left font-medium px-4 py-3 hidden lg:table-cell">Produtos</th>
              <th className="text-left font-medium px-4 py-3 hidden lg:table-cell">Clientes</th>
              <th className="text-left font-medium px-4 py-3 hidden xl:table-cell">Criada</th>
              <th className="text-left font-medium px-4 py-3 hidden xl:table-cell">Atualizada</th>
              <th className="text-left font-medium px-4 py-3 hidden md:table-cell">Resp.</th>
              <th className="text-right font-medium px-4 py-3">Ações</th>
            </tr>
          </thead>
          <tbody>
            {loading ? (
              <tr>
                <td colSpan={8} className="text-center py-12">
                  <Loader2 className="w-6 h-6 animate-spin text-blue-600 mx-auto" />
                </td>
              </tr>
            ) : filtered.length === 0 ? (
              <tr>
                <td colSpan={8} className="text-center py-12 text-muted-foreground">
                  Nenhuma tabela encontrada.
                </td>
              </tr>
            ) : (
              filtered.map((t) => {
                const isSys = isSystemCode(t.code);
                return (
              <tr key={t.id} className="border-t border-border hover:bg-muted/30 transition-colors">
                <td className="px-4 py-3">
                  <div className="flex items-center gap-2">
                    <div className="min-w-0">
                      <div className="flex items-center gap-2">
                        <p className="font-medium text-foreground truncate">{t.name}</p>
                        {isSys && (
                          <Badge className="bg-blue-100 text-blue-700 dark:bg-blue-950 dark:text-blue-400 gap-1">Sistema</Badge>
                        )}
                        {t.is_default && (
                          <Badge className="bg-amber-100 text-amber-700 dark:bg-amber-950 dark:text-amber-400 gap-1">
                            <Star className="w-3 h-3" /> Padrão
                          </Badge>
                        )}
                      </div>
                      <p className="text-xs text-muted-foreground">
                        {t.code || '—'}
                        {t.description ? ` · ${t.description}` : ''}
                      </p>
                    </div>
                  </div>
                </td>
                <td className="px-4 py-3 hidden md:table-cell">
                  <Badge variant={t.status === 'active' ? 'default' : 'secondary'} className={t.status === 'active' ? 'bg-green-100 text-green-700 dark:bg-green-950 dark:text-green-400' : ''}>
                    {t.status === 'active' ? 'Ativa' : 'Inativa'}
                  </Badge>
                </td>
                <td className="px-4 py-3 hidden lg:table-cell text-muted-foreground">{Number(t.products_count) || 0}</td>
                <td className="px-4 py-3 hidden lg:table-cell text-muted-foreground">{Number(t.customers_count) || 0}</td>
                <td className="px-4 py-3 hidden xl:table-cell text-xs text-muted-foreground">{fmtDate(t.created_date)}</td>
                <td className="px-4 py-3 hidden xl:table-cell text-xs text-muted-foreground">{fmtDate(t.updated_date)}</td>
                <td className="px-4 py-3 hidden md:table-cell text-xs text-muted-foreground truncate max-w-[120px]">{t.last_updated_by || '—'}</td>
                <td className="px-4 py-3">
                  <div className="flex items-center justify-end gap-1">
                    <Button variant="ghost" size="icon" className="h-8 w-8" title="Visualizar" onClick={() => onSelect(t)}>
                      <Eye className="w-4 h-4" />
                    </Button>
                    {canEdit && (
                      <>
                        <Button variant="ghost" size="icon" className="h-8 w-8" title="Editar" onClick={() => onEdit(t)}>
                          <Pencil className="w-4 h-4" />
                        </Button>
                        <Button variant="ghost" size="icon" className="h-8 w-8" title="Duplicar" onClick={() => onDuplicate(t)}>
                          <Copy className="w-4 h-4" />
                        </Button>
                        <Button variant="ghost" size="icon" className="h-8 w-8" title={t.status === 'active' ? 'Desativar' : 'Ativar'} onClick={() => onToggleStatus(t)}>
                          <Power className="w-4 h-4" />
                        </Button>
                        <Button variant="ghost" size="icon" className="h-8 w-8" title="Aplicar aos clientes" onClick={() => onApplyToCustomers(t)}>
                          <Users className="w-4 h-4" />
                        </Button>
                        <Button variant="ghost" size="icon" className="h-8 w-8" title="Definir como padrão" onClick={() => onSetDefault(t)}>
                          <Star className="w-4 h-4" />
                        </Button>
                        <Button variant="ghost" size="icon" className="h-8 w-8" title="Exportar" onClick={() => onExport(t)}>
                          <Download className="w-4 h-4" />
                        </Button>
                        {!isSys && (
                          <Button variant="ghost" size="icon" className="h-8 w-8 text-destructive hover:text-destructive" title="Excluir" onClick={() => onDelete(t)}>
                            <Trash2 className="w-4 h-4" />
                          </Button>
                        )}
                      </>
                    )}
                  </div>
                </td>
              </tr>
                );
              })
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}