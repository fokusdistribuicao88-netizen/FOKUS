import React, { useMemo, useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Search, Loader2 } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { formatMoney } from '@/lib/priceTables';

export default function PriceTableHistoryTab({ table }) {
  const [search, setSearch] = useState('');

  const { data: history = [], isLoading } = useQuery({
    queryKey: ['price-table-history', table.id],
    queryFn: () => base44.entities.PriceHistory.filter({ price_table_id: table.id }, '-created_date', 200),
    staleTime: 30 * 1000,
  });

  const filtered = useMemo(() => {
    const q = search.toLowerCase().trim();
    if (!q) return history;
    return history.filter((h) =>
      h.product_name?.toLowerCase().includes(q) ||
      h.batch_description?.toLowerCase().includes(q) ||
      h.user_email?.toLowerCase().includes(q) ||
      h.reason?.toLowerCase().includes(q)
    );
  }, [history, search]);

  const fmt = (d) => d ? new Date(d).toLocaleString('pt-BR', { day: '2-digit', month: '2-digit', year: '2-digit', hour: '2-digit', minute: '2-digit' }) : '—';

  return (
    <div className="space-y-4">
      <div className="relative max-w-md">
        <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
        <Input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Buscar no histórico..." className="pl-9" />
      </div>

      <div className="bg-card border border-border rounded-xl overflow-x-auto">
        <table className="w-full text-sm">
          <thead className="bg-muted/50 text-xs uppercase text-muted-foreground">
            <tr>
              <th className="text-left font-medium px-4 py-3">Produto</th>
              <th className="text-left font-medium px-4 py-3 hidden md:table-cell">Campo</th>
              <th className="text-right font-medium px-4 py-3">Anterior</th>
              <th className="text-right font-medium px-4 py-3">Novo</th>
              <th className="text-right font-medium px-4 py-3 hidden lg:table-cell">Variação</th>
              <th className="text-left font-medium px-4 py-3 hidden lg:table-cell">Lote / Motivo</th>
              <th className="text-left font-medium px-4 py-3 hidden md:table-cell">Usuário</th>
              <th className="text-left font-medium px-4 py-3">Data</th>
            </tr>
          </thead>
          <tbody>
            {isLoading ? (
              <tr><td colSpan={8} className="text-center py-12"><Loader2 className="w-6 h-6 animate-spin text-blue-600 mx-auto" /></td></tr>
            ) : filtered.length === 0 ? (
              <tr><td colSpan={8} className="text-center py-12 text-muted-foreground">Nenhuma alteração registrada.</td></tr>
            ) : filtered.map((h) => {
              const diff = (Number(h.new_value) || 0) - (Number(h.old_value) || 0);
              return (
                <tr key={h.id} className="border-t border-border hover:bg-muted/30">
                  <td className="px-4 py-2.5">
                    <p className="font-medium text-foreground truncate max-w-[200px]">{h.product_name}</p>
                    {h.action_type === 'bulk' && <Badge className="mt-0.5 bg-blue-50 text-blue-600 dark:bg-blue-950 dark:text-blue-400 text-[10px]">em lote</Badge>}
                  </td>
                  <td className="px-4 py-2.5 hidden md:table-cell text-muted-foreground">{h.field === 'custom_price' ? 'Preço na tabela' : h.field}</td>
                  <td className="px-4 py-2.5 text-right text-muted-foreground">{formatMoney(h.old_value)}</td>
                  <td className="px-4 py-2.5 text-right font-medium">{formatMoney(h.new_value)}</td>
                  <td className="px-4 py-2.5 hidden lg:table-cell text-right">
                    {h.percent !== null && h.percent !== undefined ? (
                      <span className={h.percent >= 0 ? 'text-green-600' : 'text-red-600'}>{h.percent >= 0 ? '+' : ''}{h.percent}%</span>
                    ) : (
                      <span className={diff >= 0 ? 'text-green-600' : 'text-red-600'}>{diff >= 0 ? '+' : ''}{formatMoney(diff)}</span>
                    )}
                  </td>
                  <td className="px-4 py-2.5 hidden lg:table-cell text-xs text-muted-foreground truncate max-w-[200px]">{h.batch_description || h.reason || '—'}</td>
                  <td className="px-4 py-2.5 hidden md:table-cell text-xs text-muted-foreground truncate max-w-[140px]">{h.user_email || '—'}</td>
                  <td className="px-4 py-2.5 text-xs text-muted-foreground whitespace-nowrap">{fmt(h.created_date)}</td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
}