import React, { useMemo, useState } from 'react';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { useAuth } from '@/lib/AuthContext';
import { useToast } from '@/components/ui/use-toast';
import { logActivity } from '@/lib/activityLog';
import { Search, Loader2, Link2, Unlink, CheckSquare, Square, Users } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';

export default function PriceTableCustomersTab({ table, canEdit }) {
  const queryClient = useQueryClient();
  const { user } = useAuth();
  const { toast } = useToast();
  const [search, setSearch] = useState('');
  const [selectedIds, setSelectedIds] = useState(new Set());
  const [busy, setBusy] = useState(false);

  const { data: customers = [], isLoading } = useQuery({
    queryKey: ['customers'],
    queryFn: () => base44.entities.Customer.list(),
    staleTime: 60 * 1000,
  });

  const linked = useMemo(() => customers.filter((c) => c.price_table_id === table.id), [customers, table.id]);

  const filtered = useMemo(() => {
    const q = search.toLowerCase().trim();
    if (!q) return customers;
    return customers.filter((c) =>
      c.name?.toLowerCase().includes(q) ||
      c.cpf_cnpj?.toLowerCase().includes(q) ||
      c.email?.toLowerCase().includes(q) ||
      c.company?.toLowerCase().includes(q)
    );
  }, [customers, search]);

  const toggle = (id) => setSelectedIds((prev) => {
    const n = new Set(prev); n.has(id) ? n.delete(id) : n.add(id); return n;
  });

  const linkSelected = async () => {
    setBusy(true);
    try {
      const updates = [];
      const ids = [...selectedIds];
      for (const id of ids) {
        updates.push(base44.entities.Customer.update(id, { price_table_id: table.id, price_table_name: table.name }));
      }
      await Promise.all(updates);
      await base44.entities.PriceTable.update(table.id, {
        customers_count: linked.length + ids.filter((id) => !linked.find((c) => c.id === id)).length,
        last_updated_by: user?.full_name || user?.email || '',
      });
      await logActivity({ action: 'price_table_link_customers', description: `${ids.length} cliente(s) vinculado(s) à tabela ${table.name}`, user, entityType: 'PriceTable', entityId: table.id });
      queryClient.invalidateQueries({ queryKey: ['customers'] });
      queryClient.invalidateQueries({ queryKey: ['price-tables'] });
      toast({ title: 'Clientes vinculados', description: `${ids.length} cliente(s) agora usam a tabela ${table.name}.` });
      setSelectedIds(new Set());
    } catch (e) {
      toast({ title: 'Erro ao vincular', description: e.message, variant: 'destructive' });
    } finally {
      setBusy(false);
    }
  };

  const unlink = async (customer) => {
    setBusy(true);
    try {
      await base44.entities.Customer.update(customer.id, { price_table_id: '', price_table_name: '' });
      await base44.entities.PriceTable.update(table.id, {
        customers_count: Math.max(0, linked.length - 1),
        last_updated_by: user?.full_name || user?.email || '',
      });
      await logActivity({ action: 'price_table_unlink_customer', description: `Cliente ${customer.name} desvinculado da tabela ${table.name}`, user, entityType: 'PriceTable', entityId: table.id });
      queryClient.invalidateQueries({ queryKey: ['customers'] });
      queryClient.invalidateQueries({ queryKey: ['price-tables'] });
      toast({ title: 'Cliente desvinculado' });
    } catch (e) {
      toast({ title: 'Erro', description: e.message, variant: 'destructive' });
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="space-y-4">
      <div className="flex flex-col lg:flex-row gap-3 lg:items-center">
        <div className="relative flex-1">
          <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
          <Input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Buscar cliente..." className="pl-9" />
        </div>
        {canEdit && (
          <Button onClick={linkSelected} disabled={busy || selectedIds.size === 0} className="gap-2">
            <Link2 className="w-4 h-4" /> Vincular selecionados ({selectedIds.size})
          </Button>
        )}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {/* Vinculados */}
        <div className="bg-card border border-border rounded-xl overflow-hidden">
          <div className="px-4 py-2.5 border-b border-border bg-muted/40 flex items-center gap-2">
            <Users className="w-4 h-4 text-violet-600" />
            <h4 className="text-sm font-semibold">Vinculados ({linked.length})</h4>
          </div>
          <div className="max-h-[420px] overflow-y-auto">
            {isLoading ? (
              <div className="text-center py-8"><Loader2 className="w-6 h-6 animate-spin text-blue-600 mx-auto" /></div>
            ) : linked.length === 0 ? (
              <p className="text-center py-8 text-sm text-muted-foreground">Nenhum cliente vinculado.</p>
            ) : linked.map((c) => (
              <div key={c.id} className="flex items-center justify-between px-4 py-2.5 border-b border-border hover:bg-muted/30">
                <div className="min-w-0">
                  <p className="font-medium text-sm truncate">{c.name}</p>
                  <p className="text-xs text-muted-foreground">{c.cpf_cnpj || c.email || '—'}</p>
                </div>
                {canEdit && (
                  <Button variant="ghost" size="icon" className="h-8 w-8 text-destructive" title="Desvincular" onClick={() => unlink(c)} disabled={busy}>
                    <Unlink className="w-4 h-4" />
                  </Button>
                )}
              </div>
            ))}
          </div>
        </div>

        {/* Todos */}
        <div className="bg-card border border-border rounded-xl overflow-hidden">
          <div className="px-4 py-2.5 border-b border-border bg-muted/40 flex items-center gap-2">
            <Users className="w-4 h-4 text-blue-600" />
            <h4 className="text-sm font-semibold">Todos os clientes ({customers.length})</h4>
          </div>
          <div className="max-h-[420px] overflow-y-auto">
            {filtered.length === 0 ? (
              <p className="text-center py-8 text-sm text-muted-foreground">Nenhum cliente encontrado.</p>
            ) : filtered.map((c) => {
              const isLinked = c.price_table_id === table.id;
              const other = c.price_table_id && c.price_table_id !== table.id;
              return (
                <div key={c.id} className="flex items-center gap-2 px-4 py-2.5 border-b border-border hover:bg-muted/30">
                  {canEdit && (
                    <button onClick={() => toggle(c.id)} disabled={isLinked}>
                      {selectedIds.has(c.id) ? <CheckSquare className="w-4 h-4 text-blue-600" /> : <Square className="w-4 h-4 text-muted-foreground" />}
                    </button>
                  )}
                  <div className="min-w-0 flex-1">
                    <p className="font-medium text-sm truncate">{c.name}</p>
                    <p className="text-xs text-muted-foreground">{c.cpf_cnpj || c.email || '—'}</p>
                  </div>
                  {isLinked && <Badge className="bg-violet-100 text-violet-700 dark:bg-violet-950 dark:text-violet-400 text-[10px]">nesta tabela</Badge>}
                  {other && <Badge className="bg-muted text-muted-foreground text-[10px]">{c.price_table_name || 'outra tabela'}</Badge>}
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
}