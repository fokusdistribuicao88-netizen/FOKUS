import React, { useMemo } from 'react';
import {
  Table2, CheckCircle2, XCircle, Users, Package, History, UserCog,
} from 'lucide-react';

function Stat({ icon: Icon, label, value, sub, accent }) {
  const accents = {
    slate: 'bg-slate-50 dark:bg-slate-900/40 text-slate-600 dark:text-slate-300',
    blue: 'bg-blue-50 dark:bg-blue-950/40 text-blue-600 dark:text-blue-400',
    green: 'bg-green-50 dark:bg-green-950/40 text-green-600 dark:text-green-400',
    red: 'bg-red-50 dark:bg-red-950/40 text-red-600 dark:text-red-400',
    violet: 'bg-violet-50 dark:bg-violet-950/40 text-violet-600 dark:text-violet-400',
    amber: 'bg-amber-50 dark:bg-amber-950/40 text-amber-600 dark:text-amber-400',
  };
  return (
    <div className="bg-card border border-border rounded-xl p-3 flex items-center gap-3">
      <div className={`w-9 h-9 rounded-lg flex items-center justify-center ${accents[accent] || accents.slate}`}>
        <Icon className="w-5 h-5" />
      </div>
      <div className="min-w-0">
        <p className="text-[10px] uppercase tracking-wider text-muted-foreground truncate">{label}</p>
        <p className="text-lg font-bold leading-tight">{value}</p>
        {sub && <p className="text-[11px] text-muted-foreground truncate">{sub}</p>}
      </div>
    </div>
  );
}

export default function PriceTablesOverview({ tables, customers }) {
  const stats = useMemo(() => {
    const active = tables.filter((t) => t.status === 'active').length;
    const inactive = tables.filter((t) => t.status === 'inactive').length;
    const linkedCustomers = customers.filter((c) => c.price_table_id).length;
    const customPrices = tables.reduce((s, t) => s + (Number(t.products_count) || 0), 0);

    let lastUpdate = null;
    let lastUser = '';
    tables.forEach((t) => {
      const d = new Date(t.updated_date || t.created_date);
      if (!lastUpdate || d > lastUpdate) {
        lastUpdate = d;
        lastUser = t.last_updated_by || t.created_by || '';
      }
    });

    return {
      total: tables.length,
      active,
      inactive,
      linkedCustomers,
      customPrices,
      lastUpdate,
      lastUser,
    };
  }, [tables, customers]);

  const fmtDate = (d) =>
    d ? new Date(d).toLocaleString('pt-BR', { day: '2-digit', month: '2-digit', year: 'numeric', hour: '2-digit', minute: '2-digit' }) : '—';

  return (
    <div className="grid grid-cols-2 md:grid-cols-3 xl:grid-cols-4 gap-3">
      <Stat icon={Table2} label="Total de tabelas" value={stats.total} accent="blue" />
      <Stat icon={CheckCircle2} label="Tabelas ativas" value={stats.active} accent="green" />
      <Stat icon={XCircle} label="Tabelas inativas" value={stats.inactive} accent="red" />
      <Stat icon={Users} label="Clientes vinculados" value={stats.linkedCustomers} accent="violet" />
      <Stat icon={Package} label="Produtos c/ preço personalizado" value={stats.customPrices} accent="amber" />
      <Stat icon={UserCog} label="Última alteração por" value={stats.lastUser || '—'} sub={fmtDate(stats.lastUpdate)} accent="slate" />
      <Stat icon={History} label="Última atualização" value={fmtDate(stats.lastUpdate)} accent="slate" />
    </div>
  );
}