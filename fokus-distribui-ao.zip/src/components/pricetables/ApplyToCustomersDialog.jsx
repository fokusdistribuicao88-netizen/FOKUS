import React, { useMemo, useState } from 'react';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { useAuth } from '@/lib/AuthContext';
import { useToast } from '@/components/ui/use-toast';
import { logActivity } from '@/lib/activityLog';
import { Search, Loader2, CheckSquare, Square } from 'lucide-react';
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';

export default function ApplyToCustomersDialog({ open, onClose, table, onDone }) {
  const queryClient = useQueryClient();
  const { user } = useAuth();
  const { toast } = useToast();
  const [search, setSearch] = useState('');
  const [selected, setSelected] = useState(new Set());
  const [busy, setBusy] = useState(false);

  const { data: customers = [], isLoading } = useQuery({
    queryKey: ['customers'],
    queryFn: () => base44.entities.Customer.list(),
    staleTime: 60 * 1000,
    enabled: open,
  });

  const filtered = useMemo(() => {
    const q = search.toLowerCase().trim();
    if (!q) return customers;
    return customers.filter((c) => c.name?.toLowerCase().includes(q) || c.cpf_cnpj?.toLowerCase().includes(q) || c.email?.toLowerCase().includes(q));
  }, [customers, search]);

  const toggle = (id) => setSelected((prev) => {
    const n = new Set(prev); n.has(id) ? n.delete(id) : n.add(id); return n;
  });
  const selectAll = () => setSelected(new Set(filtered.map((c) => c.id)));

  const apply = async () => {
    setBusy(true);
    try {
      const ids = [...selected];
      await Promise.all(ids.map((id) => base44.entities.Customer.update(id, { price_table_id: table.id, price_table_name: table.name })));
      await base44.entities.PriceTable.update(table.id, {
        customers_count: customers.filter((c) => c.price_table_id === table.id || ids.includes(c.id)).length,
        last_updated_by: user?.full_name || user?.email || '',
      });
      await logActivity({ action: 'price_table_apply_customers', description: `${ids.length} cliente(s) vinculados à tabela ${table.name}`, user, entityType: 'PriceTable', entityId: table.id });
      queryClient.invalidateQueries({ queryKey: ['customers'] });
      queryClient.invalidateQueries({ queryKey: ['price-tables'] });
      toast({ title: 'Tabela aplicada', description: `${ids.length} cliente(s) agora usam "${table.name}".` });
      onDone?.();
      onClose();
      setSelected(new Set());
    } catch (e) {
      toast({ title: 'Erro', description: e.message, variant: 'destructive' });
    } finally {
      setBusy(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={(o) => !o && onClose()}>
      <DialogContent className="sm:max-w-lg">
        <DialogHeader>
          <DialogTitle>Aplicar tabela aos clientes</DialogTitle>
          <DialogDescription>Vincule clientes à tabela "{table?.name}".</DialogDescription>
        </DialogHeader>
        <div className="space-y-3">
          <div className="relative">
            <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
            <Input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Buscar cliente..." className="pl-9" />
          </div>
          <div className="flex items-center justify-between">
            <Button variant="ghost" size="sm" onClick={selectAll}>Selecionar todos ({filtered.length})</Button>
            <span className="text-xs text-muted-foreground">{selected.size} selecionado(s)</span>
          </div>
          <div className="max-h-72 overflow-y-auto border border-border rounded-lg">
            {isLoading ? (
              <div className="text-center py-6"><Loader2 className="w-5 h-5 animate-spin mx-auto" /></div>
            ) : filtered.length === 0 ? (
              <p className="text-center py-6 text-sm text-muted-foreground">Nenhum cliente.</p>
            ) : filtered.map((c) => (
              <div key={c.id} className="flex items-center gap-2 px-3 py-2 border-b border-border hover:bg-muted/30">
                <button onClick={() => toggle(c.id)}>
                  {selected.has(c.id) ? <CheckSquare className="w-4 h-4 text-blue-600" /> : <Square className="w-4 h-4 text-muted-foreground" />}
                </button>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium truncate">{c.name}</p>
                  <p className="text-xs text-muted-foreground">{c.cpf_cnpj || c.email || '—'}</p>
                </div>
                {c.price_table_id === table?.id && <Badge className="bg-violet-100 text-violet-700 text-[10px]">já vinculado</Badge>}
              </div>
            ))}
          </div>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={onClose}>Cancelar</Button>
          <Button onClick={apply} disabled={busy || selected.size === 0}>
            {busy && <Loader2 className="w-4 h-4 animate-spin mr-1" />} Vincular ({selected.size})
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}