import React, { useEffect, useState } from 'react';
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from '@/components/ui/select';
import { Switch } from '@/components/ui/switch';
import { Loader2 } from 'lucide-react';

const empty = {
  name: '', code: '', description: '', status: 'active', is_default: false,
  start_date: '', end_date: '', notes: '',
};

export default function PriceTableFormDialog({ open, onClose, onSubmit, initial, saving }) {
  const [form, setForm] = useState(empty);

  useEffect(() => {
    if (open) setForm(initial ? { ...empty, ...initial } : empty);
  }, [open, initial]);

  const set = (k, v) => setForm((f) => ({ ...f, [k]: v }));

  const submit = (e) => {
    e.preventDefault();
    if (!form.name?.trim() || !form.code?.trim()) return;
    onSubmit({
      ...form,
      name: form.name.trim(),
      code: form.code.trim(),
      is_default: !!form.is_default,
    });
  };

  return (
    <Dialog open={open} onOpenChange={(o) => !o && onClose()}>
      <DialogContent className="sm:max-w-lg">
        <DialogHeader>
          <DialogTitle>{initial?.id ? 'Editar tabela de preços' : 'Nova tabela de preços'}</DialogTitle>
          <DialogDescription>
            {initial?.id ? 'Altere as informações da tabela.' : 'Preencha as informações para criar uma nova tabela.'}
          </DialogDescription>
        </DialogHeader>
        <form onSubmit={submit} className="space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div className="space-y-1.5">
              <Label>Nome *</Label>
              <Input value={form.name} onChange={(e) => set('name', e.target.value)} required autoFocus />
            </div>
            <div className="space-y-1.5">
              <Label>Código *</Label>
              <Input value={form.code} onChange={(e) => set('code', e.target.value)} required />
            </div>
          </div>
          <div className="space-y-1.5">
            <Label>Descrição</Label>
            <Textarea value={form.description} onChange={(e) => set('description', e.target.value)} rows={2} />
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div className="space-y-1.5">
              <Label>Status</Label>
              <Select value={form.status} onValueChange={(v) => set('status', v)}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="active">Ativa</SelectItem>
                  <SelectItem value="inactive">Inativa</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-1.5">
              <Label>Início de vigência</Label>
              <Input type="date" value={form.start_date || ''} onChange={(e) => set('start_date', e.target.value)} />
            </div>
            <div className="space-y-1.5">
              <Label>Término (opcional)</Label>
              <Input type="date" value={form.end_date || ''} onChange={(e) => set('end_date', e.target.value)} />
            </div>
          </div>
          <div className="flex items-center gap-3 rounded-lg border border-border p-3">
            <Switch checked={form.is_default} onCheckedChange={(v) => set('is_default', v)} />
            <div>
              <p className="text-sm font-medium">Tabela padrão</p>
              <p className="text-xs text-muted-foreground">Usada quando o cliente não possui tabela vinculada.</p>
            </div>
          </div>
          <div className="space-y-1.5">
            <Label>Observações</Label>
            <Textarea value={form.notes} onChange={(e) => set('notes', e.target.value)} rows={2} />
          </div>
          <DialogFooter>
            <Button type="button" variant="outline" onClick={onClose}>Cancelar</Button>
            <Button type="submit" disabled={saving}>
              {saving && <Loader2 className="w-4 h-4 animate-spin mr-1" />}
              {initial?.id ? 'Salvar' : 'Criar tabela'}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}