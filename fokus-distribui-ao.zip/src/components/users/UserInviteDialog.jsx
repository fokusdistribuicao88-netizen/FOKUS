import React, { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Loader2, Mail } from 'lucide-react';

const CARGOS = [
  { key: 'admin', label: 'Administrador' },
  { key: 'gerente', label: 'Gerente' },
  { key: 'financeiro', label: 'Financeiro' },
  { key: 'vendedor', label: 'Vendedor' },
  { key: 'estoquista', label: 'Estoquista' },
  { key: 'motorista', label: 'Motorista' },
  { key: 'auxiliar', label: 'Auxiliar de Entrega' },
];

export default function UserInviteDialog({ open, onClose, onInvite, inviting }) {
  const [email, setEmail] = useState('');
  const [cargo, setCargo] = useState('vendedor');

  useEffect(() => { if (open) { setEmail(''); setCargo('vendedor'); } }, [open]);

  const handleSubmit = () => {
    if (!email.trim()) return;
    const selected = CARGOS.find((c) => c.key === cargo) || CARGOS[6];
    const platformRole = ['admin', 'gerente', 'motorista', 'auxiliar'].includes(cargo) ? cargo : 'user';
    onInvite({ email: email.trim(), role: platformRole, cargoLabel: selected.label });
  };

  return (
    <Dialog open={open} onOpenChange={(o) => !o && onClose()}>
      <DialogContent className="max-w-md">
        <DialogHeader><DialogTitle>Novo Usuário</DialogTitle></DialogHeader>
        <div className="grid gap-4 py-2">
          <div className="flex items-center gap-2 text-sm text-muted-foreground bg-muted/40 rounded-lg px-3 py-2">
            <Mail className="w-4 h-4" /> O usuário receberá um convite por e-mail para se cadastrar.
          </div>
          <div className="grid gap-2">
            <Label htmlFor="u-email">E-mail *</Label>
            <Input id="u-email" type="email" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="exemplo@empresa.com" />
          </div>
          <div className="grid gap-2">
            <Label>Cargo</Label>
            <Select value={cargo} onValueChange={setCargo}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>{CARGOS.map((c) => <SelectItem key={c.key} value={c.key}>{c.label}</SelectItem>)}</SelectContent>
            </Select>
          </div>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={onClose}>Cancelar</Button>
          <Button onClick={handleSubmit} disabled={!email.trim() || inviting}>
            {inviting ? <Loader2 className="w-4 h-4 animate-spin mr-1" /> : <Mail className="w-4 h-4 mr-1" />} Enviar convite
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}