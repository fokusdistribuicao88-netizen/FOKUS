import React, { useState, useMemo } from 'react';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { useAuth } from '@/lib/AuthContext';
import { useToast } from '@/components/ui/use-toast';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Badge } from '@/components/ui/badge';
import { Loader2, UserPlus, Pencil, Trash2, Download, Search } from 'lucide-react';
import CustomerFormDialog from './CustomerFormDialog';
import { logActivity } from '@/lib/activityLog';

const fmtMoney = (v) => (Number(v) || 0).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });

export default function ClientsTab({ currentUser }) {
  const queryClient = useQueryClient();
  const { user } = useAuth();
  const { toast } = useToast();
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [formOpen, setFormOpen] = useState(false);
  const [editing, setEditing] = useState(null);
  const [saving, setSaving] = useState(false);
  const [deleteId, setDeleteId] = useState(null);

  const { data: customers = [], isLoading } = useQuery({ queryKey: ['customers'], queryFn: () => base44.entities.Customer.list(), staleTime: 30000 });

  const filtered = useMemo(() => {
    const q = search.toLowerCase().trim();
    let list = customers;
    if (q) list = list.filter((c) => (c.name || '').toLowerCase().includes(q) || (c.email || '').toLowerCase().includes(q) || (c.cpf_cnpj || '').includes(q));
    if (statusFilter !== 'all') list = list.filter((c) => (c.status || 'active') === statusFilter);
    return [...list].sort((a, b) => (a.name || '').localeCompare(b.name || '', 'pt-BR'));
  }, [customers, search, statusFilter]);

  const handleSave = async (payload) => {
    setSaving(true);
    try {
      if (editing) {
        await base44.entities.Customer.update(editing.id, payload);
        logActivity({ action: 'customer_update', description: `Cliente "${payload.name}" editado`, user, entityType: 'Customer', entityId: editing.id });
      } else {
        const created = await base44.entities.Customer.create(payload);
        logActivity({ action: 'customer_create', description: `Cliente "${payload.name}" cadastrado`, user, entityType: 'Customer', entityId: created?.id });
      }
      queryClient.invalidateQueries({ queryKey: ['customers'] });
      toast({ title: editing ? 'Cliente atualizado' : 'Cliente cadastrado' });
      setFormOpen(false); setEditing(null);
    } catch (e) {
      toast({ title: 'Erro', description: e.message, variant: 'destructive' });
    } finally { setSaving(false); }
  };

  const handleToggle = async (c) => {
    const next = c.status === 'inactive' ? 'active' : 'inactive';
    try {
      await base44.entities.Customer.update(c.id, { status: next });
      logActivity({ action: 'customer_toggle', description: `Cliente "${c.name}" ${next === 'active' ? 'ativado' : 'desativado'}`, user, entityType: 'Customer', entityId: c.id });
      queryClient.invalidateQueries({ queryKey: ['customers'] });
    } catch (e) { toast({ title: 'Erro', description: e.message, variant: 'destructive' }); }
  };

  const handleDelete = async () => {
    const c = customers.find((x) => x.id === deleteId);
    try {
      await base44.entities.Customer.delete(deleteId);
      logActivity({ action: 'customer_delete', description: `Cliente "${c?.name}" excluído`, user, entityType: 'Customer', entityId: deleteId });
      queryClient.invalidateQueries({ queryKey: ['customers'] });
      toast({ title: 'Cliente excluído' });
    } catch (e) { toast({ title: 'Erro', description: e.message, variant: 'destructive' }); }
    finally { setDeleteId(null); }
  };

  const exportCSV = () => {
    const headers = ['Nome', 'CPF/CNPJ', 'Empresa', 'Email', 'Telefone', 'Cidade', 'Estado', 'Status'];
    const rows = filtered.map((c) => [c.name || '', c.cpf_cnpj || '', c.company || '', c.email || '', c.phone || '', c.city || '', c.state || '', c.status || 'active']);
    const csv = [headers, ...rows].map((r) => r.map((x) => `"${String(x).replace(/"/g, '""')}"`).join(',')).join('\n');
    const blob = new Blob(['\ufeff' + csv], { type: 'text/csv;charset=utf-8;' });
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = 'clientes.csv';
    a.click();
    URL.revokeObjectURL(a.href);
  };

  return (
    <div className="space-y-4">
      <div className="flex flex-col sm:flex-row gap-3 items-stretch sm:items-center">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Buscar cliente..." className="pl-9" />
        </div>
        <Select value={statusFilter} onValueChange={setStatusFilter}>
          <SelectTrigger className="w-36"><SelectValue placeholder="Status" /></SelectTrigger>
          <SelectContent><SelectItem value="all">Todos status</SelectItem><SelectItem value="active">Ativos</SelectItem><SelectItem value="inactive">Inativos</SelectItem></SelectContent>
        </Select>
      </div>

      <div className="flex gap-2 flex-wrap">
        <Button onClick={() => { setEditing(null); setFormOpen(true); }} className="gap-2"><UserPlus className="w-4 h-4" /> Novo Cliente</Button>
        <Button variant="outline" onClick={exportCSV} className="gap-2"><Download className="w-4 h-4" /> Exportar Lista</Button>
      </div>

      {isLoading ? (
        <div className="flex justify-center py-12"><Loader2 className="w-8 h-8 animate-spin text-blue-600" /></div>
      ) : (
        <div className="overflow-x-auto bg-card rounded-xl border border-border">
          <table className="w-full text-sm">
            <thead className="bg-muted/50 text-muted-foreground text-xs uppercase">
              <tr>
                <th className="text-left px-4 py-3">Nome</th>
                <th className="text-left px-4 py-3">CPF/CNPJ</th>
                <th className="text-left px-4 py-3">Empresa</th>
                <th className="text-left px-4 py-3">Cidade/UF</th>
                <th className="text-left px-4 py-3">Limite</th>
                <th className="text-left px-4 py-3">Status</th>
                <th className="text-right px-4 py-3">Ações</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-border">
              {filtered.map((c) => (
                <tr key={c.id} className="hover:bg-accent/40">
                  <td className="px-4 py-3"><div className="font-medium text-foreground">{c.name}</div><div className="text-xs text-muted-foreground">{c.email || c.phone || ''}</div></td>
                  <td className="px-4 py-3 text-muted-foreground">{c.cpf_cnpj || '—'}</td>
                  <td className="px-4 py-3 text-muted-foreground">{c.company || '—'}</td>
                  <td className="px-4 py-3 text-muted-foreground">{[c.city, c.state].filter(Boolean).join(' - ') || '—'}</td>
                  <td className="px-4 py-3 text-muted-foreground">{c.credit_limit ? fmtMoney(c.credit_limit) : '—'}</td>
                  <td className="px-4 py-3"><Badge variant={c.status === 'inactive' ? 'secondary' : 'default'} className={c.status === 'active' ? 'bg-green-100 text-green-700' : ''}>{(c.status || 'active') === 'active' ? 'Ativo' : 'Inativo'}</Badge></td>
                  <td className="px-4 py-3">
                    <div className="flex justify-end gap-1">
                      <Button size="icon" variant="ghost" onClick={() => { setEditing(c); setFormOpen(true); }}><Pencil className="w-4 h-4" /></Button>
                      <Button size="icon" variant="ghost" onClick={() => handleToggle(c)} title="Ativar/Desativar"><UserPlus className="w-4 h-4" /></Button>
                      <Button size="icon" variant="ghost" onClick={() => setDeleteId(c.id)}><Trash2 className="w-4 h-4 text-red-500" /></Button>
                    </div>
                  </td>
                </tr>
              ))}
              {filtered.length === 0 && <tr><td colSpan={7} className="text-center py-8 text-muted-foreground">Nenhum cliente encontrado.</td></tr>}
            </tbody>
          </table>
        </div>
      )}

      <CustomerFormDialog open={formOpen} onClose={() => { setFormOpen(false); setEditing(null); }} onSave={handleSave} saving={saving} existing={editing} />
      <Dialog open={!!deleteId} onOpenChange={(o) => !o && setDeleteId(null)}>
        <DialogContent className="max-w-sm">
          <DialogHeader><DialogTitle>Excluir cliente?</DialogTitle></DialogHeader>
          <p className="text-sm text-muted-foreground">Esta ação não pode ser desfeita.</p>
          <DialogFooter><Button variant="outline" onClick={() => setDeleteId(null)}>Cancelar</Button><Button variant="destructive" onClick={handleDelete}>Excluir</Button></DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}