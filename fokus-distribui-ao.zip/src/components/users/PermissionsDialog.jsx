import React, { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Checkbox } from '@/components/ui/checkbox';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Loader2, ShieldCheck, Truck } from 'lucide-react';
import { CARGO_LABELS, cargoLabelToRole, LOGISTICS_PERMISSIONS, getDefaultLogisticsPerms } from '@/lib/userRoles';
import { POS_PERMISSIONS, getDefaultPosPerms } from '@/lib/posPermissions';

const CARGOS = [...CARGO_LABELS, 'Personalizado'];
const AREAS = {
  Dashboard: ['Visualizar', 'Gerar Relatórios', 'Criar Promoções', 'Criar Usuários'],
  Produtos: ['Visualizar', 'Cadastrar', 'Editar', 'Excluir', 'Alterar preços'],
  'Catálogo': ['Visualizar', 'Editar'],
  Pedidos: ['Visualizar', 'Criar', 'Editar', 'Cancelar', 'Excluir'],
  Promoções: ['Criar', 'Editar', 'Excluir', 'Ativar', 'Encerrar'],
  Clientes: ['Visualizar', 'Cadastrar', 'Editar', 'Excluir'],
  Financeiro: ['Visualizar', 'Editar', 'Exportar relatórios'],
  Configurações: ['Visualizar', 'Editar'],
  'Logística': LOGISTICS_PERMISSIONS,
  'PDV': POS_PERMISSIONS,
};

export default function PermissionsDialog({ open, onClose, targetUser, currentEmail, permission, onSave, saving }) {
  const [fullName, setFullName] = useState('');
  const [cargo, setCargo] = useState('Vendedor');
  const [customCargo, setCustomCargo] = useState('');
  const [fullAccess, setFullAccess] = useState(false);
  const [perms, setPerms] = useState({});

  useEffect(() => {
    if (!open) return;
    let p = {};
    try { p = JSON.parse(permission?.permissions || '{}'); } catch { p = {}; }
    setPerms(p);
    setFullAccess(!!p.__full__);
    setFullName(targetUser?.full_name || '');
    const c = permission?.cargo || 'Vendedor';
    setCargo(CARGOS.includes(c) ? c : 'Personalizado');
    setCustomCargo(CARGOS.includes(c) ? '' : c);
  }, [open, permission, targetUser]);

  const toggle = (area, action) => setPerms((prev) => {
    const arr = prev[area] || [];
    return { ...prev, [area]: arr.includes(action) ? arr.filter((a) => a !== action) : [...arr, action] };
  });
  const toggleAll = (area, on) => setPerms((prev) => ({ ...prev, [area]: on ? AREAS[area] : [] }));

  const handleCargoChange = (newCargo) => {
    setCargo(newCargo);
    if (!fullAccess) {
      const role = cargoLabelToRole(newCargo);
      const logistics = getDefaultLogisticsPerms(newCargo);
      const pdv = getDefaultPosPerms(role);
      setPerms((prev) => ({ ...prev, 'Logística': logistics, 'PDV': pdv }));
    }
  };

  const isSelf = targetUser?.email === currentEmail;

  const handleSave = () => {
    const finalCargo = cargo === 'Personalizado' ? (customCargo || 'Personalizado') : cargo;
    const { __full__, ...rest } = perms;
    const finalPerms = fullAccess ? { __full__: true } : rest;
    onSave({ fullName: fullName.trim(), cargo: finalCargo, permissions: JSON.stringify(finalPerms), status: permission?.status || 'active' });
  };

  return (
    <Dialog open={open} onOpenChange={(o) => !o && onClose()}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader><DialogTitle>Permissões — {targetUser?.full_name || targetUser?.email}</DialogTitle></DialogHeader>
        <div className="grid gap-4 py-2">
          <div className="grid gap-2">
            <Label>Nome</Label>
            <Input value={fullName} onChange={(e) => setFullName(e.target.value)} placeholder="Nome do usuário" />
          </div>
          <div className="grid sm:grid-cols-2 gap-3">
            <div className="grid gap-2">
              <Label>Cargo</Label>
              <Select value={cargo} onValueChange={handleCargoChange}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>{CARGOS.map((c) => <SelectItem key={c} value={c}>{c}</SelectItem>)}</SelectContent>
              </Select>
            </div>
            {cargo === 'Personalizado' && <div className="grid gap-2"><Label>Cargo personalizado</Label><Input value={customCargo} onChange={(e) => setCustomCargo(e.target.value)} /></div>}
          </div>
          <label className={`flex items-center gap-2 p-3 rounded-lg border border-border bg-muted/40 ${isSelf ? 'opacity-70' : 'cursor-pointer'}`}>
            <Checkbox checked={fullAccess} onCheckedChange={(v) => setFullAccess(!!v)} disabled={isSelf} />
            <span className="text-sm font-medium flex items-center gap-1"><ShieldCheck className="w-4 h-4 text-blue-600" /> Administração Geral (acesso total)</span>
            {isSelf && <span className="text-xs text-amber-600 ml-auto">Você não pode remover seu próprio acesso</span>}
          </label>
          {!fullAccess && (
            <div className="space-y-3">
              {Object.entries(AREAS).map(([area, actions]) => (
                <div key={area} className={`rounded-lg border p-3 ${area === 'Logística' ? 'border-orange-300 dark:border-orange-900 bg-orange-50/50 dark:bg-orange-950/20' : 'border-border'}`}>
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-sm font-semibold flex items-center gap-1.5">
                      {area === 'Logística' && <Truck className="w-4 h-4 text-orange-500" />}
                      {area === 'Logística' ? 'Logística de Entregas' : area}
                    </span>
                    <div className="flex gap-1">
                      <Button size="sm" variant="ghost" className="h-7 text-xs" onClick={() => toggleAll(area, true)}>Todos</Button>
                      <Button size="sm" variant="ghost" className="h-7 text-xs" onClick={() => toggleAll(area, false)}>Nenhum</Button>
                    </div>
                  </div>
                  <div className="flex flex-wrap gap-2">
                    {actions.map((a) => {
                      const checked = (perms[area] || []).includes(a);
                      return (
                        <label key={a} className="flex items-center gap-1.5 text-xs cursor-pointer px-2 py-1 rounded-md border border-border hover:bg-accent">
                          <Checkbox checked={checked} onCheckedChange={() => toggle(area, a)} /> {a}
                        </label>
                      );
                    })}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={onClose}>Cancelar</Button>
          <Button onClick={handleSave} disabled={saving}>{saving ? <Loader2 className="w-4 h-4 animate-spin mr-1" /> : null}Salvar permissões</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}