import React, { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Loader2 } from 'lucide-react';

export default function CustomerFormDialog({ open, onClose, onSave, saving, existing = null }) {
  const [form, setForm] = useState({
    name: '', cpf_cnpj: '', company: '', email: '', phone: '', address: '', city: '', state: '', zip_code: '', notes: '', credit_limit: '', status: 'active',
  });

  useEffect(() => {
    if (!open) return;
    if (existing) setForm({ name: existing.name || '', cpf_cnpj: existing.cpf_cnpj || '', company: existing.company || '', email: existing.email || '', phone: existing.phone || '', address: existing.address || '', city: existing.city || '', state: existing.state || '', zip_code: existing.zip_code || '', notes: existing.notes || '', credit_limit: existing.credit_limit ?? '', status: existing.status || 'active' });
    else setForm({ name: '', cpf_cnpj: '', company: '', email: '', phone: '', address: '', city: '', state: '', zip_code: '', notes: '', credit_limit: '', status: 'active' });
  }, [open, existing]);

  const set = (k, v) => setForm((f) => ({ ...f, [k]: v }));

  const handleSubmit = () => {
    if (!form.name.trim()) return;
    onSave({ ...form, credit_limit: form.credit_limit === '' ? null : Number(form.credit_limit) });
  };

  return (
    <Dialog open={open} onOpenChange={(o) => !o && onClose()}>
      <DialogContent className="max-w-xl max-h-[90vh] overflow-y-auto">
        <DialogHeader><DialogTitle>{existing ? 'Editar cliente' : 'Novo cliente'}</DialogTitle></DialogHeader>
        <div className="grid sm:grid-cols-2 gap-3 py-2">
          <div className="grid gap-2 sm:col-span-2"><Label>Nome *</Label><Input value={form.name} onChange={(e) => set('name', e.target.value)} /></div>
          <div className="grid gap-2"><Label>CPF/CNPJ</Label><Input value={form.cpf_cnpj} onChange={(e) => set('cpf_cnpj', e.target.value)} /></div>
          <div className="grid gap-2"><Label>Empresa</Label><Input value={form.company} onChange={(e) => set('company', e.target.value)} /></div>
          <div className="grid gap-2"><Label>E-mail</Label><Input type="email" value={form.email} onChange={(e) => set('email', e.target.value)} /></div>
          <div className="grid gap-2"><Label>Telefone</Label><Input value={form.phone} onChange={(e) => set('phone', e.target.value)} /></div>
          <div className="grid gap-2 sm:col-span-2"><Label>Endereço</Label><Input value={form.address} onChange={(e) => set('address', e.target.value)} /></div>
          <div className="grid gap-2"><Label>Cidade</Label><Input value={form.city} onChange={(e) => set('city', e.target.value)} /></div>
          <div className="grid gap-2"><Label>Estado (UF)</Label><Input value={form.state} maxLength={2} onChange={(e) => set('state', e.target.value.toUpperCase())} /></div>
          <div className="grid gap-2"><Label>CEP</Label><Input value={form.zip_code} onChange={(e) => set('zip_code', e.target.value)} /></div>
          <div className="grid gap-2"><Label>Limite de crédito (R$)</Label><Input type="number" step="0.01" value={form.credit_limit} onChange={(e) => set('credit_limit', e.target.value)} /></div>
          <div className="grid gap-2"><Label>Status</Label>
            <Select value={form.status} onValueChange={(v) => set('status', v)}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent><SelectItem value="active">Ativo</SelectItem><SelectItem value="inactive">Inativo</SelectItem></SelectContent>
            </Select>
          </div>
          <div className="grid gap-2 sm:col-span-2"><Label>Observações</Label><Textarea rows={2} value={form.notes} onChange={(e) => set('notes', e.target.value)} /></div>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={onClose}>Cancelar</Button>
          <Button onClick={handleSubmit} disabled={!form.name.trim() || saving}>
            {saving ? <Loader2 className="w-4 h-4 animate-spin mr-1" /> : null}{existing ? 'Salvar' : 'Cadastrar'}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}