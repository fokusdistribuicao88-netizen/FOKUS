import React, { useMemo, useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Loader2, Search, LogIn, LogOut, UserPlus, Shield, Pencil, Trash2 } from 'lucide-react';

const ACTION_META = {
  login: { label: 'Login', icon: LogIn, color: 'text-blue-600' },
  logout: { label: 'Logout', icon: LogOut, color: 'text-slate-500' },
  user_create: { label: 'Criação de usuário', icon: UserPlus, color: 'text-green-600' },
  user_delete: { label: 'Exclusão de usuário', icon: Trash2, color: 'text-red-600' },
  permission_change: { label: 'Alteração de permissões', icon: Shield, color: 'text-violet-600' },
  customer_create: { label: 'Cadastro de cliente', icon: Pencil, color: 'text-green-600' },
  customer_update: { label: 'Edição de cliente', icon: Pencil, color: 'text-blue-600' },
  customer_delete: { label: 'Exclusão de cliente', icon: Trash2, color: 'text-red-600' },
  report_generate: { label: 'Geração de relatório', icon: Shield, color: 'text-violet-600' },
};

export default function ActivityTab() {
  const [search, setSearch] = useState('');
  const [actionFilter, setActionFilter] = useState('all');

  const { data: logs = [], isLoading } = useQuery({ queryKey: ['activity-logs'], queryFn: () => base44.entities.ActivityLog.list('-created_date', 200), staleTime: 30000 });

  const filtered = useMemo(() => {
    const q = search.toLowerCase().trim();
    let list = logs;
    if (q) list = list.filter((l) => (l.description || '').toLowerCase().includes(q) || (l.user_name || l.user_email || '').toLowerCase().includes(q));
    if (actionFilter !== 'all') list = list.filter((l) => l.action === actionFilter);
    return list;
  }, [logs, search, actionFilter]);

  const actionTypes = useMemo(() => [...new Set(logs.map((l) => l.action))], [logs]);

  return (
    <div className="space-y-4">
      <div className="flex flex-col sm:flex-row gap-3 items-stretch sm:items-center">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Buscar no histórico..." className="pl-9" />
        </div>
        <Select value={actionFilter} onValueChange={setActionFilter}>
          <SelectTrigger className="w-56"><SelectValue placeholder="Filtrar ação" /></SelectTrigger>
          <SelectContent><SelectItem value="all">Todas as ações</SelectItem>{actionTypes.map((a) => <SelectItem key={a} value={a}>{ACTION_META[a]?.label || a}</SelectItem>)}</SelectContent>
        </Select>
      </div>

      {isLoading ? (
        <div className="flex justify-center py-12"><Loader2 className="w-8 h-8 animate-spin text-blue-600" /></div>
      ) : filtered.length === 0 ? (
        <div className="text-center py-12 text-muted-foreground">Nenhuma atividade registrada.</div>
      ) : (
        <div className="space-y-2">
          {filtered.map((l) => {
            const meta = ACTION_META[l.action] || { label: l.action, icon: Shield, color: 'text-slate-500' };
            const Icon = meta.icon;
            return (
              <div key={l.id} className="flex items-start gap-3 bg-card border border-border rounded-lg p-3">
                <div className={`w-8 h-8 rounded-lg bg-muted/60 flex items-center justify-center flex-shrink-0 ${meta.color}`}><Icon className="w-4 h-4" /></div>
                <div className="min-w-0 flex-1">
                  <div className="flex items-center gap-2 flex-wrap">
                    <span className="text-sm font-medium text-foreground">{meta.label}</span>
                    <span className="text-xs text-muted-foreground">{l.user_name || l.user_email || '—'}</span>
                  </div>
                  <p className="text-sm text-muted-foreground line-clamp-2">{l.description || '—'}</p>
                </div>
                <div className="text-xs text-muted-foreground text-right flex-shrink-0">
                  {l.created_date ? new Date(l.created_date).toLocaleDateString('pt-BR') : '—'}<br />
                  {l.created_date ? new Date(l.created_date).toLocaleTimeString('pt-BR') : ''}
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}