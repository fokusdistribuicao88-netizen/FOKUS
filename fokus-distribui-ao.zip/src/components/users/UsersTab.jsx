import React, { useState, useMemo } from 'react';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { useAuth } from '@/lib/AuthContext';
import { useToast } from '@/components/ui/use-toast';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Badge } from '@/components/ui/badge';
import { Loader2, UserPlus, Shield, Trash2, Download, Search, Truck } from 'lucide-react';
import UserInviteDialog from './UserInviteDialog';
import PermissionsDialog from './PermissionsDialog';
import { logActivity } from '@/lib/activityLog';
import { cargoLabelToRole, hasLogisticsAccess, accessTypeLabel } from '@/lib/userRoles';

const roleToCargo = (role) => role === 'admin' ? 'Administrador' : role === 'gerente' ? 'Gerente' : role === 'motorista' ? 'Motorista' : role === 'auxiliar' ? 'Auxiliar de Entrega' : role || 'Usuário';

export default function UsersTab({ currentUser }) {
  const queryClient = useQueryClient();
  const { user } = useAuth();
  const { toast } = useToast();
  const [search, setSearch] = useState('');
  const [cargoFilter, setCargoFilter] = useState('all');
  const [logisticsFilter, setLogisticsFilter] = useState('all');
  const [statusFilter, setStatusFilter] = useState('all');
  const [sortBy, setSortBy] = useState('name');
  const [inviteOpen, setInviteOpen] = useState(false);
  const [permUser, setPermUser] = useState(null);
  const [deleteUser, setDeleteUser] = useState(null);
  const [inviting, setInviting] = useState(false);
  const [savingPerm, setSavingPerm] = useState(false);

  const { data: users = [], isLoading } = useQuery({ queryKey: ['users'], queryFn: () => base44.entities.User.list(), staleTime: 30000 });
  const { data: perms = [] } = useQuery({ queryKey: ['user-permissions'], queryFn: () => base44.entities.UserPermission.list(), staleTime: 30000 });

  const permMap = useMemo(() => Object.fromEntries(perms.map((p) => [p.user_id, p])), [perms]);

  const rows = useMemo(() => {
    const q = search.toLowerCase().trim();
    let list = users.map((u) => {
      const perm = permMap[u.id];
      const cargo = perm?.cargo || roleToCargo(u.role);
      const status = perm?.status || 'active';
      return { ...u, cargo, status, perm, accessType: accessTypeLabel(u.role), hasLogistics: hasLogisticsAccess(u.role) };
    });
    if (q) list = list.filter((u) => (u.full_name || u.email || '').toLowerCase().includes(q));
    if (cargoFilter !== 'all') list = list.filter((u) => u.cargo === cargoFilter);
    if (logisticsFilter === 'logistics') list = list.filter((u) => u.hasLogistics);
    else if (logisticsFilter === 'motorista') list = list.filter((u) => u.role === 'motorista');
    else if (logisticsFilter === 'auxiliar') list = list.filter((u) => u.role === 'auxiliar');
    else if (logisticsFilter === 'gerente') list = list.filter((u) => u.role === 'gerente');
    if (statusFilter !== 'all') list = list.filter((u) => u.status === statusFilter);
    list.sort((a, b) => {
      if (sortBy === 'cargo') return a.cargo.localeCompare(b.cargo, 'pt-BR');
      if (sortBy === 'data') return new Date(b.created_date || 0).getTime() - new Date(a.created_date || 0).getTime();
      if (sortBy === 'acesso') return 0;
      return (a.full_name || a.email || '').localeCompare(b.full_name || b.email || '', 'pt-BR');
    });
    return list;
  }, [users, permMap, search, cargoFilter, logisticsFilter, statusFilter, sortBy]);

  const cargos = useMemo(() => [...new Set(users.map((u) => permMap[u.id]?.cargo || roleToCargo(u.role)))], [users, permMap]);

  const handleInvite = async ({ email, role, cargoLabel }) => {
    setInviting(true);
    try {
      await base44.users.inviteUser(email, role);
      logActivity({ action: 'user_create', description: `Convite enviado para ${email} (${cargoLabel})`, user, entityType: 'User' });
      toast({ title: 'Convite enviado', description: `${email} receberá um e-mail para se cadastrar.` });
      setInviteOpen(false);
      queryClient.invalidateQueries({ queryKey: ['users'] });
    } catch (e) {
      toast({ title: 'Erro ao convidar', description: e.message, variant: 'destructive' });
    } finally { setInviting(false); }
  };

  const handleSavePerm = async (data) => {
    setSavingPerm(true);
    try {
      const existing = permMap[permUser.id];
      // Sync the User entity role so RLS and logistics access reflect the new cargo immediately
      const newRole = cargoLabelToRole(data.cargo);
      const nameChanged = data.fullName && data.fullName !== (permUser.full_name || '');
      const roleChanged = newRole !== permUser.role;
      if (nameChanged || roleChanged) {
        const updatePayload = {};
        if (nameChanged) updatePayload.full_name = data.fullName;
        if (roleChanged) updatePayload.role = newRole;
        await base44.entities.User.update(permUser.id, updatePayload);
        if (nameChanged) logActivity({ action: 'user_update', description: `Nome de ${permUser.email} alterado para "${data.fullName}"`, user, entityType: 'User', entityId: permUser.id, metadata: `full_name: ${data.fullName}` });
        if (roleChanged) logActivity({ action: 'permission_change', description: `Cargo de ${permUser.email} alterado para ${data.cargo}`, user, entityType: 'User', entityId: permUser.id, metadata: `role: ${newRole}` });
      }
      if (existing) {
        await base44.entities.UserPermission.update(existing.id, { cargo: data.cargo, permissions: data.permissions, status: data.status });
      } else {
        await base44.entities.UserPermission.create({ user_id: permUser.id, user_email: permUser.email, cargo: data.cargo, permissions: data.permissions, status: data.status });
      }
      logActivity({ action: 'permission_change', description: `Permissões de ${permUser.email} atualizadas (${data.cargo})`, user, entityType: 'UserPermission', entityId: permUser.id });
      toast({ title: 'Permissões salvas', description: 'As alterações entram em vigor imediatamente.' });
      queryClient.invalidateQueries({ queryKey: ['user-permissions'] });
      queryClient.invalidateQueries({ queryKey: ['users'] });
      setPermUser(null);
    } catch (e) {
      toast({ title: 'Erro', description: e.message, variant: 'destructive' });
    } finally { setSavingPerm(false); }
  };

  const handleDeleteUser = async () => {
    try {
      const perm = permMap[deleteUser.id];
      if (perm) await base44.entities.UserPermission.delete(perm.id);
      await base44.entities.User.delete(deleteUser.id);
      logActivity({ action: 'user_delete', description: `Usuário ${deleteUser.email} excluído`, user, entityType: 'User', entityId: deleteUser.id });
      toast({ title: 'Usuário excluído' });
      queryClient.invalidateQueries({ queryKey: ['users'] });
      queryClient.invalidateQueries({ queryKey: ['user-permissions'] });
    } catch (e) {
      toast({ title: 'Erro ao excluir', description: e.message, variant: 'destructive' });
    } finally { setDeleteUser(null); }
  };

  const exportCSV = () => {
    const headers = ['Nome', 'Email', 'Cargo', 'Status', 'Cadastro'];
    const rows = rows.map((u) => [u.full_name || '', u.email || '', u.cargo, u.status, u.created_date ? new Date(u.created_date).toLocaleDateString('pt-BR') : '']);
    const csv = [headers, ...rows].map((r) => r.map((c) => `"${String(c).replace(/"/g, '""')}"`).join(',')).join('\n');
    const blob = new Blob(['\ufeff' + csv], { type: 'text/csv;charset=utf-8;' });
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = 'usuarios.csv';
    a.click();
    URL.revokeObjectURL(a.href);
  };

  return (
    <div className="space-y-4">
      <div className="flex flex-col sm:flex-row gap-3 items-stretch sm:items-center">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Buscar usuário..." className="pl-9" />
        </div>
        <Select value={cargoFilter} onValueChange={setCargoFilter}>
          <SelectTrigger className="w-40"><SelectValue placeholder="Cargo" /></SelectTrigger>
          <SelectContent><SelectItem value="all">Todos os cargos</SelectItem>{cargos.map((c) => <SelectItem key={c} value={c}>{c}</SelectItem>)}</SelectContent>
        </Select>
        <Select value={logisticsFilter} onValueChange={setLogisticsFilter}>
          <SelectTrigger className="w-44"><SelectValue placeholder="Logística" /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">Todos os usuários</SelectItem>
            <SelectItem value="logistics">Com acesso à logística</SelectItem>
            <SelectItem value="motorista">Motoristas</SelectItem>
            <SelectItem value="auxiliar">Auxiliares</SelectItem>
            <SelectItem value="gerente">Gerentes</SelectItem>
          </SelectContent>
        </Select>
        <Select value={statusFilter} onValueChange={setStatusFilter}>
          <SelectTrigger className="w-36"><SelectValue placeholder="Status" /></SelectTrigger>
          <SelectContent><SelectItem value="all">Todos status</SelectItem><SelectItem value="active">Ativos</SelectItem><SelectItem value="inactive">Inativos</SelectItem></SelectContent>
        </Select>
        <Select value={sortBy} onValueChange={setSortBy}>
          <SelectTrigger className="w-40"><SelectValue placeholder="Ordenar" /></SelectTrigger>
          <SelectContent><SelectItem value="name">Nome</SelectItem><SelectItem value="cargo">Cargo</SelectItem><SelectItem value="data">Data</SelectItem><SelectItem value="acesso">Último acesso</SelectItem></SelectContent>
        </Select>
      </div>

      <div className="flex gap-2 flex-wrap">
        <Button onClick={() => setInviteOpen(true)} className="gap-2"><UserPlus className="w-4 h-4" /> Novo Usuário</Button>
        <Button variant="outline" onClick={exportCSV} className="gap-2"><Download className="w-4 h-4" /> Exportar Lista</Button>
      </div>

      {isLoading ? (
        <div className="flex justify-center py-12"><Loader2 className="w-8 h-8 animate-spin text-blue-600" /></div>
      ) : (
        <div className="overflow-x-auto bg-card rounded-xl border border-border">
          <table className="w-full text-sm">
            <thead className="bg-muted/50 text-muted-foreground text-xs uppercase">
              <tr>
                <th className="text-left px-4 py-3">Nome</th>
                <th className="text-left px-4 py-3">Cargo</th>
                <th className="text-left px-4 py-3">Tipo de acesso</th>
                <th className="text-left px-4 py-3">Logística</th>
                <th className="text-left px-4 py-3">Status</th>
                <th className="text-left px-4 py-3">Último acesso</th>
                <th className="text-right px-4 py-3">Ações</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-border">
              {rows.map((u) => {
                const isSelf = u.email === currentUser?.email;
                const permsParsed = (() => { try { return JSON.parse(u.perm?.permissions || '{}'); } catch { return {}; } })();
                const isFull = !!permsParsed.__full__ || u.role === 'admin';
                return (
                  <tr key={u.id} className="hover:bg-accent/40">
                    <td className="px-4 py-3"><div className="font-medium text-foreground">{u.full_name || '—'}</div><div className="text-xs text-muted-foreground">{u.email}</div></td>
                    <td className="px-4 py-3">{u.cargo}</td>
                    <td className="px-4 py-3"><span className="text-sm text-muted-foreground">{u.accessType}</span></td>
                    <td className="px-4 py-3">
                      {u.hasLogistics
                        ? <Badge className="bg-orange-100 text-orange-700 dark:bg-orange-900/40 dark:text-orange-300"><Truck className="w-3 h-3 mr-1" /> Sim</Badge>
                        : <span className="text-xs text-muted-foreground">—</span>}
                    </td>
                    <td className="px-4 py-3"><Badge variant={u.status === 'active' ? 'default' : 'secondary'} className={u.status === 'active' ? 'bg-green-100 text-green-700' : ''}>{u.status === 'active' ? 'Ativo' : 'Inativo'}{isFull && ' • Admin'}</Badge></td>
                    <td className="px-4 py-3 text-xs text-muted-foreground">—</td>
                    <td className="px-4 py-3">
                      <div className="flex justify-end gap-1">
                        <Button size="icon" variant="ghost" onClick={() => setPermUser(u)} title="Permissões"><Shield className="w-4 h-4" /></Button>
                        <Button size="icon" variant="ghost" disabled={isSelf} onClick={() => setDeleteUser(u)} title={isSelf ? 'Você não pode excluir a si mesmo' : 'Excluir'}><Trash2 className="w-4 h-4 text-red-500" /></Button>
                      </div>
                    </td>
                  </tr>
                );
              })}
              {rows.length === 0 && <tr><td colSpan={7} className="text-center py-8 text-muted-foreground">Nenhum usuário encontrado.</td></tr>}
            </tbody>
          </table>
        </div>
      )}

      <UserInviteDialog open={inviteOpen} onClose={() => setInviteOpen(false)} onInvite={handleInvite} inviting={inviting} />
      <PermissionsDialog open={!!permUser} onClose={() => setPermUser(null)} targetUser={permUser} currentEmail={currentUser?.email} permission={permUser ? permMap[permUser.id] : null} onSave={handleSavePerm} saving={savingPerm} />
      <Dialog open={!!deleteUser} onOpenChange={(o) => !o && setDeleteUser(null)}>
        <DialogContent className="max-w-sm">
          <DialogHeader><DialogTitle>Excluir usuário?</DialogTitle></DialogHeader>
          <p className="text-sm text-muted-foreground">O usuário <b>{deleteUser?.email}</b> será removido permanentemente do sistema.</p>
          <DialogFooter><Button variant="outline" onClick={() => setDeleteUser(null)}>Cancelar</Button><Button variant="destructive" onClick={handleDeleteUser}>Excluir</Button></DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}