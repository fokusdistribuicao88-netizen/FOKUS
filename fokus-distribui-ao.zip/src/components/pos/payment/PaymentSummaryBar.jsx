import React from 'react';
import { fmt } from './paymentMethods';

export default function PaymentSummaryBar({ total, paid, remaining, change, canPartial }) {
  const complete = paid >= total - 0.001;
  const partial = !complete && paid > 0;
  const status = complete
    ? { label: 'Pagamento completo', tone: 'green' }
    : partial
    ? { label: 'Pagamento parcial', tone: 'amber' }
    : { label: 'Aguardando pagamento', tone: 'red' };

  const tones = {
    green: 'bg-green-50 border-green-300 text-green-700 dark:bg-green-950/40 dark:border-green-900 dark:text-green-300',
    amber: 'bg-amber-50 border-amber-300 text-amber-700 dark:bg-amber-950/40 dark:border-amber-900 dark:text-amber-300',
    red: 'bg-red-50 border-red-300 text-red-700 dark:bg-red-950/40 dark:border-red-900 dark:text-red-300',
  };

  return (
    <div className={`rounded-xl border p-3 ${tones[status.tone]}`}>
      <div className="flex items-center justify-between mb-2">
        <span className="text-sm font-semibold flex items-center gap-2">
          <span className={`w-2.5 h-2.5 rounded-full ${status.tone === 'green' ? 'bg-green-500' : status.tone === 'amber' ? 'bg-amber-500' : 'bg-red-500'}`} />
          {status.label}
        </span>
        {change > 0 && <span className="text-xs font-medium">Troco: {fmt(change)}</span>}
      </div>
      <div className="grid grid-cols-3 gap-2 text-center">
        <div>
          <p className="text-[10px] uppercase opacity-80">Total</p>
          <p className="text-base font-bold">{fmt(total)}</p>
        </div>
        <div>
          <p className="text-[10px] uppercase opacity-80">Recebido</p>
          <p className="text-base font-bold">{fmt(paid)}</p>
        </div>
        <div>
          <p className="text-[10px] uppercase opacity-80">Restante</p>
          <p className="text-base font-bold">{fmt(remaining)}</p>
        </div>
      </div>
      {partial && canPartial && (
        <p className="text-[11px] mt-2 text-center opacity-90">Saldo pendente será gerado em Convênio.</p>
      )}
      {partial && !canPartial && (
        <p className="text-[11px] mt-2 text-center font-medium">Complete o valor para finalizar a venda.</p>
      )}
    </div>
  );
}