import React from 'react';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { fmt } from './paymentMethods';

export default function TermFields({ p, set }) {
  const amt = Number(p.amount) || 0;
  const entry = Number(p.entry_amount) || 0;
  const interest = Number(p.interest_rate) || 0;
  const discount = Number(p.financial_discount) || 0;
  const base = Math.max(0, amt - entry);
  const withInterest = base * (1 + interest / 100);
  const final = Math.max(0, withInterest - discount);
  const parcels = Math.max(1, Number(p.installment_count) || 1);
  const perParcel = final / parcels;

  return (
    <div className="space-y-2">
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
        <div>
          <Label className="text-xs">Parcelas</Label>
          <Input type="number" min={1} value={p.installment_count || 1} onChange={(e) => set({ installment_count: Number(e.target.value) || 1 })} />
        </div>
        <div>
          <Label className="text-xs">Entrada</Label>
          <Input type="number" value={p.entry_amount || ''} onChange={(e) => set({ entry_amount: Number(e.target.value) || 0 })} placeholder={fmt(0)} />
        </div>
        <div>
          <Label className="text-xs">Juros %</Label>
          <Input type="number" value={p.interest_rate || ''} onChange={(e) => set({ interest_rate: Number(e.target.value) || 0 })} placeholder="0" />
        </div>
        <div>
          <Label className="text-xs">Desc. financeiro</Label>
          <Input type="number" value={p.financial_discount || ''} onChange={(e) => set({ financial_discount: Number(e.target.value) || 0 })} placeholder={fmt(0)} />
        </div>
      </div>
      <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
        <div>
          <Label className="text-xs">1º vencimento</Label>
          <Input type="date" value={p.dueDate || ''} onChange={(e) => set({ dueDate: e.target.value })} />
        </div>
        <div className="flex items-end pb-1">
          <p className="text-xs text-muted-foreground">{entry > 0 ? `Entrada ${fmt(entry)} + ` : ''}{parcels}x {fmt(perParcel)}</p>
        </div>
        <div className="flex items-end pb-1 justify-end">
          <p className="text-xs font-medium">Total a receber: {fmt(entry + final)}</p>
        </div>
      </div>
    </div>
  );
}