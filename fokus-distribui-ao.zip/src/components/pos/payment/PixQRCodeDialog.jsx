import React, { useState, useEffect } from 'react';
import QRCode from 'qrcode';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Copy, Check, Loader2, QrCode, CheckCircle2, KeyRound, Zap, ShieldCheck } from 'lucide-react';
import { generatePixBrCode } from '@/lib/pixBrCode';
import { fmt } from './paymentMethods';
import { base44 } from '@/api/base44Client';

function playPaymentSound() {
  try {
    const AudioCtx = window.AudioContext || window.webkitAudioContext;
    if (!AudioCtx) return;
    const ctx = new AudioCtx();
    const now = ctx.currentTime;
    const beep = (freq, start, duration) => {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'sine';
      osc.frequency.value = freq;
      gain.gain.setValueAtTime(0, now + start);
      gain.gain.linearRampToValueAtTime(0.25, now + start + 0.02);
      gain.gain.exponentialRampToValueAtTime(0.001, now + start + duration);
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start(now + start);
      osc.stop(now + start + duration);
    };
    beep(880, 0, 0.15);
    beep(1320, 0.12, 0.25);
    setTimeout(() => ctx.close(), 600);
  } catch { /* ignore */ }
}

/**
 * Dialog que gera o QR Code PIX para pagamento.
 *
 * Tenta primeiro gerar um PIX dinâmico via Mercado Pago (com confirmação automática).
 * Se o Mercado Pago não estiver configurado ou falhar, usa PIX estático (chave manual)
 * com confirmação manual do recebimento.
 */
export default function PixQRCodeDialog({ open, onClose, amount, settings, onConfirm }) {
  const defaultKey = settings?.pix_key || '';
  const [key, setKey] = useState(defaultKey);
  const [qrDataUrl, setQrDataUrl] = useState('');
  const [brCode, setBrCode] = useState('');
  const [copied, setCopied] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [confirmed, setConfirmed] = useState(false);
  const [mode, setMode] = useState(null); // null = tentando MP, 'mp' = MP ativo, 'static' = fallback estático
  const [paymentId, setPaymentId] = useState(null);
  const [waitingPayment, setWaitingPayment] = useState(false);
  const [autoConfirmed, setAutoConfirmed] = useState(false);

  useEffect(() => {
    if (open) {
      setKey(defaultKey);
      setCopied(false);
      setError('');
      setConfirmed(false);
      setQrDataUrl('');
      setBrCode('');
      setMode(null);
      setPaymentId(null);
      setWaitingPayment(false);
      setAutoConfirmed(false);
    }
  }, [open, defaultKey]);

  // Effect 1: Tentar PIX dinâmico via Mercado Pago ao abrir
  useEffect(() => {
    if (!open || !amount || amount <= 0) return;
    let cancelled = false;
    setLoading(true);
    setError('');
    setMode(null);

    (async () => {
      try {
        const response = await base44.functions.invoke('createPixPayment', {
          amount: Number(amount),
          description: 'Venda PDV Fokus',
        });
        if (cancelled) return;

        const data = response.data;
        if (data.qr_code) {
          setMode('mp');
          setPaymentId(data.payment_id || null);
          setWaitingPayment(true);
          setBrCode(data.qr_code);
          if (data.qr_code_base64) {
            setQrDataUrl(`data:image/png;base64,${data.qr_code_base64}`);
          } else {
            const url = await QRCode.toDataURL(data.qr_code, { width: 320, margin: 1, color: { dark: '#000000', light: '#ffffff' } });
            if (!cancelled) setQrDataUrl(url);
          }
          setLoading(false);
          return;
        }
        throw new Error('QR Code não retornado pelo Mercado Pago');
      } catch {
        // Fallback para PIX estático
        if (cancelled) return;
        setMode('static');
        // Effect 2 irá gerar o QR estático
      }
    })();

    return () => { cancelled = true; };
  }, [open, amount]);

  // Polling: consulta o Mercado Pago a cada 5s e detecta pagamento automaticamente
  useEffect(() => {
    if (!open || mode !== 'mp' || !paymentId || confirmed) return;
    let cancelled = false;
    const interval = setInterval(async () => {
      if (cancelled) return;
      try {
        const response = await base44.functions.invoke('checkPixPayment', { payment_id: paymentId });
        if (cancelled) return;
        const data = response.data;
        if (data?.approved) {
          cancelled = true;
          clearInterval(interval);
          setWaitingPayment(false);
          playPaymentSound();
          setConfirmed(true);
          setAutoConfirmed(true);
          onConfirm?.({ key: key.trim(), amount, mode: 'mp', auto: true });
        }
      } catch { /* ignora erros temporários e tenta novamente */ }
    }, 5000);
    return () => { cancelled = true; clearInterval(interval); };
  }, [open, mode, paymentId, confirmed, amount, key, onConfirm]);

  // Effect 2: Gerar QR estático quando em modo estático ou quando a chave muda
  useEffect(() => {
    if (!open || mode !== 'static') return;
    if (!key.trim() || !amount || amount <= 0) {
      setQrDataUrl('');
      setBrCode('');
      setLoading(false);
      return;
    }
    let cancelled = false;
    setLoading(true);
    try {
      const code = generatePixBrCode({
        key: key.trim(),
        amount,
        beneficiary: settings?.pix_beneficiary_name || settings?.company_name || '',
        city: settings?.pix_city || '',
      });
      if (cancelled) return;
      setBrCode(code);
      QRCode.toDataURL(code, { width: 320, margin: 1, color: { dark: '#000000', light: '#ffffff' } })
        .then((url) => { if (!cancelled) { setQrDataUrl(url); setLoading(false); } })
        .catch(() => { if (!cancelled) { setError('Falha ao gerar QR Code.'); setLoading(false); } });
    } catch (e) {
      if (!cancelled) { setError(e.message || 'Erro ao gerar BR Code.'); setLoading(false); }
    }
    return () => { cancelled = true; };
  }, [open, mode, key, amount, settings]);

  const handleCopy = async () => {
    if (!brCode) return;
    try {
      await navigator.clipboard.writeText(brCode);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch { /* ignore */ }
  };

  const handleConfirm = () => {
    setConfirmed(true);
    onConfirm?.({ key: key.trim(), amount, mode });
  };

  const handleDownload = () => {
    if (!qrDataUrl) return;
    const a = document.createElement('a');
    a.href = qrDataUrl;
    a.download = `pix-${Number(amount).toFixed(2).replace('.', ',')}.png`;
    a.click();
  };

  return (
    <Dialog open={open} onOpenChange={(o) => !o && onClose()}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <QrCode className="w-5 h-5 text-blue-600" /> QR Code PIX
          </DialogTitle>
        </DialogHeader>

        {autoConfirmed ? (
          <div className="flex flex-col items-center text-center py-4 gap-3">
            <div className="w-16 h-16 rounded-full bg-green-100 dark:bg-green-950/50 flex items-center justify-center animate-pulse">
              <CheckCircle2 className="w-10 h-10 text-green-600 dark:text-green-400" />
            </div>
            <div>
              <DialogTitle className="text-xl font-bold text-green-700 dark:text-green-400">
                Pagamento PIX Confirmado!
              </DialogTitle>
              <p className="text-sm text-muted-foreground mt-1">
                O pagamento foi identificado automaticamente.
              </p>
            </div>
            <div className="w-full rounded-xl border border-green-200 dark:border-green-900/50 bg-green-50/50 dark:bg-green-950/20 p-4 space-y-2 text-sm">
              <div className="flex justify-between">
                <span className="text-muted-foreground">Valor recebido</span>
                <span className="text-lg font-bold text-green-700 dark:text-green-400">{fmt(amount)}</span>
              </div>
              <div className="flex justify-between text-xs">
                <span className="text-muted-foreground">Confirmado em</span>
                <span className="text-muted-foreground tabular-nums">
                  {new Date().toLocaleString('pt-BR')}
                </span>
              </div>
            </div>
            <Button onClick={onClose} className="w-full bg-green-600 hover:bg-green-700 gap-2 mt-2">
              <CheckCircle2 className="w-4 h-4" /> Continuar
            </Button>
          </div>
        ) : (
        <div className="space-y-4">
          {/* Badge do modo */}
          {mode === 'mp' && (
            <div className="flex items-center gap-2 rounded-lg bg-green-50 dark:bg-green-950/40 border border-green-200 dark:border-green-900 px-3 py-2">
              <ShieldCheck className="w-4 h-4 text-green-600 dark:text-green-400 shrink-0" />
              <div className="text-xs">
                <p className="font-semibold text-green-700 dark:text-green-400">PIX Dinâmico via Mercado Pago</p>
                <p className="text-green-600 dark:text-green-500">
                  {waitingPayment
                    ? 'Aguardando pagamento — o sistema detecta automaticamente.'
                    : 'Confirmação automática ativa — o pedido será atualizado sozinho.'}
                </p>
              </div>
            </div>
          )}
          {mode === 'static' && (
            <div className="flex items-center gap-2 rounded-lg bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-900 px-3 py-2">
              <Zap className="w-4 h-4 text-amber-600 dark:text-amber-400 shrink-0" />
              <div className="text-xs">
                <p className="font-semibold text-amber-700 dark:text-amber-400">PIX Estático (manual)</p>
                <p className="text-amber-600 dark:text-amber-500">Mercado Pago indisponível — confirme o recebimento manualmente.</p>
              </div>
            </div>
          )}

          {/* Chave PIX editável (apenas no modo estático) */}
          {mode === 'static' && (
            <div className="space-y-1.5">
              <Label htmlFor="pix_key" className="flex items-center gap-1.5 text-xs">
                <KeyRound className="w-3.5 h-3.5" /> Chave PIX (qualquer tipo)
              </Label>
              <Input
                id="pix_key"
                value={key}
                onChange={(e) => setKey(e.target.value)}
                placeholder="CPF, CNPJ, email, telefone ou chave aleatória"
              />
              <p className="text-[11px] text-muted-foreground">
                A chave configurada aparece preenchida, mas pode ser alterada para esta cobrança.
              </p>
            </div>
          )}

          {/* Valor */}
          <div className="rounded-lg border border-border p-3 flex items-center justify-between">
            <span className="text-sm text-muted-foreground">Valor da nota</span>
            <span className="text-lg font-bold text-blue-700 dark:text-blue-400">{fmt(amount)}</span>
          </div>

          {/* QR Code */}
          <div className="flex flex-col items-center gap-3">
            {loading ? (
              <div className="w-48 h-48 flex items-center justify-center">
                <Loader2 className="w-8 h-8 animate-spin text-muted-foreground" />
              </div>
            ) : qrDataUrl ? (
              <img src={qrDataUrl} alt="QR Code PIX" className="w-48 h-48 rounded-lg border border-border" />
            ) : (
              <div className="w-48 h-48 flex items-center justify-center text-center text-xs text-muted-foreground border-2 border-dashed border-border rounded-lg">
                {error || 'Aguardando geração do QR Code...'}
              </div>
            )}

            {qrDataUrl && (
              <Button variant="outline" size="sm" onClick={handleDownload} className="gap-2">
                <QrCode className="w-4 h-4" /> Baixar imagem
              </Button>
            )}
          </div>

          {/* Copia e Cola */}
          {brCode && (
            <div className="space-y-1.5">
              <Label className="text-xs">PIX Copia e Cola</Label>
              <div className="flex gap-2">
                <Input readOnly value={brCode} className="font-mono text-xs" />
                <Button variant="outline" size="icon" onClick={handleCopy} title="Copiar">
                  {copied ? <Check className="w-4 h-4 text-green-600" /> : <Copy className="w-4 h-4" />}
                </Button>
              </div>
            </div>
          )}

          {error && <p className="text-xs text-red-600 text-center">{error}</p>}
        </div>
        )}

        {!autoConfirmed && (
        <DialogFooter className="flex-col sm:flex-row gap-2">
          <Button variant="outline" onClick={onClose} className="w-full sm:w-auto">
            Fechar
          </Button>
          <Button
            onClick={handleConfirm}
            disabled={!qrDataUrl || confirmed}
            className="w-full sm:w-auto gap-2 bg-green-600 hover:bg-green-700"
          >
            {confirmed ? (
              <><CheckCircle2 className="w-4 h-4" /> Pagamento confirmado</>
            ) : waitingPayment ? (
              <><Loader2 className="w-4 h-4 animate-spin" /> Aguardando pagamento...</>
            ) : (
              'Confirmar pagamento recebido'
            )}
          </Button>
        </DialogFooter>
        )}
      </DialogContent>
    </Dialog>
  );
}