import React from 'react';
import { Store, Truck, Package, Bike, CalendarClock, Wallet, CheckCircle2 } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { DELIVERY_OPTIONS } from './paymentMethods';

const ICONS = { Store, Truck, Package, Bike, CalendarClock };

export default function DeliverySection({ delivery, setDelivery }) {
  const set = (patch) => setDelivery((d) => ({ ...d, ...patch }));
  const isDelivery = delivery.type && delivery.type !== 'retirada';
  const isEmpresa = delivery.type === 'empresa';
  const showCarrier = delivery.type === 'transportadora';
  const showDriver = ['empresa', 'motoboy', 'agendada'].includes(delivery.type);

  return (
    <div className="rounded-xl border border-border p-3 space-y-3">
      <p className="text-xs font-semibold text-muted-foreground uppercase flex items-center gap-1">
        <Truck className="w-3.5 h-3.5" /> Entrega
      </p>
      <div className="grid grid-cols-2 gap-2">
        {DELIVERY_OPTIONS.map((o) => {
          const Icon = ICONS[o.icon];
          const active = delivery.type === o.key;
          return (
            <button
              key={o.key}
              type="button"
              onClick={() => set({ type: o.key, freight: o.key === 'retirada' ? 0 : delivery.freight, receipt_mode: o.key === 'empresa' ? (delivery.receipt_mode || 'already_paid') : 'none' })}
              className={`flex flex-col items-center gap-1 p-2 rounded-lg border text-xs transition ${
                active ? 'border-blue-600 bg-blue-50 text-blue-700 font-semibold' : 'border-border hover:bg-muted/50'
              }`}
            >
              {Icon && <Icon className="w-5 h-5" />}
              {o.label}
            </button>
          );
        })}
      </div>

      {isEmpresa && (
        <div className="rounded-lg border-2 border-amber-200 bg-amber-50 p-3 space-y-2">
          <p className="text-xs font-semibold text-amber-900 uppercase flex items-center gap-1">
            <Wallet className="w-3.5 h-3.5" /> Recebimento no Local
          </p>
          <div className="grid grid-cols-2 gap-2">
            <button
              type="button"
              onClick={() => set({ receipt_mode: 'on_site' })}
              className={`flex flex-col items-center gap-1 p-2 rounded-lg border text-xs transition ${
                delivery.receipt_mode === 'on_site' ? 'border-amber-600 bg-amber-100 text-amber-800 font-semibold' : 'border-amber-200 hover:bg-amber-50 text-amber-700'
              }`}
            >
              <Wallet className="w-4 h-4" />
              Receber no local
            </button>
            <button
              type="button"
              onClick={() => set({ receipt_mode: 'already_paid' })}
              className={`flex flex-col items-center gap-1 p-2 rounded-lg border text-xs transition ${
                delivery.receipt_mode === 'already_paid' ? 'border-green-600 bg-green-100 text-green-800 font-semibold' : 'border-amber-200 hover:bg-amber-50 text-amber-700'
              }`}
            >
              <CheckCircle2 className="w-4 h-4" />
              Pagamento já realizado
            </button>
          </div>
          {delivery.receipt_mode === 'on_site' && (
            <p className="text-xs text-amber-800/80">
              O valor será recebido pelo entregador no endereço do cliente. O pedido entra na logística destacado como <strong>💰 Receber no Local</strong>.
            </p>
          )}
        </div>
      )}

      {isDelivery && (
        <div className="grid sm:grid-cols-2 gap-2 pt-1">
          <div className="sm:col-span-2">
            <Label className="text-xs">Endereço de entrega</Label>
            <Input value={delivery.address} onChange={(e) => set({ address: e.target.value })} placeholder="Endereço completo" />
          </div>
          <div>
            <Label className="text-xs">Data da entrega</Label>
            <Input type="date" value={delivery.date} onChange={(e) => set({ date: e.target.value })} />
          </div>
          <div>
            <Label className="text-xs">Horário previsto</Label>
            <Input type="time" value={delivery.time} onChange={(e) => set({ time: e.target.value })} />
          </div>
          {showCarrier && (
            <div>
              <Label className="text-xs">Transportadora</Label>
              <Input value={delivery.carrier} onChange={(e) => set({ carrier: e.target.value })} placeholder="Nome da transportadora" />
            </div>
          )}
          {showDriver && (
            <div>
              <Label className="text-xs">Motorista responsável</Label>
              <Input value={delivery.driver} onChange={(e) => set({ driver: e.target.value })} placeholder="Nome do motorista" />
            </div>
          )}
          <div>
            <Label className="text-xs">Valor do frete</Label>
            <Input type="number" value={delivery.freight} onChange={(e) => set({ freight: Number(e.target.value) || 0 })} />
          </div>
          <div className="sm:col-span-2">
            <Label className="text-xs">Observações</Label>
            <Textarea rows={2} value={delivery.notes} onChange={(e) => set({ notes: e.target.value })} placeholder="Observações da entrega" />
          </div>
        </div>
      )}
    </div>
  );
}