export const METHODS = [
  { key: 'cash', label: 'Dinheiro', instant: true },
  { key: 'pix', label: 'PIX', instant: true },
  { key: 'convenio', label: 'Convênio', term: true },
  { key: 'cheque', label: 'Cheque', term: true },
];

// Alias legados → Convênio (unificação: Crediário/Contas a Receber = Convênio)
const LEGACY_ALIAS = { crediario: 'convenio', contas_receber: 'convenio' };

export const DELIVERY_OPTIONS = [
  { key: 'retirada', label: 'Retirada', icon: 'Store' },
  { key: 'empresa', label: 'Entrega empresa', icon: 'Truck' },
];

export const fmt = (v) => `R$ ${(Number(v) || 0).toFixed(2).replace('.', ',')}`;
export const methodDef = (key) =>
  METHODS.find((m) => m.key === key) ||
  (LEGACY_ALIAS[key] ? METHODS.find((m) => m.key === LEGACY_ALIAS[key]) : undefined);
export const isCash = (key) => key === 'cash';
export const isCard = (key) => !!methodDef(key)?.card;
export const isTerm = (key) => !!methodDef(key)?.term;
export const isCheque = (key) => key === 'cheque';
export const isReceivable = (key) => key === 'contas_receber';
export const INSTANT_METHODS = ['cash', 'pix'];