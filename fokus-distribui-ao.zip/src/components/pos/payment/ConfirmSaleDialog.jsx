import React from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { CheckCircle2, Loader2, Printer } from 'lucide-react';
import { fmt, methodDef, DELIVERY_OPTIONS } from './paymentMethods';

export default function ConfirmSaleDialog({
  open, onClose, onConfirm, onPrint, busy, cart, customer, gross, discount, freight,
  total, payments, paid, remaining, change, delivery, canPartial,
}) {
  const deliveryLabel = DELIVERY_OPTIONS.find((d) => d.key === delivery?.type)?.label || '—';
  const blocked = remaining > 0.001 && !canPartial;

  return (
    <Dialog open={open} onOpenChange={(o) => !o && onClose()}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <CheckCircle2 className="w-5 h-5 text-green-600" /> Conferência da Venda
          </DialogTitle>
        </DialogHeader>
        <div className="space-y-2 text-sm max-h-[60vh] overflow-y-auto">
          <div className="rounded-lg border border-border p-3 space-y-1">
            <div className="flex justify-between"><span className="text-muted-foreground">Cliente</span><span className="font-medium text-right">{customer?.name || 'Consumidor Final'}</span></div>
            <div className="flex justify-between"><span className="text-muted-foreground">Itens</span><span>{cart.length}</span></div>
            <div className="flex justify-between"><span className="text-muted-foreground">Valor bruto</span><span>{fmt(gross)}</span></div>
            <div className="flex justify-between"><span className="text-muted-foreground">Desconto</span><span className="text-red-600">- {fmt(discount)}</span></div>
            <div className="flex justify-between"><span className="text-muted-foreground">Frete</span><span>{fmt(freight)}</span></div>
            <div className="flex justify-between border-t border-border pt-1"><span className="font-semibold">Total</span><span className="font-bold">{fmt(total)}</span></div>
          </div>
          <div className="rounded-lg border border-border p-3">
            <p className="text-xs font-semibold text-muted-foreground uppercase mb-1">Pagamentos</p>
            {payments.map((p, i) => (
              <div key={i} className="flex justify-between py-0.5">
                <span>
                  {methodDef(p.method)?.label || p.method}
                  {p.method === 'credit_card' && (p.installments || 1) > 1 ? ` (${p.installments}x)` : ''}
                  {isTermP(p) && (p.installment_count || 1) > 1 ? ` (${p.installment_count}x)` : ''}
                </span>
                <span className="font-medium">{fmt(p.amount)}</span>
              </div>
            ))}
            <div className="flex justify-between border-t border-border mt-1 pt-1">
              <span className="text-muted-foreground">Total recebido</span>
              <span className="font-semibold text-green-600">{fmt(paid)}</span>
            </div>
            {change > 0 && <div className="flex justify-between"><span className="text-muted-foreground">Troco</span><span>{fmt(change)}</span></div>}
            {remaining > 0.001 && (
              <div className="flex justify-between"><span className="text-muted-foreground">Saldo pendente</span><span className="font-semibold text-amber-600">{fmt(remaining)}</span></div>
            )}
          </div>
          <div className="rounded-lg border border-border p-3">
            <p className="text-xs font-semibold text-muted-foreground uppercase mb-1">Entrega</p>
            <div className="flex justify-between"><span className="text-muted-foreground">Tipo</span><span>{deliveryLabel}</span></div>
            {delivery?.type && delivery.type !== 'retirada' && (
              <>
                {delivery.address && <div className="flex justify-between gap-2"><span className="text-muted-foreground shrink-0">Endereço</span><span className="text-right">{delivery.address}</span></div>}
                {delivery.date && <div className="flex justify-between"><span className="text-muted-foreground">Data</span><span>{delivery.date}</span></div>}
                {delivery.driver && <div className="flex justify-between"><span className="text-muted-foreground">Motorista</span><span>{delivery.driver}</span></div>}
                {delivery.carrier && <div className="flex justify-between"><span className="text-muted-foreground">Transportadora</span><span>{delivery.carrier}</span></div>}
              </>
            )}
          </div>
          {blocked && <p className="text-xs text-red-600 text-center font-medium">Não é permitido concluir com saldo pendente.</p>}
        </div>
        <DialogFooter className="flex-col gap-2 sm:flex-col sm:space-x-0">
          <Button variant="outline" onClick={onPrint} disabled={busy} className="gap-2 w-full">
            <Printer className="w-4 h-4" /> Imprimir antes de finalizar
          </Button>
          <div className="flex gap-2 w-full">
            <Button variant="outline" onClick={onClose} disabled={busy} className="flex-1">Voltar</Button>
            <Button onClick={onConfirm} disabled={busy || blocked} className="bg-green-600 hover:bg-green-700 gap-2 flex-1">
              {busy ? <><Loader2 className="w-4 h-4 animate-spin" /> Processando...</> : 'Confirmar e finalizar'}
            </Button>
          </div>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

function isTermP(p) {
  return ['boleto', 'transfer', 'convenio', 'crediario', 'credit', 'cheque'].includes(p.method);
}