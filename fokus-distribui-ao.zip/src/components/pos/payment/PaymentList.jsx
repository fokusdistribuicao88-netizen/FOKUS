import React from 'react';
import { Button } from '@/components/ui/button';
import { Plus } from 'lucide-react';
import { fmt } from './paymentMethods';
import PaymentRow from './PaymentRow';

export default function PaymentList({ payments, setPayments, canCredit, remaining }) {
  const set = (i, patch) => setPayments((ps) => ps.map((x, idx) => (idx === i ? { ...x, ...patch } : x)));
  const remove = (i) => setPayments((ps) => ps.filter((_, idx) => idx !== i));
  const add = () =>
    setPayments((ps) => [
      ...ps,
      { method: 'pix', amount: remaining, received: '', installments: 1, installment_count: 1, entry_amount: 0, interest_rate: 0, financial_discount: 0 },
    ]);

  return (
    <div className="space-y-2">
      {payments.map((p, i) => (
        <PaymentRow key={i} p={p} i={i} canCredit={canCredit} set={(patch) => set(i, patch)} remove={remove} />
      ))}
      {remaining > 0.001 && (
        <Button variant="outline" size="sm" onClick={add} className="w-full gap-2">
          <Plus className="w-4 h-4" /> Adicionar pagamento (falta {fmt(remaining)})
        </Button>
      )}
    </div>
  );
}