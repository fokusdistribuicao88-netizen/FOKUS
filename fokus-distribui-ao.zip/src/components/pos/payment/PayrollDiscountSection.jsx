import React, { useMemo } from 'react';
import { Checkbox } from '@/components/ui/checkbox';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import {
  Select, SelectTrigger, SelectValue, SelectContent, SelectItem,
} from '@/components/ui/select';
import { UserCheck } from 'lucide-react';
import { competenceOptions } from '@/lib/employeePurchaseSync';

const MONTH_LABELS = ['Jan', 'Fev', 'Mar', 'Abr', 'Mai', 'Jun', 'Jul', 'Ago', 'Set', 'Out', 'Nov', 'Dez'];

function competenceLabel(value) {
  if (!value) return '—';
  const [y, m] = value.split('-');
  return `${MONTH_LABELS[Number(m) - 1] || ''}/${y}`;
}

export default function PayrollDiscountSection({ employee, checked, onToggle, competenceMode, onModeChange, competenceValue, onCompetenceChange }) {
  const options = useMemo(() => competenceOptions(), []);

  if (!employee) return null;

  return (
    <div className="rounded-lg border-2 border-blue-200 bg-blue-50 p-3 space-y-3">
      <label className="flex items-start gap-3 cursor-pointer">
        <Checkbox checked={checked} onCheckedChange={(v) => onToggle(v === true)} className="mt-0.5" />
        <div className="flex-1">
          <p className="text-sm font-semibold flex items-center gap-2 text-blue-900">
            <UserCheck className="w-4 h-4" /> Descontar na folha do funcionário
          </p>
          <p className="text-xs text-blue-800/80">
            Cliente identificado como funcionário: <strong>{employee.name}</strong>
            {employee.role ? ` (${employee.role})` : ''}
          </p>
        </div>
      </label>

      {checked && (
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pl-8">
          <div>
            <Label className="text-xs">Competência do desconto</Label>
            <Select value={competenceMode} onValueChange={onModeChange}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                {options.map((o) => <SelectItem key={o.key} value={o.key}>{o.label} — {competenceLabel(o.value)}</SelectItem>)}
              </SelectContent>
            </Select>
          </div>
          {competenceMode === 'other' && (
            <div>
              <Label className="text-xs">Mês/Ano</Label>
              <Input type="month" value={competenceValue} onChange={(e) => onCompetenceChange(e.target.value)} />
            </div>
          )}
          {competenceMode !== 'other' && (
            <div className="flex items-end">
              <Badge className="bg-blue-100 text-blue-800">Desconto em: {competenceLabel(competenceValue)}</Badge>
            </div>
          )}
          <p className="text-xs text-blue-800/80 sm:col-span-2">
            O valor não será recebido no caixa agora. Será descontado automaticamente na folha do funcionário na competência selecionada.
          </p>
        </div>
      )}
    </div>
  );
}