import React from 'react';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';

export default function ChequeFields({ p, set }) {
  return (
    <div className="grid grid-cols-3 gap-2">
      <div>
        <Label className="text-xs">Nº do cheque</Label>
        <Input value={p.check_number || ''} onChange={(e) => set({ check_number: e.target.value })} placeholder="000000" />
      </div>
      <div>
        <Label className="text-xs">Banco</Label>
        <Input value={p.check_bank || ''} onChange={(e) => set({ check_bank: e.target.value })} placeholder="Nome do banco" />
      </div>
      <div>
        <Label className="text-xs">Bom para</Label>
        <Input type="date" value={p.check_date || ''} onChange={(e) => set({ check_date: e.target.value })} />
      </div>
    </div>
  );
}