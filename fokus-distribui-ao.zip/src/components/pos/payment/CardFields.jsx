import React from 'react';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectTrigger, SelectValue, SelectContent, SelectItem } from '@/components/ui/select';
import { fmt } from './paymentMethods';

const BRANDS = ['Visa', 'Mastercard', 'Elo', 'Amex', 'Hipercard', 'Outra'];
const OPERATORS = ['Cielo', 'Rede', 'Stone', 'Getnet', 'PagSeguro', 'Sicredi', 'Outra'];

export default function CardFields({ p, set }) {
  return (
    <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
      <div>
        <Label className="text-xs">Parcelas</Label>
        <Select value={String(p.installments || 1)} onValueChange={(v) => set({ installments: Number(v) })}>
          <SelectTrigger className="h-9"><SelectValue /></SelectTrigger>
          <SelectContent>
            {[1, 2, 3, 4, 5, 6, 10, 12].map((n) => (
              <SelectItem key={n} value={String(n)}>{n}x {fmt((Number(p.amount) || 0) / n)}</SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>
      <div>
        <Label className="text-xs">Operadora</Label>
        <Select value={p.card_operator || ''} onValueChange={(v) => set({ card_operator: v })}>
          <SelectTrigger className="h-9"><SelectValue placeholder="—" /></SelectTrigger>
          <SelectContent>{OPERATORS.map((o) => <SelectItem key={o} value={o}>{o}</SelectItem>)}</SelectContent>
        </Select>
      </div>
      <div>
        <Label className="text-xs">Bandeira</Label>
        <Select value={p.card_brand || ''} onValueChange={(v) => set({ card_brand: v })}>
          <SelectTrigger className="h-9"><SelectValue placeholder="—" /></SelectTrigger>
          <SelectContent>{BRANDS.map((b) => <SelectItem key={b} value={b}>{b}</SelectItem>)}</SelectContent>
        </Select>
      </div>
      <div>
        <Label className="text-xs">Autorização</Label>
        <Input value={p.card_auth || ''} onChange={(e) => set({ card_auth: e.target.value })} placeholder="Nº" />
      </div>
    </div>
  );
}