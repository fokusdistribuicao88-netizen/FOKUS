import React from 'react';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectTrigger, SelectValue, SelectContent, SelectItem } from '@/components/ui/select';
import { fmt } from './paymentMethods';

const COST_CENTERS = ['Vendas', 'Logística', 'Administrativo', 'Operacional', 'Outros'];
const CATEGORIES = ['Receita de Vendas', 'Serviços', 'Frete', 'Outros'];

export default function ReceivableFields({ p, set }) {
  const amt = Number(p.amount) || 0;
  const parcels = Math.max(1, Number(p.installment_count) || 1);
  const perParcel = amt / parcels;

  return (
    <div className="space-y-2">
      <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
        <div>
          <Label className="text-xs">Parcelas</Label>
          <Input type="number" min={1} value={p.installment_count || 1} onChange={(e) => set({ installment_count: Number(e.target.value) || 1 })} />
        </div>
        <div>
          <Label className="text-xs">1º vencimento</Label>
          <Input type="date" value={p.dueDate || ''} onChange={(e) => set({ dueDate: e.target.value })} />
        </div>
        <div className="flex items-end pb-1">
          <p className="text-xs font-medium">{parcels}x {fmt(perParcel)}</p>
        </div>
      </div>
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
        <div>
          <Label className="text-xs">Categoria</Label>
          <Select value={p.category || 'Receita de Vendas'} onValueChange={(v) => set({ category: v })}>
            <SelectTrigger className="h-9"><SelectValue /></SelectTrigger>
            <SelectContent>
              {CATEGORIES.map((c) => <SelectItem key={c} value={c}>{c}</SelectItem>)}
            </SelectContent>
          </Select>
        </div>
        <div>
          <Label className="text-xs">Centro de custo</Label>
          <Select value={p.cost_center || 'Vendas'} onValueChange={(v) => set({ cost_center: v })}>
            <SelectTrigger className="h-9"><SelectValue /></SelectTrigger>
            <SelectContent>
              {COST_CENTERS.map((c) => <SelectItem key={c} value={c}>{c}</SelectItem>)}
            </SelectContent>
          </Select>
        </div>
      </div>
      <div>
        <Label className="text-xs">Observações</Label>
        <Textarea value={p.notes || ''} onChange={(e) => set({ notes: e.target.value })} rows={2} placeholder="Observações do lançamento" />
      </div>
    </div>
  );
}