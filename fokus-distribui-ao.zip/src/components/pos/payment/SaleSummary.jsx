import React from 'react';
import { fmt } from './paymentMethods';

function Row({ label, value, strong, accent }) {
  return (
    <div className="flex justify-between text-sm py-0.5 gap-2">
      <span className="text-muted-foreground shrink-0">{label}</span>
      <span
        className={`text-right truncate ${strong ? 'font-bold' : 'font-medium'}`}
        style={accent ? { color: accent } : undefined}
      >
        {value}
      </span>
    </div>
  );
}

export default function SaleSummary({ cart, customer, gross, discount, freight, total, paid, remaining }) {
  const itemCount = cart.reduce((s, i) => s + (Number(i.quantity) || 0), 0);
  return (
    <div className="rounded-xl border border-border bg-muted/30 p-3">
      <p className="text-xs font-semibold text-muted-foreground uppercase mb-2">Resumo da Venda</p>
      <div className="grid sm:grid-cols-2 gap-x-6">
        <div>
          <Row label="Cliente" value={customer?.name || 'Consumidor Final'} />
          <Row label="Itens" value={`${cart.length} prod. (${itemCount} un)`} />
          <Row label="Valor bruto" value={fmt(gross)} />
          <Row label="Desconto" value={`- ${fmt(discount)}`} accent="#dc2626" />
        </div>
        <div>
          <Row label="Frete/Acréscimos" value={fmt(freight)} />
          <Row label="Valor total" value={fmt(total)} strong />
          <Row label="Recebido" value={fmt(paid)} accent="#16a34a" />
          <Row label="Restante" value={fmt(remaining)} accent={remaining > 0 ? '#dc2626' : '#16a34a'} strong />
        </div>
      </div>
    </div>
  );
}