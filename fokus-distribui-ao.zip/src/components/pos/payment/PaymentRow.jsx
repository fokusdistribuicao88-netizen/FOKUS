import React from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Trash2 } from 'lucide-react';
import { Select, SelectTrigger, SelectValue, SelectContent, SelectItem } from '@/components/ui/select';
import { METHODS, fmt, isCash, isCard, isTerm, isCheque, isReceivable } from './paymentMethods';
import CardFields from './CardFields';
import TermFields from './TermFields';
import ChequeFields from './ChequeFields';
import ReceivableFields from './ReceivableFields';

export default function PaymentRow({ p, i, canCredit, set, remove }) {
  const change = isCash(p.method) && Number(p.received) > 0
    ? Math.max(0, Number(p.received) - (Number(p.amount) || 0))
    : 0;

  return (
    <div className="rounded-lg border border-border p-3 space-y-2 bg-card">
      <div className="flex items-end gap-2">
        <div className="flex-1">
          <Label className="text-xs">Forma de pagamento</Label>
          <Select value={p.method} onValueChange={(v) => set({ method: v })}>
            <SelectTrigger className="h-9"><SelectValue /></SelectTrigger>
            <SelectContent>
              {METHODS.filter((m) => m.key !== 'credit' || canCredit).map((m) => (
                <SelectItem key={m.key} value={m.key}>{m.label}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
        <div className="w-28">
          <Label className="text-xs">Valor</Label>
          <Input type="number" value={p.amount} onChange={(e) => set({ amount: Number(e.target.value) || 0 })} />
        </div>
        <Button size="icon" variant="ghost" onClick={() => remove(i)} className="text-red-500"><Trash2 className="w-4 h-4" /></Button>
      </div>
      {isCash(p.method) && (
        <div className="flex items-end gap-3">
          <div className="w-40">
            <Label className="text-xs">Recebido</Label>
            <Input type="number" value={p.received || ''} placeholder={fmt(p.amount)} onChange={(e) => set({ received: e.target.value })} />
          </div>
          {change > 0 && <p className="text-sm font-semibold text-green-600 pb-2">Troco: {fmt(change)}</p>}
        </div>
      )}
      {isCard(p.method) && <CardFields p={p} set={set} />}
      {isTerm(p.method) && <TermFields p={p} set={set} />}
      {isCheque(p.method) && <ChequeFields p={p} set={set} />}
      {isReceivable(p.method) && <ReceivableFields p={p} set={set} />}
    </div>
  );
}