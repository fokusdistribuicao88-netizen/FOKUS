import React, { useState, useMemo } from 'react';
import { useQuery } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { FileText, FileSpreadsheet, TrendingUp, Package, User, Share2 } from 'lucide-react';
import { generatePDF, sharePDF } from '@/lib/pdfService';
import { posSalesToSections } from '@/lib/pdfAdapters';
import { useAuth } from '@/lib/AuthContext';
import { useToast } from '@/components/ui/use-toast';

const fmt = (v) => `R$ ${(Number(v) || 0).toFixed(2).replace('.', ',')}`;
const isPos = (o) => (o.timeline || []).some((t) => t.event && t.event.includes('PDV'));

export default function PosReports() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [start, setStart] = useState('');
  const [end, setEnd] = useState('');
  const [sharing, setSharing] = useState(false);

  const { data: orders = [] } = useQuery({ queryKey: ['orders'], queryFn: () => base44.entities.Order.list('-created_date') });
  const { data: sessions = [] } = useQuery({ queryKey: ['cashRegisters'], queryFn: () => base44.entities.CashRegister.list('-opening_date') });

  const sales = useMemo(() => {
    const ds = start ? new Date(start) : null;
    const de = end ? new Date(end + 'T23:59:59') : null;
    return orders.filter((o) => {
      if (!isPos(o)) return false;
      if (o.status === 'cancelled') return false;
      const d = new Date(o.created_date);
      if (ds && d < ds) return false;
      if (de && d > de) return false;
      return true;
    });
  }, [orders, start, end]);

  const byOperator = useMemo(() => {
    const m = {};
    sales.forEach((o) => { const k = o.seller || '—'; m[k] = (m[k] || 0) + (Number(o.total) || 0); });
    return Object.entries(m).sort((a, b) => b[1] - a[1]);
  }, [sales]);

  const byProduct = useMemo(() => {
    const m = {};
    sales.forEach((o) => (o.items || []).forEach((it) => {
      const k = it.product_name || '—';
      if (!m[k]) m[k] = { qty: 0, revenue: 0 };
      m[k].qty += it.quantity;
      m[k].revenue += it.subtotal;
    }));
    return Object.entries(m).sort((a, b) => b[1].qty - a[1].qty);
  }, [sales]);

  const byCustomer = useMemo(() => {
    const m = {};
    sales.forEach((o) => { const k = o.customer_name || 'Consumidor Final'; m[k] = (m[k] || 0) + (Number(o.total) || 0); });
    return Object.entries(m).sort((a, b) => b[1] - a[1]);
  }, [sales]);

  const totalRev = sales.reduce((s, o) => s + (Number(o.total) || 0), 0);

  const exportPDF = async () => {
    const r = posSalesToSections({ sales, byOperator, byProduct, byCustomer, totalRev, start, end });
    await generatePDF({ documentType: 'pos_sales_report', data: r.data, sections: r.sections, module: 'PDV', user, fileName: `relatorio-vendas-pdv-${new Date().toISOString().slice(0, 10)}.pdf` });
  };

  const shareReport = async () => {
    setSharing(true);
    try {
      const r = posSalesToSections({ sales, byOperator, byProduct, byCustomer, totalRev, start, end });
      const { shared } = await sharePDF({ documentType: 'pos_sales_report', data: r.data, sections: r.sections, module: 'PDV', user, fileName: `relatorio-vendas-pdv-${new Date().toISOString().slice(0, 10)}.pdf` });
      toast({ title: shared ? 'Compartilhando PDF' : 'PDF baixado', description: shared ? 'Escolha o aplicativo para enviar.' : 'Compartilhamento não suportado — PDF baixado.' });
    } catch (e) {
      if (e?.name !== 'AbortError') toast({ title: 'Erro ao compartilhar', description: String(e.message || e), variant: 'destructive' });
    } finally { setSharing(false); }
  };

  const exportExcel = () => {
    const headers = ['Venda', 'Data', 'Cliente', 'Operador', 'Total'];
    const rows = sales.map((o) => [
      o.id.substring(0, 8).toUpperCase(), new Date(o.created_date).toLocaleString('pt-BR'),
      o.customer_name || 'Consumidor Final', o.seller || '—', o.total,
    ]);
    const csv = [headers, ...rows].map((r) => r.map((c) => `"${String(c).replace(/"/g, '""')}"`).join(',')).join('\n');
    const blob = new Blob(['\uFEFF' + csv], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url; a.download = `vendas-pdv-${new Date().toISOString().slice(0, 10)}.csv`;
    a.click(); URL.revokeObjectURL(url);
  };

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-end gap-3 bg-card rounded-xl border p-3">
        <div>
          <Label className="text-xs">Data inicial</Label>
          <Input type="date" value={start} onChange={(e) => setStart(e.target.value)} />
        </div>
        <div>
          <Label className="text-xs">Data final</Label>
          <Input type="date" value={end} onChange={(e) => setEnd(e.target.value)} />
        </div>
        <div className="flex gap-2 ml-auto">
          <Button variant="outline" onClick={exportPDF} className="gap-2" disabled={sharing}><FileText className="w-4 h-4" /> PDF</Button>
          <Button variant="outline" onClick={shareReport} className="gap-2" disabled={sharing}><Share2 className="w-4 h-4" /> Compartilhar</Button>
          <Button variant="outline" onClick={exportExcel} className="gap-2"><FileSpreadsheet className="w-4 h-4" /> Excel</Button>
        </div>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        <div className="bg-card rounded-xl border p-3">
          <TrendingUp className="w-5 h-5 text-blue-600 mb-1" />
          <p className="text-xs text-muted-foreground">Faturamento</p>
          <p className="text-xl font-bold">{fmt(totalRev)}</p>
        </div>
        <div className="bg-card rounded-xl border p-3">
          <Package className="w-5 h-5 text-green-600 mb-1" />
          <p className="text-xs text-muted-foreground">Vendas</p>
          <p className="text-xl font-bold">{sales.length}</p>
        </div>
        <div className="bg-card rounded-xl border p-3">
          <User className="w-5 h-5 text-violet-600 mb-1" />
          <p className="text-xs text-muted-foreground">Operadores ativos</p>
          <p className="text-xl font-bold">{byOperator.length}</p>
        </div>
        <div className="bg-card rounded-xl border p-3">
          <Package className="w-5 h-5 text-amber-600 mb-1" />
          <p className="text-xs text-muted-foreground">Caixas abertos hoje</p>
          <p className="text-xl font-bold">{sessions.filter((s) => s.status === 'open').length}</p>
        </div>
      </div>

      <div className="grid md:grid-cols-2 gap-3">
        <div className="bg-card rounded-xl border p-3">
          <h4 className="text-sm font-semibold mb-2">Vendas por operador</h4>
          <div className="space-y-1">
            {byOperator.length === 0 && <p className="text-sm text-muted-foreground">Sem dados.</p>}
            {byOperator.map(([k, v]) => (
              <div key={k} className="flex justify-between text-sm py-1 border-b border-border last:border-0 gap-2">
                <span className="truncate min-w-0">{k}</span><span className="font-medium whitespace-nowrap">{fmt(v)}</span>
              </div>
            ))}
          </div>
        </div>
        <div className="bg-card rounded-xl border p-3">
          <h4 className="text-sm font-semibold mb-2">Produtos mais vendidos</h4>
          <div className="space-y-1 max-h-56 overflow-y-auto">
            {byProduct.length === 0 && <p className="text-sm text-muted-foreground">Sem dados.</p>}
            {byProduct.map(([k, v]) => (
              <div key={k} className="flex justify-between text-sm py-1 border-b border-border last:border-0 gap-2">
                <span className="truncate min-w-0 flex-1">{k}</span>
                <span className="font-medium whitespace-nowrap">{v.qty} un · {fmt(v.revenue)}</span>
              </div>
            ))}
          </div>
        </div>
        <div className="bg-card rounded-xl border p-3 md:col-span-2">
          <h4 className="text-sm font-semibold mb-2">Vendas por cliente</h4>
          <div className="space-y-1">
            {byCustomer.length === 0 && <p className="text-sm text-muted-foreground">Sem dados.</p>}
            {byCustomer.map(([k, v]) => (
              <div key={k} className="flex justify-between text-sm py-1 border-b border-border last:border-0 gap-2">
                <span className="truncate min-w-0">{k}</span><span className="font-medium whitespace-nowrap">{fmt(v)}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}