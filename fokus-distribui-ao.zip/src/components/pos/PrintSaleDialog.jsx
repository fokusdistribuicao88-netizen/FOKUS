import React, { useMemo, useState, useEffect } from 'react';
import { useQuery } from '@tanstack/react-query';
import { Link } from 'react-router-dom';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Select, SelectTrigger, SelectValue, SelectContent, SelectItem } from '@/components/ui/select';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { Printer, FileText, Mail, MessageCircle, Truck, X, CheckCircle2, Droplet, Eye, Loader2, Pencil, RefreshCw, Share2 } from 'lucide-react';
import { buildPreviewUrl, generatePDF, printPDF, sharePDF, logEmission } from '@/lib/pdfService';
import PdfViewerDialog from '@/components/PdfViewerDialog';
import PdfRenderer from '@/components/PdfRenderer';
import { saleToData } from '@/lib/pdfAdapters';
import { PDF_DOCUMENTS } from '@/lib/pdfTemplateDefaults';
import { useAuth } from '@/lib/AuthContext';
import { useToast } from '@/components/ui/use-toast';
import { base44 } from '@/api/base44Client';
import { useAvailableDocTypes } from '@/lib/useAvailableDocTypes';

const fmt = (v) => `R$ ${(Number(v) || 0).toFixed(2).replace('.', ',')}`;

const docMeta = (type) => PDF_DOCUMENTS.find((d) => d.type === type);
const paperLabel = (size) => (size === '58' ? 'Térmica 58mm' : size === '80' ? 'Térmica 80mm' : 'A4');

export default function PrintSaleDialog({ open, onClose, sale, settings, isDelivery, productMap }) {
  const { user } = useAuth();
  const { toast } = useToast();
  const [docType, setDocType] = useState('pos_full');
  const [templateId, setTemplateId] = useState('');
  const [wmId, setWmId] = useState('none');
  const [copies, setCopies] = useState(1);
  const [scale, setScale] = useState(100);
  const [previewUrl, setPreviewUrl] = useState('');
  const [previewing, setPreviewing] = useState(false);
  const [busy, setBusy] = useState(false);
  const [viewerOpen, setViewerOpen] = useState(false);

  const { docs: visibleDocs, templates: allTemplates } = useAvailableDocTypes();

  useEffect(() => {
    if (visibleDocs.length && !visibleDocs.find((d) => d.type === docType)) {
      setDocType(visibleDocs[0].type);
      setTemplateId('');
    }
  }, [visibleDocs, docType]);

  const { data: watermarks = [] } = useQuery({
    queryKey: ['watermarks'],
    queryFn: () => base44.entities.Watermark.list('-updated_date'),
    staleTime: 60 * 1000,
  });
  const activeWms = useMemo(() => watermarks.filter((w) => w.status === 'active'), [watermarks]);
  const selectedWm = useMemo(() => activeWms.find((w) => w.id === wmId) || null, [activeWms, wmId]);
  const typeTemplates = useMemo(
    () => allTemplates.filter((t) => t.document_type === docType && t.status === 'active'),
    [allTemplates, docType]
  );
  const currentTemplate = useMemo(
    () => typeTemplates.find((t) => t.id === templateId) || typeTemplates[0] || null,
    [typeTemplates, templateId]
  );

  const code = (sale?.id || '').substring(0, 8).toUpperCase();
  const data = useMemo(() => (sale ? saleToData(sale, settings, productMap) : {}), [sale, settings, productMap]);
  const meta = docMeta(docType);
  const effectiveTemplateId = currentTemplate?.id || '';

  // Pré-visualização idêntica ao PDF final (mesmo motor do Gerenciador).
  useEffect(() => {
    if (!open || !sale) return;
    let revoked = false;
    let prev = '';
    setPreviewing(true);
    buildPreviewUrl({ documentType: docType, data, templateId: effectiveTemplateId, watermark: selectedWm })
      .then(({ url }) => {
        if (revoked) { URL.revokeObjectURL(url); return; }
        prev = url;
        setPreviewUrl(url);
      })
      .catch(() => setPreviewUrl(''))
      .finally(() => setPreviewing(false));
    return () => {
      revoked = true;
      if (prev) URL.revokeObjectURL(prev);
      setPreviewUrl('');
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [open, docType, effectiveTemplateId, wmId, sale?.id]);

  if (!sale) return null;

  const track = (action, extra = {}) => {
    logEmission({
      documentType: docType,
      templateId: effectiveTemplateId || null,
      version: currentTemplate?.version || 1,
      watermark: selectedWm,
      module: 'PDV',
      user,
      entityId: sale.id,
      action,
      copies,
      scale,
      ...extra,
    });
  };

  const handlePrint = async () => {
    setBusy(true);
    try {
      await printPDF({ documentType: docType, data, templateId: effectiveTemplateId, watermark: selectedWm, copies, scale, module: 'PDV', user, entityId: sale.id });
      track('print');
      toast({ title: 'Enviando para impressão', description: `${meta?.label || docType}${selectedWm ? ` · ${selectedWm.name}` : ''}` });
    } catch (e) {
      toast({ title: 'Erro ao imprimir', description: String(e.message || e), variant: 'destructive' });
    } finally { setBusy(false); }
  };

  const handlePDF = async () => {
    setBusy(true);
    try {
      await generatePDF({ documentType: docType, data, templateId: effectiveTemplateId, watermark: selectedWm, fileName: `${docType}-${code}.pdf`, module: 'PDV', user, entityId: sale.id });
      track('generate');
      toast({ title: 'PDF gerado', description: `${meta?.label || docType} baixado` });
    } catch (e) {
      toast({ title: 'Erro ao gerar PDF', description: String(e.message || e), variant: 'destructive' });
    } finally { setBusy(false); }
  };

  const handleShare = async () => {
    setBusy(true);
    try {
      const { shared } = await sharePDF({ documentType: docType, data, templateId: effectiveTemplateId, watermark: selectedWm, fileName: `${docType}-${code}.pdf`, module: 'PDV', user, entityId: sale.id });
      track('share');
      toast({ title: shared ? 'Compartilhando PDF' : 'PDF baixado', description: shared ? 'Escolha o aplicativo para enviar.' : 'Compartilhamento não suportado — PDF baixado.' });
    } catch (e) {
      if (e?.name !== 'AbortError') toast({ title: 'Erro ao compartilhar', description: String(e.message || e), variant: 'destructive' });
    } finally { setBusy(false); }
  };

  const handlePreviewTab = () => {
    if (!previewUrl) {
      toast({ title: 'Aguardando pré-visualização', description: 'Aguarde o carregamento do documento.' });
      return;
    }
    setViewerOpen(true);
  };

  const paidSum = (sale.payments || []).reduce((s, p) => s + (Number(p.amount) || 0), 0);
  const remaining = Math.max(0, (sale.total || 0) - paidSum);
  const cashPay = (sale.payments || []).find((p) => p.method === 'cash');
  const change = cashPay ? (Number(cashPay.change) || 0) : 0;

  const handleEmail = () => {
    if (!sale.customer_email) { toast({ title: 'Sem e-mail', description: 'O cliente não possui e-mail cadastrado.', variant: 'destructive' }); return; }
    const subject = `Pedido #${code} — ${settings?.company_name || 'PDV'}`;
    const body = `Olá ${sale.customer_name || ''},\n\nSegue o resumo do seu pedido #${code}:\nTotal: ${fmt(sale.total)}\nPago: ${fmt(paidSum)}\n${remaining > 0 ? `Saldo pendente: ${fmt(remaining)}\n` : ''}Obrigado pela preferência!`;
    window.location.href = `mailto:${sale.customer_email}?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`;
    track('email');
    toast({ title: 'Abrindo cliente de e-mail', description: `Para: ${sale.customer_email}` });
  };

  const handleWhatsApp = () => {
    const phone = (sale.customer_phone || '').replace(/\D/g, '');
    if (!phone) { toast({ title: 'Sem telefone', description: 'O cliente não possui WhatsApp/celular cadastrado.', variant: 'destructive' }); return; }
    const msg = `*Pedido #${code}* — ${settings?.company_name || ''}\nTotal: ${fmt(sale.total)}\nPago: ${fmt(paidSum)}${remaining > 0 ? `\nSaldo: ${fmt(remaining)}` : ''}${change > 0 ? `\nTroco: ${fmt(change)}` : ''}\nObrigado!`;
    window.open(`https://wa.me/55${phone}?text=${encodeURIComponent(msg)}`, '_blank');
    track('whatsapp');
    toast({ title: 'Abrindo WhatsApp', description: `Para: ${phone}` });
  };

  const handleLogistics = () => {
    toast({ title: 'Pedido na Logística', description: 'O pedido já foi encaminhado para o módulo de Entregas.' });
    track('logistics');
  };

  return (
    <>
    <Dialog open={open} onOpenChange={(o) => !o && onClose()}>
      <DialogContent className="max-w-3xl max-h-[92vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Printer className="w-5 h-5" /> Impressão do Pedido
          </DialogTitle>
        </DialogHeader>

        <div className="grid md:grid-cols-2 gap-4">
          {/* Coluna esquerda: configurações */}
          <div className="space-y-3">
            {/* Resumo da venda */}
            <div className="rounded-lg border border-border p-3 space-y-1 text-sm">
              <div className="flex justify-between"><span className="text-muted-foreground">Venda nº</span><span className="font-bold">{code}</span></div>
              <div className="flex justify-between"><span className="text-muted-foreground">Cliente</span><span className="font-medium text-right">{sale.customer_name || 'Consumidor Final'}</span></div>
              <div className="flex justify-between"><span className="text-muted-foreground">Data</span><span>{new Date(sale.created_date || Date.now()).toLocaleString('pt-BR')}</span></div>
              <div className="flex justify-between"><span className="text-muted-foreground">Operador</span><span>{sale.operator_name || sale.seller || '—'}</span></div>
              <div className="flex justify-between"><span className="text-muted-foreground">Total</span><span className="font-bold">{fmt(sale.total)}</span></div>
            </div>

            {/* Documento a emitir */}
            <div>
              <p className="text-xs font-semibold text-muted-foreground uppercase mb-2">Documento a Emitir</p>
              {visibleDocs.length === 0 ? (
                <p className="text-xs text-muted-foreground text-center py-4">Nenhum modelo de PDF disponível no Gerenciador de Modelos PDF.</p>
              ) : (
                <div className="grid grid-cols-2 gap-2">
                  {visibleDocs.map((d) => (
                    <button
                      key={d.type}
                      onClick={() => { setDocType(d.type); setTemplateId(''); }}
                      className={`flex items-center gap-2 rounded-lg border p-2.5 text-sm transition ${docType === d.type ? 'border-green-600 bg-green-50 font-semibold' : 'border-border hover:bg-accent'}`}
                    >
                      <span className="text-base">{d.icon || '📄'}</span>
                      <span className="text-left leading-tight">{d.label}</span>
                      {docType === d.type && <CheckCircle2 className="w-4 h-4 text-green-600 ml-auto" />}
                    </button>
                  ))}
                </div>
              )}
            </div>

            {/* Modelo de PDF (vinculado ao Gerenciador) */}
            <div>
              <Label className="text-xs font-semibold text-muted-foreground uppercase mb-1.5 flex items-center gap-1.5">
                <FileText className="w-3.5 h-3.5" /> Modelo de PDF
              </Label>
              <div className="flex gap-2">
                <Select value={effectiveTemplateId} onValueChange={setTemplateId} disabled={typeTemplates.length === 0}>
                  <SelectTrigger className="flex-1">
                    <SelectValue placeholder="Padrão do Sistema" />
                  </SelectTrigger>
                  <SelectContent>
                    {typeTemplates.length === 0 && <SelectItem value={null} disabled>Padrão do Sistema</SelectItem>}
                    {typeTemplates.map((t) => (
                      <SelectItem key={t.id} value={t.id}>
                        {t.document_label || meta?.label || docType} (v{t.version}){t.is_published ? ' · publicado' : ''}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <Button asChild variant="outline" size="icon" title="Editar modelo no Gerenciador de Modelos PDF">
                  <Link to={`/pdf-template-management?doc=${docType}`} target="_blank"><Pencil className="w-4 h-4" /></Link>
                </Button>
              </div>
              <p className="text-[10px] text-muted-foreground mt-1 flex items-center gap-1">
                {currentTemplate ? (
                  <>Modelo cadastrado v{currentTemplate.version}{currentTemplate.is_published ? ' (publicado)' : ''} · {paperLabel(meta?.size)}
                  <RefreshCw className="w-3 h-3" /> usa sempre a versão mais recente</>
                ) : (
                  <>Padrão do Sistema · {paperLabel(meta?.size)} — clique no lápis para personalizar no Gerenciador</>
                )}
              </p>
            </div>

            {/* Marca d'água */}
            <div>
              <Label className="text-xs font-semibold text-muted-foreground uppercase mb-1.5 flex items-center gap-1.5">
                <Droplet className="w-3.5 h-3.5" /> Marca d'Água
              </Label>
              <Select value={wmId} onValueChange={setWmId}>
                <SelectTrigger className="w-full"><SelectValue placeholder="Sem marca d'água" /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="none">Sem marca d'água</SelectItem>
                  {activeWms.map((w) => (
                    <SelectItem key={w.id} value={w.id}>{w.name}{w.is_default ? ' (padrão)' : ''}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {/* Configurações de impressão */}
            <div className="rounded-lg border border-border p-3 space-y-2">
              <p className="text-xs font-semibold text-muted-foreground uppercase">Configurações de Impressão</p>
              <div className="grid grid-cols-2 gap-2">
                <div>
                  <Label className="text-xs">Formato</Label>
                  <Input value={paperLabel(meta?.size)} disabled className="h-8 text-xs bg-muted" />
                </div>
                <div>
                  <Label className="text-xs">Cópias</Label>
                  <Input type="number" min={1} max={20} value={copies} onChange={(e) => setCopies(Math.max(1, Math.min(20, Number(e.target.value) || 1)))} className="h-8 text-xs" />
                </div>
                <div className="col-span-2">
                  <Label className="text-xs">Escala de impressão (%)</Label>
                  <Input type="number" min={50} max={200} value={scale} onChange={(e) => setScale(Math.max(50, Math.min(200, Number(e.target.value) || 100)))} className="h-8 text-xs" />
                </div>
              </div>
              <p className="text-[10px] text-muted-foreground">O layout (margens, fontes, campos) segue o modelo selecionado. Cópias e escala são enviados à impressora.</p>
            </div>
          </div>

          {/* Coluna direita: pré-visualização idêntica */}
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <p className="text-xs font-semibold text-muted-foreground uppercase">Pré-visualização</p>
              {previewing && <Loader2 className="w-3.5 h-3.5 animate-spin text-muted-foreground" />}
            </div>
            <div className="rounded-lg border border-border bg-muted/30 h-[420px] overflow-hidden">
              {previewUrl ? (
                <PdfRenderer url={previewUrl} scale={1.2} />
              ) : (
                <div className="text-sm text-muted-foreground flex flex-col items-center gap-2">
                  {previewing ? <Loader2 className="w-6 h-6 animate-spin" /> : <Eye className="w-6 h-6" />}
                  <span>{previewing ? 'Gerando pré-visualização...' : 'Selecione um documento'}</span>
                </div>
              )}
            </div>
            <p className="text-[10px] text-muted-foreground text-center">Idêntica ao documento final — gerada pelo mesmo motor do Gerenciador de Modelos PDF.</p>
          </div>
        </div>

        {/* Botões de ação */}
        <div className="grid grid-cols-2 gap-2 pt-1">
          <Button onClick={handlePrint} className="bg-green-600 hover:bg-green-700 gap-2" disabled={busy}><Printer className="w-4 h-4" /> Imprimir</Button>
          <Button onClick={handlePDF} variant="outline" className="gap-2" disabled={busy}><FileText className="w-4 h-4" /> Gerar PDF</Button>
          <Button onClick={handlePreviewTab} variant="outline" className="gap-2" disabled={busy}><Eye className="w-4 h-4" /> Ampliar pré-visualização</Button>
          <Button onClick={handleEmail} variant="outline" className="gap-2"><Mail className="w-4 h-4" /> E-mail</Button>
          <Button onClick={handleShare} variant="outline" className="gap-2" disabled={busy}><Share2 className="w-4 h-4" /> Compartilhar</Button>
          <Button onClick={handleWhatsApp} variant="outline" className="gap-2"><MessageCircle className="w-4 h-4" /> WhatsApp</Button>
          {isDelivery && <Button onClick={handleLogistics} variant="secondary" className="gap-2"><Truck className="w-4 h-4" /> Logística</Button>}
        </div>

        <DialogFooter>
          <Button variant="ghost" onClick={onClose} className="gap-2 w-full" disabled={busy}><X className="w-4 h-4" /> Fechar</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
    <PdfViewerDialog open={viewerOpen} onClose={() => setViewerOpen(false)} url={previewUrl} fileName={`${docType}-${code}.pdf`} loading={previewing} />
    </>
  );
}