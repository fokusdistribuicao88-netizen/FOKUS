import React, { useMemo } from 'react';
import { Input } from '@/components/ui/input';
import { cn } from '@/lib/utils';

const BILLS = [200, 100, 50, 20, 10, 5, 2];
const COINS = [1, 0.5, 0.25, 0.1, 0.05];

export const ALL_DENOMS = [...BILLS, ...COINS];
export const formatBRL = (v) => `R$ ${(Number(v) || 0).toFixed(2).replace('.', ',')}`;

// Calcula o total a partir do objeto de contagem { "200": 3, "100": 2, ... }
export function computeTotal(counts) {
  return ALL_DENOMS.reduce((s, d) => s + d * (Number(counts?.[String(d)]) || 0), 0);
}

// Conerte um objeto de contagem para string JSON seguro
export function countsToString(counts) {
  return JSON.stringify(counts || {});
}

// Converte uma string JSON de contagem para objeto (com fallback)
export function parseCounts(str) {
  try { return JSON.parse(str || '{}') || {}; } catch { return {}; }
}

function DenomRow({ label, value, onChange, total }) {
  return (
    <div className="flex items-center gap-2">
      <span className="w-16 text-xs text-muted-foreground tabular-nums">{label}</span>
      <Input
        type="number"
        min="0"
        value={value ?? ''}
        onChange={(e) => onChange(e.target.value)}
        placeholder="0"
        className="h-7 w-20 text-sm"
      />
      <span className="ml-auto text-xs font-medium tabular-nums">{formatBRL(total)}</span>
    </div>
  );
}

/**
 * Contador de cédulas e moedas reutilizável.
 * props:
 *   counts  — objeto { "200": 3, ... }
 *   onCountsChange — (counts) => void
 *   compact — layout mais compacto (uma coluna)
 */
export default function BillCounter({ counts = {}, onCountsChange, compact = false }) {
  const setCount = (d, v) => onCountsChange({ ...counts, [String(d)]: v });

  const totalBills = useMemo(
    () => BILLS.reduce((s, d) => s + d * (Number(counts[String(d)]) || 0), 0),
    [counts]
  );
  const totalCoins = useMemo(
    () => COINS.reduce((s, d) => s + d * (Number(counts[String(d)]) || 0), 0),
    [counts]
  );
  const total = totalBills + totalCoins;

  if (compact) {
    return (
      <div className="space-y-1">
        {ALL_DENOMS.map((d) => {
          const isBill = BILLS.includes(d);
          return (
            <DenomRow
              key={d}
              label={formatBRL(d)}
              value={counts[String(d)]}
              onChange={(v) => setCount(d, v)}
              total={d * (Number(counts[String(d)]) || 0)}
            />
          );
        })}
        <div className="flex justify-between text-xs font-semibold pt-1 border-t border-border">
          <span>Total</span><span>{formatBRL(total)}</span>
        </div>
      </div>
    );
  }

  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
      <div className="rounded-lg border border-border p-2">
        <p className="text-xs font-medium text-muted-foreground mb-1">Cédulas</p>
        <div className="space-y-1">
          {BILLS.map((d) => (
            <DenomRow
              key={d}
              label={formatBRL(d)}
              value={counts[String(d)]}
              onChange={(v) => setCount(d, v)}
              total={d * (Number(counts[String(d)]) || 0)}
            />
          ))}
          <div className="flex justify-between text-xs font-semibold pt-1 border-t border-border">
            <span>Subtotal cédulas</span><span>{formatBRL(totalBills)}</span>
          </div>
        </div>
      </div>
      <div className="rounded-lg border border-border p-2">
        <p className="text-xs font-medium text-muted-foreground mb-1">Moedas</p>
        <div className="space-y-1">
          {COINS.map((d) => (
            <DenomRow
              key={d}
              label={formatBRL(d)}
              value={counts[String(d)]}
              onChange={(v) => setCount(d, v)}
              total={d * (Number(counts[String(d)]) || 0)}
            />
          ))}
          <div className="flex justify-between text-xs font-semibold pt-1 border-t border-border">
            <span>Subtotal moedas</span><span>{formatBRL(totalCoins)}</span>
          </div>
        </div>
      </div>
    </div>
  );
}

/**
 * Tabela de comparação entre a contagem de abertura e a de fechamento.
 * props:
 *   opening — objeto de contagem da abertura
 *   closing — objeto de contagem do fechamento
 */
export function BillCompareTable({ opening = {}, closing = {} }) {
  return (
    <div className="rounded-lg border border-border overflow-hidden">
      <table className="w-full text-xs">
        <thead className="bg-muted/50">
          <tr>
            <th className="text-left font-semibold px-2 py-1.5">Cédula/Moeda</th>
            <th className="text-center font-semibold px-2 py-1.5">Abertura</th>
            <th className="text-center font-semibold px-2 py-1.5">Fechamento</th>
            <th className="text-right font-semibold px-2 py-1.5">Diferença</th>
          </tr>
        </thead>
        <tbody>
          {ALL_DENOMS.map((d) => {
            const o = Number(opening[String(d)]) || 0;
            const c = Number(closing[String(d)]) || 0;
            const diff = c - o;
            const show = o || c;
            if (!show) return null;
            return (
              <tr key={d} className="border-t border-border">
                <td className="px-2 py-1.5 tabular-nums">{formatBRL(d)}</td>
                <td className="px-2 py-1.5 text-center tabular-nums">{o}</td>
                <td className="px-2 py-1.5 text-center tabular-nums">{c}</td>
                <td className={cn(
                  "px-2 py-1.5 text-right tabular-nums font-medium",
                  diff > 0 && "text-green-600",
                  diff < 0 && "text-red-600"
                )}>
                  {diff > 0 ? `+${diff}` : diff || ''}
                </td>
              </tr>
            );
          })}
        </tbody>
      </table>
    </div>
  );
}