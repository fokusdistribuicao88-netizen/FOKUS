import React, { useState, useMemo, useEffect } from 'react';
import { useQuery } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { CreditCard, Loader2, QrCode, UserCheck, Wallet } from 'lucide-react';
import { Checkbox } from '@/components/ui/checkbox';
import { Label } from '@/components/ui/label';
import {
  Select, SelectTrigger, SelectValue, SelectContent, SelectItem,
} from '@/components/ui/select';
import SaleSummary from './payment/SaleSummary';
import DeliverySection from './payment/DeliverySection';
import PaymentList from './payment/PaymentList';
import PaymentSummaryBar from './payment/PaymentSummaryBar';
import ConfirmSaleDialog from './payment/ConfirmSaleDialog';
import PixQRCodeDialog from './payment/PixQRCodeDialog';
import PayrollDiscountSection from './payment/PayrollDiscountSection';
import { methodDef, fmt } from './payment/paymentMethods';
import { findEmployeeForCustomer, competenceOptions } from '@/lib/employeePurchaseSync';

const MONTH_LABELS = ['Jan', 'Fev', 'Mar', 'Abr', 'Mai', 'Jun', 'Jul', 'Ago', 'Set', 'Out', 'Nov', 'Dez'];
function competenceLabel(value) {
  if (!value) return '—';
  const [y, m] = value.split('-');
  return `${MONTH_LABELS[Number(m) - 1] || ''}/${y}`;
}

const newPayment = (method, amount) => ({
  method, amount, received: '', installments: 1,
  installment_count: 1, entry_amount: 0, interest_rate: 0, financial_discount: 0,
  card_operator: '', card_brand: '', card_auth: '',
  check_number: '', check_bank: '', check_date: '',
  dueDate: new Date().toISOString().slice(0, 10),
});

const newDelivery = (customer) => ({
  type: 'retirada', address: customer?.address || '', date: '', time: '',
  carrier: '', driver: '', freight: 0, notes: '',
});

export default function PaymentDialog({
  open, onClose, cart, customer, gross, discount, notes, total,
  canCredit, canPartial, onConfirm, onPrePrint, operatorName, busy,
  headerInfo, hideDelivery, hidePayrollDiscount, receiptMode,
  initialDelivery,
}) {
  const [payments, setPayments] = useState([newPayment('cash', total)]);
  const [delivery, setDelivery] = useState(initialDelivery || newDelivery(customer));
  const [confirmOpen, setConfirmOpen] = useState(false);
  const [pixOpen, setPixOpen] = useState(false);
  const [pixConfirmed, setPixConfirmed] = useState(false);
  const [payrollEnabled, setPayrollEnabled] = useState(false);
  const [competenceMode, setCompetenceMode] = useState('current');
  const [competenceValue, setCompetenceValue] = useState(() => competenceOptions()[0].value);
  const [crediarioPayroll, setCrediarioPayroll] = useState(false);
  const [crediarioCompetence, setCrediarioCompetence] = useState(() => competenceOptions()[0].value);

  const { data: settings } = useQuery({
    queryKey: ['settings'],
    queryFn: async () => {
      const list = await base44.entities.Settings.list('-updated_date', 1);
      return list[0] || null;
    },
  });

  const { data: employees = [] } = useQuery({
    queryKey: ['employees'],
    queryFn: () => base44.entities.Employee.list(),
    staleTime: 60 * 1000,
  });

  const matchedEmployee = useMemo(() => {
    if (customer?._isEmployee) return customer;
    return findEmployeeForCustomer(customer, employees);
  }, [customer, employees]);

  useEffect(() => {
    if (open) {
      setPayments([newPayment('cash', total)]);
      setDelivery(initialDelivery || newDelivery(customer));
      setConfirmOpen(false);
      setPixConfirmed(false);
      setPayrollEnabled(false);
      setCompetenceMode('current');
      setCompetenceValue(competenceOptions()[0].value);
      setCrediarioPayroll(false);
      setCrediarioCompetence(competenceOptions()[0].value);
    }
  }, [open, total, customer, initialDelivery]);

  // Atualiza competência quando o modo muda
  useEffect(() => {
    const opts = competenceOptions();
    const opt = opts.find((o) => o.key === competenceMode);
    if (opt && competenceMode !== 'other') setCompetenceValue(opt.value);
  }, [competenceMode]);

  const freight = useMemo(
    () => (delivery.type && delivery.type !== 'retirada' ? Number(delivery.freight) || 0 : 0),
    [delivery],
  );
  const isOnSite = delivery.type === 'empresa' && delivery.receipt_mode === 'on_site';
  const finalTotal = useMemo(() => total + freight, [total, freight]);
  const paid = useMemo(() => payments.reduce((s, p) => s + (Number(p.amount) || 0), 0), [payments]);
  const remaining = useMemo(() => Math.max(0, finalTotal - paid), [finalTotal, paid]);
  const change = useMemo(() => {
    const cashRows = payments.filter((p) => p.method === 'cash' && p.received);
    if (!cashRows.length) return 0;
    const receivedSum = cashRows.reduce((s, p) => s + (Number(p.received) || 0), 0);
    const cashAmt = cashRows.reduce((s, p) => s + (Number(p.amount) || 0), 0);
    return Math.max(0, receivedSum - cashAmt);
  }, [payments]);

  const complete = paid >= finalTotal - 0.001;
  const partial = !complete && paid > 0;
  const valid = isOnSite || payrollEnabled || complete || (canPartial && paid > 0);

  const hasPix = payments.some((p) => p.method === 'pix' && (Number(p.amount) || 0) > 0);
  const pixAmount = payments.find((p) => p.method === 'pix')?.amount || finalTotal;

  // Convênio para funcionário: quando "convenio" é selecionado e o cliente é funcionário
  const hasCrediario = payments.some((p) => p.method === 'convenio' && (Number(p.amount) || 0) > 0);
  const showCrediarioEmployee = !!matchedEmployee && hasCrediario && !payrollEnabled;

  const handleConfirm = () => {
    setConfirmOpen(false);
    if (isOnSite) {
      onConfirm([], { ...delivery, freight }, finalTotal, { enabled: false, onSite: true });
      return;
    }
    if (payrollEnabled && matchedEmployee) {
      onConfirm([], { ...delivery, freight }, finalTotal, {
        enabled: true,
        employee: matchedEmployee,
        competence: competenceValue,
      });
      return;
    }
    if (showCrediarioEmployee) {
      onConfirm([], { ...delivery, freight }, finalTotal, {
        enabled: true,
        type: 'convenio',
        employee: matchedEmployee,
        competence: crediarioPayroll ? crediarioCompetence : null,
      });
      return;
    }
    const enriched = payments.map((p) => ({
      method: p.method,
      label: methodDef(p.method)?.label || p.method,
      amount: Number(p.amount) || 0,
      received: p.method === 'cash' ? Number(p.received) || Number(p.amount) || 0 : undefined,
      change: p.method === 'cash' ? Math.max(0, (Number(p.received) || 0) - (Number(p.amount) || 0)) : 0,
      installments: p.method === 'credit_card' ? Math.max(1, Number(p.installments) || 1) : 1,
      card_operator: p.card_operator || '',
      card_brand: p.card_brand || '',
      card_auth: p.card_auth || '',
      installment_count: Math.max(1, Number(p.installment_count) || 1),
      entry_amount: Number(p.entry_amount) || 0,
      interest_rate: Number(p.interest_rate) || 0,
      financial_discount: Number(p.financial_discount) || 0,
      dueDate: p.dueDate || new Date().toISOString().slice(0, 10),
      check_number: p.check_number || '',
      check_bank: p.check_bank || '',
      check_date: p.check_date || '',
      category: p.category || '',
      cost_center: p.cost_center || '',
      notes: p.notes || '',
      confirmed: p.method === 'pix' ? pixConfirmed : true,
    }));
    onConfirm(enriched, { ...delivery, freight }, finalTotal);
  };

  const handlePrePrint = () => {
    const preSale = {
      id: '',
      items: cart.map((it) => ({
        product_id: it.product_id,
        product_name: it.product_name,
        quantity: it.quantity,
        unit_price: it.unit_price,
        subtotal: it.subtotal,
      })),
      customer_name: customer?.name || 'Consumidor Final',
      customer_address: customer?.address || delivery?.address || '',
      city: customer?.city || '',
      state: customer?.state || '',
      created_date: new Date().toISOString(),
      operator_name: operatorName || '—',
      status: 'Conferência',
      discount,
      freight,
      total: finalTotal,
      payments: payments.map((p) => ({
        method: p.method,
        label: methodDef(p.method)?.label || p.method,
        amount: Number(p.amount) || 0,
      })),
      driver_name: '',
      carrier: delivery?.carrier || '',
    };
    const isDelivery = !!(delivery?.type && delivery.type !== 'retirada');
    onPrePrint(preSale, isDelivery);
  };

  return (
    <>
      <Dialog open={open} onOpenChange={(o) => !o && onClose()}>
        <DialogContent className="max-w-3xl max-h-[92vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <CreditCard className="w-5 h-5" /> {receiptMode ? 'Recebimento no Local' : 'Pagamento'}
            </DialogTitle>
          </DialogHeader>

          <div className="space-y-3">
            {headerInfo}

            <SaleSummary
              cart={cart} customer={customer} gross={gross} discount={discount}
              freight={freight} total={finalTotal} paid={paid} remaining={remaining}
            />

            {!hideDelivery && (
              <DeliverySection delivery={delivery} setDelivery={setDelivery} />
            )}

            {!hidePayrollDiscount && matchedEmployee && (
              <PayrollDiscountSection
                employee={matchedEmployee}
                checked={payrollEnabled}
                onToggle={(v) => { setPayrollEnabled(v); if (!v) { setCompetenceMode('current'); setCompetenceValue(competenceOptions()[0].value); } }}
                competenceMode={competenceMode}
                onModeChange={setCompetenceMode}
                competenceValue={competenceValue}
                onCompetenceChange={setCompetenceValue}
              />
            )}

            {isOnSite && (
              <div className="rounded-lg border-2 border-amber-300 bg-amber-50 p-3 text-sm text-amber-900 space-y-1">
                <p className="font-semibold flex items-center gap-2">
                  <Wallet className="w-4 h-4" /> Recebimento no Local
                </p>
                <p className="text-xs text-amber-800/80">
                  O valor de <strong>{fmt(finalTotal)}</strong> será recebido pelo entregador no endereço do cliente.
                  Nenhum pagamento é registrado agora — o pedido entra na logística destacado como <strong>💰 Receber no Local</strong>
                  {' '}e o recebimento será confirmado no momento da entrega.
                </p>
              </div>
            )}

            {!payrollEnabled && !isOnSite && (
              <div>
                <p className="text-xs font-semibold text-muted-foreground uppercase mb-2">
                  Formas de Recebimento
                </p>
                <PaymentList
                  payments={payments} setPayments={setPayments}
                  canCredit={canCredit} remaining={remaining}
                />
              </div>
            )}

            {!payrollEnabled && !isOnSite && (
              <PaymentSummaryBar
                total={finalTotal} paid={paid} remaining={remaining}
                change={change} canPartial={canPartial}
              />
            )}

            {showCrediarioEmployee && (
              <div className="rounded-lg border-2 border-amber-300 bg-amber-50 p-3 space-y-3">
                <div>
                  <p className="text-sm font-semibold flex items-center gap-2 text-amber-900">
                    <UserCheck className="w-4 h-4" /> Convênio — Funcionário: {matchedEmployee?.name}
                  </p>
                  <p className="text-xs text-amber-800/80 mt-0.5">
                    O valor de <strong>{fmt(finalTotal)}</strong> será lançado como dívida do funcionário. Sem recebimento no caixa agora.
                  </p>
                </div>
                <label className="flex items-center gap-2.5 cursor-pointer">
                  <Checkbox checked={crediarioPayroll} onCheckedChange={(v) => setCrediarioPayroll(v === true)} />
                  <span className="text-sm font-medium text-amber-900">Descontar na folha de pagamento?</span>
                </label>
                {crediarioPayroll && (
                  <div className="pl-8 space-y-1.5">
                    <Label className="text-xs">Competência do desconto</Label>
                    <Select value={crediarioCompetence} onValueChange={setCrediarioCompetence}>
                      <SelectTrigger><SelectValue /></SelectTrigger>
                      <SelectContent>
                        {competenceOptions().map((o) => (
                          <SelectItem key={o.key} value={o.value}>{o.label} — {competenceLabel(o.value)}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <p className="text-xs text-amber-800/80">
                      Será descontado automaticamente na folha de <strong>{matchedEmployee?.name}</strong> na competência {competenceLabel(crediarioCompetence)}.
                    </p>
                  </div>
                )}
                {!crediarioPayroll && (
                  <p className="text-xs text-amber-800/80 pl-8">
                    A dívida ficará em aberto. O funcionário poderá quitá-la posteriormente ou ser vinculada à folha manualmente.
                  </p>
                )}
              </div>
            )}

            {payrollEnabled && (
              <div className="rounded-lg border border-blue-200 bg-blue-50 p-3 text-sm text-blue-900">
                <p className="font-semibold">Desconto em folha — {fmt(finalTotal)}</p>
                <p className="text-xs text-blue-800/80">
                  Será lançado como compra para desconto na folha de <strong>{matchedEmployee?.name}</strong> ({competenceValue}). Sem recebimento no caixa.
                </p>
              </div>
            )}

            {hasPix && (
              <Button
                variant="outline"
                onClick={() => setPixOpen(true)}
                className="w-full gap-2 border-blue-300 text-blue-700 hover:bg-blue-50 dark:border-blue-900 dark:text-blue-400 dark:hover:bg-blue-950/40"
              >
                <QrCode className="w-4 h-4" /> Gerar QR Code PIX ({fmt(pixAmount)})
              </Button>
            )}

            {partial && canPartial && (
              <p className="text-xs text-amber-600 text-center">
                Recebimento parcial autorizado — o saldo de {remaining.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })} será gerado em Convênio.
              </p>
            )}
          </div>

          <DialogFooter className="flex-col sm:flex-row gap-2">
            <Button variant="outline" onClick={onClose} disabled={busy} className="w-full sm:w-auto">
              Cancelar
            </Button>
            <Button
              onClick={() => (isOnSite || payrollEnabled || showCrediarioEmployee) ? handleConfirm() : setConfirmOpen(true)}
              disabled={!valid || busy}
              className="bg-green-600 hover:bg-green-700 gap-2 w-full sm:w-auto"
            >
              {busy ? <><Loader2 className="w-4 h-4 animate-spin" /> Processando...</> : isOnSite ? 'Finalizar — Receber no local' : payrollEnabled ? 'Lançar desconto em folha' : showCrediarioEmployee ? 'Lançar convênio' : receiptMode ? 'Revisar e confirmar recebimento' : 'Revisar e finalizar'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <ConfirmSaleDialog
        open={confirmOpen}
        onClose={() => setConfirmOpen(false)}
        onConfirm={handleConfirm}
        onPrint={handlePrePrint}
        busy={busy}
        cart={cart} customer={customer} gross={gross} discount={discount} freight={freight}
        total={finalTotal} payments={payments} paid={paid} remaining={remaining}
        change={change} delivery={delivery} canPartial={canPartial}
      />

      <PixQRCodeDialog
        open={pixOpen}
        onClose={() => setPixOpen(false)}
        amount={pixAmount}
        settings={settings}
        onConfirm={() => setPixConfirmed(true)}
      />
    </>
  );
}