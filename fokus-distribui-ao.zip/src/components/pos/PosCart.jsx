import React, { useRef, useEffect } from 'react';
import { Trash2, Plus, Minus, User, X } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import {
  Select, SelectTrigger, SelectValue, SelectContent, SelectItem } from
'@/components/ui/select';
import CustomerPicker from '@/components/customers/CustomerPicker';

const fmt = (v) => `R$ ${(Number(v) || 0).toFixed(2).replace('.', ',')}`;

export default function PosCart({
  cart, setCart, customers, customer, setCustomer,
  gross, discount, setDiscount, total, canDiscount, notes, setNotes,
  priceTableId, setPriceTableId, canEditPrice, onPriceEdit, priceTableOptions = [],
  employees = []
}) {
  const updateQty = (idx, delta) => {
    setCart((prev) => prev.map((it, i) => {
      if (i !== idx) return it;
      const q = Math.max(1, it.quantity + delta);
      return { ...it, quantity: q, subtotal: q * it.unit_price };
    }));
  };
  const updatePrice = (idx, val) => {
    const v = Math.max(0, Number(val) || 0);
    setCart((prev) => prev.map((it, i) => i === idx ? { ...it, unit_price: v, subtotal: it.quantity * v } : it));
    onPriceEdit?.(cart[idx]?.product_id);
  };
  const removeItem = (idx) => setCart((prev) => prev.filter((_, i) => i !== idx));

  const totalItems = cart.reduce((s, i) => s + i.quantity, 0);
  const scrollRef = useRef(null);
  const prevCount = useRef(0);

  // Rola automaticamente até o último item quando um novo produto é adicionado
  useEffect(() => {
    if (cart.length > prevCount.current && scrollRef.current) {
      scrollRef.current.scrollTo({ top: scrollRef.current.scrollHeight, behavior: 'smooth' });
    }
    prevCount.current = cart.length;
  }, [cart.length]);

  return (
    <div className="flex flex-col flex-1 min-h-0">
      {/* Cliente */}
      <div className="p-3 border-b border-border">
        <div className="flex items-center gap-2">
          <User className="w-4 h-4 text-muted-foreground shrink-0" />
          <CustomerPicker
            customers={customers}
            employees={employees}
            onSelect={(c) => setCustomer(c || null)}
            selectedId={customer?.id || null}
            allowConsumerFinal
            consumerFinalLabel="Consumidor Final"
            triggerVariant="select"
            triggerLabel="Consumidor Final"
            triggerClassName="h-9" />
          
        </div>
        {customer &&
        <div className="mt-2 text-xs space-y-0.5">
            {customer._isEmployee && (
              <p className="font-semibold text-blue-700">FUNCIONÁRIO: {customer.name}</p>
            )}
            {customer.cpf_cnpj && <p className="text-muted-foreground">CPF/CNPJ: {customer.cpf_cnpj}</p>}
            {customer.phone && <p className="text-muted-foreground">Telefone: {customer.phone}</p>}
            {!customer._isEmployee && Number(customer.credit_limit) > 0 && (() => {
              const limit = Number(customer.credit_limit);
              const over = total > limit;
              const remaining = Math.max(0, limit - total);
              return (
                <div className={`mt-1 rounded-md border px-2 py-1.5 text-xs ${over ? 'border-red-300 bg-red-50 text-red-700' : 'border-emerald-200 bg-emerald-50 text-emerald-700'}`}>
                  <div className="flex items-center justify-between font-semibold">
                    <span>Limite: {fmt(limit)}</span>
                    <span>{over ? 'EXCEDIDO' : 'Disponível: ' + fmt(remaining)}</span>
                  </div>
                  <div className="mt-0.5 opacity-80">Total da venda: {fmt(total)}</div>
                </div>
              );
            })()}
          </div>
        }
      </div>

      {/* Cabeçalho fixo das colunas */}
      {cart.length > 0 &&
      <div className="hidden sm:grid px-3 py-1.5 border-b border-border bg-muted/40 text-[10px] font-semibold uppercase tracking-wide text-muted-foreground grid-cols-12 gap-1 select-none">
          <span className="col-span-6">Produto</span>
          <span className="col-span-2 text-center">Qtd</span>
          <span className="col-span-2 text-right">Unitário</span>
          <span className="col-span-1 text-right">Subtotal</span>
          <span className="col-span-1 text-center">Ação</span>
        </div>
      }

      {/* Itens */}
      <div ref={scrollRef} className="flex-1 overflow-y-auto scroll-smooth p-2 space-y-2 min-h-0">
        {cart.length === 0 &&
        <div className="text-center text-sm text-muted-foreground py-20">
            Carrinho vazio. Selecione produtos para iniciar a venda.
          </div>
        }
        {cart.map((it, idx) =>
        <div key={idx} className="rounded-lg border border-border p-2">
            <div className="flex items-start justify-between gap-2">
              <span className="text-sm font-medium leading-tight">{it.product_name}</span>
              <button onClick={() => removeItem(idx)} className="text-red-500 hover:text-red-700">
                <X className="w-4 h-4" />
              </button>
            </div>
            <div className="flex items-center justify-between mt-2 gap-2">
              <div className="flex items-center gap-1">
                <Button size="icon" variant="outline" className="h-7 w-7" onClick={() => updateQty(idx, -1)}>
                  <Minus className="w-3 h-3" />
                </Button>
                <Input
                type="number"
                value={it.quantity}
                onChange={(e) => updateQty(idx, Number(e.target.value) - it.quantity)}
                className="h-7 w-14 text-center px-1" />
              
                <Button size="icon" variant="outline" className="h-7 w-7" onClick={() => updateQty(idx, 1)}>
                  <Plus className="w-3 h-3" />
                </Button>
              </div>
              <div className="text-right">
                {canEditPrice ?
              <Input
                type="number"
                value={it.unit_price}
                onChange={(e) => updatePrice(idx, e.target.value)}
                className="h-7 w-20 text-right text-sm px-1" /> :


              <span className="text-sm">{fmt(it.unit_price)}</span>
              }
                <p className="text-sm font-bold">{fmt(it.subtotal)}</p>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Resumo */}
      <div className="border-t border-border p-3 space-y-2">
        <div className="flex items-center gap-2">
          <span className="text-xs text-muted-foreground">Tabela</span>
          <Select value={priceTableId} onValueChange={setPriceTableId} disabled={!canEditPrice}>
            <SelectTrigger className="h-8 text-xs flex-1"><SelectValue /></SelectTrigger>
            <SelectContent>
              {priceTableOptions.map((o) =>
              <SelectItem key={o.value} value={o.value}>{o.label}</SelectItem>
              )}
            </SelectContent>
          </Select>
        </div>
        <Input
          placeholder="Observações da venda"
          value={notes}
          onChange={(e) => setNotes(e.target.value)}
          className="h-8 text-xs" />
        
        <div className="flex items-center gap-2">
          <span className="text-xs text-muted-foreground whitespace-nowrap">Desconto</span>
          <Input
            type="number"
            value={discount}
            onChange={(e) => setDiscount(Math.max(0, Number(e.target.value) || 0))}
            disabled={!canDiscount}
            className="h-8 text-sm"
            placeholder="0,00" />
          
        </div>
        <div className="space-y-1 pt-1">
          <div className="flex justify-between text-sm text-muted-foreground">
            <span>Itens: {totalItems}</span><span>Subtotal: {fmt(gross)}</span>
          </div>
          {discount > 0 &&
          <div className="flex justify-between text-sm text-red-600">
              <span>Desconto</span><span>-{fmt(discount)}</span>
            </div>
          }
          <div className="flex justify-between items-center pt-1 border-t border-border">
            <span className="font-semibold">Total</span>
            <span className="text-xl font-bold text-blue-700">{fmt(total)}</span>
          </div>
        </div>
      </div>
    </div>);

}