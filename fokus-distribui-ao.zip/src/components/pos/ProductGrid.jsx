import React, { useState, useMemo } from 'react';
import { Search, Barcode } from 'lucide-react';
import { Input } from '@/components/ui/input';
import {
  Select, SelectTrigger, SelectValue, SelectContent, SelectItem } from
'@/components/ui/select';
import QuantityPromptDialog from '@/components/orders/QuantityPromptDialog';

const fmt = (v) => `R$ ${(Number(v) || 0).toFixed(2).replace('.', ',')}`;

export default function ProductGrid({ products, onAdd, priceOf }) {
  const [q, setQ] = useState('');
  const [cat, setCat] = useState('all');
  const [brand, setBrand] = useState('all');
  const [pending, setPending] = useState(null);

  const categories = useMemo(
    () => [...new Set(products.map((p) => p.category).filter(Boolean))].sort(),
    [products]
  );
  const brands = useMemo(
    () => [...new Set(products.map((p) => p.brand).filter(Boolean))].sort(),
    [products]
  );

  const filtered = useMemo(() => {
    const s = q.trim().toLowerCase();
    return products.filter((p) => {
      if (p.status === 'inactive') return false;
      if (cat !== 'all' && p.category !== cat) return false;
      if (brand !== 'all' && p.brand !== brand) return false;
      if (s) {
        const hay = [p.name, p.code, p.brand].filter(Boolean).join(' ').toLowerCase();
        if (!hay.includes(s)) return false;
      }
      return true;
    });
  }, [products, q, cat, brand]);

  const priceOfFn = typeof priceOf === 'function' ? priceOf : (p) => p.price_promo ? p.price_promo : p.price ?? 0;

  return (
    <div className="flex flex-col h-full">
      <div className="space-y-2 mb-3">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input
            autoFocus
            placeholder="Buscar por nome, código de barras, marca..."
            value={q}
            onChange={(e) => setQ(e.target.value)}
            className="pl-9 h-11 text-base" />
          
        </div>
        <div className="grid grid-cols-2 gap-2">
          <Select value={cat} onValueChange={setCat}>
            <SelectTrigger className="h-9"><SelectValue placeholder="Categoria" /></SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Todas categorias</SelectItem>
              {categories.map((c) => <SelectItem key={c} value={c}>{c}</SelectItem>)}
            </SelectContent>
          </Select>
          <Select value={brand} onValueChange={setBrand}>
            <SelectTrigger className="h-9"><SelectValue placeholder="Marca" /></SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Todas marcas</SelectItem>
              {brands.map((b) => <SelectItem key={b} value={b}>{b}</SelectItem>)}
            </SelectContent>
          </Select>
        </div>
      </div>

      <div className="flex-1 overflow-y-auto grid grid-cols-2 sm:grid-cols-3 xl:grid-cols-4 2xl:grid-cols-5 gap-2.5 pt-2 pr-1 pb-4 pl-1">
        {filtered.length === 0 &&
        <div className="col-span-full text-center text-sm text-muted-foreground py-10">
            <Barcode className="w-8 h-8 mx-auto mb-2 opacity-40" />
            Nenhum produto encontrado.
          </div>
        }
        {filtered.map((p) => {
          const stock = p.stock_quantity;
          const out = p.in_stock === false || stock === 0;
          const promo = !!p.price_promo;
          return (
            <button
              key={p.id}
              onClick={() => setPending(p)}
              disabled={out}
              className={`flex flex-col text-left p-2 sm:p-2.5 rounded-xl border transition-all ${
              out ?
              'border-border bg-muted/40 opacity-60 cursor-not-allowed' :
              'border-border bg-card hover:border-blue-500 hover:shadow-md active:scale-[0.98]'}`
              }>

              <div className="aspect-square sm:aspect-[5/4] rounded-lg bg-muted mb-2 overflow-hidden flex items-center justify-center">
                {p.image_url ?
                <img src={p.image_url} alt={p.name} className="w-full h-full object-cover" /> :

                <span className="text-2xl font-bold text-muted-foreground">{(p.name || '?')[0]}</span>
                }
              </div>
              <span className="text-xs font-medium line-clamp-2 leading-tight min-h-[2rem]">{p.name}</span>
              <div className="flex items-center justify-between mt-1">
                {promo &&
                <span className="text-[10px] text-muted-foreground line-through">{fmt(p.price)}</span>
                }
                <span className={`text-sm font-bold ${promo ? 'text-green-600' : 'text-blue-700'}`}>
                  {fmt(priceOfFn(p))}
                </span>
              </div>
              <span className={`text-[10px] mt-0.5 ${out ? 'text-red-500' : 'text-muted-foreground'}`}>
                {out ? 'Sem estoque' : `Estoque: ${stock ?? '—'} ${p.unit_type || ''}`}
              </span>
            </button>);

        })}
      </div>

      <QuantityPromptDialog
        open={!!pending}
        product={pending}
        unitPrice={pending ? priceOfFn(pending) : 0}
        onConfirm={(qty) => { onAdd(pending, qty); setPending(null); }}
        onCancel={() => setPending(null)}
      />
    </div>);

}