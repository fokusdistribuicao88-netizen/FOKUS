import React from 'react';
import { ShoppingCart } from 'lucide-react';
import { Button } from '@/components/ui/button';

const fmt = (v) => `R$ ${(Number(v) || 0).toFixed(2).replace('.', ',')}`;

export default function PosSaleSuccessCard({ sale, onPrint, onClose }) {
  if (!sale) return null;
  return (
    <div className="fixed bottom-20 right-4 lg:bottom-4 z-50 bg-card rounded-xl border border-green-500 shadow-lg p-3 max-w-xs">
      <p className="text-sm font-semibold text-green-700 mb-1">Venda concluída!</p>
      <p className="text-xs text-muted-foreground mb-2">Venda #{(sale.id || '').substring(0, 8).toUpperCase()} — {fmt(sale.total)}</p>
      <div className="flex gap-2">
        <Button size="sm" variant="outline" className="gap-1" onClick={onPrint}>
          <ShoppingCart className="w-3 h-3" /> Imprimir
        </Button>
        <Button size="sm" variant="ghost" onClick={onClose}>Fechar</Button>
      </div>
    </div>
  );
}