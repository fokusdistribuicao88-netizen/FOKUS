import React, { useState } from 'react';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { useAuth } from '@/lib/AuthContext';
import { useToast } from '@/components/ui/use-toast';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Loader2, Lock, Unlock, ArrowDownCircle, ArrowUpCircle, Printer, Trash2, FileText } from 'lucide-react';
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter,
} from '@/components/ui/dialog';
import { generatePDF } from '@/lib/pdfService';
import { cashCloseToSections, cashSessionToSections } from '@/lib/pdfAdapters';
import CloseCashDialog from '@/components/pos/CloseCashDialog';
import BillCounter, { computeTotal, countsToString } from '@/components/pos/BillCounter';
import { logActivity } from '@/lib/activityLog';

const fmt = (v) => `R$ ${(Number(v) || 0).toFixed(2).replace('.', ',')}`;
const sumMov = (movements, type, excludeOpening = false) =>
  (movements || [])
    .filter((m) => m.type === type && !(excludeOpening && m.description === 'Abertura de caixa'))
    .reduce((s, m) => s + (Number(m.amount) || 0), 0);

export default function CashControl({ canCash, settings }) {
  const { user } = useAuth();
  const { toast } = useToast();
  const qc = useQueryClient();
  const [openCounts, setOpenCounts] = useState({});
  const [openNotes, setOpenNotes] = useState('');
  const [dlg, setDlg] = useState(null); // { type: 'sangria'|'suprimento' }
  const [mvDesc, setMvDesc] = useState('');
  const [mvAmt, setMvAmt] = useState('');
  const [closeOpen, setCloseOpen] = useState(false);
  const openTotal = computeTotal(openCounts);

  const { data: sessions = [], isLoading } = useQuery({
    queryKey: ['cashRegisters'],
    queryFn: () => base44.entities.CashRegister.list('-opening_date'),
  });
  const active = sessions.find((s) => s.status === 'open' && s.operator_email === user?.email);

  const openCash = async () => {
    const total = computeTotal(openCounts);
    if (total <= 0) {
      toast({ title: 'Informe a contagem inicial', description: 'Conte as cédulas e moedas do fundo de caixa.', variant: 'destructive' });
      return;
    }
    try {
      await base44.entities.CashRegister.create({
        operator_name: user?.full_name || user?.email || 'Operador',
        operator_email: user?.email || '',
        opening_date: new Date().toISOString(),
        opening_amount: total,
        opening_bill_count: countsToString(openCounts),
        status: 'open',
        movements: [{ type: 'suprimento', amount: total, description: 'Abertura de caixa', date: new Date().toISOString() }],
        sales_ids: [], total_sales: 0, sales_count: 0, totals_by_method: '{}',
      });
      setOpenCounts({}); setOpenNotes('');
      qc.invalidateQueries({ queryKey: ['cashRegisters'] });
      logActivity({
        action: 'pos_cash_open',
        description: `Abertura de caixa — Fundo inicial: ${fmt(total)}`,
        user, entityType: 'CashRegister',
      });
      toast({ title: 'Caixa aberto', description: `Fundo inicial: ${fmt(total)}` });
    } catch (e) {
      toast({ title: 'Erro ao abrir caixa', description: String(e.message || e), variant: 'destructive' });
    }
  };

  const addMovement = async () => {
    if (!active || !dlg) return;
    const amt = Number(mvAmt) || 0;
    if (amt <= 0) return;
    try {
      const movements = [...(active.movements || []), { type: dlg.type, amount: amt, description: mvDesc || '', date: new Date().toISOString() }];
      await base44.entities.CashRegister.update(active.id, { movements });
      setDlg(null); setMvDesc(''); setMvAmt('');
      qc.invalidateQueries({ queryKey: ['cashRegisters'] });
      toast({ title: dlg.type === 'sangria' ? 'Sangria registrada' : 'Suprimento registrado' });
    } catch (e) {
      toast({ title: 'Erro', description: String(e.message || e), variant: 'destructive' });
    }
  };

  const confirmClose = async (data) => {
    if (!active) return;
    try {
      const updated = await base44.entities.CashRegister.update(active.id, {
        status: 'closed',
        closing_date: new Date().toISOString(),
        closing_amount: data.counted_amount,
        expected_cash: data.expected_cash,
        difference: data.difference,
        difference_notes: data.difference_notes,
        bill_count: data.bill_count,
        closed_by_name: user?.full_name || user?.email || active.operator_name,
      });
      // Gera o PDF automaticamente (modelo central do sistema)
      try { const r = cashCloseToSections({ ...updated }, settings); await generatePDF({ documentType: 'cash_close', data: r.data, sections: r.sections, module: 'PDV', user, entityId: updated.id, fileName: `fechamento-caixa-${(updated.id || '').substring(0, 8).toUpperCase()}.pdf` }); } catch { /* best-effort */ }
      logActivity({
        action: 'pos_cash_close',
        description: `Fechamento de caixa #${(active.id || '').substring(0, 8).toUpperCase()} — Diferença: ${fmt(data.difference)}`,
        user, entityType: 'CashRegister', entityId: active.id,
      });
      qc.invalidateQueries({ queryKey: ['cashRegisters'] });
      toast({
        title: 'Caixa fechado',
        description: `Diferença: ${fmt(data.difference)}${Math.abs(data.difference) < 0.005 ? ' (conferido)' : ''}`,
      });
      setCloseOpen(false);
    } catch (e) {
      toast({ title: 'Erro ao fechar', description: String(e.message || e), variant: 'destructive' });
    }
  };

  const reprintClose = async (s) => {
    try { const r = cashCloseToSections(s, settings); await generatePDF({ documentType: 'cash_close', data: r.data, sections: r.sections, module: 'PDV', user, entityId: s.id, fileName: `fechamento-caixa-${(s.id || '').substring(0, 8).toUpperCase()}.pdf` }); }
    catch (e) { toast({ title: 'Erro ao gerar PDF', description: String(e.message || e), variant: 'destructive' }); }
  };

  const deleteSession = async (s) => {
    if (!confirm('Excluir este registro de fechamento?')) return;
    try {
      await base44.entities.CashRegister.delete(s.id);
      qc.invalidateQueries({ queryKey: ['cashRegisters'] });
      toast({ title: 'Registro excluído' });
    } catch (e) {
      toast({ title: 'Erro ao excluir', description: String(e.message || e), variant: 'destructive' });
    }
  };

  if (!canCash) {
    return (
      <div className="text-center text-sm text-muted-foreground py-10">
        <Lock className="w-8 h-8 mx-auto mb-2 opacity-40" />
        Você não tem permissão para operar o caixa.
      </div>
    );
  }

  if (isLoading) return <div className="flex justify-center py-10"><Loader2 className="w-6 h-6 animate-spin" /></div>;

  const totals = active ? JSON.parse(active.totals_by_method || '{}') : {};

  return (
    <div className="space-y-4">
      {!active ? (
        <div className="max-w-2xl mx-auto bg-card rounded-2xl border border-border p-6 space-y-4">
          <div className="text-center">
            <Unlock className="w-10 h-10 mx-auto mb-2 text-green-500" />
            <h3 className="font-semibold text-lg">Abrir Caixa</h3>
            <p className="text-sm text-muted-foreground">💵 Contagem inicial de cédulas e moedas — o fundo de caixa é calculado automaticamente.</p>
          </div>
          <BillCounter counts={openCounts} onCountsChange={setOpenCounts} />
          <div className="bg-primary/5 border border-primary/20 rounded-xl px-4 py-3 text-center">
            <p className="text-xs text-muted-foreground">💰 Valor inicial do caixa</p>
            <p className="text-2xl font-bold text-primary tabular-nums">{fmt(openTotal)}</p>
          </div>
          <div>
            <Label>Observações (opcional)</Label>
            <Input value={openNotes} onChange={(e) => setOpenNotes(e.target.value)} placeholder="Notas sobre a abertura..." />
          </div>
          <Button onClick={openCash} disabled={openTotal <= 0} className="w-full bg-green-600 hover:bg-green-700 gap-2">
            <Unlock className="w-4 h-4" /> Confirmar abertura do caixa
          </Button>
        </div>
      ) : (
        <>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
            <div className="bg-card rounded-xl border p-3">
              <p className="text-xs text-muted-foreground">Abertura</p>
              <p className="text-lg font-bold">{fmt(active.opening_amount)}</p>
              <p className="text-[10px] text-muted-foreground">{new Date(active.opening_date).toLocaleString('pt-BR')}</p>
            </div>
            <div className="bg-card rounded-xl border p-3">
              <p className="text-xs text-muted-foreground">Total vendido</p>
              <p className="text-lg font-bold text-blue-700">{fmt(active.total_sales)}</p>
              <p className="text-[10px] text-muted-foreground">{active.sales_count} venda(s)</p>
            </div>
            <div className="bg-card rounded-xl border p-3">
              <p className="text-xs text-muted-foreground">Dinheiro (esperado)</p>
              <p className="text-lg font-bold">{fmt((active.opening_amount || 0) + (Number(totals.cash) || 0) + sumMov(active.movements, 'suprimento', true) - sumMov(active.movements, 'sangria') - (Number(active.change_total) || 0))}</p>
            </div>
            <div className="bg-card rounded-xl border p-3">
              <p className="text-xs text-muted-foreground">Movimentações</p>
              <p className="text-lg font-bold">{(active.movements || []).length}</p>
            </div>
          </div>

          <div className="flex flex-wrap gap-2">
            <Button variant="outline" onClick={() => setDlg({ type: 'suprimento' })} className="gap-2">
              <ArrowUpCircle className="w-4 h-4 text-green-600" /> Suprimento
            </Button>
            <Button variant="outline" onClick={() => setDlg({ type: 'sangria' })} className="gap-2">
              <ArrowDownCircle className="w-4 h-4 text-red-600" /> Sangria
            </Button>
            <Button variant="outline" onClick={async () => { try { const r = cashSessionToSections(active, settings); await generatePDF({ documentType: 'pos_cash_session', data: r.data, sections: r.sections, module: 'PDV', user, entityId: active.id, fileName: `relatorio-caixa-${(active.id || '').substring(0, 8).toUpperCase()}.pdf` }); } catch (e) { toast({ title: 'Erro ao gerar PDF', description: String(e.message || e), variant: 'destructive' }); } }} className="gap-2">
              <Printer className="w-4 h-4" /> Relatório
            </Button>
            <Button variant="destructive" onClick={() => setCloseOpen(true)} className="gap-2 ml-auto">
              <Lock className="w-4 h-4" /> Fechar caixa
            </Button>
          </div>

          <div className="bg-card rounded-xl border p-3">
            <h4 className="text-sm font-semibold mb-2">Movimentações</h4>
            <div className="space-y-1 max-h-64 overflow-y-auto">
              {(active.movements || []).slice().reverse().map((m, i) => (
                <div key={i} className="flex items-center justify-between text-sm py-1 border-b border-border last:border-0">
                  <span>
                    <span className={`text-xs font-medium ${m.type === 'sangria' ? 'text-red-600' : m.type === 'sale' ? 'text-blue-700' : 'text-green-600'}`}>
                      {m.type === 'sale' ? 'Venda' : m.type === 'sangria' ? 'Sangria' : m.type === 'suprimento' ? 'Suprimento' : m.type}
                    </span>
                    {m.description && <span className="text-muted-foreground"> — {m.description}</span>}
                  </span>
                  <span className="font-medium">{m.type === 'sangria' ? '-' : ''}{fmt(m.amount)}</span>
                </div>
              ))}
            </div>
          </div>
        </>
      )}

      {/* Histórico de fechamentos */}
      {sessions.filter((s) => s.status === 'closed').length > 0 && (
        <div className="bg-card rounded-xl border p-3">
          <h4 className="text-sm font-semibold mb-2 flex items-center gap-2"><FileText className="w-4 h-4" /> Histórico de Fechamentos</h4>
          <div className="space-y-1 max-h-72 overflow-y-auto">
            {sessions.filter((s) => s.status === 'closed').map((s) => (
              <div key={s.id} className="flex items-center justify-between text-sm py-1.5 border-b border-border last:border-0">
                <div>
                  <span className="font-mono text-xs">#{(s.id || '').substring(0, 8).toUpperCase()}</span>
                  <span className="text-muted-foreground text-xs ml-2">{new Date(s.closing_date || s.opening_date).toLocaleString('pt-BR')}</span>
                  <span className="text-muted-foreground text-xs ml-2">{s.operator_name || '—'}</span>
                </div>
                <div className="flex items-center gap-2">
                  <span className={`text-xs font-medium ${Math.abs(s.difference || 0) < 0.005 ? 'text-green-600' : 'text-amber-600'}`}>
                    {fmt(s.difference || 0)}
                  </span>
                  <Button size="icon" variant="ghost" title="Reimprimir relatório" onClick={() => reprintClose(s)}>
                    <Printer className="w-4 h-4" />
                  </Button>
                  {user?.role === 'admin' && (
                    <Button size="icon" variant="ghost" title="Excluir registro" className="text-red-500" onClick={() => deleteSession(s)}>
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      <Dialog open={!!dlg} onOpenChange={(o) => !o && setDlg(null)}>
        <DialogContent className="max-w-sm">
          <DialogHeader><DialogTitle>{dlg?.type === 'sangria' ? 'Sangria' : 'Suprimento'}</DialogTitle></DialogHeader>
          <div className="space-y-2">
            <div>
              <Label>Valor (R$)</Label>
              <Input type="number" value={mvAmt} onChange={(e) => setMvAmt(e.target.value)} />
            </div>
            <div>
              <Label>Descrição</Label>
              <Input value={mvDesc} onChange={(e) => setMvDesc(e.target.value)} placeholder="Motivo" />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setDlg(null)}>Cancelar</Button>
            <Button onClick={addMovement} className={dlg?.type === 'sangria' ? 'bg-red-600 hover:bg-red-700' : 'bg-green-600 hover:bg-green-700'}>
              Confirmar
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <CloseCashDialog
        key={active?.id || 'none'}
        open={closeOpen}
        onClose={() => setCloseOpen(false)}
        session={active}
        settings={settings}
        onConfirm={confirmClose}
      />
    </div>
  );
}