import React from 'react';
import { Link } from 'react-router-dom';
import { ShieldAlert, ArrowLeft } from 'lucide-react';
import { Button } from '@/components/ui/button';

export default function PosAccessDenied() {
  return (
    <div className="min-h-screen flex items-center justify-center p-6 text-center">
      <div>
        <ShieldAlert className="w-12 h-12 text-amber-500 mx-auto mb-3" />
        <h2 className="text-xl font-semibold mb-2">Acesso restrito</h2>
        <p className="text-muted-foreground mb-6">Você não tem permissão para acessar o PDV.</p>
        <Link to="/Dashboard"><Button variant="outline" className="gap-2"><ArrowLeft className="w-4 h-4" /> Voltar</Button></Link>
      </div>
    </div>
  );
}