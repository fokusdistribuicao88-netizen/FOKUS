import React, { useState, useMemo } from 'react';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { useToast } from '@/components/ui/use-toast';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Search, Printer, Ban, Receipt } from 'lucide-react';
import {
  Select, SelectTrigger, SelectValue, SelectContent, SelectItem,
} from '@/components/ui/select';
import { generateReceiptPDF } from '@/lib/posReceipt';
import { cancelOrderWithReversal } from '@/lib/orderCancelService';

const fmt = (v) => `R$ ${(Number(v) || 0).toFixed(2).replace('.', ',')}`;
const isPos = (o) => (o.timeline || []).some((t) => t.event && t.event.includes('PDV'));

export default function PosHistory({ canCancel, onPrint, settings }) {
  const { toast } = useToast();
  const qc = useQueryClient();
  const [q, setQ] = useState('');
  const [status, setStatus] = useState('all');

  const { data: orders = [], isLoading } = useQuery({
    queryKey: ['orders'],
    queryFn: () => base44.entities.Order.list('-created_date'),
  });

  const posSales = useMemo(() => orders.filter(isPos), [orders]);

  const filtered = useMemo(() => {
    const s = q.trim().toLowerCase();
    return posSales.filter((o) => {
      if (status !== 'all' && o.status !== status) return false;
      if (!s) return true;
      const hay = [o.id, o.customer_name, o.seller, (o.items || []).map((i) => i.product_name).join(' ')].filter(Boolean).join(' ').toLowerCase();
      return hay.includes(s);
    });
  }, [posSales, q, status]);

  const cancelSale = async (o) => {
    if (!confirm('Cancelar esta venda? O estoque será restaurado.')) return;
    const reason = prompt('Motivo do cancelamento:') || '';
    try {
      const updates = { status: 'cancelled', notes: reason, timeline: [...(o.timeline || []), { date: new Date().toISOString(), event: 'Venda cancelada no PDV', author: 'Operador' }] };
      await base44.entities.Order.update(o.id, updates);
      // Cancelar lançamentos financeiros vinculados (Contas a Receber) — best-effort
      try {
        const finIds = Array.isArray(o.financial_entry_ids) ? o.financial_entry_ids.filter(Boolean) : [];
        if (finIds.length) {
          await base44.entities.FinancialEntry.updateMany({ id: { $in: finIds } }, { $set: { status: 'cancelled' } });
        }
      } catch { /* não bloqueia o cancelamento */ }
      // Restaurar estoque
      for (const it of (o.items || [])) {
        const p = await base44.entities.Product.get(it.product_id);
        await base44.entities.Product.update(it.product_id, { stock_quantity: (p.stock_quantity || 0) + it.quantity, in_stock: true });
        await base44.entities.InventoryMovement.create({
          product_id: it.product_id, product_name: it.product_name, type: 'entry', quantity: it.quantity,
          reason: 'cancelamento_pdv', notes: reason, responsible: 'Sistema',
        });
      }
      qc.invalidateQueries({ queryKey: ['orders'] });
      qc.invalidateQueries({ queryKey: ['products'] });
      qc.invalidateQueries({ queryKey: ['financialEntries'] });
      toast({ title: 'Venda cancelada e estoque restaurado' });
    } catch (e) {
      toast({ title: 'Erro ao cancelar', description: String(e.message || e), variant: 'destructive' });
    }
  };

  return (
    <div className="space-y-3">
      <div className="flex flex-wrap items-center gap-2">
        <div className="relative flex-1 min-w-[200px]">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input placeholder="Buscar por venda, cliente, operador, produto..." value={q} onChange={(e) => setQ(e.target.value)} className="pl-9" />
        </div>
        <Select value={status} onValueChange={setStatus}>
          <SelectTrigger className="w-44"><SelectValue /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">Todos</SelectItem>
            <SelectItem value="completed">Concluído</SelectItem>
            <SelectItem value="delivered">Entregue</SelectItem>
            <SelectItem value="cancelled">Cancelado</SelectItem>
          </SelectContent>
        </Select>
      </div>

      <div className="rounded-xl border border-border overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="bg-muted/50 text-xs text-muted-foreground">
              <tr>
                <th className="text-left p-2">Venda</th>
                <th className="text-left p-2">Data</th>
                <th className="text-left p-2">Cliente</th>
                <th className="text-left p-2">Operador</th>
                <th className="text-left p-2">Itens</th>
                <th className="text-right p-2">Total</th>
                <th className="text-left p-2">Status</th>
                <th className="text-center p-2">Ações</th>
              </tr>
            </thead>
            <tbody>
              {isLoading && <tr><td colSpan={8} className="text-center p-4 text-muted-foreground">Carregando...</td></tr>}
              {!isLoading && filtered.length === 0 && <tr><td colSpan={8} className="text-center p-4 text-muted-foreground">Nenhuma venda.</td></tr>}
              {filtered.map((o) => (
                <tr key={o.id} className="border-t border-border hover:bg-muted/30">
                  <td className="p-2 font-mono text-xs">{o.id.substring(0, 8).toUpperCase()}</td>
                  <td className="p-2 text-xs">{new Date(o.created_date).toLocaleString('pt-BR')}</td>
                  <td className="p-2">{o.customer_name || 'Consumidor Final'}</td>
                  <td className="p-2 text-xs">{o.seller || '—'}</td>
                  <td className="p-2 text-xs">{(o.items || []).reduce((s, i) => s + i.quantity, 0)}</td>
                  <td className="p-2 text-right font-semibold">{fmt(o.total)}</td>
                  <td className="p-2">
                    <span className={`text-xs px-2 py-0.5 rounded-full ${o.status === 'cancelled' ? 'bg-red-100 text-red-700' : 'bg-green-100 text-green-700'}`}>
                      {o.status === 'cancelled' ? 'Cancelado' : 'Concluído'}
                    </span>
                  </td>
                  <td className="p-2">
                    <div className="flex items-center justify-center gap-1">
                      <Button size="icon" variant="ghost" title="Imprimir cupom" onClick={() => generateReceiptPDF(o, settings)}>
                        <Printer className="w-4 h-4" />
                      </Button>
                      {canCancel && o.status !== 'cancelled' && (
                        <Button size="icon" variant="ghost" title="Cancelar venda" className="text-red-500" onClick={() => cancelSale(o)}>
                          <Ban className="w-4 h-4" />
                        </Button>
                      )}
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}