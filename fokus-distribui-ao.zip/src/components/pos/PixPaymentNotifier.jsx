import React, { useState, useEffect, useRef, useCallback } from 'react';
import { base44 } from '@/api/base44Client';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { CheckCircle2, X, Volume2, VolumeX } from 'lucide-react';

const fmt = (v) => `R$ ${(Number(v) || 0).toFixed(2).replace('.', ',')}`;

/**
 * Toca um som de notificação usando Web Audio API (sem arquivo externo).
 * Sequência de 2 bips ascendentes — som de "pagamento recebido".
 */
function playPaymentSound() {
  try {
    const AudioCtx = window.AudioContext || window.webkitAudioContext;
    if (!AudioCtx) return;
    const ctx = new AudioCtx();
    const now = ctx.currentTime;

    const beep = (freq, start, duration) => {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'sine';
      osc.frequency.value = freq;
      gain.gain.setValueAtTime(0, now + start);
      gain.gain.linearRampToValueAtTime(0.25, now + start + 0.02);
      gain.gain.exponentialRampToValueAtTime(0.001, now + start + duration);
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start(now + start);
      osc.stop(now + start + duration);
    };

    beep(880, 0, 0.15);      // Lá
    beep(1320, 0.12, 0.25);  // Mi agudo

    setTimeout(() => ctx.close(), 600);
  } catch { /* ignore */ }
}

/**
 * Componente que escuta atualizações da entidade Order em tempo real e exibe
 * uma notificação visual + sonora prominente quando um pagamento PIX é confirmado.
 *
 * Deve ser montado uma única vez na tela do PDV (ou globalmente no layout admin).
 */
export default function PixPaymentNotifier() {
  const [notification, setNotification] = useState(null);
  const [soundEnabled, setSoundEnabled] = useState(true);
  const knownPaidRef = useRef(new Set());
  const initializedRef = useRef(false);

  // Carrega baseline de pedidos PIX já pagos para evitar notificações de pagamentos antigos
  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        const orders = await base44.entities.Order.filter({ payment_method: 'pix' }, '-created_date', 50);
        if (cancelled) return;
        orders.forEach((o) => {
          if (o.payment_status === 'paid') knownPaidRef.current.add(o.id);
        });
        initializedRef.current = true;
      } catch {
        initializedRef.current = true;
      }
    })();
    return () => { cancelled = true; };
  }, []);

  const handleOrderEvent = useCallback((event) => {
    if (!initializedRef.current) return;
    const o = event.data;
    if (!o || o.payment_method !== 'pix') return;
    if (o.payment_status !== 'paid') return;
    if (knownPaidRef.current.has(o.id)) return;

    knownPaidRef.current.add(o.id);
    if (soundEnabled) playPaymentSound();

    setNotification({
      orderId: o.id,
      saleCode: (o.id || '').substring(0, 8).toUpperCase(),
      customer: o.customer_name || 'Cliente',
      total: o.total || 0,
      timestamp: new Date().toISOString(),
    });
  }, [soundEnabled]);

  // Inscrição em tempo real nas atualizações de Order
  useEffect(() => {
    const unsubscribe = base44.entities.Order.subscribe((event) => {
      if (event.type === 'update') handleOrderEvent(event);
    });
    return unsubscribe;
  }, [handleOrderEvent]);

  const dismiss = () => setNotification(null);

  return (
    <>
      {/* Botão flutuante para alternar som */}
      <button
        onClick={() => setSoundEnabled((s) => !s)}
        className="fixed bottom-4 left-4 z-40 w-10 h-10 rounded-full bg-card border border-border shadow-sm flex items-center justify-center text-muted-foreground hover:text-foreground transition-colors"
        title={soundEnabled ? 'Som de notificação ativado' : 'Som de notificação desativado'}
      >
        {soundEnabled ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4" />}
      </button>

      <Dialog open={!!notification} onOpenChange={(o) => !o && dismiss()}>
        <DialogContent className="max-w-sm border-green-500/40 shadow-2xl" onCloseAutoFocus={(e) => e.preventDefault()}>
          <button
            onClick={dismiss}
            className="absolute right-3 top-3 p-1 rounded-md text-muted-foreground hover:text-foreground hover:bg-accent transition-colors"
          >
            <X className="w-4 h-4" />
          </button>

          <div className="flex flex-col items-center text-center py-4 gap-3">
            <div className="w-16 h-16 rounded-full bg-green-100 dark:bg-green-950/50 flex items-center justify-center animate-pulse">
              <CheckCircle2 className="w-10 h-10 text-green-600 dark:text-green-400" />
            </div>

            <div>
              <DialogTitle className="text-xl font-bold text-green-700 dark:text-green-400">
                Pagamento PIX Confirmado!
              </DialogTitle>
              <p className="text-sm text-muted-foreground mt-1">
                O pagamento foi identificado automaticamente.
              </p>
            </div>

            {notification && (
              <div className="w-full rounded-xl border border-green-200 dark:border-green-900/50 bg-green-50/50 dark:bg-green-950/20 p-4 space-y-2 text-sm">
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Venda</span>
                  <span className="font-semibold">#{notification.saleCode}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Cliente</span>
                  <span className="font-medium truncate ml-2 max-w-[160px]">{notification.customer}</span>
                </div>
                <div className="flex justify-between border-t border-green-200 dark:border-green-900/50 pt-2 mt-2">
                  <span className="text-muted-foreground">Valor</span>
                  <span className="text-lg font-bold text-green-700 dark:text-green-400">{fmt(notification.total)}</span>
                </div>
                <div className="flex justify-between text-xs">
                  <span className="text-muted-foreground">Recebido em</span>
                  <span className="text-muted-foreground tabular-nums">
                    {new Date(notification.timestamp).toLocaleString('pt-BR')}
                  </span>
                </div>
              </div>
            )}

            <Button
              onClick={dismiss}
              className="w-full bg-green-600 hover:bg-green-700 gap-2 mt-2"
            >
              <CheckCircle2 className="w-4 h-4" /> Confirmar
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
}