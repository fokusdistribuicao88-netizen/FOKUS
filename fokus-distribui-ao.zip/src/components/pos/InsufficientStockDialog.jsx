import React from 'react';
import { AlertTriangle } from 'lucide-react';
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';

/**
 * Diálogo reutilizável de estoque insuficiente.
 * Mostra tabela com produto, solicitado, disponível e diferença.
 * Botão "Voltar ao pedido" permite ajustar as quantidades.
 */
export default function InsufficientStockDialog({ open, items, onClose }) {
  return (
    <Dialog open={open} onOpenChange={(o) => !o && onClose()}>
      <DialogContent className="max-w-lg">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 text-amber-700">
            <AlertTriangle className="w-5 h-5" /> Estoque insuficiente para finalizar esta operação.
          </DialogTitle>
        </DialogHeader>

        <p className="text-sm text-muted-foreground">
          Ajuste as quantidades no pedido e tente novamente. A baixa de estoque só é realizada
          na confirmação final, e o saldo é revalidado no momento da finalização.
        </p>

        <div className="rounded-lg border border-border overflow-hidden">
          <table className="w-full text-sm">
            <thead className="bg-muted/50 text-xs text-muted-foreground">
              <tr>
                <th className="text-left p-2">Produto</th>
                <th className="text-right p-2">Solicitado</th>
                <th className="text-right p-2">Disponível</th>
                <th className="text-right p-2">Diferença</th>
              </tr>
            </thead>
            <tbody>
              {(items || []).map((it) => (
                <tr key={it.product_id} className="border-t border-border">
                  <td className="p-2">{it.product_name}</td>
                  <td className="p-2 text-right">{it.requested}</td>
                  <td className="p-2 text-right text-red-600 font-medium">{it.available}</td>
                  <td className="p-2 text-right text-red-600 font-medium">{it.difference}</td>
                </tr>
              ))}
              {(!items || items.length === 0) && (
                <tr><td colSpan={4} className="p-3 text-center text-muted-foreground">Sem detalhes.</td></tr>
              )}
            </tbody>
          </table>
        </div>

        <DialogFooter>
          <Button onClick={onClose} className="w-full">Voltar ao pedido</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}