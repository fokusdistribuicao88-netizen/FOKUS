import React, { useState, useMemo, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Loader2, Lock, AlertTriangle, CheckCircle2, BarChart3 } from 'lucide-react';
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter,
} from '@/components/ui/dialog';
import BillCounter, { computeTotal, parseCounts, BillCompareTable } from '@/components/pos/BillCounter';

const fmt = (v) => `R$ ${(Number(v) || 0).toFixed(2).replace('.', ',')}`;
const TOLERANCE = 5; // tolerância em reais para diferença pequena

function sumMov(movements, type, excludeOpening = false) {
  return (movements || [])
    .filter((m) => m.type === type && !(excludeOpening && m.description === 'Abertura de caixa'))
    .reduce((s, m) => s + (Number(m.amount) || 0), 0);
}

export default function CloseCashDialog({ open, onClose, session, settings, onConfirm }) {
  const [counts, setCounts] = useState(() => parseCounts(session?.bill_count));
  const [notes, setNotes] = useState(session?.difference_notes || '');
  const [busy, setBusy] = useState(false);
  const [showCompare, setShowCompare] = useState(false);
  const [pixEntry, setPixEntry] = useState(0);

  const totals = useMemo(() => parseCounts(session?.totals_by_method), [session]);

  // Pré-preenche as entradas de PIX com o total de vendas PIX do caixa
  useEffect(() => {
    if (open && session) {
      setPixEntry(Number(totals.pix) || 0);
    }
  }, [open, session, totals.pix]);

  const counted = useMemo(() => computeTotal(counts) + pixEntry, [counts, pixEntry]);

  const openingCounts = useMemo(() => parseCounts(session?.opening_bill_count), [session]);

  const expected = useMemo(() => {
    if (!session) return 0;
    const cashSales = Number(totals.cash) || 0;
    const pixSales = Number(totals.pix) || 0;
    const suprimentos = sumMov(session.movements, 'suprimento', true);
    const sangrias = sumMov(session.movements, 'sangria');
    const change = Number(session.change_total) || 0;
    return (Number(session.opening_amount) || 0) + cashSales + pixSales + suprimentos - sangrias - change;
  }, [session, totals]);

  const diff = counted - expected;
  const absDiff = Math.abs(diff);
  const hasDiff = absDiff > 0.005;
  const needsNotes = absDiff > TOLERANCE;
  const status = !hasDiff
    ? { label: 'Caixa conferido', color: 'green', icon: CheckCircle2 }
    : absDiff <= TOLERANCE
      ? { label: 'Diferença pequena', color: 'yellow', icon: AlertTriangle }
      : { label: 'Diferença significativa', color: 'red', icon: AlertTriangle };

  const statusClasses = {
    green: 'bg-green-50 text-green-700 border-green-300',
    yellow: 'bg-amber-50 text-amber-700 border-amber-300',
    red: 'bg-red-50 text-red-700 border-red-300',
  };

  const summary = useMemo(() => {
    if (!session) return [];
    const rows = [
      ['Valor inicial', session.opening_amount],
      ['Total de vendas', session.total_sales],
      ['Dinheiro', totals.cash],
      ['PIX', totals.pix],
      ['PIX (entradas)', pixEntry],
      ['Cartão de Crédito', totals.credit_card],
      ['Cartão de Débito', totals.debit_card],
      ['Boleto', totals.boleto],
      ['Transferência', totals.transfer],
    ];
    const otherKeys = Object.keys(totals).filter((k) => !['cash', 'pix', 'credit_card', 'debit_card', 'boleto', 'transfer'].includes(k));
    if (otherKeys.length) rows.push(['Outras formas', otherKeys.reduce((s, k) => s + (Number(totals[k]) || 0), 0)]);
    rows.push(['Sangrias', -sumMov(session.movements, 'sangria')]);
    rows.push(['Suprimentos', sumMov(session.movements, 'suprimento', true)]);
    rows.push(['Descontos concedidos', session.discount_total]);
    rows.push(['Troco entregue', -(session.change_total || 0)]);
    return rows;
  }, [session, totals, pixEntry]);

  const canConfirm = !needsNotes || notes.trim().length >= 3;

  const handleConfirm = async () => {
    if (!canConfirm || busy) return;
    setBusy(true);
    try {
      await onConfirm({
        bill_count: JSON.stringify(counts),
        counted_amount: counted,
        expected_cash: expected,
        difference: diff,
        difference_notes: hasDiff ? notes.trim() : '',
        pix_entry: pixEntry,
      });
    } finally {
      setBusy(false);
    }
  };

  if (!session) return null;
  const code = (session.id || '').substring(0, 8).toUpperCase();

  return (
    <Dialog open={open} onOpenChange={(o) => !o && onClose()}>
      <DialogContent className="max-w-2xl max-h-[92vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2"><Lock className="w-4 h-4" /> Fechamento de Caixa — #{code}</DialogTitle>
        </DialogHeader>

        <div className="space-y-4">
          {/* Resumo financeiro */}
          <div>
            <h4 className="text-sm font-semibold mb-2">Resumo do Caixa</h4>
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
              {summary.map(([label, val]) => (
                <div key={label} className="bg-muted/40 rounded-lg px-2 py-1.5">
                  <p className="text-[10px] text-muted-foreground">{label}</p>
                  <p className="text-sm font-semibold">{fmt(val)}</p>
                </div>
              ))}
            </div>
            <div className="mt-2 text-xs text-muted-foreground flex flex-wrap gap-x-4 gap-y-1">
              <span>Abertura: {new Date(session.opening_date).toLocaleString('pt-BR')}</span>
              <span>Fechamento: {new Date().toLocaleString('pt-BR')}</span>
              <span>Vendas: {session.sales_count || 0}</span>
            </div>
          </div>

          {/* Contagem de cédulas */}
          <div>
            <div className="flex items-center justify-between mb-2">
              <h4 className="text-sm font-semibold">💵 Contagem Final de Cédulas e Moedas</h4>
              {session?.opening_bill_count && (
                <Button
                  variant="ghost"
                  size="sm"
                  className="text-xs gap-1 h-7"
                  onClick={() => setShowCompare((s) => !s)}
                >
                  <BarChart3 className="w-3.5 h-3.5" /> {showCompare ? 'Ocultar' : 'Comparar'} abertura
                </Button>
              )}
            </div>

            {/* Comparativo abertura x fechamento */}
            {showCompare && session?.opening_bill_count && (
              <div className="mb-3 space-y-1.5">
                <p className="text-xs text-muted-foreground font-medium">Comparativo de contagem (abertura → fechamento)</p>
                <BillCompareTable opening={openingCounts} closing={counts} />
                <div className="grid grid-cols-2 gap-2 text-xs">
                  <div className="rounded-lg border border-border px-2 py-1.5">
                    <p className="text-[10px] text-muted-foreground">Total abertura</p>
                    <p className="font-semibold">{fmt(session.opening_amount)}</p>
                  </div>
                  <div className="rounded-lg border border-border px-2 py-1.5">
                    <p className="text-[10px] text-muted-foreground">Total contado agora</p>
                    <p className="font-semibold">{fmt(counted)}</p>
                  </div>
                </div>
              </div>
            )}

            <BillCounter counts={counts} onCountsChange={setCounts} />

            {/* Entradas de PIX */}
            <div className="mt-3 rounded-lg border border-violet-200 bg-violet-50/40 p-2.5">
              <div className="flex items-center gap-2">
                <span className="w-20 text-xs font-medium text-violet-700">PIX (entradas)</span>
                <Input
                  type="number"
                  min="0"
                  step="0.01"
                  value={pixEntry || ''}
                  onChange={(e) => setPixEntry(Number(e.target.value) || 0)}
                  placeholder="0,00"
                  className="h-7 w-32 text-sm"
                />
                <span className="ml-auto text-xs font-semibold tabular-nums text-violet-700">{fmt(pixEntry)}</span>
              </div>
              <p className="text-[10px] text-muted-foreground mt-1">Informe o valor total recebido via PIX no período (entradas manuais).</p>
            </div>
          </div>

          {/* Resultado */}
          <div className={`rounded-xl border p-3 ${statusClasses[status.color]}`}>
            <div className="flex items-center gap-2 mb-2">
              <status.icon className="w-5 h-5" />
              <span className="font-semibold">{status.label}</span>
            </div>
            <div className="grid grid-cols-3 gap-2 text-center">
              <div><p className="text-[10px] opacity-80">Esperado</p><p className="text-base font-bold">{fmt(expected)}</p></div>
              <div><p className="text-[10px] opacity-80">Contado</p><p className="text-base font-bold">{fmt(counted)}</p></div>
              <div><p className="text-[10px] opacity-80">Diferença</p><p className="text-base font-bold">{diff >= 0 ? '+' : ''}{fmt(diff)}</p></div>
            </div>
          </div>

          {/* Justificativa */}
          {hasDiff && (
            <div>
              <Label className="text-xs">
                Justificativa da diferença {needsNotes && <span className="text-red-500">*</span>}
              </Label>
              <Textarea
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                placeholder="Descreva o motivo da diferença..."
                className="mt-1"
                rows={2}
              />
              {needsNotes && !notes.trim() && (
                <p className="text-xs text-red-500 mt-1">Justificativa obrigatória para diferenças acima de {fmt(TOLERANCE)}.</p>
              )}
            </div>
          )}
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={onClose} disabled={busy}>Cancelar</Button>
          <Button onClick={handleConfirm} disabled={!canConfirm || busy} variant="destructive" className="gap-2">
            {busy ? <Loader2 className="w-4 h-4 animate-spin" /> : <Lock className="w-4 h-4" />}
            Concluir fechamento
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}