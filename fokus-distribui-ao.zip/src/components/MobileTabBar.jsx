import React, { useEffect, useState } from 'react';
import { NavLink, useLocation, useNavigate } from 'react-router-dom';
import { Home, ClipboardList, User, ShoppingBag } from 'lucide-react';

const TABS = [
  { to: '/', label: 'Início', icon: Home, exact: true },
  { to: '/Checkout', label: 'Pedido', icon: ShoppingBag, exact: false },
  { to: '/Orders', label: 'Pedidos', icon: ClipboardList, exact: false },
  { to: '/MinhaConta', label: 'Conta', icon: User, exact: false },
];

const CUSTOMER_ROUTES = ['/', '/Checkout', '/Orders', '/MinhaConta'];

function tabForPath(pathname) {
  if (pathname === '/') return '/';
  for (const t of TABS) {
    if (t.to !== '/' && pathname.startsWith(t.to)) return t.to;
  }
  return null;
}

export default function MobileTabBar() {
  const location = useLocation();
  const navigate = useNavigate();
  const [lastRoutes, setLastRoutes] = useState(() => {
    try {
      const saved = sessionStorage.getItem('tabRoutes');
      if (saved) return JSON.parse(saved);
    } catch {}
    return {};
  });

  // Preserva o último pathname visitado de cada aba
  useEffect(() => {
    const tab = tabForPath(location.pathname);
    if (tab && lastRoutes[tab] !== location.pathname) {
      const next = { ...lastRoutes, [tab]: location.pathname };
      setLastRoutes(next);
      try { sessionStorage.setItem('tabRoutes', JSON.stringify(next)); } catch {}
    }
  }, [location.pathname]); // eslint-disable-line react-hooks/exhaustive-deps

  const isCustomerRoute = CUSTOMER_ROUTES.includes(location.pathname);

  if (!isCustomerRoute) return null;

  return (
    <nav
      className="mobile-tab-bar md:hidden fixed bottom-0 inset-x-0 z-40 bg-card/95 backdrop-blur-md border-t border-border shadow-[0_-2px_8px_rgba(0,0,0,0.06)]"
      style={{ paddingBottom: 'env(safe-area-inset-bottom)' }}
      aria-label="Navegação principal"
    >
      <div className="flex items-stretch justify-around h-14">
        {TABS.map(({ to, label, icon: Icon, exact }) => {
          const isActive = exact
            ? location.pathname === to
            : location.pathname === to ||
              (to !== '/' && location.pathname.startsWith(to));
          return (
            <NavLink
              key={to}
              to={to}
              end={exact}
              onClick={(e) => {
                const stored = lastRoutes[to];
                if (stored && stored !== to) {
                  e.preventDefault();
                  navigate(stored);
                  return;
                }
                if (isActive) {
                  window.scrollTo({ top: 0, behavior: 'smooth' });
                }
              }}
              className="flex flex-col items-center justify-center gap-0.5 flex-1 min-h-11 text-[11px] font-medium transition-colors touch-manipulation"
            >
              {({ isActive: navActive }) => {
                const active = isActive || navActive;
                return (
                  <>
                    <Icon
                      className={`w-5 h-5 transition-colors ${
                        active ? 'text-blue-600' : 'text-muted-foreground'
                      }`}
                    />
                    <span
                      className={`transition-colors ${
                        active ? 'text-blue-600' : 'text-muted-foreground'
                      }`}
                    >
                      {label}
                    </span>
                  </>
                );
              }}
            </NavLink>
          );
        })}
      </div>
    </nav>
  );
}