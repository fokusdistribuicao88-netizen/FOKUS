import React, { useEffect, useRef, useState } from 'react';
import * as pdfjsLib from 'pdfjs-dist';
import PdfjsWorker from 'pdfjs-dist/build/pdf.worker.min.mjs?worker';
import { Loader2 } from 'lucide-react';

pdfjsLib.GlobalWorkerOptions.workerPort = new PdfjsWorker();

// Renderiza um PDF (blob: ou data: URL) como páginas em canvas.
// Funciona em WebView (Android/iOS) onde iframes com blob: ficam em branco.
export default function PdfRenderer({ url, className = '', scale = 1.5 }) {
  const containerRef = useRef(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [pageCount, setPageCount] = useState(0);

  useEffect(() => {
    if (!url) return;
    let cancelled = false;
    let pdfDoc = null;

    const render = async () => {
      setLoading(true);
      setError(false);
      try {
        // Busca o blob/data URL como ArrayBuffer — mais confiável em WebView
        // do que passar a URL diretamente (evita problemas de CORS e blob:).
        const response = await fetch(url);
        const arrayBuffer = await response.arrayBuffer();
        const loadingTask = pdfjsLib.getDocument({ data: arrayBuffer });
        pdfDoc = await loadingTask.promise;
        if (cancelled) return;
        setPageCount(pdfDoc.numPages);
        const container = containerRef.current;
        if (!container) return;
        container.innerHTML = '';

        for (let i = 1; i <= pdfDoc.numPages; i++) {
          if (cancelled) return;
          const page = await pdfDoc.getPage(i);
          const viewport = page.getViewport({ scale });
          const canvas = document.createElement('canvas');
          canvas.className = 'block mx-auto mb-2 shadow-sm';
          const ctx = canvas.getContext('2d');
          canvas.width = viewport.width;
          canvas.height = viewport.height;
          canvas.style.maxWidth = '100%';
          canvas.style.height = 'auto';
          container.appendChild(canvas);
          await page.render({ canvasContext: ctx, viewport }).promise;
        }
      } catch (e) {
        if (!cancelled) { setError(String(e?.message || e)); console.error('PdfRenderer error:', e); }
      } finally {
        if (!cancelled) setLoading(false);
      }
    };

    render();
    return () => {
      cancelled = true;
      if (pdfDoc) pdfDoc.destroy();
    };
  }, [url, scale]);

  if (error) {
    return (
      <div className={`flex flex-col items-center justify-center h-full gap-2 text-muted-foreground p-4 text-center ${className}`}>
        <p className="text-sm font-medium">Não foi possível renderizar o PDF.</p>
        <p className="text-xs text-destructive">{error}</p>
      </div>
    );
  }

  return (
    <div className={`relative h-full overflow-y-auto ${className}`}>
      {loading && (
        <div className="absolute inset-0 flex flex-col items-center justify-center gap-2 text-muted-foreground">
          <Loader2 className="w-8 h-8 animate-spin" />
          <span className="text-sm">Renderizando documento... {pageCount > 0 ? `(${pageCount} pág.)` : ''}</span>
        </div>
      )}
      <div ref={containerRef} className="p-2" />
    </div>
  );
}