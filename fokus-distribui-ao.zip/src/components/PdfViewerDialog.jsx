import React, { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Download, FileText, Loader2, Share2 } from 'lucide-react';
import PdfRenderer from '@/components/PdfRenderer';
import { shareBlobUrl } from '@/lib/pdfService';
import { useToast } from '@/components/ui/use-toast';

// Visualizador de PDF em tela cheia dentro do app.
// Usa pdf.js (canvas) em vez de iframe — funciona em WebView (Android/iOS).
// Inclui botões de download e compartilhamento (Web Share API).
export default function PdfViewerDialog({ open, onClose, url, fileName, loading }) {
  const { toast } = useToast();
  const [sharing, setSharing] = useState(false);

  const handleDownload = () => {
    if (!url) return;
    const a = document.createElement('a');
    a.href = url;
    a.download = fileName || 'documento.pdf';
    document.body.appendChild(a);
    a.click();
    a.remove();
  };

  const handleShare = async () => {
    if (!url) return;
    setSharing(true);
    try {
      const shared = await shareBlobUrl(url, fileName || 'documento.pdf');
      toast({ title: shared ? 'Compartilhando PDF' : 'PDF baixado', description: shared ? 'Escolha o aplicativo para enviar.' : 'Compartilhamento não suportado — PDF baixado.' });
    } catch (e) {
      if (e?.name !== 'AbortError') toast({ title: 'Erro ao compartilhar', description: String(e.message || e), variant: 'destructive' });
    } finally {
      setSharing(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={(o) => !o && onClose()}>
      <DialogContent className="max-w-4xl w-[95vw] h-[92vh] p-0 flex flex-col overflow-hidden gap-0">
        <DialogHeader className="px-4 py-3 border-b border-border flex flex-row items-center justify-between space-y-0">
          <DialogTitle className="flex items-center gap-2 text-base">
            <FileText className="w-5 h-5" /> Visualização do PDF
          </DialogTitle>
          <div className="flex items-center gap-2">
            <Button size="sm" variant="outline" onClick={handleShare} disabled={!url || loading || sharing} className="gap-2">
              {sharing ? <Loader2 className="w-4 h-4 animate-spin" /> : <Share2 className="w-4 h-4" />}
              Compartilhar
            </Button>
            <Button size="sm" variant="outline" onClick={handleDownload} disabled={!url || loading} className="gap-2">
              {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Download className="w-4 h-4" />}
              Baixar PDF
            </Button>
          </div>
        </DialogHeader>
        <div className="flex-1 overflow-hidden bg-muted/30">
          {loading || !url ? (
            <div className="flex flex-col items-center justify-center h-full gap-2 text-muted-foreground">
              <Loader2 className="w-8 h-8 animate-spin" />
              <span className="text-sm">Gerando documento...</span>
            </div>
          ) : (
            <PdfRenderer url={url} className="bg-muted/30" />
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}