import React, { useState, useEffect } from 'react';
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import {
  Select, SelectTrigger, SelectValue, SelectContent, SelectItem,
} from '@/components/ui/select';
import { useAuth } from '@/lib/AuthContext';
import { useToast } from '@/components/ui/use-toast';
import { base44 } from '@/api/base44Client';
import { logActivity } from '@/lib/activityLog';
import { syncExpenseFinance } from '@/lib/expenseFinance';
import { EXPENSE_PAYMENT_METHODS, EXPENSE_STATUS } from '@/lib/expenseCategories';
import EmployeePicker from '@/components/hr/EmployeePicker';

const COST_CENTERS = ['Operacional', 'Funcionários', 'Veículos', 'Administrativo', 'Vendas', 'Outros'];

const empty = {
  category: '', description: '', amount: '', date: new Date().toISOString().slice(0, 10),
  due_date: '', paid_date: '', payment_method: 'Dinheiro', supplier: '',
  vehicle: '', employee_id: '', employee_name: '', cost_center: 'Operacional',
  status: 'pending', notes: '', receipt_url: '',
};

export default function ExpenseFormDialog({ open, expense, categories, employees, onClose, onSaved }) {
  const { user } = useAuth();
  const { toast } = useToast();
  const [form, setForm] = useState(empty);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (open) setForm(expense ? { ...empty, ...expense } : empty);
  }, [open, expense]);

  const set = (k, v) => setForm((f) => ({ ...f, [k]: v }));

  const setEmployee = (id) => {
    const emp = employees?.find((e) => e.id === id);
    setForm((f) => ({ ...f, employee_id: id, employee_name: emp?.name || '' }));
  };

  const submit = async () => {
    if (!form.category) return toast({ title: 'Selecione a categoria', variant: 'destructive' });
    if (!form.description?.trim()) return toast({ title: 'Informe a descrição', variant: 'destructive' });
    if (!form.amount || Number(form.amount) <= 0) return toast({ title: 'Valor inválido', variant: 'destructive' });
    setSaving(true);
    try {
      const payload = {
        ...form,
        amount: Number(form.amount) || 0,
        origin: 'manual',
        registered_by: user?.email || '',
      };
      let saved;
      if (expense?.id) {
        saved = await base44.entities.Expense.update(expense.id, payload);
        await syncExpenseFinance({ ...saved, ...payload }, user);
        await logActivity({ action: 'expense_update', description: `Editou despesa: ${payload.description}`, user, entityType: 'Expense', entityId: expense.id });
      } else {
        saved = await base44.entities.Expense.create(payload);
        const feId = await syncExpenseFinance({ ...saved, ...payload }, user);
        if (feId) await base44.entities.Expense.update(saved.id, { financial_entry_id: feId });
        await logActivity({ action: 'expense_create', description: `Despesa: ${payload.description} (${payload.category})`, user, entityType: 'Expense', entityId: saved.id });
      }
      toast({ title: 'Despesa salva' });
      onSaved?.(saved);
      onClose();
    } catch (e) {
      toast({ title: 'Erro', description: e.message, variant: 'destructive' });
    } finally {
      setSaving(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={(op) => !op && onClose()}>
      <DialogContent className="max-w-2xl max-h-[92vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>{expense?.id ? 'Editar despesa' : 'Nova despesa'}</DialogTitle>
          <DialogDescription>Registro de gasto da empresa.</DialogDescription>
        </DialogHeader>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
          <div>
            <Label>Categoria *</Label>
            <Select value={form.category} onValueChange={(v) => set('category', v)}>
              <SelectTrigger><SelectValue placeholder="Selecione..." /></SelectTrigger>
              <SelectContent>
                {(categories || []).map((c) => <SelectItem key={c.id || c.name} value={c.name}>{c.name}</SelectItem>)}
              </SelectContent>
            </Select>
          </div>
          <div>
            <Label>Status</Label>
            <Select value={form.status} onValueChange={(v) => set('status', v)}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                {EXPENSE_STATUS.map((s) => <SelectItem key={s.key} value={s.key}>{s.label}</SelectItem>)}
              </SelectContent>
            </Select>
          </div>
          <div className="md:col-span-2">
            <Label>Descrição *</Label>
            <Input value={form.description} onChange={(e) => set('description', e.target.value)} />
          </div>
          <div>
            <Label>Valor *</Label>
            <Input type="number" step="0.01" value={form.amount} onChange={(e) => set('amount', e.target.value)} />
          </div>
          <div>
            <Label>Fornecedor</Label>
            <Input value={form.supplier} onChange={(e) => set('supplier', e.target.value)} />
          </div>
          <div>
            <Label>Data</Label>
            <Input type="date" value={form.date} onChange={(e) => set('date', e.target.value)} />
          </div>
          <div>
            <Label>Vencimento</Label>
            <Input type="date" value={form.due_date || ''} onChange={(e) => set('due_date', e.target.value)} />
          </div>
          <div>
            <Label>Data de pagamento</Label>
            <Input type="date" value={form.paid_date || ''} onChange={(e) => set('paid_date', e.target.value)} disabled={form.status !== 'paid'} />
          </div>
          <div>
            <Label>Forma de pagamento</Label>
            <Select value={form.payment_method} onValueChange={(v) => set('payment_method', v)}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                {EXPENSE_PAYMENT_METHODS.map((m) => <SelectItem key={m} value={m}>{m}</SelectItem>)}
              </SelectContent>
            </Select>
          </div>
          <div>
            <Label>Centro de custo</Label>
            <Select value={form.cost_center} onValueChange={(v) => set('cost_center', v)}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                {COST_CENTERS.map((c) => <SelectItem key={c} value={c}>{c}</SelectItem>)}
              </SelectContent>
            </Select>
          </div>
          <div>
            <Label>Veículo relacionado</Label>
            <Input value={form.vehicle} onChange={(e) => set('vehicle', e.target.value)} placeholder="Placa/nome" />
          </div>
          <div>
            <Label>Funcionário relacionado</Label>
            <EmployeePicker employees={employees || []} value={form.employee_id} onChange={setEmployee} placeholder="Nenhum" />
          </div>
          <div className="md:col-span-2">
            <Label>Comprovante (URL)</Label>
            <Input value={form.receipt_url} onChange={(e) => set('receipt_url', e.target.value)} placeholder="https://..." />
          </div>
          <div className="md:col-span-2">
            <Label>Observações</Label>
            <Textarea rows={2} value={form.notes} onChange={(e) => set('notes', e.target.value)} />
          </div>
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={onClose} disabled={saving}>Cancelar</Button>
          <Button onClick={submit} disabled={saving}>{saving ? 'Salvando...' : 'Salvar'}</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}