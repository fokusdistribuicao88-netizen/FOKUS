import React, { useState, useMemo } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import {
  Select, SelectTrigger, SelectValue, SelectContent, SelectItem,
} from '@/components/ui/select';
import { Plus, Pencil, Search } from 'lucide-react';
import { useToast } from '@/components/ui/use-toast';
import { base44 } from '@/api/base44Client';
import { useAuth } from '@/lib/AuthContext';
import { formatBRL, formatDate } from '@/lib/format';
import FuelFormDialog from './FuelFormDialog';

export default function FuelTab({ fuelRecords, can, onReload }) {
  const { toast } = useToast();
  const [open, setOpen] = useState(false);
  const [editing, setEditing] = useState(null);
  const [q, setQ] = useState('');
  const [fVehicle, setFVehicle] = useState('all');

  const vehicles = useMemo(() => {
    const set = new Set((fuelRecords || []).map((r) => r.vehicle).filter(Boolean));
    return [...set];
  }, [fuelRecords]);

  const filtered = useMemo(() => {
    let list = [...(fuelRecords || [])];
    if (fVehicle !== 'all') list = list.filter((r) => r.vehicle === fVehicle);
    const query = q.trim().toLowerCase();
    if (query) list = list.filter((r) => (r.vehicle || '').toLowerCase().includes(query) || (r.driver_name || '').toLowerCase().includes(query) || (r.station || '').toLowerCase().includes(query));
    return list.sort((a, b) => new Date(b.date || 0) - new Date(a.date || 0));
  }, [fuelRecords, q, fVehicle]);

  const stats = useMemo(() => {
    const valid = filtered;
    const totalCost = valid.reduce((s, r) => s + (Number(r.total) || 0), 0);
    const totalLiters = valid.reduce((s, r) => s + (Number(r.liters) || 0), 0);
    const avgPrice = totalLiters > 0 ? totalCost / totalLiters : 0;
    const byVehicle = {};
    for (const r of valid) {
      if (!byVehicle[r.vehicle]) byVehicle[r.vehicle] = { cost: 0, liters: 0 };
      byVehicle[r.vehicle].cost += Number(r.total) || 0;
      byVehicle[r.vehicle].liters += Number(r.liters) || 0;
    }
    return { totalCost, totalLiters, avgPrice, byVehicle };
  }, [filtered]);

  const remove = async (r) => {
    if (!confirm('Excluir este abastecimento?')) return;
    await base44.entities.FuelRecord.delete(r.id);
    if (r.expense_id) await base44.entities.Expense.delete(r.expense_id).catch(() => {});
    toast({ title: 'Abastecimento removido' });
    onReload?.();
  };

  return (
    <div className="space-y-3">
      <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
        <div className="rounded-lg border border-border p-3"><p className="text-xs text-muted-foreground">Gasto total</p><p className="text-lg font-bold">{formatBRL(stats.totalCost)}</p></div>
        <div className="rounded-lg border border-border p-3"><p className="text-xs text-muted-foreground">Litros</p><p className="text-lg font-bold">{stats.totalLiters.toFixed(2)}L</p></div>
        <div className="rounded-lg border border-border p-3"><p className="text-xs text-muted-foreground">Preço médio/L</p><p className="text-lg font-bold">{formatBRL(stats.avgPrice)}</p></div>
        <div className="rounded-lg border border-border p-3"><p className="text-xs text-muted-foreground">Veículos</p><p className="text-lg font-bold">{Object.keys(stats.byVehicle).length}</p></div>
      </div>

      <div className="flex flex-col md:flex-row gap-2 md:items-center">
        <div className="relative flex-1">
          <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
          <Input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Buscar por veículo, motorista, posto..." className="pl-9" />
        </div>
        <Select value={fVehicle} onValueChange={setFVehicle}>
          <SelectTrigger className="md:w-48"><SelectValue placeholder="Veículo" /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">Todos veículos</SelectItem>
            {vehicles.map((v) => <SelectItem key={v} value={v}>{v}</SelectItem>)}
          </SelectContent>
        </Select>
        {can('Registrar combustível') && <Button onClick={() => { setEditing(null); setOpen(true); }}><Plus className="w-4 h-4" /> Novo abastecimento</Button>}
      </div>

      <div className="overflow-x-auto rounded-lg border border-border">
        <table className="w-full text-sm">
          <thead className="bg-muted/50 text-muted-foreground">
            <tr>
              <th className="text-left px-3 py-2 font-medium">Veículo</th>
              <th className="text-left px-3 py-2 font-medium hidden md:table-cell">Motorista</th>
              <th className="text-left px-3 py-2 font-medium">Data</th>
              <th className="text-right px-3 py-2 font-medium">Litros</th>
              <th className="text-right px-3 py-2 font-medium hidden md:table-cell">R$/L</th>
              <th className="text-right px-3 py-2 font-medium">Total</th>
              <th className="text-right px-3 py-2 font-medium hidden lg:table-cell">Km</th>
              <th className="text-center px-3 py-2 font-medium">Ações</th>
            </tr>
          </thead>
          <tbody>
            {filtered.length === 0 && <tr><td colSpan={8} className="text-center py-8 text-muted-foreground">Nenhum abastecimento registrado.</td></tr>}
            {filtered.map((r) => (
              <tr key={r.id} className="border-t border-border hover:bg-muted/30">
                <td className="px-3 py-2 font-medium">{r.vehicle}</td>
                <td className="px-3 py-2 hidden md:table-cell text-muted-foreground">{r.driver_name || '—'}</td>
                <td className="px-3 py-2">{formatDate(r.date)}</td>
                <td className="px-3 py-2 text-right">{Number(r.liters).toFixed(2)}</td>
                <td className="px-3 py-2 text-right hidden md:table-cell">{formatBRL(r.price_per_liter)}</td>
                <td className="px-3 py-2 text-right font-medium">{formatBRL(r.total)}</td>
                <td className="px-3 py-2 text-right hidden lg:table-cell text-muted-foreground">{r.mileage || '—'}</td>
                <td className="px-3 py-2">
                  <div className="flex items-center justify-center gap-1">
                    {can('Registrar combustível') && <Button variant="ghost" size="icon" onClick={() => { setEditing(r); setOpen(true); }} title="Editar"><Pencil className="w-4 h-4" /></Button>}
                    {can('Cancelar despesas') && <Button variant="ghost" size="sm" onClick={() => remove(r)} title="Excluir" className="text-red-600">✕</Button>}
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <FuelFormDialog open={open} record={editing} onClose={() => setOpen(false)} onSaved={onReload} />
    </div>
  );
}