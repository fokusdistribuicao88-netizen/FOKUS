import React, { useState, useMemo } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import {
  Select, SelectTrigger, SelectValue, SelectContent, SelectItem,
} from '@/components/ui/select';
import { Plus, Pencil, Search, Info, ChevronDown, Check } from 'lucide-react';
import { useToast } from '@/components/ui/use-toast';
import { base44 } from '@/api/base44Client';
import { logActivity } from '@/lib/activityLog';
import { useAuth } from '@/lib/AuthContext';
import { syncExpenseFinance } from '@/lib/expenseFinance';
import { EXPENSE_STATUS, statusLabel, statusColor } from '@/lib/expenseCategories';
import { formatBRL, formatDate } from '@/lib/format';
import {
  DropdownMenu, DropdownMenuTrigger, DropdownMenuContent, DropdownMenuItem,
} from '@/components/ui/dropdown-menu';
import { Checkbox } from '@/components/ui/checkbox';
import ExpenseFormDialog from './ExpenseFormDialog';
import ExpenseDetailDialog from './ExpenseDetailDialog';

const COST_CENTERS = ['Operacional', 'Funcionários', 'Veículos', 'Administrativo', 'Vendas', 'Outros'];

export default function ExpensesTab({ expenses, categories, employees, can, onReload }) {
  const { user } = useAuth();
  const { toast } = useToast();
  const [open, setOpen] = useState(false);
  const [editing, setEditing] = useState(null);
  const [detail, setDetail] = useState(null);
  const [q, setQ] = useState('');
  const [fCats, setFCats] = useState([]);
  const [fStatus, setFStatus] = useState('all');
  const [fEmp, setFEmp] = useState('all');
  const [fCompetence, setFCompetence] = useState('all');
  const [fCost, setFCost] = useState('all');

  const filtered = useMemo(() => {
    let list = [...(expenses || [])];
    if (fCats.length) list = list.filter((e) => fCats.includes(e.category));
    if (fStatus !== 'all') list = list.filter((e) => e.status === fStatus);
    if (fEmp !== 'all') list = list.filter((e) => e.employee_id === fEmp);
    if (fCompetence !== 'all') list = list.filter((e) => e.competence_month === fCompetence);
    if (fCost !== 'all') list = list.filter((e) => e.cost_center === fCost);
    const query = q.trim().toLowerCase();
    if (query) {
      list = list.filter((e) =>
        (e.description || '').toLowerCase().includes(query) ||
        (e.supplier || '').toLowerCase().includes(query) ||
        (e.category || '').toLowerCase().includes(query) ||
        (e.employee_name || '').toLowerCase().includes(query)
      );
    }
    return list.sort((a, b) => new Date(b.date || 0) - new Date(a.date || 0));
  }, [expenses, q, fCats, fStatus, fEmp, fCompetence, fCost]);

  const competenceOptions = useMemo(() => {
    const set = new Set();
    for (const e of expenses || []) if (e.competence_month) set.add(e.competence_month);
    return [...set].sort().reverse();
  }, [expenses]);

  const totals = useMemo(() => {
    const valid = filtered.filter((e) => e.status !== 'cancelled');
    return {
      total: valid.reduce((s, e) => s + (Number(e.amount) || 0), 0),
      paid: valid.filter((e) => e.status === 'paid').reduce((s, e) => s + (Number(e.amount) || 0), 0),
      pending: valid.filter((e) => e.status === 'pending').reduce((s, e) => s + (Number(e.amount) || 0), 0),
      overdue: valid.filter((e) => e.status === 'overdue').reduce((s, e) => s + (Number(e.amount) || 0), 0),
    };
  }, [filtered]);

  const openNew = () => { setEditing(null); setOpen(true); };
  const openEdit = (e) => { setEditing(e); setOpen(true); };
  const toggleCat = (name) => setFCats((prev) => prev.includes(name) ? prev.filter((c) => c !== name) : [...prev, name]);

  const setStatus = async (e, status) => {
    const paid_date = status === 'paid' ? new Date().toISOString().slice(0, 10) : (status === 'paid' ? e.paid_date : '');
    await base44.entities.Expense.update(e.id, { status, paid_date });
    const updated = { ...e, status, paid_date };
    await syncExpenseFinance(updated, user);
    await logActivity({ action: 'expense_status', description: `Despesa ${e.description} → ${statusLabel(status)}`, user, entityType: 'Expense', entityId: e.id });
    toast({ title: `Despesa marcada como ${statusLabel(status)}` });
    onReload?.();
  };

  const cancel = async (e) => {
    if (!confirm('Cancelar esta despesa?')) return;
    await base44.entities.Expense.update(e.id, { status: 'cancelled' });
    await logActivity({ action: 'expense_cancel', description: `Cancelou despesa: ${e.description}`, user, entityType: 'Expense', entityId: e.id });
    toast({ title: 'Despesa cancelada' });
    onReload?.();
  };

  return (
    <div className="space-y-3">
      <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
        <div className="rounded-lg border border-border p-3"><p className="text-xs text-muted-foreground">Total</p><p className="text-lg font-bold">{formatBRL(totals.total)}</p></div>
        <div className="rounded-lg border border-border p-3"><p className="text-xs text-muted-foreground">Pago</p><p className="text-lg font-bold text-green-600">{formatBRL(totals.paid)}</p></div>
        <div className="rounded-lg border border-border p-3"><p className="text-xs text-muted-foreground">Pendente</p><p className="text-lg font-bold text-yellow-600">{formatBRL(totals.pending)}</p></div>
        <div className="rounded-lg border border-border p-3"><p className="text-xs text-muted-foreground">Vencido</p><p className="text-lg font-bold text-red-600">{formatBRL(totals.overdue)}</p></div>
      </div>

      <div className="flex flex-col md:flex-row gap-2 md:items-center">
        <div className="relative flex-1">
          <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
          <Input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Buscar despesa..." className="pl-9" />
        </div>
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="outline" size="sm" className="md:w-44 justify-between h-9 font-normal">
              {fCats.length === 0 ? 'Todas categorias' : `${fCats.length} categoria(s)`}
              <ChevronDown className="w-4 h-4 opacity-50" />
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent className="w-52 max-h-64 overflow-y-auto">
            <DropdownMenuItem onClick={() => setFCats([])} className="text-xs text-muted-foreground">
              <Check className={`w-4 h-4 mr-2 ${fCats.length === 0 ? 'opacity-100' : 'opacity-0'}`} />
              Todas categorias
            </DropdownMenuItem>
            {(categories || []).map((c) => (
              <DropdownMenuItem key={c.id || c.name} onClick={() => toggleCat(c.name)} className="cursor-pointer">
                <Checkbox checked={fCats.includes(c.name)} className="mr-2" />
                {c.name}
              </DropdownMenuItem>
            ))}
          </DropdownMenuContent>
        </DropdownMenu>
        <Select value={fStatus} onValueChange={setFStatus}>
          <SelectTrigger className="md:w-40"><SelectValue /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">Todos status</SelectItem>
            {EXPENSE_STATUS.map((s) => <SelectItem key={s.key} value={s.key}>{s.label}</SelectItem>)}
          </SelectContent>
        </Select>
        <Select value={fEmp} onValueChange={setFEmp}>
          <SelectTrigger className="md:w-44"><SelectValue placeholder="Funcionário" /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">Todos func.</SelectItem>
            {(employees || []).map((e) => <SelectItem key={e.id} value={e.id}>{e.name}</SelectItem>)}
          </SelectContent>
        </Select>
        <Select value={fCompetence} onValueChange={setFCompetence}>
          <SelectTrigger className="md:w-40"><SelectValue placeholder="Competência" /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">Toda competência</SelectItem>
            {competenceOptions.map((c) => <SelectItem key={c} value={c}>{c}</SelectItem>)}
          </SelectContent>
        </Select>
        <Select value={fCost} onValueChange={setFCost}>
          <SelectTrigger className="md:w-40"><SelectValue placeholder="C. de custo" /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">Todo c. custo</SelectItem>
            {COST_CENTERS.map((c) => <SelectItem key={c} value={c}>{c}</SelectItem>)}
          </SelectContent>
        </Select>
        {can('Registrar despesas') && <Button onClick={openNew}><Plus className="w-4 h-4" /> Nova</Button>}
      </div>

      <div className="overflow-x-auto rounded-lg border border-border">
        <table className="w-full text-sm">
          <thead className="bg-muted/50 text-muted-foreground">
            <tr>
              <th className="text-left px-3 py-2 font-medium">Descrição</th>
              <th className="text-left px-3 py-2 font-medium hidden md:table-cell">Categoria</th>
              <th className="text-right px-3 py-2 font-medium">Valor</th>
              <th className="text-left px-3 py-2 font-medium hidden md:table-cell">Data</th>
              <th className="text-left px-3 py-2 font-medium hidden lg:table-cell">Competência</th>
              <th className="text-left px-3 py-2 font-medium hidden lg:table-cell">Fornecedor</th>
              <th className="text-center px-3 py-2 font-medium">Status</th>
              <th className="text-center px-3 py-2 font-medium">Ações</th>
            </tr>
          </thead>
          <tbody>
            {filtered.length === 0 && <tr><td colSpan={8} className="text-center py-8 text-muted-foreground">Nenhuma despesa encontrada.</td></tr>}
            {filtered.map((e) => {
              const isPayroll = e.origin === 'folha' || !!e.payroll_id;
              return (
              <tr key={e.id} className="border-t border-border hover:bg-muted/30">
                <td className="px-3 py-2 font-medium">
                  <div className="flex items-center gap-1.5">
                    {e.description}
                    {isPayroll && <span className="text-[10px] px-1.5 py-0.5 rounded bg-blue-100 text-blue-700 font-medium" title="Origem: Folha de Pagamento">Folha</span>}
                  </div>
                </td>
                <td className="px-3 py-2 hidden md:table-cell text-muted-foreground">{e.category}</td>
                <td className="px-3 py-2 text-right font-medium">{formatBRL(e.amount)}</td>
                <td className="px-3 py-2 hidden md:table-cell text-muted-foreground">{formatDate(e.date)}</td>
                <td className="px-3 py-2 hidden lg:table-cell text-muted-foreground">{e.competence_month || '—'}</td>
                <td className="px-3 py-2 hidden lg:table-cell text-muted-foreground">{e.supplier || e.employee_name || '—'}</td>
                <td className="px-3 py-2 text-center"><span className={`text-xs px-2 py-0.5 rounded-full ${statusColor(e.status)}`}>{statusLabel(e.status)}</span></td>
                <td className="px-3 py-2">
                  <div className="flex items-center justify-center gap-1">
                    {isPayroll && (
                      <Button variant="ghost" size="icon" onClick={() => setDetail(e)} title="Ver detalhe da folha"><Info className="w-4 h-4 text-blue-600" /></Button>
                    )}
                    {can('Editar despesas') && e.status !== 'cancelled' && e.status !== 'paid' && !isPayroll && (
                      <Button variant="ghost" size="sm" onClick={() => setStatus(e, 'paid')} title="Marcar pago" className="text-green-600">✓</Button>
                    )}
                    {can('Editar despesas') && !isPayroll && (
                      <Button variant="ghost" size="icon" onClick={() => openEdit(e)} title="Editar"><Pencil className="w-4 h-4" /></Button>
                    )}
                    {can('Cancelar despesas') && e.status !== 'cancelled' && !isPayroll && (
                      <Button variant="ghost" size="sm" onClick={() => cancel(e)} title="Cancelar" className="text-red-600">✕</Button>
                    )}
                  </div>
                </td>
              </tr>
              );
            })}
          </tbody>
        </table>
      </div>

      <ExpenseFormDialog open={open} expense={editing} categories={categories} employees={employees} onClose={() => setOpen(false)} onSaved={onReload} />
      <ExpenseDetailDialog open={!!detail} expense={detail} onClose={() => setDetail(null)} />
    </div>
  );
}