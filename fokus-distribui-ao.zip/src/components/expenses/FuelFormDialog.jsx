import React, { useState, useEffect } from 'react';
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import {
  Select, SelectTrigger, SelectValue, SelectContent, SelectItem,
} from '@/components/ui/select';
import { useAuth } from '@/lib/AuthContext';
import { useToast } from '@/components/ui/use-toast';
import { base44 } from '@/api/base44Client';
import { logActivity } from '@/lib/activityLog';
import { syncExpenseFinance } from '@/lib/expenseFinance';
import { FUEL_TYPES, EXPENSE_PAYMENT_METHODS } from '@/lib/expenseCategories';
import { formatBRL } from '@/lib/format';

const empty = {
  vehicle: '', driver_name: '', date: new Date().toISOString().slice(0, 10),
  station: '', liters: '', price_per_liter: '', total: 0, mileage: '',
  fuel_type: 'flex', payment_method: 'Dinheiro', notes: '',
};

export default function FuelFormDialog({ open, record, onClose, onSaved }) {
  const { user } = useAuth();
  const { toast } = useToast();
  const [form, setForm] = useState(empty);
  const [saving, setSaving] = useState(false);

  useEffect(() => { if (open) setForm(record ? { ...empty, ...record } : empty); }, [open, record]);

  const set = (k, v) => setForm((f) => {
    const next = { ...f, [k]: v };
    if (k === 'liters' || k === 'price_per_liter') {
      next.total = Math.round(((Number(next.liters) || 0) * (Number(next.price_per_liter) || 0)) * 100) / 100;
    }
    return next;
  });

  const submit = async () => {
    if (!form.vehicle?.trim()) return toast({ title: 'Informe o veículo', variant: 'destructive' });
    if (!form.liters || Number(form.liters) <= 0) return toast({ title: 'Litros inválidos', variant: 'destructive' });
    setSaving(true);
    try {
      const total = Math.round(((Number(form.liters) || 0) * (Number(form.price_per_liter) || 0)) * 100) / 100;
      const payload = { ...form, liters: Number(form.liters) || 0, price_per_liter: Number(form.price_per_liter) || 0, total, mileage: Number(form.mileage) || 0, registered_by: user?.email || '' };
      let saved;
      if (record?.id) {
        saved = await base44.entities.FuelRecord.update(record.id, payload);
      } else {
        saved = await base44.entities.FuelRecord.create(payload);
        // Cria despesa vinculada na categoria Combustível
        const expense = await base44.entities.Expense.create({
          category: 'Combustível',
          description: `Combustível ${form.vehicle} — ${form.liters}L`,
          amount: total,
          date: form.date,
          payment_method: form.payment_method,
          vehicle: form.vehicle,
          employee_name: form.driver_name,
          cost_center: 'Veículos',
          status: 'paid',
          paid_date: form.date,
          notes: `Abastecimento em ${form.station || 'posto'}`,
          origin: 'combustivel',
          origin_id: saved.id,
          registered_by: user?.email || '',
        });
        const feId = await syncExpenseFinance(expense, user);
        if (feId) await base44.entities.Expense.update(expense.id, { financial_entry_id: feId });
        await base44.entities.FuelRecord.update(saved.id, { expense_id: expense.id });
        await logActivity({ action: 'fuel_create', description: `Abastecimento ${form.vehicle}: ${form.liters}L`, user, entityType: 'FuelRecord', entityId: saved.id });
      }
      toast({ title: 'Abastecimento salvo' });
      onSaved?.(saved);
      onClose();
    } catch (e) {
      toast({ title: 'Erro', description: e.message, variant: 'destructive' });
    } finally {
      setSaving(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={(op) => !op && onClose()}>
      <DialogContent className="max-w-lg">
        <DialogHeader><DialogTitle>{record?.id ? 'Editar abastecimento' : 'Novo abastecimento'}</DialogTitle></DialogHeader>
        <div className="space-y-3">
          <div className="grid grid-cols-2 gap-3">
            <div><Label>Veículo *</Label><Input value={form.vehicle} onChange={(e) => set('vehicle', e.target.value)} placeholder="Placa/nome" /></div>
            <div><Label>Motorista</Label><Input value={form.driver_name} onChange={(e) => set('driver_name', e.target.value)} /></div>
            <div><Label>Data</Label><Input type="date" value={form.date} onChange={(e) => set('date', e.target.value)} /></div>
            <div><Label>Posto</Label><Input value={form.station} onChange={(e) => set('station', e.target.value)} /></div>
            <div><Label>Litros *</Label><Input type="number" step="0.01" value={form.liters} onChange={(e) => set('liters', e.target.value)} /></div>
            <div><Label>Preço/litro</Label><Input type="number" step="0.01" value={form.price_per_liter} onChange={(e) => set('price_per_liter', e.target.value)} /></div>
            <div><Label>Valor total</Label><Input value={formatBRL(form.total)} disabled className="bg-muted/40 font-semibold" /></div>
            <div><Label>Quilometragem</Label><Input type="number" value={form.mileage} onChange={(e) => set('mileage', e.target.value)} /></div>
            <div>
              <Label>Tipo de combustível</Label>
              <Select value={form.fuel_type} onValueChange={(v) => set('fuel_type', v)}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>{FUEL_TYPES.map((t) => <SelectItem key={t.key} value={t.key}>{t.label}</SelectItem>)}</SelectContent>
              </Select>
            </div>
            <div>
              <Label>Forma de pagamento</Label>
              <Select value={form.payment_method} onValueChange={(v) => set('payment_method', v)}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>{EXPENSE_PAYMENT_METHODS.map((m) => <SelectItem key={m} value={m}>{m}</SelectItem>)}</SelectContent>
              </Select>
            </div>
          </div>
          <div><Label>Observações</Label><Textarea rows={2} value={form.notes} onChange={(e) => set('notes', e.target.value)} /></div>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={onClose} disabled={saving}>Cancelar</Button>
          <Button onClick={submit} disabled={saving}>{saving ? 'Salvando...' : 'Salvar'}</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}