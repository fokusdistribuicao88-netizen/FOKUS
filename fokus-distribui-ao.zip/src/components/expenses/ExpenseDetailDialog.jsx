import React, { useEffect, useState } from 'react';
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription,
} from '@/components/ui/dialog';
import { Badge } from '@/components/ui/badge';
import { base44 } from '@/api/base44Client';
import { formatBRL, formatDate } from '@/lib/format';
import { statusLabel, statusColor } from '@/lib/expenseCategories';

function Row({ label, value, strong = false, muted = false }) {
  return (
    <div className="flex justify-between py-1.5 border-b border-border last:border-0">
      <span className={`text-sm ${muted ? 'text-muted-foreground' : ''}`}>{label}</span>
      <span className={`text-sm tabular-nums ${strong ? 'font-bold' : 'font-medium'}`}>{value}</span>
    </div>
  );
}

export default function ExpenseDetailDialog({ open, expense, onClose }) {
  const [payroll, setPayroll] = useState(null);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (!open || !expense?.payroll_id) { setPayroll(null); return; }
    setLoading(true);
    base44.entities.Payroll.get(expense.payroll_id)
      .then(setPayroll)
      .catch(() => setPayroll(null))
      .finally(() => setLoading(false));
  }, [open, expense]);

  if (!expense) return null;
  const isPayroll = expense.origin === 'folha' || !!expense.payroll_id;

  return (
    <Dialog open={open} onOpenChange={(op) => !op && onClose()}>
      <DialogContent className="max-w-lg max-h-[92vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            Detalhe da despesa
            {isPayroll && <Badge className="bg-blue-100 text-blue-800">Folha de Pagamento</Badge>}
          </DialogTitle>
          <DialogDescription>{expense.description}</DialogDescription>
        </DialogHeader>

        <div className="space-y-4">
          <div className="grid grid-cols-2 gap-3 text-sm">
            <div><span className="text-muted-foreground">Categoria:</span> <span className="font-medium">{expense.category}</span></div>
            <div><span className="text-muted-foreground">Centro de custo:</span> <span className="font-medium">{expense.cost_center || '—'}</span></div>
            <div><span className="text-muted-foreground">Funcionário:</span> <span className="font-medium">{expense.employee_name || '—'}</span></div>
            <div><span className="text-muted-foreground">Competência:</span> <span className="font-medium">{expense.competence_month || '—'}</span></div>
            <div><span className="text-muted-foreground">Vencimento:</span> <span className="font-medium">{formatDate(expense.due_date)}</span></div>
            <div><span className="text-muted-foreground">Pagamento:</span> <span className="font-medium">{expense.paid_date ? formatDate(expense.paid_date) : '—'}</span></div>
            <div><span className="text-muted-foreground">Status:</span> <span className={`text-xs px-2 py-0.5 rounded-full ${statusColor(expense.status)}`}>{statusLabel(expense.status)}</span></div>
            <div><span className="text-muted-foreground">Valor:</span> <span className="font-bold">{formatBRL(expense.amount)}</span></div>
          </div>

          {isPayroll && (
            <>
              <div className="rounded-lg border border-border p-3">
                <p className="text-sm font-semibold mb-2 text-green-700">Proventos</p>
                <Row label="Salário base" value={formatBRL(payroll?.base_salary ?? 0)} muted />
                <Row label="Horas extras" value={formatBRL(payroll?.overtime_total ?? 0)} muted />
                <Row label="Bonificação" value={formatBRL(expense.bonus ?? payroll?.bonus ?? 0)} muted />
                <Row label="Outros acréscimos" value={formatBRL(expense.additions ?? 0)} muted />
                <Row label="Salário bruto" value={formatBRL(expense.gross_salary ?? payroll?.gross_salary ?? 0)} strong />
              </div>

              <div className="rounded-lg border border-border p-3">
                <p className="text-sm font-semibold mb-2 text-red-700">Descontos</p>
                <Row label="INSS" value={formatBRL(expense.inss ?? 0)} muted />
                <Row label="Adiantamentos" value={formatBRL(expense.advances_total ?? 0)} muted />
                <Row label="Compras descontadas" value={formatBRL(expense.purchases_total ?? 0)} muted />
                <Row label="Outros descontos" value={formatBRL(expense.other_discounts ?? 0)} muted />
                <Row label="Total de descontos" value={formatBRL((expense.inss || 0) + (expense.advances_total || 0) + (expense.purchases_total || 0) + (expense.other_discounts || 0))} strong />
              </div>

              <div className="rounded-lg border-2 border-blue-200 bg-blue-50 p-3 flex items-center justify-between">
                <span className="text-sm text-blue-900">Salário líquido (valor pago pela empresa)</span>
                <span className="text-xl font-bold text-blue-900">{formatBRL(expense.net_salary ?? expense.amount)}</span>
              </div>

              {payroll && (
                <div className="text-xs text-muted-foreground space-y-1">
                  <p>Folha correspondente: <span className="font-medium text-foreground">{payroll.competence_month}</span></p>
                  <p>Fechada por: <span className="font-medium text-foreground">{payroll.closed_by || '—'}</span></p>
                  <p>Data de fechamento: <span className="font-medium text-foreground">{payroll.closed_at ? formatDate(payroll.closed_at.slice(0, 10)) : '—'}</span></p>
                  {loading && <p>Carregando folha...</p>}
                </div>
              )}
            </>
          )}

          {expense.notes && (
            <div className="text-sm">
              <p className="text-muted-foreground mb-1">Observações</p>
              <p className="whitespace-pre-wrap">{expense.notes}</p>
            </div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}