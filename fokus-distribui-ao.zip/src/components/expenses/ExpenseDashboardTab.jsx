import React, { useMemo, useState } from 'react';
import { Input } from '@/components/ui/input';
import {
  Select, SelectTrigger, SelectValue, SelectContent, SelectItem,
} from '@/components/ui/select';
import {
  BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, PieChart, Pie, Cell, Legend, CartesianGrid,
} from 'recharts';
import { formatBRL } from '@/lib/format';
import { EXPENSE_STATUS, statusLabel } from '@/lib/expenseCategories';

const GROUP_LABELS = {
  operacional: 'Operacional', funcionarios: 'Funcionários', veiculos: 'Veículos',
  servicos: 'Serviços', impostos: 'Impostos', outros: 'Outros',
};

export default function ExpenseDashboardTab({ expenses, categories }) {
  const [period, setPeriod] = useState('month'); // month, all, range
  const [month, setMonth] = useState(new Date().toISOString().slice(0, 7));

  const catGroup = useMemo(() => {
    const map = {};
    for (const c of categories || []) map[c.name] = c.group || 'outros';
    return map;
  }, [categories]);

  const filtered = useMemo(() => {
    let list = (expenses || []).filter((e) => e.status !== 'cancelled');
    if (period === 'month') {
      list = list.filter((e) => (e.date || '').startsWith(month));
    }
    return list;
  }, [expenses, period, month]);

  const totals = useMemo(() => {
    const t = { total: 0, paid: 0, pending: 0, overdue: 0 };
    for (const e of filtered) {
      const v = Number(e.amount) || 0;
      t.total += v;
      if (e.status === 'paid') t.paid += v;
      else if (e.status === 'overdue') t.overdue += v;
      else if (e.status === 'pending') t.pending += v;
    }
    return t;
  }, [filtered]);

  const byCategory = useMemo(() => {
    const map = {};
    for (const e of filtered) {
      const k = e.category || 'Outros';
      map[k] = (map[k] || 0) + (Number(e.amount) || 0);
    }
    return Object.entries(map).map(([name, value]) => ({ name, value })).sort((a, b) => b.value - a.value);
  }, [filtered]);

  const byGroup = useMemo(() => {
    const map = {};
    for (const e of filtered) {
      const g = catGroup[e.category] || 'outros';
      map[g] = (map[g] || 0) + (Number(e.amount) || 0);
    }
    return Object.entries(map).map(([key, value]) => ({ name: GROUP_LABELS[key] || key, value })).sort((a, b) => b.value - a.value);
  }, [filtered, catGroup]);

  const byStatus = useMemo(() => {
    const map = {};
    for (const e of filtered) {
      map[e.status] = (map[e.status] || 0) + (Number(e.amount) || 0);
    }
    return EXPENSE_STATUS.map((s) => ({ name: s.label, value: map[s.key] || 0 })).filter((x) => x.value > 0);
  }, [filtered]);

  const COLORS = ['#3b82f6', '#ef4444', '#f59e0b', '#10b981', '#8b5cf6', '#ec4899', '#06b6d4', '#64748b'];

  return (
    <div className="space-y-4">
      <div className="flex flex-col md:flex-row gap-2 md:items-center">
        <Select value={period} onValueChange={setPeriod}>
          <SelectTrigger className="md:w-48"><SelectValue /></SelectTrigger>
          <SelectContent>
            <SelectItem value="month">Mês específico</SelectItem>
            <SelectItem value="all">Todo o histórico</SelectItem>
          </SelectContent>
        </Select>
        {period === 'month' && <Input type="month" value={month} onChange={(e) => setMonth(e.target.value)} className="md:w-44" />}
      </div>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        <div className="rounded-lg border border-border p-4 bg-muted/20"><p className="text-xs text-muted-foreground">Total do período</p><p className="text-xl font-bold">{formatBRL(totals.total)}</p></div>
        <div className="rounded-lg border border-border p-4 bg-green-50"><p className="text-xs text-muted-foreground">Pago</p><p className="text-xl font-bold text-green-700">{formatBRL(totals.paid)}</p></div>
        <div className="rounded-lg border border-border p-4 bg-yellow-50"><p className="text-xs text-muted-foreground">Pendente</p><p className="text-xl font-bold text-yellow-700">{formatBRL(totals.pending)}</p></div>
        <div className="rounded-lg border border-border p-4 bg-red-50"><p className="text-xs text-muted-foreground">Vencido</p><p className="text-xl font-bold text-red-700">{formatBRL(totals.overdue)}</p></div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <div className="rounded-lg border border-border p-4">
          <p className="text-sm font-semibold mb-3">Despesas por grupo</p>
          <ResponsiveContainer width="100%" height={260}>
            <BarChart data={byGroup}>
              <CartesianGrid strokeDasharray="3 3" className="stroke-border" />
              <XAxis dataKey="name" tick={{ fontSize: 11 }} />
              <YAxis tick={{ fontSize: 11 }} />
              <Tooltip formatter={(v) => formatBRL(v)} />
              <Bar dataKey="value" fill="#3b82f6" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>

        <div className="rounded-lg border border-border p-4">
          <p className="text-sm font-semibold mb-3">Despesas por categoria</p>
          {byCategory.length === 0 ? (
            <p className="text-center text-muted-foreground py-10">Sem dados no período.</p>
          ) : (
            <ResponsiveContainer width="100%" height={260}>
              <PieChart>
                <Pie data={byCategory} dataKey="value" nameKey="name" cx="50%" cy="50%" outerRadius={90} label={(d) => d.name}>
                  {byCategory.map((_, i) => <Cell key={i} fill={COLORS[i % COLORS.length]} />)}
                </Pie>
                <Tooltip formatter={(v) => formatBRL(v)} />
                <Legend wrapperStyle={{ fontSize: 11 }} />
              </PieChart>
            </ResponsiveContainer>
          )}
        </div>
      </div>

      <div className="rounded-lg border border-border p-4">
        <p className="text-sm font-semibold mb-3">Despesas por status</p>
        {byStatus.length === 0 ? (
          <p className="text-center text-muted-foreground py-6">Sem dados.</p>
        ) : (
          <ResponsiveContainer width="100%" height={200}>
            <BarChart data={byStatus} layout="vertical">
              <CartesianGrid strokeDasharray="3 3" className="stroke-border" />
              <XAxis type="number" tick={{ fontSize: 11 }} tickFormatter={(v) => `R$ ${v}`} />
              <YAxis type="category" dataKey="name" tick={{ fontSize: 11 }} width={80} />
              <Tooltip formatter={(v) => formatBRL(v)} />
              <Bar dataKey="value" fill="#8b5cf6" radius={[0, 4, 4, 0]} />
            </BarChart>
          </ResponsiveContainer>
        )}
      </div>

      {byCategory.length > 0 && (
        <div className="rounded-lg border border-border overflow-hidden">
          <table className="w-full text-sm">
            <thead className="bg-muted/50 text-muted-foreground">
              <tr><th className="text-left px-3 py-2 font-medium">Categoria</th><th className="text-right px-3 py-2 font-medium">Total</th><th className="text-right px-3 py-2 font-medium hidden md:table-cell">% do total</th></tr>
            </thead>
            <tbody>
              {byCategory.map((c) => (
                <tr key={c.name} className="border-t border-border">
                  <td className="px-3 py-2">{c.name}</td>
                  <td className="px-3 py-2 text-right font-medium">{formatBRL(c.value)}</td>
                  <td className="px-3 py-2 text-right hidden md:table-cell text-muted-foreground">{totals.total > 0 ? ((c.value / totals.total) * 100).toFixed(1) : 0}%</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}