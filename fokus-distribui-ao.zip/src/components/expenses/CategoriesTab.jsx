import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter,
} from '@/components/ui/dialog';
import {
  Select, SelectTrigger, SelectValue, SelectContent, SelectItem,
} from '@/components/ui/select';
import { Plus, Pencil, Trash2 } from 'lucide-react';
import { useToast } from '@/components/ui/use-toast';
import { base44 } from '@/api/base44Client';
import { useAuth } from '@/lib/AuthContext';
import { logActivity } from '@/lib/activityLog';
import { EXPENSE_GROUPS } from '@/lib/expenseCategories';

const empty = { name: '', description: '', color: '#3b82f6', group: 'outros', status: 'active' };

export default function CategoriesTab({ categories, can, onReload }) {
  const { user } = useAuth();
  const { toast } = useToast();
  const [open, setOpen] = useState(false);
  const [editing, setEditing] = useState(null);
  const [form, setForm] = useState(empty);

  const set = (k, v) => setForm((f) => ({ ...f, [k]: v }));
  const openNew = () => { setEditing(null); setForm(empty); setOpen(true); };
  const openEdit = (c) => { setEditing(c); setForm({ ...empty, ...c }); setOpen(true); };

  const submit = async () => {
    if (!form.name?.trim()) return toast({ title: 'Nome obrigatório', variant: 'destructive' });
    const dup = categories.find((c) => c.name.trim().toLowerCase() === form.name.trim().toLowerCase() && c.id !== editing?.id);
    if (dup) return toast({ title: 'Categoria duplicada', description: `Já existe uma categoria chamada "${dup.name}"`, variant: 'destructive' });
    try {
      if (editing?.id) {
        await base44.entities.ExpenseCategory.update(editing.id, form);
        await logActivity({ action: 'expense_category_update', description: `Editou categoria ${form.name}`, user, entityType: 'ExpenseCategory', entityId: editing.id });
      } else {
        const saved = await base44.entities.ExpenseCategory.create(form);
        await logActivity({ action: 'expense_category_create', description: `Criou categoria ${form.name}`, user, entityType: 'ExpenseCategory', entityId: saved.id });
      }
      toast({ title: 'Categoria salva' });
      setOpen(false);
      onReload?.();
    } catch (e) {
      toast({ title: 'Erro', description: e.message, variant: 'destructive' });
    }
  };

  const remove = async (c) => {
    if (!confirm(`Excluir categoria "${c.name}"?`)) return;
    try {
      await base44.entities.ExpenseCategory.delete(c.id);
      toast({ title: 'Categoria removida' });
    } catch (e) {
      if (e.message?.includes('not found')) {
        toast({ title: 'Categoria já removida', variant: 'warning' });
      } else {
        toast({ title: 'Erro', description: e.message, variant: 'destructive' });
      }
    }
    onReload?.();
  };

  return (
    <div className="space-y-3">
      <div className="flex justify-between items-center">
        <p className="text-sm text-muted-foreground">{categories.length} categorias cadastradas</p>
        {can('Registrar despesas') && <Button onClick={openNew}><Plus className="w-4 h-4" /> Nova categoria</Button>}
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
        {categories.map((c) => (
          <div key={c.id} className="rounded-lg border border-border p-3 flex items-center gap-3">
            <div className="w-3 h-10 rounded-full" style={{ backgroundColor: c.color || '#3b82f6' }} />
            <div className="flex-1 min-w-0">
              <p className="font-medium truncate">{c.name}</p>
              <p className="text-xs text-muted-foreground">{EXPENSE_GROUPS.find((g) => g.key === c.group)?.label || c.group}</p>
            </div>
            <div className="flex gap-1">
              {can('Registrar despesas') && <Button variant="ghost" size="icon" onClick={() => openEdit(c)}><Pencil className="w-4 h-4" /></Button>}
              {can('Cancelar despesas') && <Button variant="ghost" size="icon" onClick={() => remove(c)}><Trash2 className="w-4 h-4 text-red-600" /></Button>}
            </div>
          </div>
        ))}
      </div>

      <Dialog open={open} onOpenChange={(op) => !op && setOpen(false)}>
        <DialogContent className="max-w-md">
          <DialogHeader><DialogTitle>{editing?.id ? 'Editar categoria' : 'Nova categoria'}</DialogTitle></DialogHeader>
          <div className="space-y-3">
            <div><Label>Nome *</Label><Input value={form.name} onChange={(e) => set('name', e.target.value)} /></div>
            <div><Label>Descrição</Label><Textarea rows={2} value={form.description} onChange={(e) => set('description', e.target.value)} /></div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <Label>Grupo</Label>
                <Select value={form.group} onValueChange={(v) => set('group', v)}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>{EXPENSE_GROUPS.map((g) => <SelectItem key={g.key} value={g.key}>{g.label}</SelectItem>)}</SelectContent>
                </Select>
              </div>
              <div><Label>Cor</Label><Input type="color" value={form.color} onChange={(e) => set('color', e.target.value)} className="h-9" /></div>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setOpen(false)}>Cancelar</Button>
            <Button onClick={submit}>Salvar</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}