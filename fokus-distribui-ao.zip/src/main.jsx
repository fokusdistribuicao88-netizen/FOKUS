import React from 'react'
import ReactDOM from 'react-dom/client'
import App from '@/App.jsx'
import '@/index.css'

// DEV: unregister ALL service workers and clear ALL caches.
// A stale service worker was cache-serving mismatched Vite dep chunks
// (React from one optimization pass, React-DOM from another) → "useState is null".
// Removing the SW + clearing its Cache API caches forces fresh fetches from the
// Vite dev server, and the ?v= hash on chunk URLs busts the browser HTTP cache.
if (import.meta.env.DEV && 'serviceWorker' in navigator) {
  navigator.serviceWorker.getRegistrations().then((regs) => {
    regs.forEach((r) => r.unregister());
  }).catch(() => {});
}
if (import.meta.env.DEV && window.caches) {
  caches.keys().then((keys) => {
    keys.forEach((k) => caches.delete(k));
  }).catch(() => {});
}

ReactDOM.createRoot(document.getElementById('root')).render(
  <App />
)