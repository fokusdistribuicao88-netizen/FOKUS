import { createClientFromRequest } from 'npm:@base44/sdk@0.8.40';
import { secrets } from 'base44:runtime';

/**
 * Cria um pagamento PIX dinâmico no Mercado Pago.
 *
 * Recebe: { amount, description?, external_reference?, payer_email?, payer_name? }
 * Retorna: { payment_id, status, qr_code, qr_code_base64, external_reference }
 *
 * O QR Code dinâmico é único por transação e permite confirmação automática via webhook.
 */
export default async function(req) {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    const body = await req.json();
    const { amount, description, external_reference, payer_email, payer_name } = body;

    const accessToken = (secrets.get('MERCADO_PAGO_ACCESS_TOKEN') || '').trim();
    if (!accessToken) {
      return Response.json({ error: 'Mercado Pago não configurado. Defina o token de acesso nas configurações.' }, { status: 500 });
    }

    if (!amount || Number(amount) <= 0) {
      return Response.json({ error: 'Valor inválido' }, { status: 400 });
    }

    const ref = external_reference || `PDV-${Date.now()}`;

    const paymentData = {
      transaction_amount: Number(amount),
      payment_method_id: 'pix',
      description: description || 'Venda PDV',
      external_reference: ref,
      payer: {
        email: payer_email || 'cliente@fokus.com.br',
        first_name: payer_name || 'Cliente PDV',
      },
    };

    const response = await fetch('https://api.mercadopago.com/v1/payments', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${accessToken}`,
        'Content-Type': 'application/json',
        'X-Idempotency-Key': ref,
      },
      body: JSON.stringify(paymentData),
    });

    const data = await response.json();

    if (!response.ok) {
      return Response.json({ error: data.message || 'Erro no Mercado Pago', details: data }, { status: response.status });
    }

    const txData = data.point_of_interaction?.transaction_data;

    return Response.json({
      payment_id: data.id,
      status: data.status,
      qr_code: txData?.qr_code || '',
      qr_code_base64: txData?.qr_code_base64 || '',
      external_reference: data.external_reference,
    });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
}