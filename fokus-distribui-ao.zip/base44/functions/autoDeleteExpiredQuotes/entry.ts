import { createClientFromRequest } from 'npm:@base44/sdk@0.8.44';

/**
 * Expiração automática de orçamentos.
 *
 * Executado diariamente por workflow agendado. Faz três coisas:
 *  1. Marca como "expirado" os orçamentos cuja validade venceu (não convertidos).
 *  2. Registra avisos de proximidade da expiração (7, 3 e 1 dias) no campo
 *     expiry_warning_sent para a UI exibir alertas.
 *  3. Envia para a lixeira (soft-delete: define deleted_at + deletion_reason) os
 *     orçamentos não convertidos cuja data de criação ultrapassou
 *     settings.quote_auto_delete_days (padrão 30).
 *
 * Orçamentos JÁ convertidos em pedido (status = "transformado") são protegidos
 * e nunca são excluídos — permanecem no histórico para auditoria.
 *
 * Retorna: { processed, expired, warned, deleted, results }
 */
const CONVERTED = 'transformado';
const CANCELLED = 'cancelado';

export default async function(req) {
  try {
    const base44 = createClientFromRequest(req);

    try {
      const user = await base44.auth.me();
      if (user && user.role !== 'admin' && user.role !== 'gerente') {
        return Response.json({ error: 'Forbidden' }, { status: 403 });
      }
    } catch { /* sem usuário — contexto agendado */ }

    const sr = base44.asServiceRole;

    // Configuração de dias para exclusão automática
    let autoDeleteDays = 30;
    try {
      const settings = await sr.entities.Settings.list('-updated_date', 1);
      if (settings && settings[0] && Number(settings[0].quote_auto_delete_days) > 0) {
        autoDeleteDays = Number(settings[0].quote_auto_delete_days);
      }
    } catch { /* fallback padrão */ }

    const now = new Date();
    const today = now.toISOString().slice(0, 10);
    const autoDeleteCutoff = new Date(now.getTime() - autoDeleteDays * 86400000);

    const quotes = await sr.entities.Quote.list('-created_date', 1000);

    let expired = 0;
    let warned = 0;
    let deleted = 0;
    const results = [];

    for (const quote of (quotes || [])) {
      // Protege orçamentos convertidos ou cancelados da exclusão automática
      if (quote.status === CONVERTED || quote.status === CANCELLED) {
        results.push({ id: quote.id, skipped: 'protected' });
        continue;
      }
      // Já na lixeira — pula
      if (quote.deleted_at) {
        results.push({ id: quote.id, skipped: 'already_deleted' });
        continue;
      }

      const createdDate = quote.created_date ? new Date(quote.created_date) : null;
      const validUntil = quote.valid_until ? new Date(quote.valid_until + 'T00:00:00') : null;

      // 1. Exclusão automática (lixeira) — criação mais antiga que o limite
      if (createdDate && createdDate < autoDeleteCutoff) {
        await sr.entities.Quote.update(quote.id, {
          status: 'expirado',
          deleted_at: now.toISOString(),
          deletion_reason: 'Expiração automática',
          expiry_warning_sent: 'deleted',
          timeline: [
            ...(quote.timeline || []),
            { date: now.toISOString(), event: `Exclusão automática — orçamento não convertido em ${autoDeleteDays} dias`, author: 'Sistema' },
          ],
        });
        deleted++;
        results.push({ id: quote.id, deleted: true });
        continue;
      }

      // 2. Marcar como expirado (validade vencida)
      if (validUntil && validUntil < now && quote.status !== 'expirado') {
        await sr.entities.Quote.update(quote.id, {
          status: 'expirado',
          timeline: [
            ...(quote.timeline || []),
            { date: now.toISOString(), event: 'Orçamento expirado — validade vencida', author: 'Sistema' },
          ],
        });
        expired++;
        results.push({ id: quote.id, expired: true });
        continue;
      }

      // 3. Avisos de proximidade da expiração (7, 3, 1 dias)
      if (validUntil) {
        const daysLeft = Math.ceil((validUntil.getTime() - now.getTime()) / 86400000);
        const lastWarn = quote.expiry_warning_sent || '';
        let newWarn = null;
        if (daysLeft <= 1 && daysLeft >= 0 && lastWarn !== '1') newWarn = '1';
        else if (daysLeft <= 3 && daysLeft > 1 && lastWarn !== '3') newWarn = '3';
        else if (daysLeft <= 7 && daysLeft > 3 && lastWarn !== '7') newWarn = '7';

        if (newWarn) {
          await sr.entities.Quote.update(quote.id, {
            expiry_warning_sent: newWarn,
            timeline: [
              ...(quote.timeline || []),
              { date: now.toISOString(), event: `Aviso de expiração — ${daysLeft} dia(s) restante(s)`, author: 'Sistema' },
            ],
          });
          warned++;
          results.push({ id: quote.id, warned: newWarn });
        }
      }
    }

    return Response.json({
      processed: (quotes || []).length,
      expired,
      warned,
      deleted,
      auto_delete_days: autoDeleteDays,
      results,
    });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
}