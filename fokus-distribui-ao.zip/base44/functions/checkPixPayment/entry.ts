import { createClientFromRequest } from 'npm:@base44/sdk@0.8.40';
import { secrets } from 'base44:runtime';

/**
 * Consulta o status de um pagamento PIX no Mercado Pago.
 *
 * Recebe: { payment_id }
 * Retorna: { status, approved, external_reference, amount }
 *
 * Usado pelo PDV para detectar pagamento automaticamente (polling),
 * sem depender de webhook configurado.
 */
export default async function(req) {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    const body = await req.json();
    const paymentId = body?.payment_id;
    if (!paymentId) return Response.json({ error: 'payment_id é obrigatório' }, { status: 400 });

    const accessToken = (secrets.get('MERCADO_PAGO_ACCESS_TOKEN') || '').trim();
    if (!accessToken) {
      return Response.json({ error: 'Mercado Pago não configurado' }, { status: 500 });
    }

    const response = await fetch(`https://api.mercadopago.com/v1/payments/${paymentId}`, {
      headers: { 'Authorization': `Bearer ${accessToken}` },
    });

    if (!response.ok) {
      return Response.json({ error: 'Erro ao consultar Mercado Pago', mpStatus: response.status }, { status: 502 });
    }

    const payment = await response.json();
    const status = String(payment.status || '').toLowerCase();

    return Response.json({
      status,
      approved: status === 'approved',
      external_reference: payment.external_reference || '',
      amount: Number(payment.transaction_amount) || 0,
    });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
}