import { createClientFromRequest } from 'npm:@base44/sdk@0.8.40';
import { secrets } from 'base44:runtime';

/**
 * Webhook para confirmação automática de pagamentos PIX (Mercado Pago).
 *
 * Autenticação: validação oficial por assinatura HMAC-SHA256 (header x-signature),
 * conforme documentação do Mercado Pago. Não usa mais token na URL.
 *
 * Mercado Pago envia:
 *   - Header: x-signature = "ts=<timestamp>,v1=<hash_hmac_sha256>"
 *   - Header: x-request-id = "<uuid>"
 *   - Query param: data.id = "<payment_id>"
 *   - Body: { action, data: { id }, ... }
 *
 * O manifest assinado é: "id:<data.id>;request-id:<x-request-id>;ts:<ts>;"
 * (pares com valor ausente são omitidos).
 */

// ---- Helpers de criptografia (Web Crypto API) ----

async function hmacSha256Hex(key: string, message: string): Promise<string> {
  const enc = new TextEncoder();
  const cryptoKey = await crypto.subtle.importKey(
    'raw',
    enc.encode(key),
    { name: 'HMAC', hash: 'SHA-256' },
    false,
    ['sign']
  );
  const sig = await crypto.subtle.sign('HMAC', cryptoKey, enc.encode(message));
  const bytes = new Uint8Array(sig);
  return Array.from(bytes).map((b) => b.toString(16).padStart(2, '0')).join('');
}

// Comparação timing-safe entre dois hex strings (proteção contra timing attacks)
function timingSafeEqualHex(a: string, b: string): boolean {
  if (a.length !== b.length) return false;
  let result = 0;
  for (let i = 0; i < a.length; i++) {
    result |= a.charCodeAt(i) ^ b.charCodeAt(i);
  }
  return result === 0;
}

// Faz o parse do header x-signature no formato "ts=<ts>,v1=<hash>"
function parseSignatureHeader(header: string): { ts: string; v1: string } {
  const parts = header.split(',').map((p) => p.trim());
  let ts = '';
  let v1 = '';
  for (const part of parts) {
    const eq = part.indexOf('=');
    if (eq === -1) continue;
    const key = part.slice(0, eq).trim();
    const value = part.slice(eq + 1).trim();
    if (key === 'ts') ts = value;
    else if (key === 'v1') v1 = value;
  }
  return { ts, v1 };
}

// Monta o manifest conforme documentação oficial do MP.
// Pares com valor ausente são omitidos.
function buildManifest(dataId: string, requestId: string, ts: string): string {
  const parts: string[] = [];
  if (dataId) parts.push(`id:${dataId}`);
  if (requestId) parts.push(`request-id:${requestId}`);
  if (ts) parts.push(`ts:${ts}`);
  return parts.join(';') + ';';
}

export default async function (req: Request) {
  try {
    const url = new URL(req.url);

    // 1. Validar assinatura HMAC-SHA256 (x-signature)
    const webhookSecret = secrets.get('MERCADO_PAGO_WEBHOOK_SECRET') || '';
    if (!webhookSecret) {
      return Response.json(
        { error: 'MERCADO_PAGO_WEBHOOK_SECRET not configured' },
        { status: 500 }
      );
    }

    const signatureHeader = req.headers.get('x-signature') || '';
    const requestId = req.headers.get('x-request-id') || '';
    const dataId = url.searchParams.get('data.id') || '';

    if (!signatureHeader) {
      return Response.json({ error: 'Missing x-signature header' }, { status: 401 });
    }

    const { ts, v1 } = parseSignatureHeader(signatureHeader);
    if (!ts || !v1) {
      return Response.json({ error: 'Invalid x-signature format' }, { status: 401 });
    }

    // Monta o manifest e calcula o HMAC esperado
    const manifest = buildManifest(dataId, requestId, ts);
    const expectedHash = await hmacSha256Hex(webhookSecret, manifest);

    if (!timingSafeEqualHex(expectedHash, v1)) {
      return Response.json({ error: 'Invalid signature' }, { status: 401 });
    }

    // 2. Parse do corpo
    let body;
    try {
      body = await req.json();
    } catch {
      return Response.json({ error: 'Invalid JSON body' }, { status: 400 });
    }

    // 3. Extrair dados do pagamento
    let orderId = '';
    let paymentStatus = '';
    let txid = '';
    let amount = 0;

    const isMercadoPago =
      (dataId || body.data?.id) && body.action && String(body.action).startsWith('payment');

    if (isMercadoPago) {
      // payment_id vem do query param data.id (padrão MP), com fallback para body.data.id
      const paymentId = dataId || String(body.data?.id || '');
      const accessToken = secrets.get('MERCADO_PAGO_ACCESS_TOKEN') || '';
      if (!accessToken) {
        return Response.json(
          { error: 'MERCADO_PAGO_ACCESS_TOKEN not configured' },
          { status: 500 }
        );
      }

      const mpResponse = await fetch(`https://api.mercadopago.com/v1/payments/${paymentId}`, {
        headers: { Authorization: `Bearer ${accessToken}` },
      });

      if (!mpResponse.ok) {
        return Response.json(
          {
            error: 'Failed to fetch payment from Mercado Pago',
            mpStatus: mpResponse.status,
          },
          { status: 502 }
        );
      }

      const payment = await mpResponse.json();
      paymentStatus = String(payment.status || '').toUpperCase();
      orderId = payment.external_reference || '';
      txid = String(paymentId);
      amount = Number(payment.transaction_amount) || 0;
    } else {
      // Formato genérico (fallback para outros PSPs)
      orderId =
        body.reference || body.order_id || body.external_reference || body.id || '';
      txid =
        body.txid ||
        body.endToEndId ||
        body.transaction_id ||
        (body.data && body.data.txid) ||
        '';
      amount = Number(
        body.amount ||
          body.valor ||
          body.value ||
          (body.data && (body.data.amount || body.data.valor)) ||
          0
      );
      paymentStatus = String(
        body.status ||
          body.situacao ||
          (body.data && (body.data.status || body.data.situacao)) ||
          ''
      ).toUpperCase();
    }

    // 4. Verificar se foi aprovado
    const PAID_STATUSES = [
      'APPROVED',
      'PAID',
      'CONFIRMED',
      'CONCLUIDO',
      'COMPLETED',
      'CONFIRMADA',
      'RECEIVED',
    ];
    const isPaid = PAID_STATUSES.includes(paymentStatus);

    if (!isPaid) {
      return Response.json({ ok: true, status: paymentStatus || 'unknown', confirmed: false });
    }

    if (!orderId) {
      return Response.json(
        { error: 'Missing order reference', confirmed: false },
        { status: 400 }
      );
    }

    // 5. Buscar e atualizar pedido (service role — webhook sem usuário autenticado)
    const base44 = createClientFromRequest(req);
    const svc = base44.asServiceRole;

    let order = null;
    try {
      order = await svc.entities.Order.get(orderId);
    } catch {
      // Se não encontrou por ID, tenta buscar por referência em pedidos PIX pendentes
      if (txid || orderId) {
        const pending = await svc.entities.Order.filter(
          { payment_method: 'pix', payment_status: 'pending' },
          '-created_date',
          50
        );
        order =
          pending.find(
            (o) =>
              (o.internal_notes || '').includes(orderId) ||
              (o.notes || '').includes(txid) ||
              (o.internal_notes || '').includes(txid)
          ) || null;
      }
    }

    if (!order) {
      return Response.json(
        { error: 'Order not found', reference: orderId, confirmed: false },
        { status: 404 }
      );
    }

    // 6. Atualizar apenas se ainda não foi pago (evita reprocessamento)
    if (order.payment_status === 'paid') {
      return Response.json({ ok: true, confirmed: true, alreadyPaid: true, orderId: order.id });
    }

    const now = new Date().toISOString();
    const timeline = [
      ...(order.timeline || []),
      {
        date: now,
        event: '✅ Pagamento PIX confirmado automaticamente' + (txid ? ` (ID MP: ${txid})` : ''),
        author: 'Sistema (Webhook Mercado Pago)',
      },
    ];

    const updateData: any = {
      payment_status: 'paid',
      timeline,
    };

    if (order.status === 'awaiting_payment') {
      updateData.status = 'confirmed';
    }

    if (order.financial_status === 'pending' || order.financial_status === 'not_sent') {
      updateData.financial_status = 'paid';
    }

    await svc.entities.Order.update(order.id, updateData);

    return Response.json({
      ok: true,
      confirmed: true,
      orderId: order.id,
      amount,
      txid,
    });
  } catch (error) {
    return Response.json({ error: error.message, confirmed: false }, { status: 500 });
  }
}