import { createClientFromRequest } from 'npm:@base44/sdk@0.8.44';

/**
 * Baixa automática de mercadoria — pedidos não finalizados em 7 dias.
 *
 * Executado diariamente por workflow agendado. Para cada pedido com mais de
 * 7 dias que ainda não teve o estoque baixado (sem movimentação de saída
 * vinculada), decrementa o estoque dos itens e registra no histórico.
 *
 * Retorna: { processed, results: [{ order_id, written_off | skipped | error }] }
 */
const SEVEN_DAYS_MS = 7 * 24 * 60 * 60 * 1000;
const FINALIZED_STATUSES = ['completed', 'invoiced', 'cancelled', 'refunded', 'returned'];

export default async function(req) {
  try {
    const base44 = createClientFromRequest(req);

    // Permite execução agendada (sem usuário) ou por admin/gerente.
    try {
      const user = await base44.auth.me();
      if (user && user.role !== 'admin' && user.role !== 'gerente') {
        return Response.json({ error: 'Forbidden' }, { status: 403 });
      }
    } catch { /* sem usuário — contexto agendado */ }

    const sr = base44.asServiceRole;
    const cutoff = new Date(Date.now() - SEVEN_DAYS_MS);

    const orders = await sr.entities.Order.list('-created_date', 500);
    const candidates = (orders || []).filter((o) => {
      if (!o.created_date) return false;
      if (new Date(o.created_date) > cutoff) return false;
      if (FINALIZED_STATUSES.includes(o.status)) return false;
      if (!o.items || !o.items.length) return false;
      return true;
    });

    const results = [];
    for (const order of candidates) {
      try {
        // Idempotência: pula pedidos já baixados
        const existing = await sr.entities.InventoryMovement.filter({ batch_id: order.id, type: 'exit' });
        if (existing && existing.length > 0) {
          results.push({ order_id: order.id, skipped: 'already_depleted' });
          continue;
        }

        const items = order.items || [];
        const productIds = [...new Set(items.map((i) => i.product_id).filter(Boolean))];
        const products = productIds.length
          ? await sr.entities.Product.filter({ id: { $in: productIds } })
          : [];
        const productMap = {};
        (products || []).forEach((p) => { productMap[p.id] = p; });

        const updates = [];
        const movements = [];
        for (const it of items) {
          const p = productMap[it.product_id];
          if (!p) continue;
          const prevQty = Number(p.stock_quantity) || 0;
          const newQty = prevQty - (Number(it.quantity) || 0);
          updates.push({ id: it.product_id, stock_quantity: newQty, in_stock: newQty > 0 });
          movements.push({
            product_id: it.product_id,
            product_name: it.product_name,
            type: 'exit',
            quantity: it.quantity,
            reason: 'baixa_automatica_7dias',
            responsible: 'Sistema',
            notes: `Baixa automática — Pedido #${order.id.substring(0, 8).toUpperCase()} não finalizado em 7 dias`,
            previous_quantity: prevQty,
            new_quantity: newQty,
            unit_cost: Number(p.cost) || 0,
            total_cost: (Number(p.cost) || 0) * it.quantity,
            batch_id: order.id,
          });
        }

        if (updates.length) await sr.entities.Product.bulkUpdate(updates);
        if (movements.length) await sr.entities.InventoryMovement.bulkCreate(movements);

        const now = new Date().toISOString();
        await sr.entities.Order.update(order.id, {
          timeline: [
            ...(order.timeline || []),
            { date: now, event: 'Baixa automática de mercadoria — pedido não finalizado em 7 dias', author: 'Sistema' },
          ],
        });

        results.push({ order_id: order.id, written_off: movements.length });
      } catch (e) {
        results.push({ order_id: order.id, error: String(e.message || e) });
      }
    }

    return Response.json({ processed: candidates.length, results });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
}