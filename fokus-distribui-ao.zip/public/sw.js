// Self-unregistering service worker.
// A previous cache-first SW was serving stale Vite dep chunks, causing
// mismatched React/React-DOM copies ("useState is null" crash).
// This SW unregisters itself and clears all caches on activation.
self.addEventListener('install', (event) => {
  self.skipWaiting();
});

self.addEventListener('activate', (event) => {
  event.waitUntil(
    (async () => {
      // Clear all Cache API caches
      if (self.caches) {
        const keys = await self.caches.keys();
        await Promise.all(keys.map((k) => self.caches.delete(k)));
      }
      // Unregister self
      await self.registration.unregister();
      // Take control of all clients so the unregistration takes effect immediately
      const clients = await self.clients.matchAll({ type: 'window' });
      clients.forEach((client) => client.navigate(client.url));
    })()
  );
});
